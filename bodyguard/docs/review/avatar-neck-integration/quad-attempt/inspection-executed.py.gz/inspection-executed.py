"""FR-A-02/03: read-only patch boundary, existing native professional asset."""

import json
import sys
from collections import Counter
from pathlib import Path

import bmesh
import bpy

result = []
for label in ("Male", "Female"):
    body = bpy.data.objects[f"BODYGUARD {label} sculpt WIP"]
    bm = bmesh.new()
    bm.from_mesh(body.data)
    bm.faces.ensure_lookup_table()
    height = max(v.co.z for v in bm.verts)
    faces = {
        f for f in bm.faces
        if (c := f.calc_center_median()).y > 0
        and abs(c.x) / height < 0.1 and 0.82 < c.z / height < 0.94
    }
    boundary = {e for f in faces for e in f.edges if sum(g in faces for g in e.link_faces) == 1}
    incidence = Counter(v for e in boundary for v in e.verts)
    unseen = set(boundary)
    loops = []
    while unseen:
        initial = unseen.pop()
        stack = [initial]
        group = {initial}
        while stack:
            edge = stack.pop()
            for v in edge.verts:
                for other in v.link_edges:
                    if other in unseen:
                        unseen.remove(other)
                        group.add(other)
                        stack.append(other)
        vertices = {v for e in group for v in e.verts}
        loops.append({
            "edges": len(group), "vertices": len(vertices),
            "degree": dict(Counter(incidence[v] for v in vertices)),
            "bbox_normalized": [[min(v.co[i] for v in vertices)/height,
                                  max(v.co[i] for v in vertices)/height] for i in range(3)],
        })
    result.append({"gender": label, "selected_faces": len(faces),
                   "boundary_loops": sorted(loops, key=lambda row: row["edges"], reverse=True),
                   "closed_before": all(e.is_manifold for e in bm.edges)})
    bm.free()
target = Path(sys.argv[sys.argv.index("--")+1])
assert not target.exists()
target.write_text(json.dumps(result, indent=2), encoding="utf-8")
print(json.dumps(result, indent=2))
