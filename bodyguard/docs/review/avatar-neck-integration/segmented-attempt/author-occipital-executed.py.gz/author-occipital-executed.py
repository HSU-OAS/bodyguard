"""FR-A-02/03/08: one aligned native patch on the existing professional body.

No generated primitive human, source overwrite, clinical target or public asset.
Blender --factory-startup --disable-autoexec -b candidate-unapproved.blend
  --python-exit-code 1 --python author_segmented_patch.py
  -- new.blend report.json segment input-sha256
"""

import hashlib
import json
import math
import sys
from collections import Counter
from pathlib import Path

import bmesh
import bpy
from mathutils.bvhtree import BVHTree

sys.path.insert(0, str(Path(__file__).resolve().parent))
from artist_snapshot_values import snapshot

HISTORY_ARRAYS = (
    "bodyguard_authoring_a123_original_ids",
    "bodyguard_a146_parent_ids",
    "bodyguard_a195_parent_ids",
)


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def region(point, height, limits, side):
    return (
        point.y > 0
        and abs(point.x) / height < 0.1
        and limits[0] < point.z / height < limits[1]
        and (side == 0 or point.x * side > 0)
    )


def boundary(faces):
    return {
        e
        for f in faces
        for e in f.edges
        if sum(other in faces for other in e.link_faces) == 1
    }


def canonical(values):
    values = tuple(values)
    first = values.index(min(values))
    return values[first:] + values[:first]


def geometry(body):
    mesh = bmesh.new()
    try:
        mesh.from_mesh(body.data)
        mesh.normal_update()
        return {
            "vertices": len(mesh.verts),
            "faces": len(mesh.faces),
            "nonmanifold": sum(not e.is_manifold for e in mesh.edges),
            "winding": sum(not e.is_contiguous for e in mesh.edges if e.is_manifold),
            "tiny_faces": sum(f.calc_area() < 1e-10 for f in mesh.faces),
        }
    finally:
        mesh.free()


def fixed_state(body, rig):
    state = snapshot(body, rig)
    for key in ("points", "skin", "faces", "point_ledger", "hands"):
        state.pop(key)
    for key in (*HISTORY_ARRAYS, "bodyguard_distal_hand_vertices"):
        state["properties"].pop(key)
    return state


args = sys.argv[sys.argv.index("--") + 1 :]
assert len(args) == 4
target, output = map(Path, args[:2])
segment, INPUT_SHA = args[2:]
assert segment in {"occipital", "neck", "shoulder-left", "shoulder-right"}
assert len(INPUT_SHA) == 64 and all(c in "0123456789abcdef" for c in INPUT_SHA)
ORIGIN = f"integration segmented original {segment}"
loaded = Path(bpy.data.filepath)
assert digest(loaded) == INPUT_SHA
assert not target.exists() and not output.exists()
assert target.resolve() != loaded.resolve()
report = {
    "input_sha256": INPUT_SHA,
    "blender": bpy.app.version_string,
    "passed": False,
    "appearance_approved": False,
    "clinical_or_camera_work": False,
    "segment": segment,
    "rows": [],
}
try:
    for gender in ("Male", "Female"):
        body = bpy.data.objects[f"BODYGUARD {gender} sculpt WIP"]
        rig = bpy.data.objects[f"BODYGUARD {gender} rig WIP"]
        before = snapshot(body, rig)
        fixed = fixed_state(body, rig)
        old_geometry = geometry(body)
        points = [v.co.copy() for v in body.data.vertices]
        history = {key: list(body[key]) for key in HISTORY_ARRAYS}
        assert all(len(values) == len(points) for values in history.values())
        assert body.data.shape_keys is None
        assert len(body.modifiers) == 1 and body.modifiers[0].type == "ARMATURE"
        assert all(pb.matrix_basis.is_identity for pb in rig.pose.bones)
        # Preserve the professional mesh as a private native weight-transfer source.
        # It is not saved or published and is removed before the final snapshot.
        skin_source = body.copy()
        skin_source.data = body.data.copy()
        skin_source.name = f"Private native skin source - {gender}"
        bpy.context.scene.collection.objects.link(skin_source)
        skin_source.hide_render = True
        mesh = bmesh.new()
        try:
            mesh.from_mesh(body.data)
            mesh.verts.ensure_lookup_table()
            mesh.faces.ensure_lookup_table()
            mesh.normal_update()
            assert body.data.attributes.get(ORIGIN) is None
            # Create CustomData before retaining element wrappers/boundary refs.
            origin = mesh.verts.layers.int.new(ORIGIN)
            mesh.verts.index_update()
            for vertex in mesh.verts:
                assert tuple(vertex.co) == before["points"][vertex.index]
                vertex[origin] = vertex.index
            height = max(v.co.z for v in mesh.verts)
            rig_to_body = body.matrix_world.inverted() @ rig.matrix_world
            lower = (rig_to_body @ rig.data.bones["neck01"].head_local).z / height
            upper = (rig_to_body @ rig.data.bones["neck02"].tail_local).z / height
            assert 0.82 < lower < upper < 0.94
            limits, side = {
                "occipital": ((upper, 0.94), 0),
                "neck": ((lower, upper), 0),
                "shoulder-left": ((0.82, lower), -1),
                "shoulder-right": ((0.82, lower), 1),
            }[segment]
            chosen = {
                f
                for f in mesh.faces
                if all(region(v.co, height, limits, side) for v in f.verts)
            }
            # Only shrink the selection at touching boundaries; never enter front.
            pruned = []
            for _ in range(8):
                borders = boundary(chosen)
                incidence = Counter(v for e in borders for v in e.verts)
                bad = {v for v, degree in incidence.items() if degree != 2}
                if not bad:
                    break
                remove = {f for f in chosen if any(v in bad for v in f.verts)}
                assert remove
                pruned.append(len(remove))
                chosen -= remove
            else:
                raise AssertionError("Patch boundary did not become regular")
            assert len(chosen) > 500
            borders = boundary(chosen)
            successor = {}
            for edge in borders:
                face = next(f for f in edge.link_faces if f in chosen)
                loop = next(loop for loop in face.loops if loop.edge == edge)
                assert loop.vert not in successor
                successor[loop.vert] = loop.link_loop_next.vert
            start = min(successor, key=lambda v: v.index)
            ordered = [start]
            next_point = successor[start]
            while next_point != start:
                assert next_point not in ordered, "Multiple/self-touching boundary"
                ordered.append(next_point)
                next_point = successor[next_point]
            assert len(ordered) == len(borders), "Patch has more than one opening"
            protected = {
                v.index
                for v in mesh.verts
                if any(f not in chosen for f in v.link_faces)
            }
            protected |= {v.index for v in ordered}
            assert all(i in protected for i in before["hands"])
            assert all(i in protected for i, p in enumerate(points) if p.y <= 0)
            outside_faces = Counter(
                (canonical(v.index for v in f.verts), f.material_index, f.smooth)
                for f in mesh.faces
                if f not in chosen
            )
            selected_ids = {f.index for f in chosen}
            body.data.calc_loop_triangles()
            triangles = [
                tuple(t.vertices)
                for t in body.data.loop_triangles
                if t.polygon_index in selected_ids
            ]
            tree = BVHTree.FromPolygons(points, triangles, all_triangles=True)
            # Faces-only removal followed by internal-only orphan removal.
            assert all(v.is_valid for v in ordered), (
                "Boundary refs invalid before removal"
            )
            bmesh.ops.delete(mesh, geom=list(chosen), context="FACES_ONLY")
            assert all(v.is_valid for v in ordered), (
                "Boundary lost in face-only removal"
            )
            unused = [
                v for v in mesh.verts if not v.link_faces and v[origin] not in protected
            ]
            bmesh.ops.delete(mesh, geom=unused, context="VERTS")
            assert all(v.is_valid for v in ordered), (
                "Boundary lost in internal vertex removal"
            )
            # Removing only faces can leave chords between retained boundary points.
            bmesh.ops.delete(
                mesh, geom=[e for e in mesh.edges if e.is_wire], context="EDGES_FACES"
            )
            assert all(v.is_valid for v in ordered)
            transition = None
            if len(ordered) % 2:
                # Odd boundaries mathematically require one triangular transition.
                candidates = []
                for i, v in enumerate(ordered):
                    first, last = ordered[i - 1], ordered[(i + 1) % len(ordered)]
                    turn = (v.co - first.co).cross(last.co - v.co)
                    if turn.y > 1e-9 and mesh.edges.get((first, last)) is None:
                        candidates.append((turn.y, i))
                assert candidates, "No convex native triangle transition"
                _, offset = max(candidates)
                triangle = (
                    ordered[offset - 1],
                    ordered[offset],
                    ordered[(offset + 1) % len(ordered)],
                )
                transition = mesh.faces.new(triangle)
                transition.smooth = True
                ordered.pop(offset)
            # Define the corner and column count geometrically, not by vertex ID.
            xmin, xmax = min(v.co.x for v in ordered), max(v.co.x for v in ordered)
            zmin, zmax = min(v.co.z for v in ordered), max(v.co.z for v in ordered)
            assert xmax > xmin and zmax > zmin
            corners = [
                min(
                    ordered,
                    key=lambda v, x=x, z=z: (
                        ((v.co.x - x) / (xmax - xmin)) ** 2
                        + ((v.co.z - z) / (zmax - zmin)) ** 2
                    ),
                )
                for x, z in ((xmin, zmin), (xmin, zmax), (xmax, zmax), (xmax, zmin))
            ]
            assert len(set(corners)) == 4, "Patch does not have four distinct corners"
            corner_id = corners[0][origin]
            corner_offset = ordered.index(corners[0])
            steps = [
                (ordered.index(v) - corner_offset) % len(ordered) for v in corners[1:]
            ]
            grid_span = min(steps)
            assert 2 <= grid_span < len(ordered) // 2 - 1
            corner_ids = [v[origin] for v in corners]
            mesh.to_mesh(body.data)
        finally:
            mesh.free()
        bpy.ops.object.select_all(action="DESELECT")
        body.select_set(True)
        bpy.context.view_layer.objects.active = body
        bpy.ops.object.mode_set(mode="EDIT")
        edit = bmesh.from_edit_mesh(body.data)
        for vertex in edit.verts:
            vertex.select = False
        for face in edit.faces:
            face.select = False
        for edge in edit.edges:
            edge.select_set(edge.is_boundary)
        origin = edit.verts.layers.int[ORIGIN]
        active_corner = next(v for v in edit.verts if v[origin] == corner_id)
        edit.select_history.clear()
        edit.select_history.add(active_corner)
        retained = set(edit.verts)
        bmesh.update_edit_mesh(body.data)
        report["last_grid"] = {
            "gender": gender,
            "span": grid_span,
            "boundary": len(ordered),
            "geometric_corner_ids": corner_ids,
        }
        result = bpy.ops.mesh.fill_grid(
            span=grid_span, offset=0, use_interp_simple=False
        )
        assert result == {"FINISHED"}, "Native Grid Fill did not construct a surface"
        new_points = [v for v in edit.verts if v not in retained]
        origin = edit.verts.layers.int[ORIGIN]
        assert new_points
        for vertex in new_points:
            vertex[origin] = -1
        transfer_distance = 0
        for vertex in new_points:
            surface, _, _, distance = tree.find_nearest(vertex.co)
            assert surface is not None
            transfer_distance = max(transfer_distance, distance)
            assert distance < 0.006, f"Native grid leaves source surface: {distance}m"
            for name in ("a239_source_point_id", "A123 authored parent point"):
                layer = edit.verts.layers.int.get(name)
                if layer is not None:
                    vertex[layer] = -1
        bmesh.ops.recalc_face_normals(edit, faces=list(edit.faces))
        edit.verts.index_update()
        new_point_ids = [vertex.index for vertex in new_points]
        bmesh.update_edit_mesh(body.data)
        bpy.ops.object.mode_set(mode="OBJECT")
        mask = body.vertex_groups.new(name="Quad patch native skin mask")
        mask_name = mask.name
        mask.add(new_point_ids, 1, "REPLACE")
        transfer = body.modifiers.new(
            "Professional surface skin transfer", "DATA_TRANSFER"
        )
        transfer.object = skin_source
        transfer.use_vert_data = True
        transfer.data_types_verts = {"VGROUP_WEIGHTS"}
        transfer.vert_mapping = "POLYINTERP_NEAREST"
        transfer.layers_vgroup_select_src = "ALL"
        transfer.layers_vgroup_select_dst = "NAME"
        transfer.mix_mode = "REPLACE"
        transfer.mix_factor = 1
        transfer.vertex_group = mask_name
        transfer.use_max_distance = True
        transfer.max_distance = 0.006
        transfer_name = transfer.name
        body.modifiers.move(len(body.modifiers) - 1, 0)
        assert bpy.ops.object.modifier_apply(modifier=transfer_name) == {"FINISHED"}
        body.vertex_groups.remove(body.vertex_groups[mask_name])
        # Native Data Transfer can add zero-valued memberships even under a
        # zero mask. Do not restore changed influences: verify every positive
        # value exactly first, then remove only newly added literal-zero entries.
        zero_entries_removed = 0
        cleanup = bmesh.new()
        try:
            cleanup.from_mesh(body.data)
            ids_layer = cleanup.verts.layers.int[ORIGIN]
            weights_layer = cleanup.verts.layers.deform.active
            assert weights_layer is not None
            for vertex in cleanup.verts:
                old_id = vertex[ids_layer]
                if old_id < 0:
                    continue
                original = dict(before["skin"][old_id])
                weights = vertex[weights_layer]
                assert {i: w for i, w in weights.items() if w != 0} == {
                    i: w for i, w in original.items() if w != 0
                }, f"Protected influence changed at original point {old_id}"
                for group_id, value in list(weights.items()):
                    if group_id not in original:
                        assert value == 0
                        del weights[group_id]
                        zero_entries_removed += 1
            cleanup.to_mesh(body.data)
        finally:
            cleanup.free()
        private_mesh = skin_source.data
        bpy.data.objects.remove(skin_source, do_unlink=True)
        assert private_mesh.users == 0
        bpy.data.meshes.remove(private_mesh)
        ids = [item.value for item in body.data.attributes[ORIGIN].data]
        remap = {old: new for new, old in enumerate(ids) if old >= 0}
        assert len(remap) == len([i for i in ids if i >= 0])
        assert set(remap) == protected
        current_outside = Counter()
        for face in body.data.polygons:
            values = tuple(ids[i] for i in face.vertices)
            if all(i >= 0 for i in values):
                key = (canonical(values), face.material_index, face.use_smooth)
                if key in outside_faces:
                    current_outside[key] += 1
        assert current_outside == outside_faces, "Original outside polygons changed"
        for vertex in body.data.vertices:
            old_id = ids[vertex.index]
            if old_id >= 0:
                assert tuple(vertex.co) == before["points"][old_id]
                raw = [(g.group, g.weight) for g in vertex.groups]
                if raw != before["skin"][old_id]:
                    report["protected_raw_skin_difference"] = {
                        "gender": gender,
                        "source_point": old_id,
                        "candidate_point": vertex.index,
                        "source": before["skin"][old_id],
                        "candidate": raw,
                        "positive_weights_exact": {
                            i: value for i, value in raw if value != 0
                        }
                        == {
                            i: value
                            for i, value in before["skin"][old_id]
                            if value != 0
                        },
                    }
                    raise AssertionError("Protected raw skin changed")
            assert all(math.isfinite(value) for value in vertex.co)
            assert abs(sum(g.weight for g in vertex.groups) - 1) < 0.01
        body["bodyguard_distal_hand_vertices"] = [remap[i] for i in before["hands"]]
        for key, values in history.items():
            body[key] = [values[i] if i >= 0 else -1 for i in ids]
        assert fixed_state(body, rig) == fixed, "Rest rig/material/scene changed"
        new_geometry = geometry(body)
        report["rows"].append(
            {
                "gender": gender,
                "boundary_vertices": len(ordered),
                "native_grid_span": grid_span,
                "boundary_pruned_faces": pruned,
                "original_patch_faces": len(selected_ids),
                "new_points": len(new_points),
                "odd_boundary_triangle_transition": transition is not None,
                "maximum_surface_binding_distance_m": transfer_distance,
                "surface_design": "aligned native quad interpolation; no smoothing or shrinkwrap",
                "geometric_corner_ids": corner_ids,
                "body_space_z_limits": limits,
                "skin_transfer": "native Data Transfer / POLYINTERP_NEAREST / new-point mask only",
                "new_literal_zero_memberships_removed": zero_entries_removed,
                "outside_coordinates_raw_skin_polygons_exact": True,
                "front_hands_preserved": True,
                "rest_rig_world_material_exact": True,
                "before": old_geometry,
                "after": new_geometry,
            }
        )
        assert new_geometry["nonmanifold"] == new_geometry["winding"] == 0
        assert new_geometry["tiny_faces"] <= old_geometry["tiny_faces"]
    bpy.context.preferences.filepaths.save_version = 0
    bpy.ops.wm.save_as_mainfile(filepath=str(target), check_existing=True)
    assert digest(loaded) == INPUT_SHA
    report["output_sha256"] = digest(target)
    report["passed"] = True
except Exception as error:
    report["failure"] = f"{type(error).__name__}: {error}"
    raise
finally:
    output.write_text(json.dumps(report, indent=2), encoding="utf-8")
