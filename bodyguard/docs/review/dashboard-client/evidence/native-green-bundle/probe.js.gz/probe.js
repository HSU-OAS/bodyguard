//#region src/api/auth.ts
var ApiError = class extends Error {
	status;
	retryAfter;
	constructor(status, retryAfter = 0) {
		super("계정 요청을 완료하지 못했습니다");
		this.status = status;
		this.retryAfter = retryAfter;
	}
};
async function request(path, signal, body, expected) {
	let headers;
	if (body !== void 0 || path === "/auth/logout") {
		const csrf = await request("/auth/csrf", signal);
		if (!csrf || typeof csrf !== "object" || !("csrf_token" in csrf) || typeof csrf.csrf_token !== "string") throw new ApiError(503);
		headers = {
			"Content-Type": "application/json",
			"X-CSRF-Token": csrf.csrf_token
		};
	}
	const response = await fetch(`/api/v1${path}`, {
		method: headers ? "POST" : "GET",
		credentials: "same-origin",
		cache: "no-store",
		signal: AbortSignal.any([signal, AbortSignal.timeout(15e3)]),
		headers,
		body: body === void 0 ? void 0 : JSON.stringify(body)
	});
	if (!response.ok) {
		const delay = Number(response.headers.get("Retry-After"));
		throw new ApiError(response.status, Number.isFinite(delay) ? Math.max(0, delay) : 0);
	}
	if (expected !== void 0 && response.status !== expected) throw new ApiError(503);
	return response.status === 204 || path === "/auth/resend" ? null : response.json();
}
//#endregion
//#region src/api/records.ts
function validDay(value) {
	if (!/^[0-9]{4}-[0-9]{2}-[0-9]{2}$/.test(value) || value.startsWith("0000")) return false;
	const parsed = /* @__PURE__ */ new Date(`${value}T00:00:00Z`);
	return Number.isFinite(parsed.getTime()) && parsed.toISOString().slice(0, 10) === value;
}
//#endregion
//#region src/api/dashboard.ts
var token = /^[a-zA-Z0-9][a-zA-Z0-9._+-]{0,63}$/;
var uuid = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/;
var names = [
	"neck",
	"shoulder",
	"trunk"
];
var durations = [
	"coverage_sec",
	"measured_sec",
	"unmeasurable_sec",
	"present_sec",
	"background_sec",
	"any_bad_sec"
];
var epsilon = 1e-6;
function object(value, fields) {
	if (!value || typeof value !== "object" || Array.isArray(value)) throw new ApiError(503);
	const row = value;
	if (Object.keys(row).length !== fields.length || !fields.every((key) => Object.hasOwn(row, key))) throw new ApiError(503);
	return row;
}
function finite(value) {
	return typeof value === "number" && Number.isFinite(value);
}
function nonnegative(value) {
	return finite(value) && value >= 0;
}
function count(value) {
	return nonnegative(value) && Number.isSafeInteger(value);
}
function utcDay(day) {
	return /* @__PURE__ */ new Date(`${day}T00:00:00Z`);
}
function dashboardTimezone(value) {
	if (!/^[A-Za-z][A-Za-z0-9._+-]*(?:\/[A-Za-z0-9._+-]+)*$/.test(value)) throw new ApiError(422);
	try {
		return new Intl.DateTimeFormat("en", { timeZone: value }).resolvedOptions().timeZone;
	} catch {
		throw new ApiError(422);
	}
}
function localFormatter(zone) {
	const formatter = new Intl.DateTimeFormat("en-CA", {
		timeZone: zone,
		year: "numeric",
		month: "2-digit",
		day: "2-digit",
		hour: "2-digit",
		minute: "2-digit",
		second: "2-digit",
		hourCycle: "h23"
	});
	return (value) => {
		const parts = formatter.formatToParts(value);
		const get = (type) => parts.find((part) => part.type === type)?.value ?? "";
		return `${get("year").padStart(4, "0")}-${get("month")}-${get("day")}T${get("hour")}:${get("minute")}:${get("second")}Z`;
	};
}
function boundary(day, formatted, latest = false) {
	if (!validDay(day)) throw new ApiError(422);
	const utc = utcDay(day).getTime();
	const matches = [
		-2,
		0,
		2
	].map((delta) => {
		const sample = utc + delta * 864e5;
		return utc - (Date.parse(formatted(sample)) - sample);
	}).sort((a, b) => a - b).filter((candidate) => formatted(candidate) === `${day}T00:00:00Z`);
	let result = latest ? matches.at(-1) : matches[0];
	if (result === void 0) {
		let low = Math.floor((utc - 1728e5) / 1e3);
		let high = Math.ceil((utc + 1728e5) / 1e3);
		while (low < high) {
			const mid = Math.floor((low + high) / 2);
			if (formatted(mid * 1e3).slice(0, 10) < day) low = mid + 1;
			else high = mid;
		}
		result = low * 1e3;
	}
	if (result === void 0 || !Number.isFinite(result) || new Date(result).getUTCFullYear() < 1) throw new ApiError(422);
	return result;
}
function range(query) {
	if (!validDay(query.date) || !["day", "week"].includes(query.period)) throw new ApiError(422);
	try {
		const formatted = localFormatter(query.timezone);
		if (formatted(boundary(query.date, formatted)).slice(0, 10) !== query.date) throw new ApiError(422);
		const startDay = utcDay(query.date);
		if (query.period === "week") startDay.setUTCDate(startDay.getUTCDate() - (startDay.getUTCDay() + 6) % 7);
		const endDay = new Date(startDay);
		endDay.setUTCDate(endDay.getUTCDate() + (query.period === "week" ? 7 : 1));
		const local_start = startDay.toISOString().slice(0, 10), local_end = endDay.toISOString().slice(0, 10);
		const start = boundary(local_start, formatted), end = boundary(local_end, formatted, true);
		if (start >= end) throw new ApiError(422);
		return {
			local_start,
			local_end,
			start,
			end
		};
	} catch {
		throw new ApiError(422);
	}
}
function dashboardQuery(params) {
	if (![
		"date",
		"period",
		"timezone"
	].every((key) => params.has(key)) || [...params.keys()].some((key) => ![
		"date",
		"period",
		"timezone"
	].includes(key) || params.getAll(key).length !== 1)) throw new ApiError(422);
	const query = {
		date: params.get("date") ?? "",
		period: params.get("period") ?? "",
		timezone: dashboardTimezone(params.get("timezone") ?? "")
	};
	if (query.period !== "day" && query.period !== "week") throw new ApiError(422);
	const result = {
		...query,
		period: query.period
	};
	range(result);
	return Object.freeze(result);
}
function instant(value) {
	if (typeof value !== "string" || !/^[0-9]{4}-[0-9]{2}-[0-9]{2}T([01]\d|2[0-3]):[0-5]\d:[0-5]\d(?:\.0{1,6})?(?:Z|\+00:00)$/.test(value) || !validDay(value.slice(0, 10)) || !Number.isFinite(Date.parse(value))) throw new ApiError(503);
	return Date.parse(value);
}
function parseDashboard(value, query) {
	const row = object(value, [
		"date",
		"period",
		"timezone",
		"local_start",
		"local_end",
		"start",
		"end",
		"totals",
		"metrics",
		"stretch",
		"notifications",
		"provenance"
	]);
	const expected = range(query);
	if (row.date !== query.date || row.period !== query.period || row.timezone !== query.timezone || row.local_start !== expected.local_start || row.local_end !== expected.local_end || instant(row.start) !== expected.start || instant(row.end) !== expected.end || row.notifications !== null || row.provenance !== "client-reported") throw new ApiError(503);
	const totals = object(row.totals, ["minutes", ...durations]);
	if (!count(totals.minutes) || totals.minutes > Math.ceil((expected.end - expected.start) / 6e4)) throw new ApiError(503);
	const tolerance = epsilon * totals.minutes;
	if (!durations.every((key) => nonnegative(totals[key]) && totals[key] <= totals.minutes * 60 + tolerance)) throw new ApiError(503);
	const t = totals;
	if (Math.abs(t.coverage_sec - t.measured_sec - t.unmeasurable_sec - t.background_sec) > tolerance || t.measured_sec > t.present_sec + tolerance || t.present_sec > t.coverage_sec - t.background_sec + tolerance || t.any_bad_sec > t.measured_sec + tolerance) throw new ApiError(503);
	if (!Array.isArray(row.metrics) || row.metrics.length > t.minutes * 3 || t.minutes > 0 && row.metrics.length < 3) throw new ApiError(503);
	const seen = /* @__PURE__ */ new Set();
	const partitions = /* @__PURE__ */ new Map();
	const metrics = row.metrics.map((value) => {
		const item = object(value, [
			"part",
			"baseline_id",
			"client_version",
			"method",
			"unit",
			"measured_sec",
			"bad_sec",
			"dev_mean",
			"bad_ratio"
		]);
		const ratio = nonnegative(item.bad_sec) && nonnegative(item.measured_sec) && item.measured_sec > 0 ? item.bad_sec / item.measured_sec : null;
		const precisionNull = ratio === null || !Number.isFinite(ratio) || ratio === 0 && nonnegative(item.bad_sec) && item.bad_sec > 0;
		if (!names.some((name) => name === item.part) || item.baseline_id !== null && (typeof item.baseline_id !== "string" || !uuid.test(item.baseline_id)) || ![
			"client_version",
			"method",
			"unit"
		].every((key) => typeof item[key] === "string" && token.test(item[key])) || !nonnegative(item.measured_sec) || item.measured_sec > t.measured_sec + tolerance || !nonnegative(item.bad_sec) || item.bad_sec > item.measured_sec + epsilon * t.minutes || item.dev_mean === null !== (item.measured_sec === 0) || item.bad_ratio === null !== precisionNull || item.dev_mean !== null && (!finite(item.dev_mean) || Math.abs(item.dev_mean) > Number.MAX_SAFE_INTEGER) || item.bad_ratio !== null && (!nonnegative(item.bad_ratio) || Math.abs(item.bad_ratio - (ratio ?? 0)) > epsilon * Math.max(1, ratio ?? 0)) || item.measured_sec === 0 && item.bad_sec !== 0 || item.baseline_id === null && item.part !== "shoulder" && item.measured_sec !== 0) throw new ApiError(503);
		const key = JSON.stringify([
			item.part,
			item.baseline_id,
			item.client_version,
			item.method,
			item.unit
		]);
		if (seen.has(key)) throw new ApiError(503);
		seen.add(key);
		const partition = JSON.stringify([item.baseline_id, item.client_version]);
		const parts = partitions.get(partition) ?? /* @__PURE__ */ new Set();
		parts.add(item.part);
		partitions.set(partition, parts);
		return Object.freeze(item);
	});
	const partTime = names.map((part) => metrics.filter((metric) => metric.part === part).reduce((sum, item) => sum + item.measured_sec, 0));
	const bad = metrics.reduce((sum, item) => sum + item.bad_sec, 0);
	const partBad = names.map((part) => metrics.filter((metric) => metric.part === part).reduce((sum, item) => sum + item.bad_sec, 0));
	if ([...partitions.values()].some((parts) => !names.every((part) => parts.has(part))) || t.minutes > 0 && !names.every((part) => metrics.some((metric) => metric.part === part)) || Math.max(...partBad) > t.any_bad_sec + tolerance || Math.max(...partTime) > t.measured_sec + tolerance || t.measured_sec > partTime.reduce((a, b) => a + b, 0) + tolerance || t.any_bad_sec > bad + tolerance || t.measured_sec - t.any_bad_sec > partTime.reduce((a, b) => a + b, 0) - bad + tolerance) throw new ApiError(503);
	const stretch = object(row.stretch, [
		"completed",
		"interrupted",
		"skipped"
	]);
	if (!Object.values(stretch).every(count)) throw new ApiError(503);
	return Object.freeze({
		...row,
		totals: Object.freeze(t),
		metrics: Object.freeze(metrics),
		stretch: Object.freeze(stretch)
	});
}
async function readDashboard(options, query) {
	const snapshot = dashboardQuery(new URLSearchParams(query));
	const { authority } = options;
	const owner = authority.user.id;
	const signal = AbortSignal.any([options.signal, AbortSignal.timeout(15e3)]);
	function check() {
		if (options.signal.aborted || options.readAuthority() !== authority || authority.user.id !== owner) throw new ApiError(401);
		if (signal.aborted) throw new ApiError(503);
	}
	async function sameAccount() {
		check();
		const user = await request("/me", signal, void 0, 200);
		check();
		if (!user || typeof user !== "object" || !("id" in user) || user.id !== owner) throw new ApiError(401);
	}
	try {
		await sameAccount();
		const csrf = object(await request("/auth/csrf", signal, void 0, 200), ["csrf_token"]);
		check();
		if (typeof csrf.csrf_token !== "string" || !/^[0-9a-f]{64}$/.test(csrf.csrf_token)) throw new ApiError(503);
		await sameAccount();
		const response = await fetch(`/api/v1/records/dashboard?${new URLSearchParams(snapshot)}`, {
			credentials: "same-origin",
			cache: "no-store",
			signal,
			headers: {
				"X-CSRF-Token": csrf.csrf_token,
				"X-Account-ID": owner
			}
		});
		check();
		if (response.status !== 200) throw new ApiError(response.status);
		const value = await response.json();
		check();
		const result = parseDashboard(value, snapshot);
		await sameAccount();
		check();
		return result;
	} catch (error) {
		check();
		throw error instanceof ApiError ? error : new ApiError(503);
	}
}
//#endregion
//#region e2e/fixtures/dashboardClientProbe.ts
function createDashboardProbe(authority) {
	let current = authority;
	const operation = new AbortController();
	return {
		async read(query) {
			try {
				const result = await readDashboard({
					authority,
					readAuthority: () => current,
					signal: operation.signal
				}, query);
				return {
					status: 200,
					minutes: result.totals.minutes,
					measured: result.totals.measured_sec,
					notificationsMissing: result.notifications === null,
					clientReported: result.provenance === "client-reported",
					partitions: result.metrics.length
				};
			} catch (error) {
				return { status: error instanceof ApiError ? error.status : -1 };
			}
		},
		replace() {
			current = {
				...authority,
				user: { ...authority.user }
			};
		},
		rebind(owner) {
			authority.user.id = owner;
		},
		close() {
			operation.abort();
		}
	};
}
//#endregion
export { createDashboardProbe };
