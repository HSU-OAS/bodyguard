# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: dashboardclient.spec.ts >> DQ-W05 controlled current-CSRF delivery after same-object owner mutation cannot rebind a read
- Location: e2e/dashboardclient.spec.ts:240:1

# Error details

```
Error: expect(received).toEqual(expected) // deep equality

- Expected  - 1
+ Received  + 6

  Object {
-   "status": 401,
+   "clientReported": true,
+   "measured": 30,
+   "minutes": 1,
+   "notificationsMissing": true,
+   "partitions": 3,
+   "status": 200,
  }
```

# Page snapshot

```yaml
- generic [ref=e3]:
  - button "본문으로 이동" [ref=e4]
  - banner [ref=e5]:
    - link "BODYGUARD 서비스 소개" [ref=e6] [cursor=pointer]:
      - /url: /
      - text: BODYGUARD.
    - navigation "계정 메뉴" [ref=e7]:
      - link "내 시작" [ref=e8] [cursor=pointer]:
        - /url: /start
      - link "자세 기록" [ref=e9] [cursor=pointer]:
        - /url: /posture-records
      - link "수행 기록" [ref=e10] [cursor=pointer]:
        - /url: /records
      - link "내 계정" [ref=e11] [cursor=pointer]:
        - /url: /account
  - main [ref=e12]:
    - generic [ref=e13]:
      - paragraph [ref=e14]: MY BODYGUARD
      - heading "내 몸을 위한 시작" [active] [level=1] [ref=e15]
      - paragraph [ref=e16]: dashboard-fce5d899-e0a2-4a09-95fb-9e5f744a056b@example.com
      - link "스트레칭 시작 경로 선택" [ref=e17] [cursor=pointer]:
        - /url: /explore
      - paragraph [ref=e18]:
        - link "내 수행 기록 확인" [ref=e19] [cursor=pointer]:
          - /url: /records
      - paragraph [ref=e20]:
        - link "내 자세 기록 확인" [ref=e21] [cursor=pointer]:
          - /url: /posture-records
      - paragraph [ref=e22]:
        - link "계정 관리" [ref=e23] [cursor=pointer]:
          - /url: /account
      - generic [ref=e24]:
        - heading "첫 코칭 흐름을 준비하고 있습니다" [level=2] [ref=e25]
        - paragraph [ref=e26]: 동작 검증과 남녀 3D 아바타 제작이 끝나면 스트레칭 선택과 코칭을 이곳에 연결합니다. 지금은 계정 기능을 사용할 수 있습니다.
        - paragraph [ref=e27]: 카메라는 켜지지 않았습니다.
      - button "로그아웃" [ref=e28] [cursor=pointer]
  - contentinfo [ref=e29]:
    - generic [ref=e30]: BODYGUARD
    - paragraph [ref=e31]: 일상을 위한 스트레칭과 자세 코칭 · 출시 준비 중
    - navigation "서비스 안내" [ref=e32]:
      - link "도움말" [ref=e33] [cursor=pointer]:
        - /url: /help
      - link "카메라·데이터 안내" [ref=e34] [cursor=pointer]:
        - /url: /data
```

# Test source

```ts
  167 |     },
  168 |   })
  169 |   try {
  170 |     await join(other)
  171 |     await seed(other, 1)
  172 |     await join(context)
  173 |     await seed(context, 2)
  174 |     const previous = new Date(anchor)
  175 |     previous.setUTCDate(previous.getUTCDate() - 1)
  176 |     await seed(context, 1, previous.toISOString().slice(0, 10))
  177 |     await prepare(page, context)
  178 |     expect(await read(page)).toEqual({
  179 |       status: 200,
  180 |       minutes: 2,
  181 |       measured: 60,
  182 |       notificationsMissing: true,
  183 |       clientReported: true,
  184 |       partitions: 3,
  185 |     })
  186 |     expect(await read(page, { ...query, period: 'week' })).toEqual({
  187 |       status: 200,
  188 |       minutes: 3,
  189 |       measured: 90,
  190 |       notificationsMissing: true,
  191 |       clientReported: true,
  192 |       partitions: 3,
  193 |     })
  194 |   } finally {
  195 |     await other.close()
  196 |   }
  197 | })
  198 | test('DQ-W02 actual old response after logout and account switch is discarded', async ({
  199 |   page,
  200 |   context,
  201 | }) => {
  202 |   await join(context)
  203 |   await seed(context, 2)
  204 |   await prepare(page, context)
  205 |   await page.route('**/api/v1/records/dashboard?**', async (route) => {
  206 |     const response = await route.fetch()
  207 |     expect(response.status()).toBe(200)
  208 |     expect((await post(context, '/auth/logout')).status()).toBe(204)
  209 |     await join(context)
  210 |     await seed(context, 1)
  211 |     await route.fulfill({ response })
  212 |   })
  213 |   await start(page)
  214 |   expect(await finish(page)).toEqual({ status: 401 })
  215 | })
  216 | test('DQ-W03 actual revoked cookie cannot read original owner', async ({ page, context }) => {
  217 |   await join(context)
  218 |   await seed(context, 1)
  219 |   await prepare(page, context)
  220 |   expect((await post(context, '/auth/logout')).status()).toBe(204)
  221 |   expect(await read(page)).toEqual({ status: 401 })
  222 | })
  223 | test('DQ-W04 real 200 with injected invalid provenance cannot become a result', async ({
  224 |   page,
  225 |   context,
  226 | }) => {
  227 |   await join(context)
  228 |   await seed(context, 1)
  229 |   await prepare(page, context)
  230 |   await page.route('**/api/v1/records/dashboard?**', async (route) => {
  231 |     const response = await route.fetch()
  232 |     expect(response.status()).toBe(200)
  233 |     await route.fulfill({
  234 |       response,
  235 |       json: { ...(await response.json()), provenance: 'server-verified' },
  236 |     })
  237 |   })
  238 |   expect(await read(page)).toEqual({ status: 503 })
  239 | })
  240 | test('DQ-W05 controlled current-CSRF delivery after same-object owner mutation cannot rebind a read', async ({
  241 |   page,
  242 |   context,
  243 | }) => {
  244 |   await join(context)
  245 |   await seed(context, 2)
  246 |   await prepare(page, context)
  247 |   let rebound = false
  248 |   await page.route('**/api/v1/auth/csrf', async (route) => {
  249 |     expect((await post(context, '/auth/logout')).status()).toBe(204)
  250 |     await join(context)
  251 |     await seed(context, 1)
  252 |     const user = await (await context.request.get('/api/v1/me')).json()
  253 |     await page.evaluate(
  254 |       (owner) => (window as unknown as PrivateWindow).dashboardProbe.rebind(owner),
  255 |       user.id,
  256 |     )
  257 |     rebound = true
  258 |     // TEST ONLY: deliver a real current-session CSRF response, not the old
  259 |     // intercepted request's Cookie snapshot (which the server correctly rejects).
  260 |     const response = await context.request.get('/api/v1/auth/csrf')
  261 |     expect(response.status()).toBe(200)
  262 |     await route.fulfill({ response })
  263 |   })
  264 |   await start(page)
  265 |   const result = await finish(page)
  266 |   expect(rebound).toBe(true)
> 267 |   expect(result).toEqual({ status: 401 })
      |                  ^ Error: expect(received).toEqual(expected) // deep equality
  268 | })
  269 | 
```