# 소유 확인 한계 기록

이 문서는 실행 뒤 작성한 메모이며 ps stdout가 아니다. 이번 Story가 mktemp/initdb/pg_ctl로 생성한 /private/tmp/bodyguard-auth-test.PMReFg의 data/socket는 UID501·0700이다. 중단 직전 postmaster.pid의 PID83173과 실제 SQL의 bodyguard_test 역할/DB, 동일 data_directory·빈 listen_addresses를 확인했다(owned-db-check.log).

추가 ps PID/UID 조회는 sandbox에서 operation not permitted로 미실행됐다. PID의 OS UID를 ps로 실측했다고 표시하지 않는다. 임시 생성 경로·SQL 소유 확인 후 해당 data_directory만 pg_ctl로 정상 중단했다. owned-stop/status.log는 실제 server stopped/no server running(exit3)이고 데이터와 원본 실패는 보존했다. 운영 DB·기존 서버·메일/cookie/token IPC는 증거에 넣지 않았다.
