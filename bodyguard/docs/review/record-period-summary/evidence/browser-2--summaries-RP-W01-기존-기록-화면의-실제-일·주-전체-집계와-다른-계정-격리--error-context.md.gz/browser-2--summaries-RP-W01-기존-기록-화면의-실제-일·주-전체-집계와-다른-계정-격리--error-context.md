# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: summaries.spec.ts >> RP-W01 기존 기록 화면의 실제 일·주 전체 집계와 다른 계정 격리
- Location: e2e/summaries.spec.ts:61:1

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByRole('region', { name: '일·주 기록 요약' }).getByText('21분 기록', { exact: true })
Expected: visible
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" getByRole('region', { name: '일·주 기록 요약' }).getByText('21분 기록', { exact: true }) with timeout 5000ms
  - waiting for getByRole('region', { name: '일·주 기록 요약' }).getByText('21분 기록', { exact: true })

```

```yaml
- button "본문으로 이동"
- banner:
  - link "BODYGUARD 서비스 소개":
    - /url: /
    - text: BODYGUARD
  - navigation "계정 메뉴":
    - link "내 시작":
      - /url: /start
    - link "자세 기록":
      - /url: /posture-records
    - link "수행 기록":
      - /url: /records
    - link "내 계정":
      - /url: /account
- main:
  - paragraph: MY POSTURE RECORDS
  - heading "내 자세 기록" [level=1]
  - paragraph: 저장된 자세 기록을 1분 단위로 확인합니다.
  - paragraph: 부위별 측정 시간과 평균 편차를 함께 살펴보세요. 기록된 값은 질환 진단이나 올바른 자세의 인증이 아닙니다. 자세 측정 연결은 준비 중이며, 저장된 기록이 없다면 빈 목록으로 표시됩니다.
  - form "자세 기록 기간":
    - text: 시작 날짜
    - textbox "시작 날짜": 2026-10-06
    - text: 종료 날짜
    - textbox "종료 날짜": 2026-10-12
    - button "기간 조회"
  - region "일·주 기록 요약":
    - heading "일·주 기록 요약" [level=2]
    - form "일·주 요약 조회":
      - text: 요약 날짜
      - textbox "요약 날짜": 2026-10-12
      - text: 요약 단위
      - combobox "요약 단위":
        - option "일" [selected]
        - option "주"
      - button "요약 조회"
    - paragraph: Asia/Seoul 기준 · 주는 월요일부터 일요일까지
    - heading "2026-10-12 ~ 2026-10-12" [level=3]
    - paragraph: 10분 기록 · 측정 300초
    - paragraph: 완료 0 · 중단 0 · 건너뜀 0
    - region "기간 요약 표 스크롤":
      - table "기간 전체의 부위별 저장 지표":
        - caption: 기간 전체의 부위별 저장 지표
        - rowgroup:
          - row "부위·방법 기준 평균 편차 측정 시간 이탈 비율":
            - columnheader "부위·방법"
            - columnheader "기준"
            - columnheader "평균 편차"
            - columnheader "측정 시간"
            - columnheader "이탈 비율"
        - rowgroup:
          - row "목 보정 전 — 0초 —":
            - rowheader "목":
              - text: 목
              - group: 측정 기준
            - cell "보정 전"
            - cell "—"
            - cell "0초"
            - cell "—"
          - row "어깨 보정 전 1.25 deg 300초 50%":
            - rowheader "어깨":
              - text: 어깨
              - group: 측정 기준
            - cell "보정 전"
            - cell "1.25 deg"
            - cell "300초"
            - cell "50%"
          - row "몸통 보정 전 — 0초 —":
            - rowheader "몸통":
              - text: 몸통
              - group: 측정 기준
            - cell "보정 전"
            - cell "—"
            - cell "0초"
            - cell "—"
    - paragraph: 저장된 기록의 집계입니다. ‘—’는 측정값 없음이며 정상 판정이 아닙니다. 다른 기준·방법·단위는 합치지 않습니다.
  - region "2026-10-06 ~ 2026-10-12 · 자세 기록":
    - heading "2026-10-06 ~ 2026-10-12 · 자세 기록" [level=2]
    - paragraph: 현재 페이지 20건 · 평균 편차는 기록된 단위로 표시합니다.
    - paragraph: 목록은 조회 시점마다 달라질 수 있습니다. 기록이 추가·삭제됐다면 기간을 다시 조회해 확인하세요.
    - region "분별 자세 기록 표":
      - table "분별 평균 편차와 전체 측정 시간":
        - caption: 분별 평균 편차와 전체 측정 시간
        - rowgroup:
          - row "기록 시각 목 평균 편차 어깨 평균 편차 몸통 평균 편차 측정 시간":
            - columnheader "기록 시각"
            - columnheader "목 평균 편차"
            - columnheader "어깨 평균 편차"
            - columnheader "몸통 평균 편차"
            - columnheader "측정 시간"
        - rowgroup:
          - row "2026. 10. 12. 오전 12:09 — 1.25 deg — 30초":
            - rowheader "2026. 10. 12. 오전 12:09":
              - button "2026. 10. 12. 오전 12:09"
            - cell "—"
            - cell "1.25 deg"
            - cell "—"
            - cell "30초"
          - row "2026. 10. 12. 오전 12:08 — 1.25 deg — 30초":
            - rowheader "2026. 10. 12. 오전 12:08":
              - button "2026. 10. 12. 오전 12:08"
            - cell "—"
            - cell "1.25 deg"
            - cell "—"
            - cell "30초"
          - row "2026. 10. 12. 오전 12:07 — 1.25 deg — 30초":
            - rowheader "2026. 10. 12. 오전 12:07":
              - button "2026. 10. 12. 오전 12:07"
            - cell "—"
            - cell "1.25 deg"
            - cell "—"
            - cell "30초"
          - row "2026. 10. 12. 오전 12:06 — 1.25 deg — 30초":
            - rowheader "2026. 10. 12. 오전 12:06":
              - button "2026. 10. 12. 오전 12:06"
            - cell "—"
            - cell "1.25 deg"
            - cell "—"
            - cell "30초"
          - row "2026. 10. 12. 오전 12:05 — 1.25 deg — 30초":
            - rowheader "2026. 10. 12. 오전 12:05":
              - button "2026. 10. 12. 오전 12:05"
            - cell "—"
            - cell "1.25 deg"
            - cell "—"
            - cell "30초"
          - row "2026. 10. 12. 오전 12:04 — 1.25 deg — 30초":
            - rowheader "2026. 10. 12. 오전 12:04":
              - button "2026. 10. 12. 오전 12:04"
            - cell "—"
            - cell "1.25 deg"
            - cell "—"
            - cell "30초"
          - row "2026. 10. 12. 오전 12:03 — 1.25 deg — 30초":
            - rowheader "2026. 10. 12. 오전 12:03":
              - button "2026. 10. 12. 오전 12:03"
            - cell "—"
            - cell "1.25 deg"
            - cell "—"
            - cell "30초"
          - row "2026. 10. 12. 오전 12:02 — 1.25 deg — 30초":
            - rowheader "2026. 10. 12. 오전 12:02":
              - button "2026. 10. 12. 오전 12:02"
            - cell "—"
            - cell "1.25 deg"
            - cell "—"
            - cell "30초"
          - row "2026. 10. 12. 오전 12:01 — 1.25 deg — 30초":
            - rowheader "2026. 10. 12. 오전 12:01":
              - button "2026. 10. 12. 오전 12:01"
            - cell "—"
            - cell "1.25 deg"
            - cell "—"
            - cell "30초"
          - row "2026. 10. 12. 오전 12:00 — 1.25 deg — 30초":
            - rowheader "2026. 10. 12. 오전 12:00":
              - button "2026. 10. 12. 오전 12:00"
            - cell "—"
            - cell "1.25 deg"
            - cell "—"
            - cell "30초"
          - row "2026. 10. 11. 오후 11:59 — 1.25 deg — 30초":
            - rowheader "2026. 10. 11. 오후 11:59":
              - button "2026. 10. 11. 오후 11:59"
            - cell "—"
            - cell "1.25 deg"
            - cell "—"
            - cell "30초"
          - row "2026. 10. 11. 오후 11:58 — 1.25 deg — 30초":
            - rowheader "2026. 10. 11. 오후 11:58":
              - button "2026. 10. 11. 오후 11:58"
            - cell "—"
            - cell "1.25 deg"
            - cell "—"
            - cell "30초"
          - row "2026. 10. 11. 오후 11:57 — 1.25 deg — 30초":
            - rowheader "2026. 10. 11. 오후 11:57":
              - button "2026. 10. 11. 오후 11:57"
            - cell "—"
            - cell "1.25 deg"
            - cell "—"
            - cell "30초"
          - row "2026. 10. 11. 오후 11:56 — 1.25 deg — 30초":
            - rowheader "2026. 10. 11. 오후 11:56":
              - button "2026. 10. 11. 오후 11:56"
            - cell "—"
            - cell "1.25 deg"
            - cell "—"
            - cell "30초"
          - row "2026. 10. 11. 오후 11:55 — 1.25 deg — 30초":
            - rowheader "2026. 10. 11. 오후 11:55":
              - button "2026. 10. 11. 오후 11:55"
            - cell "—"
            - cell "1.25 deg"
            - cell "—"
            - cell "30초"
          - row "2026. 10. 11. 오후 11:54 — 1.25 deg — 30초":
            - rowheader "2026. 10. 11. 오후 11:54":
              - button "2026. 10. 11. 오후 11:54"
            - cell "—"
            - cell "1.25 deg"
            - cell "—"
            - cell "30초"
          - row "2026. 10. 11. 오후 11:53 — 1.25 deg — 30초":
            - rowheader "2026. 10. 11. 오후 11:53":
              - button "2026. 10. 11. 오후 11:53"
            - cell "—"
            - cell "1.25 deg"
            - cell "—"
            - cell "30초"
          - row "2026. 10. 11. 오후 11:52 — 1.25 deg — 30초":
            - rowheader "2026. 10. 11. 오후 11:52":
              - button "2026. 10. 11. 오후 11:52"
            - cell "—"
            - cell "1.25 deg"
            - cell "—"
            - cell "30초"
          - row "2026. 10. 11. 오후 11:51 — 1.25 deg — 30초":
            - rowheader "2026. 10. 11. 오후 11:51":
              - button "2026. 10. 11. 오후 11:51"
            - cell "—"
            - cell "1.25 deg"
            - cell "—"
            - cell "30초"
          - row "2026. 10. 11. 오후 11:50 — 1.25 deg — 30초":
            - rowheader "2026. 10. 11. 오후 11:50":
              - button "2026. 10. 11. 오후 11:50"
            - cell "—"
            - cell "1.25 deg"
            - cell "—"
            - cell "30초"
    - button "이전 기록" [disabled]
    - text: 1페이지
    - button "다음 기록"
    - region "이 기간의 자세 기록 삭제":
      - heading "이 기간의 자세 기록 삭제" [level=2]
      - paragraph: 선택한 기간의 자세 기록만 삭제합니다. 먼저 대상 수를 확인하세요. 수행 기록과 개인 기준선은 삭제하지 않습니다.
      - button "삭제 대상 확인"
  - link "수행 기록 보기":
    - /url: /records
  - link "내 계정으로":
    - /url: /account
- contentinfo:
  - text: BODYGUARD
  - paragraph: 일상을 위한 스트레칭과 자세 코칭 · 출시 준비 중
  - navigation "서비스 안내":
    - link "도움말":
      - /url: /help
    - link "카메라·데이터 안내":
      - /url: /data
```

# Test source

```ts
  1   | // S4.15: actual production web/HTTP/SQL; synthetic accounts, aggregates, mail and faults.
  2   | import { randomUUID } from 'node:crypto'
  3   | import { readFileSync } from 'node:fs'
  4   | import { type BrowserContext, expect, type Page, test } from '@playwright/test'
  5   | 
  6   | const origin = 'http://localhost:4173'
  7   | const mailbox = process.env.BODYGUARD_TEST_MAILBOX
  8   | if (!mailbox?.startsWith('/private/tmp/bodyguard-browser-'))
  9   |   throw new Error('Owned mailbox required')
  10  | const password = '격리된 자세 기록 시험 비밀번호 12345'
  11  | async function post(context: BrowserContext, path: string, data?: unknown) {
  12  |   const csrf = await (await context.request.get('/api/v1/auth/csrf')).json()
  13  |   return context.request.post(`/api/v1${path}`, {
  14  |     headers: { Origin: origin, 'X-CSRF-Token': csrf.csrf_token },
  15  |     data,
  16  |   })
  17  | }
  18  | async function register(context: BrowserContext) {
  19  |   const email = `summaries-${randomUUID()}@example.com`
  20  |   const sent = await post(context, '/auth/signup', { email, password })
  21  |   expect(sent.status()).toBe(202)
  22  |   let code = ''
  23  |   await expect
  24  |     .poll(() => {
  25  |       code = JSON.parse(readFileSync(mailbox as string, 'utf8'))[email] ?? ''
  26  |       return code
  27  |     })
  28  |     .toMatch(/^\d{6}$/)
  29  |   expect(
  30  |     (
  31  |       await post(context, '/auth/verify', { challenge_id: (await sent.json()).challenge_id, code })
  32  |     ).status(),
  33  |   ).toBe(201)
  34  |   return email
  35  | }
  36  | async function seed(context: BrowserContext, count = 1, deviation = 1.25) {
  37  |   const top = new Date(Math.floor(Date.now() / 60000) * 60000 - 5 * 60000)
  38  |   const part = { method: 'Fixture+V1', unit: 'deg', measured_sec: 0, bad_sec: 0, dev_mean: null }
  39  |   const items = Array.from({ length: count }, (_, index) => ({
  40  |     minute_start: new Date(top.getTime() - index * 60000).toISOString(),
  41  |     baseline_id: null,
  42  |     client_version: 'Fixture+V1',
  43  |     coverage_sec: 60,
  44  |     measured_sec: 30,
  45  |     unmeasurable_sec: 20,
  46  |     present_sec: 45,
  47  |     background_sec: 10,
  48  |     any_bad_sec: 15,
  49  |     neck: part,
  50  |     trunk: part,
  51  |     shoulder: { ...part, measured_sec: 30, bad_sec: 15, dev_mean: deviation },
  52  |   }))
  53  |   expect((await post(context, '/summaries/batch', { items })).status()).toBe(201)
  54  |   return items
  55  | }
  56  | async function open(page: Page) {
  57  |   await page.goto('/posture-records')
  58  |   await expect(page.getByRole('button', { name: '삭제 대상 확인' })).toBeVisible()
  59  | }
  60  | 
  61  | test('RP-W01 기존 기록 화면의 실제 일·주 전체 집계와 다른 계정 격리', async ({
  62  |   page,
  63  |   context,
  64  |   browser,
  65  | }, info) => {
  66  |   test.setTimeout(90_000)
  67  |   await register(context)
  68  |   await seed(context, 21)
  69  |   const other = await browser.newContext()
  70  |   try {
  71  |     await register(other)
  72  |     await seed(other, 1, 8.75)
  73  |     let reads = 0
  74  |     page.on('request', (request) => {
  75  |       if (request.url().includes('/records/dashboard?')) reads++
  76  |     })
  77  |     await open(page)
  78  |     const list = page.getByRole('table', { name: '분별 평균 편차와 전체 측정 시간' })
  79  |     await expect(list.locator('tbody tr')).toHaveCount(20)
  80  |     const region = page.getByRole('region', { name: '일·주 기록 요약' })
  81  |     expect(reads).toBe(0)
  82  |     const query = region.getByRole('button', { name: '요약 조회' })
  83  |     await query.focus()
  84  |     await page.keyboard.press('Enter')
> 85  |     await expect(region.getByText('21분 기록', { exact: true })).toBeVisible()
      |                                                               ^ Error: expect(locator).toBeVisible() failed
  86  |     const table = region.getByRole('table', { name: '기간 전체의 부위별 저장 지표' })
  87  |     await expect(table.getByRole('row', { name: /어깨/ })).toContainText('50%')
  88  |     await expect(table.getByRole('row', { name: /목/ })).toContainText('—')
  89  |     expect(await table.textContent()).not.toContain('8.75')
  90  |     await expect(query).toBeFocused()
  91  |     await page.screenshot({ path: info.outputPath('record-period-day.png'), fullPage: true })
  92  |     await region.getByLabel('요약 단위').selectOption('week')
  93  |     await expect(region.getByText('21분 기록', { exact: true })).toHaveCount(0)
  94  |     expect(reads).toBe(1)
  95  |     await query.click()
  96  |     await expect(region.getByText('21분 기록', { exact: true })).toBeVisible()
  97  |     expect(reads).toBe(2)
  98  |     await page.setViewportSize({ width: 800, height: 900 })
  99  |     expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true)
  100 |     expect((await query.boundingBox())?.height).toBeGreaterThanOrEqual(44)
  101 |     await region.getByLabel('요약 단위').focus()
  102 |     await expect(region.getByLabel('요약 단위')).toHaveCSS('outline-width', '3px')
  103 |     await page.screenshot({ path: info.outputPath('record-period-notebook.png'), fullPage: true })
  104 |   } finally {
  105 |     await other.close()
  106 |   }
  107 | })
  108 | 
  109 | test('RP-W02 실제 집계 오류 재조회와 날짜 편집의 늦은 응답 격리', async ({
  110 |   page,
  111 |   context,
  112 | }, info) => {
  113 |   test.setTimeout(90_000)
  114 |   await register(context)
  115 |   await seed(context)
  116 |   await open(page)
  117 |   const region = page.getByRole('region', { name: '일·주 기록 요약' })
  118 |   await page.route('**/api/v1/records/dashboard?**', (route) =>
  119 |     route.fulfill({ status: 503, body: '' }),
  120 |   )
  121 |   await region.getByRole('button', { name: '요약 조회' }).click()
  122 |   await expect(region.getByRole('alert')).toContainText('다시 조회')
  123 |   await page.screenshot({ path: info.outputPath('record-period-error.png'), fullPage: true })
  124 |   await page.unroute('**/api/v1/records/dashboard?**')
  125 |   await region.getByRole('button', { name: '요약 다시 조회' }).click()
  126 |   await expect(region.getByText('1분 기록', { exact: true })).toBeVisible()
  127 |   let release!: () => void
  128 |   await page.route('**/api/v1/records/dashboard?**', async (route) => {
  129 |     const response = await route.fetch()
  130 |     await new Promise<void>((resolve) => {
  131 |       release = resolve
  132 |     })
  133 |     try {
  134 |       await route.fulfill({ response })
  135 |     } catch {
  136 |       /* The caller intentionally retired this request. */
  137 |     }
  138 |   })
  139 |   await region.getByRole('button', { name: '요약 조회' }).click()
  140 |   await expect.poll(() => typeof release).toBe('function')
  141 |   const unit = region.getByLabel('요약 단위')
  142 |   await unit.focus()
  143 |   await unit.selectOption('week')
  144 |   release()
  145 |   await expect(unit).toBeFocused()
  146 |   await expect(region.getByText('1분 기록', { exact: true })).toHaveCount(0)
  147 |   await page.unroute('**/api/v1/records/dashboard?**')
  148 |   await region.getByLabel('요약 날짜').fill('2000-01-01')
  149 |   await region.getByRole('button', { name: '요약 조회' }).click()
  150 |   await expect(region.getByText('이 기간에는 저장된 기록이 없습니다')).toBeVisible()
  151 |   await page.screenshot({ path: info.outputPath('record-period-empty.png'), fullPage: true })
  152 | })
  153 | 
  154 | test('RP-W03 실제 삭제 뒤 오래된 집계 폐기와 계정 오류 회수', async ({ page, context }) => {
  155 |   test.setTimeout(90_000)
  156 |   await register(context)
  157 |   await seed(context)
  158 |   await open(page)
  159 |   const region = page.getByRole('region', { name: '일·주 기록 요약' })
  160 |   await region.getByRole('button', { name: '요약 조회' }).click()
  161 |   await expect(region.getByText('1분 기록', { exact: true })).toBeVisible()
  162 |   await page.getByRole('button', { name: '삭제 대상 확인' }).click()
  163 |   await page.getByRole('button', { name: '확인한 자세 기록 삭제' }).click()
  164 |   await expect(page.getByText(/자세 기록 1건을 삭제했습니다/)).toBeVisible()
  165 |   await expect(region.getByText('1분 기록', { exact: true })).toHaveCount(0)
  166 |   await expect(region.getByRole('button', { name: '요약 조회' })).toBeDisabled()
  167 |   await page.getByRole('button', { name: '기간 다시 조회' }).click()
  168 |   await page
  169 |     .getByRole('region', { name: '일·주 기록 요약' })
  170 |     .getByRole('button', { name: '요약 조회' })
  171 |     .click()
  172 |   await expect(page.getByText('이 기간에는 저장된 기록이 없습니다')).toBeVisible()
  173 |   await page.route('**/api/v1/records/dashboard?**', (route) =>
  174 |     route.fulfill({ status: 403, body: '' }),
  175 |   )
  176 |   await page
  177 |     .getByRole('region', { name: '일·주 기록 요약' })
  178 |     .getByRole('button', { name: '요약 조회' })
  179 |     .click()
  180 |   await expect(page.getByRole('button', { name: '계정 다시 확인' })).toBeVisible()
  181 |   await expect(page.getByRole('button', { name: '삭제 대상 확인' })).toHaveCount(0)
  182 | })
  183 | function contrast(a: string, b: string) {
  184 |   function luminance(value: string) {
  185 |     const rgb = value
```