# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: summaries.spec.ts >> RP-W01 기존 기록 화면의 실제 일·주 전체 집계와 다른 계정 격리
- Location: e2e/summaries.spec.ts:72:1

# Error details

```
Error: expect(locator).toBeFocused() failed

Locator:  getByRole('region', { name: '일·주 기록 요약' }).getByRole('button', { name: '요약 조회' })
Expected: focused
Received: inactive
Timeout:  5000ms

Call log:
  - Expect "toBeFocused" getByRole('region', { name: '일·주 기록 요약' }).getByRole('button', { name: '요약 조회' }) with timeout 5000ms
  - waiting for getByRole('region', { name: '일·주 기록 요약' }).getByRole('button', { name: '요약 조회' })
    14 × locator resolved to <button type="submit" class="button secondary">요약 조회</button>
       - unexpected value "inactive"

```

```yaml
- button "요약 조회"
```

# Test source

```ts
  9   |   throw new Error('Owned mailbox required')
  10  | const password = '격리된 자세 기록 시험 비밀번호 12345'
  11  | async function post(context: BrowserContext, path: string, data?: unknown) {
  12  |   const csrf = await (await context.request.get('/api/v1/auth/csrf')).json()
  13  |   return context.request.post(`/api/v1${path}`, {
  14  |     headers: { Origin: origin, 'X-CSRF-Token': csrf.csrf_token },
  15  |     data,
  16  |   })
  17  | }
  18  | async function register(context: BrowserContext) {
  19  |   const email = `summaries-${randomUUID()}@example.com`
  20  |   const sent = await post(context, '/auth/signup', { email, password })
  21  |   expect(sent.status()).toBe(202)
  22  |   let code = ''
  23  |   await expect
  24  |     .poll(() => {
  25  |       code = JSON.parse(readFileSync(mailbox as string, 'utf8'))[email] ?? ''
  26  |       return code
  27  |     })
  28  |     .toMatch(/^\d{6}$/)
  29  |   expect(
  30  |     (
  31  |       await post(context, '/auth/verify', { challenge_id: (await sent.json()).challenge_id, code })
  32  |     ).status(),
  33  |   ).toBe(201)
  34  |   return email
  35  | }
  36  | async function seed(
  37  |   context: BrowserContext,
  38  |   count = 1,
  39  |   deviation = 1.25,
  40  |   top = new Date(Math.floor(Date.now() / 60000) * 60000 - 5 * 60000),
  41  | ) {
  42  |   const part = { method: 'Fixture+V1', unit: 'deg', measured_sec: 0, bad_sec: 0, dev_mean: null }
  43  |   const items = Array.from({ length: count }, (_, index) => ({
  44  |     minute_start: new Date(top.getTime() - index * 60000).toISOString(),
  45  |     baseline_id: null,
  46  |     client_version: 'Fixture+V1',
  47  |     coverage_sec: 60,
  48  |     measured_sec: 30,
  49  |     unmeasurable_sec: 20,
  50  |     present_sec: 45,
  51  |     background_sec: 10,
  52  |     any_bad_sec: 15,
  53  |     neck: part,
  54  |     trunk: part,
  55  |     shoulder: { ...part, measured_sec: 30, bad_sec: 15, dev_mean: deviation },
  56  |   }))
  57  |   expect((await post(context, '/summaries/batch', { items })).status()).toBe(201)
  58  |   return items
  59  | }
  60  | async function open(page: Page) {
  61  |   await page.goto('/posture-records')
  62  |   await expect(page.getByRole('button', { name: '삭제 대상 확인' })).toBeVisible()
  63  | }
  64  | async function selectSeedDay(page: Page, instant: string) {
  65  |   const day = await page.evaluate((value) => {
  66  |     const d = new Date(value)
  67  |     return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`
  68  |   }, instant)
  69  |   await page.getByRole('region', { name: '일·주 기록 요약' }).getByLabel('요약 날짜').fill(day)
  70  | }
  71  | 
  72  | test('RP-W01 기존 기록 화면의 실제 일·주 전체 집계와 다른 계정 격리', async ({
  73  |   page,
  74  |   context,
  75  |   browser,
  76  | }, info) => {
  77  |   test.setTimeout(90_000)
  78  |   // Yesterday at browser-local noon keeps all 21 minutes in one day/week even at midnight.
  79  |   const instant = await page.evaluate(() => {
  80  |     const d = new Date()
  81  |     d.setDate(d.getDate() - 1)
  82  |     d.setHours(12, 0, 0, 0)
  83  |     return d.toISOString()
  84  |   })
  85  |   await register(context)
  86  |   await seed(context, 21, 1.25, new Date(instant))
  87  |   const other = await browser.newContext()
  88  |   try {
  89  |     await register(other)
  90  |     await seed(other, 1, 8.75, new Date(instant))
  91  |     let reads = 0
  92  |     page.on('request', (request) => {
  93  |       if (request.url().includes('/records/dashboard?')) reads++
  94  |     })
  95  |     await open(page)
  96  |     await selectSeedDay(page, instant)
  97  |     const list = page.getByRole('table', { name: '분별 평균 편차와 전체 측정 시간' })
  98  |     await expect(list.locator('tbody tr')).toHaveCount(20)
  99  |     const region = page.getByRole('region', { name: '일·주 기록 요약' })
  100 |     expect(reads).toBe(0)
  101 |     const query = region.getByRole('button', { name: '요약 조회' })
  102 |     await query.focus()
  103 |     await page.keyboard.press('Enter')
  104 |     await expect(region.getByText('21분 기록', { exact: true })).toBeVisible()
  105 |     const table = region.getByRole('table', { name: '기간 전체의 부위별 저장 지표' })
  106 |     await expect(table.getByRole('row', { name: /어깨/ })).toContainText('50%')
  107 |     await expect(table.getByRole('row', { name: /목/ })).toContainText('—')
  108 |     expect(await table.textContent()).not.toContain('8.75')
> 109 |     await expect(query).toBeFocused()
      |                         ^ Error: expect(locator).toBeFocused() failed
  110 |     await page.screenshot({ path: info.outputPath('record-period-day.png'), fullPage: true })
  111 |     await region.getByLabel('요약 단위').selectOption('week')
  112 |     await expect(region.getByText('21분 기록', { exact: true })).toHaveCount(0)
  113 |     expect(reads).toBe(1)
  114 |     await query.click()
  115 |     await expect(region.getByText('21분 기록', { exact: true })).toBeVisible()
  116 |     expect(reads).toBe(2)
  117 |     await page.setViewportSize({ width: 800, height: 900 })
  118 |     expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true)
  119 |     expect((await query.boundingBox())?.height).toBeGreaterThanOrEqual(44)
  120 |     await region.getByLabel('요약 단위').focus()
  121 |     await expect(region.getByLabel('요약 단위')).toHaveCSS('outline-width', '3px')
  122 |     await page.screenshot({ path: info.outputPath('record-period-notebook.png'), fullPage: true })
  123 |   } finally {
  124 |     await other.close()
  125 |   }
  126 | })
  127 | 
  128 | test('RP-W02 실제 집계 오류 재조회와 날짜 편집의 늦은 응답 격리', async ({
  129 |   page,
  130 |   context,
  131 | }, info) => {
  132 |   test.setTimeout(90_000)
  133 |   await register(context)
  134 |   const items = await seed(context)
  135 |   await open(page)
  136 |   await selectSeedDay(page, items[0].minute_start)
  137 |   const region = page.getByRole('region', { name: '일·주 기록 요약' })
  138 |   await page.route('**/api/v1/records/dashboard?**', (route) =>
  139 |     route.fulfill({ status: 503, body: '' }),
  140 |   )
  141 |   await region.getByRole('button', { name: '요약 조회' }).click()
  142 |   await expect(region.getByRole('alert')).toContainText('다시 조회')
  143 |   await page.screenshot({ path: info.outputPath('record-period-error.png'), fullPage: true })
  144 |   await page.unroute('**/api/v1/records/dashboard?**')
  145 |   await region.getByRole('button', { name: '요약 다시 조회' }).click()
  146 |   await expect(region.getByText('1분 기록', { exact: true })).toBeVisible()
  147 |   let release!: () => void
  148 |   await page.route('**/api/v1/records/dashboard?**', async (route) => {
  149 |     const response = await route.fetch()
  150 |     await new Promise<void>((resolve) => {
  151 |       release = resolve
  152 |     })
  153 |     try {
  154 |       await route.fulfill({ response })
  155 |     } catch {
  156 |       /* The caller intentionally retired this request. */
  157 |     }
  158 |   })
  159 |   await region.getByRole('button', { name: '요약 조회' }).click()
  160 |   await expect.poll(() => typeof release).toBe('function')
  161 |   const unit = region.getByLabel('요약 단위')
  162 |   await unit.focus()
  163 |   await unit.selectOption('week')
  164 |   release()
  165 |   await expect(unit).toBeFocused()
  166 |   await expect(region.getByText('1분 기록', { exact: true })).toHaveCount(0)
  167 |   await page.unroute('**/api/v1/records/dashboard?**')
  168 |   await region.getByLabel('요약 날짜').fill('2000-01-01')
  169 |   await region.getByRole('button', { name: '요약 조회' }).click()
  170 |   await expect(region.getByText('이 기간에는 저장된 기록이 없습니다')).toBeVisible()
  171 |   await page.screenshot({ path: info.outputPath('record-period-empty.png'), fullPage: true })
  172 | })
  173 | 
  174 | test('RP-W03 실제 삭제 뒤 오래된 집계 폐기와 계정 오류 회수', async ({ page, context }) => {
  175 |   test.setTimeout(90_000)
  176 |   await register(context)
  177 |   const items = await seed(context)
  178 |   await open(page)
  179 |   await selectSeedDay(page, items[0].minute_start)
  180 |   const region = page.getByRole('region', { name: '일·주 기록 요약' })
  181 |   await region.getByRole('button', { name: '요약 조회' }).click()
  182 |   await expect(region.getByText('1분 기록', { exact: true })).toBeVisible()
  183 |   await page.getByRole('button', { name: '삭제 대상 확인' }).click()
  184 |   await page.getByRole('button', { name: '확인한 자세 기록 삭제' }).click()
  185 |   await expect(page.getByText(/자세 기록 1건을 삭제했습니다/)).toBeVisible()
  186 |   await expect(region.getByText('1분 기록', { exact: true })).toHaveCount(0)
  187 |   await expect(region.getByRole('button', { name: '요약 조회' })).toBeDisabled()
  188 |   await page.getByRole('button', { name: '기간 다시 조회' }).click()
  189 |   await page
  190 |     .getByRole('region', { name: '일·주 기록 요약' })
  191 |     .getByRole('button', { name: '요약 조회' })
  192 |     .click()
  193 |   await expect(page.getByText('이 기간에는 저장된 기록이 없습니다')).toBeVisible()
  194 |   await page.route('**/api/v1/records/dashboard?**', (route) =>
  195 |     route.fulfill({ status: 403, body: '' }),
  196 |   )
  197 |   await page
  198 |     .getByRole('region', { name: '일·주 기록 요약' })
  199 |     .getByRole('button', { name: '요약 조회' })
  200 |     .click()
  201 |   await expect(page.getByRole('button', { name: '계정 다시 확인' })).toBeVisible()
  202 |   await expect(page.getByRole('button', { name: '삭제 대상 확인' })).toHaveCount(0)
  203 | })
  204 | function contrast(a: string, b: string) {
  205 |   function luminance(value: string) {
  206 |     const rgb = value
  207 |       .match(/[\d.]+/g)
  208 |       ?.slice(0, 3)
  209 |       .map(Number)
```