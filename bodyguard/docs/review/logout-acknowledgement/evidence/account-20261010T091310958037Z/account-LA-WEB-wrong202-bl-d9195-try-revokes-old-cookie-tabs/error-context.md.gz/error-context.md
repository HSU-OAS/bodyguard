# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: account.spec.ts >> LA-WEB wrong202 blocks private UI; real204 retry revokes old cookie/tabs
- Location: e2e/account.spec.ts:262:3

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByRole('heading', { name: '로그아웃을 확인하지 못했습니다' })
Expected: visible
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" getByRole('heading', { name: '로그아웃을 확인하지 못했습니다' }) with timeout 5000ms
  - waiting for getByRole('heading', { name: '로그아웃을 확인하지 못했습니다' })

```

```yaml
- button "본문으로 이동"
- banner:
  - link "BODYGUARD 서비스 소개":
    - /url: /
    - text: BODYGUARD
  - navigation "계정 메뉴":
    - link "로그인":
      - /url: /login
- main:
  - complementary:
    - paragraph: BODYGUARD / MY ACCOUNT
    - heading "일상에 맞춘 몸 돌보기." [level=2]
    - paragraph: 노트북 웹캠 한 대로 시작하는 스트레칭과 자세 코칭.
    - text: "01"
    - paragraph: 카메라는 직접 시작할 때만 켜집니다. 원본 영상은 저장하거나 전송하지 않습니다.
    - paragraph: 현재 개발 중인 웹입니다. 출시 전 기능·안전·개인정보 검증을 진행하고 있습니다.
  - paragraph: 로그인
  - heading "다시 만나 반갑습니다" [level=1]
  - paragraph: 이메일로 내 계정에 로그인하세요.
  - button "Google로 계속하기" [disabled]
  - status: 구글 연결을 준비하고 있습니다. 이메일로 계속해 주세요.
  - paragraph: 또는 이메일로
  - text: 이메일
  - textbox "이메일"
  - text: 비밀번호
  - textbox "비밀번호"
  - button "비밀번호 표시": 표시
  - button "로그인"
  - paragraph:
    - text: 처음 오셨나요?
    - link "이메일로 가입":
      - /url: /signup?next=%2Fstart
  - paragraph:
    - link "비밀번호를 잊으셨나요?":
      - /url: /password/forgot
  - link "서비스 소개로 돌아가기":
    - /url: /
- contentinfo:
  - text: BODYGUARD
  - paragraph: 일상을 위한 스트레칭과 자세 코칭 · 출시 준비 중
  - navigation "서비스 안내":
    - link "도움말":
      - /url: /help
    - link "카메라·데이터 안내":
      - /url: /data
```

# Test source

```ts
  189 |   await page.screenshot({ path: info.outputPath('verification-error.png'), fullPage: true })
  190 |   await page.getByLabel('인증 코드', { exact: true }).fill(code)
  191 |   await page.getByRole('button', { name: '인증하고 시작하기' }).click()
  192 |   await expect(page).toHaveURL('/start')
  193 |   await expect(page.getByText(email, { exact: true })).toBeVisible()
  194 |   await page.screenshot({ path: info.outputPath('protected-start.png'), fullPage: true })
  195 |   expect(
  196 |     (await context.cookies()).find((cookie) => cookie.name === 'bodyguard_session')?.httpOnly,
  197 |   ).toBe(true)
  198 |   expect(await page.evaluate(() => [localStorage.length, sessionStorage.length])).toEqual([0, 0])
  199 |   await page.reload()
  200 |   await expect(page.getByText(email, { exact: true })).toBeVisible()
  201 |   await page.getByRole('button', { name: '로그아웃', exact: true }).click()
  202 |   await expect(page).toHaveURL(/\/login/)
  203 |   await page.goto('/login?next=https%3A%2F%2Fevil.example')
  204 |   await fillCredentials(page, email)
  205 |   await page.getByRole('button', { name: '로그인', exact: true }).click()
  206 |   await expect(page).toHaveURL('/start')
  207 |   await expect(page.getByText(email, { exact: true })).toBeVisible()
  208 | })
  209 | 
  210 | test('B-02 실제 가입 단계 새로고침은 인증 권한 없이 안전하게 재시작', async ({ page }) => {
  211 |   await page.goto('/signup')
  212 |   await fillCredentials(page, address())
  213 |   await page.getByRole('button', { name: '인증 코드 받기', exact: true }).click()
  214 |   await expect(page.getByRole('heading', { name: '이메일을 확인해 주세요' })).toBeVisible()
  215 |   await page.reload()
  216 |   await expect(page.getByRole('heading', { name: '나를 위한 움직임의 시작' })).toBeVisible()
  217 |   await expect(page.getByLabel('이메일', { exact: true })).toHaveValue('')
  218 |   await page.goto('/start')
  219 |   await expect(page).toHaveURL(/\/login/)
  220 | })
  221 | 
  222 | test('B-02 서버 연결 실패를 게스트로 표시하지 않고 실제 API로 재시도', async ({ page }, info) => {
  223 |   await page.route('**/api/v1/me', (route) => route.abort('failed'))
  224 |   await page.goto('/start')
  225 |   await expect(page.getByRole('heading', { name: '연결을 확인해 주세요' })).toBeVisible()
  226 |   await expect(page.getByRole('heading', { name: '내 몸을 위한 시작' })).toHaveCount(0)
  227 |   await page.screenshot({ path: info.outputPath('connection-error.png'), fullPage: true })
  228 |   await page.unroute('**/api/v1/me')
  229 |   await page.getByRole('button', { name: '다시 확인' }).click()
  230 |   await expect(page).toHaveURL(/\/login/)
  231 | })
  232 | 
  233 | test('B-03 실패한 로그아웃은 개인 화면 차단·재시도·다른 탭 폐기', async ({ page, context }) => {
  234 |   const email = address()
  235 |   await join(page, email)
  236 |   const other = await context.newPage()
  237 |   await other.goto('/start')
  238 |   await expect(other.getByText(email, { exact: true })).toBeVisible()
  239 |   await page.route('**/api/v1/auth/logout', (route) => route.abort('failed'))
  240 |   await page.getByRole('button', { name: '로그아웃', exact: true }).click()
  241 |   await expect(page.getByRole('heading', { name: '로그아웃을 확인하지 못했습니다' })).toBeVisible()
  242 |   await expect(page.getByText(email, { exact: true })).toHaveCount(0)
  243 |   await page.unroute('**/api/v1/auth/logout')
  244 |   await page.getByRole('button', { name: '로그아웃 다시 시도' }).click()
  245 |   await expect(page).toHaveURL(/\/login/)
  246 |   await expect(other).toHaveURL(/\/login/)
  247 |   await expect(other.getByText(email, { exact: true })).toHaveCount(0)
  248 |   await other.close()
  249 | })
  250 | 
  251 | test('B-01/03 삭제된 실제 세션 쿠키는 보호 화면을 열지 않는다', async ({ page, context }) => {
  252 |   const email = address()
  253 |   await join(page, email)
  254 |   await context.clearCookies()
  255 |   await page.evaluate(() => window.dispatchEvent(new Event('focus')))
  256 |   await expect(page).toHaveURL(/\/login/)
  257 |   await expect(page.getByText(email, { exact: true })).toHaveCount(0)
  258 | })
  259 | 
  260 | // FR-U-04: wrong wire is injected; real account/old cookie/retry API remain native.
  261 | for (const status of [200, 202]) {
  262 |   test(`LA-WEB wrong${status} blocks private UI; real204 retry revokes old cookie/tabs`, async ({
  263 |     page,
  264 |     context,
  265 |   }, info) => {
  266 |     const unexpected: string[] = [],
  267 |       errors: string[] = []
  268 |     context.on('request', (request) => {
  269 |       const url = new URL(request.url())
  270 |       if (url.origin !== 'http://localhost:4173' || /\.glb|\.task|\.wasm|mediapipe/i.test(url.pathname))
  271 |         unexpected.push(url.origin + url.pathname)
  272 |     })
  273 |     page.on('pageerror', (error) => errors.push(error.message))
  274 |     const email = address()
  275 |     await join(page, email)
  276 |     const other = await context.newPage()
  277 |     try {
  278 |       await other.goto('/start')
  279 |       await expect(other.getByText(email, { exact: true })).toBeVisible()
  280 |       await page.bringToFront()
  281 |       const old = (await context.cookies()).find((cookie) => cookie.name === 'bodyguard_session')
  282 |       expect(old?.httpOnly).toBe(true)
  283 |       let intercepted = 0
  284 |       await page.route('**/api/v1/auth/logout', (route) => {
  285 |         intercepted++
  286 |         return route.fulfill({ status, json: { logged_out: true } })
  287 |       })
  288 |       await page.getByRole('button', { name: '로그아웃', exact: true }).click()
> 289 |       await expect(page.getByRole('heading', { name: '로그아웃을 확인하지 못했습니다' })).toBeVisible()
      |                                                                             ^ Error: expect(locator).toBeVisible() failed
  290 |       expect(intercepted).toBe(1)
  291 |       await expect(page.getByText(email, { exact: true })).toHaveCount(0)
  292 |       expect((await context.request.get('/api/v1/me')).status()).toBe(200)
  293 |       await page.evaluate(() => window.dispatchEvent(new Event('focus')))
  294 |       await page.evaluate(() => {
  295 |         const channel = new BroadcastChannel('bodyguard-account-change')
  296 |         channel.postMessage('changed')
  297 |         channel.close()
  298 |       })
  299 |       await expect(page.getByRole('heading', { name: '로그아웃을 확인하지 못했습니다' })).toBeVisible()
  300 |       await expect(page.getByText(email, { exact: true })).toHaveCount(0)
  301 |       await page.screenshot({ path: info.outputPath(`wrong-${status}-blocked.png`), fullPage: true })
  302 |       await page.unroute('**/api/v1/auth/logout')
  303 |       const actual = page.waitForResponse((response) =>
  304 |         new URL(response.url()).pathname === '/api/v1/auth/logout' && response.request().method() === 'POST',
  305 |       )
  306 |       await page.getByRole('button', { name: '로그아웃 다시 시도' }).click()
  307 |       expect((await actual).status()).toBe(204)
  308 |       await expect(page).toHaveURL(/\/login/)
  309 |       await expect(other).toHaveURL(/\/login/)
  310 |       await expect(other.getByText(email, { exact: true })).toHaveCount(0)
  311 |       expect((await context.request.get('/api/v1/me')).status()).toBe(401)
  312 |       expect(old).toBeDefined()
  313 |       const replay = await context.request.get('/api/v1/me', {
  314 |         headers: { Cookie: `bodyguard_session=${old?.value}` },
  315 |       })
  316 |       expect(replay.status()).toBe(401)
  317 |       const storage = await page.evaluate(() => [localStorage.length, sessionStorage.length])
  318 |       await info.attach('logout-boundary.json', {
  319 |         body: Buffer.from(JSON.stringify({
  320 |           statusInjected: status, intercepted, actualRetry204: true, nativeSessionBefore200: true,
  321 |           oldCookieAfter401: true, actualWebHttpSql: true, actualProvider: false, actualCamera: false,
  322 |           cameraCalls, unexpected, errors, storage, browserVersion: context.browser()?.version(),
  323 |         })),
  324 |         contentType: 'application/json',
  325 |       })
  326 |       expect(unexpected).toEqual([])
  327 |       expect(errors).toEqual([])
  328 |       expect(storage).toEqual([0, 0])
  329 |     } finally {
  330 |       await other.close()
  331 |     }
  332 |   })
  333 | }
  334 | 
```