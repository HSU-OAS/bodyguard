// Validate this Story's actual reports before preserving immutable evidence copies.
import fs from 'node:fs'
import path from 'node:path'
import crypto from 'node:crypto'
import { gzipSync } from 'node:zlib'
import { execFileSync } from 'node:child_process'
import assert from 'node:assert/strict'
const root = process.cwd()
assert(root.endsWith('/BODYGUARD-dashboard-client/bodyguard'))
const proof = '/private/tmp/bodyguard-record-baseline.KBEZMbms'
const out = path.join(root, 'docs/review/record-baseline-detail')
const read = name => fs.readFileSync(name)
const json = name => JSON.parse(read(name))
const hash = bytes => crypto.createHash('sha256').update(bytes).digest('hex')
const owned = json(proof + '/results.json')
assert.equal(owned.stopped, true)
assert(owned.results.every(r => r.code === 0 && r.signal === null))
assert.deepEqual(owned.originalSources, owned.finalSources)
for (const s of owned.finalSources) assert.equal(hash(read(path.join(root, s.name))), s.sha256, s.name)
assert(!fs.existsSync('/private/tmp/bodyguard-auth-test.aJYJJu4O/data/postmaster.pid'))
const unit = json(proof + '/frontend-final.json')
assert.deepEqual([unit.numTotalTests, unit.numPassedTests, unit.numFailedTests, unit.numPendingTests], [1844,1844,0,0])
assert(unit.testResults.every(r => r.status === 'passed' && r.assertionResults.every(a => a.status === 'passed')))
assert.equal(unit.testResults.find(r => r.name.endsWith('MinuteSummaryPage.baseline.test.tsx')).assertionResults.length, 17)
const red = json(proof + '/unit-red.json'), compatibility = json(proof + '/compatibility-red.json')
assert.deepEqual([red.numPassedTests, red.numFailedTests], [1,11])
assert.deepEqual([compatibility.numPassedTests, compatibility.numFailedTests], [13,2])
const api = JSON.parse(execFileSync(root + '/backend/.venv/bin/python', ['-c',
  'import sys,json,xml.etree.ElementTree as E; r=E.parse(sys.argv[1]).getroot(); s=r.find("testsuite"); c=r.findall(".//testcase"); assert len(c)==150 and all(not list(x) for x in c); print(json.dumps(s.attrib))',
  proof + '/backend.xml'], {encoding:'utf8'}))
assert.deepEqual([api.tests, api.failures, api.errors, api.skipped], ['150','0','0','0'])
const nativePath = root + '/frontend/test-results/recordbaseline-20261011T122736535925Z/report.json'
const oldPath = root + '/frontend/test-results/summaries-20261011T122753255491Z/report.json'
const specs = r => [...(r.specs ?? []), ...(r.suites ?? []).flatMap(specs)]
function browser(file, count, attachment) {
  const report = json(file)
  assert.deepEqual([report.stats.expected, report.stats.unexpected, report.stats.skipped, report.stats.flaky], [count,0,0,0])
  const cases = report.suites.flatMap(specs)
  assert.equal(cases.length, count)
  const flows = cases.map(s => {
    assert.equal(s.ok, true)
    assert.equal(s.tests.length, 1)
    const t = s.tests[0]
    assert.equal(t.status, 'expected'); assert.equal(t.expectedStatus, 'passed')
    assert.equal(t.results.length, 1)
    const r = t.results[0]
    assert.equal(r.status, 'passed'); assert.equal(r.retry, 0); assert.deepEqual(r.errors, [])
    const b = JSON.parse(Buffer.from(r.attachments.find(a => a.name === attachment).body, 'base64'))
    assert.equal(b.camera, 0); assert.deepEqual(b.storage, [0,0]); assert.deepEqual(b.errors, [])
    if (attachment === 'record-baseline-boundaries.json') {
      assert.equal(b.external, 0)
      assert(b.baselineRequests.every(x => x.method === 'GET' && !x.path.endsWith('/active')))
    } else assert.deepEqual(b.unexpected, [])
    return {title:s.title, boundaries:b}
  })
  return {report, summary:{stats:report.stats, flows}}
}
const native = browser(nativePath, 3, 'record-baseline-boundaries.json')
assert.deepEqual(native.summary.flows.map(f => f.boundaries.baselineRequests.length), [1,2,0])
const regression = browser(oldPath, 4, 'summary-boundaries.json')
assert.equal(read(proof + '/sql-census.log').toString().trim(), '6|3|3|3')
const assets = root + '/frontend/dist/assets'
const production = fs.readdirSync(assets).filter(n => /\.(js|css)$/.test(n)).sort().map(file => {
  const bytes = read(path.join(assets, file))
  return {file, bytes:bytes.length, sha256:hash(bytes)}
})
assert.equal(production.length, 2)

fs.mkdirSync(out, {recursive:true})
const artifacts = []
function save(file, source, bytes, compressed) {
  const stored = compressed ? gzipSync(bytes) : bytes
  const target = path.join(out, file)
  fs.writeFileSync(target, stored, {flag:'wx'})
  assert.equal(hash(read(target)), hash(stored))
  artifacts.push({file, source, bytes:bytes.length, sha256:hash(bytes), storedBytes:stored.length, storedSha256:hash(stored), gzip:compressed})
}
const raw = ['verify-owned.mjs','collect-final.mjs','sources-before.json','results.json','initdb.log','pg-start.log','create-test-db.log','sql-identity.log','backend-related.log','backend.xml','browser-recordbaseline.log','browser-summaries.log','sql-census.log','pg-stop.log','frontend-final.json','frontend-final.log','unit-red.json','unit-red.log','unit-first.json','unit-first.log','compatibility-red.json','compatibility-red.log','types-corrected.log','types-final.log','biome-final.log','ruff-final.log','backend-format-final.log','guard-final.log']
for (const name of raw) save(name + '.gz', proof + '/' + name, read(proof + '/' + name), true)
save('chrome-final.json.gz', nativePath, read(nativePath), true)
save('chrome-regression.json.gz', oldPath, read(oldPath), true)
for (const s of native.report.suites.flatMap(specs)) for (const t of s.tests) for (const a of t.results[0].attachments) {
  if (a.contentType === 'image/png') save(a.name, nativePath + '#' + a.name, Buffer.from(a.body,'base64'), false)
}
const summary = {at:new Date().toISOString(), scope:'existing posture-record detail baseline read only, not calibration/clinical verification/stage completion', sources:owned.finalSources, frontend:{files:unit.testResults.length, tests:1844, featureTests:17}, backendRelated:{tests:150, failures:0, errors:0, skipped:0}, actualProductionChrome:native.summary, actualRecordRegression:regression.summary, controlledRed:{initial:{passed:1,failed:11}, compatibility:{passed:13,failed:2}}, sqlBaselinesActiveMinutesOwners:[6,3,3,3], ownedDatabaseStopped:true, ownedPid:owned.ownedPid, production, productionChangedForActualFeature:true, remoteGate:'pending, not asserted here'}
fs.writeFileSync(out + '/final-verification.json', JSON.stringify(summary,null,2)+'\n',{flag:'wx'})
fs.writeFileSync(out + '/manifest.json', JSON.stringify({artifacts},null,2)+'\n',{flag:'wx'})
console.log(JSON.stringify({sourceHashes:owned.finalSources.length, frontend:summary.frontend, backendRelated:summary.backendRelated, actualProductionChrome:native.summary.stats, actualRecordRegression:regression.summary.stats, artifacts:artifacts.length, databaseStopped:true, production}))
