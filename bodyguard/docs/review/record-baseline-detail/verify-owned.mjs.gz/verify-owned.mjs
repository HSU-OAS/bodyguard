// FR-M-03/FR-U-04/NFR-08: only a newly allocated, isolated local SQL proof.
import fs from 'node:fs'
import path from 'node:path'
import crypto from 'node:crypto'
import { spawn, spawnSync } from 'node:child_process'
import assert from 'node:assert/strict'

const [wd, dbRoot, proofRoot] = process.argv.slice(2)
assert(/^\/private\/tmp\/bodyguard-auth-test\.[A-Za-z0-9]+$/.test(dbRoot))
assert(/^\/private\/tmp\/bodyguard-record-baseline\.[A-Za-z0-9]+$/.test(proofRoot))
const pg = path.dirname(fs.realpathSync('/opt/homebrew/bin/pg_ctl'))
const backend = path.join(wd, 'bodyguard/backend')
const socket = path.join(dbRoot, 'socket'), data = path.join(dbRoot, 'data')
fs.mkdirSync(socket, { mode: 0o700 })
const roots = [dbRoot, socket].map(p => [p, fs.statSync(p).dev, fs.statSync(p).ino])
let pid
const env = { ...process.env, PGPASSFILE: path.join(dbRoot, 'empty.pgpass'),
  BODYGUARD_TEST_DATABASE_URL: `postgresql+psycopg://bodyguard_test@/bodyguard_test?host=${socket}` }
fs.writeFileSync(env.PGPASSFILE, '', { mode: 0o600, flag: 'wx' })
function guard() {
  for (const [p, dev, ino] of roots) {
    const s = fs.lstatSync(p)
    assert(s.isDirectory() && !s.isSymbolicLink() && s.dev === dev && s.ino === ino &&
      s.uid === process.getuid() && (s.mode & 0o077) === 0 && fs.realpathSync(p) === p)
  }
}
const results = []
async function run(label, binary, args, cwd = backend) {
  const file = path.join(proofRoot, label + '.log')
  const log = fs.openSync(file, 'wx', 0o600)
  console.log(label + ': started')
  try {
    const result = await new Promise((resolve, reject) => {
      const child = spawn(binary, args, { cwd, env, stdio: ['ignore', log, log] })
      child.once('error', reject)
      child.once('exit', (code, signal) => resolve({ code, signal }))
    })
    results.push({ label, ...result })
    console.log(label + ': ' + JSON.stringify(result))
    assert(result.code === 0, label + ' failed; raw output preserved')
  } finally { fs.closeSync(log) }
}
const sources = [
  'backend/tests/run_browser.py', 'backend/app/main.py', 'backend/app/baselines.py',
  'backend/app/summaries.py', 'frontend/src/pages/RecordBaseline.tsx',
  'frontend/src/pages/MinuteSummaryPage.tsx', 'frontend/src/pages/MinuteSummaryPage.css',
  'frontend/src/pages/MinuteSummaryPage.baseline.test.tsx',
  'frontend/src/api/baselines.ts', 'frontend/src/api/minuteSummaries.ts',
  'frontend/src/api/auth.ts', 'frontend/src/auth.tsx', 'frontend/src/App.tsx',
  'frontend/e2e/recordbaseline.spec.ts', 'frontend/playwright.account.config.ts',
  'frontend/scripts/check-selection-production.mjs',
]
function hashes() { return sources.map(name => ({ name, sha256: crypto.createHash('sha256')
  .update(fs.readFileSync(path.join(wd, 'bodyguard', name))).digest('hex') })) }
const before = hashes()
fs.writeFileSync(path.join(proofRoot, 'sources-before.json'), JSON.stringify(before, null, 2))
try {
  guard()
  await run('initdb', path.join(pg, 'initdb'), ['-D', data, '-U', 'bodyguard_test',
    '--auth-local=trust', '--auth-host=reject', '--locale=C', '--encoding=UTF8'])
  const info = fs.statSync(data); roots.push([data, info.dev, info.ino])
  guard()
  await run('pg-start', path.join(pg, 'pg_ctl'), ['-D', data, '-l', path.join(dbRoot, 'server.log'),
    '-o', `-k ${socket} -c listen_addresses='' -c unix_socket_permissions=0700`, '-w', '-t', '30', 'start'])
  const fields = fs.readFileSync(path.join(data, 'postmaster.pid'), 'utf8').split('\n')
  assert(fields[1] === data && Number(fields[0]) > 1); pid = Number(fields[0])
  await run('create-test-db', path.join(pg, 'createdb'), ['-h', socket, '-U', 'bodyguard_test', '-w', 'bodyguard_test'])
  await run('sql-identity', path.join(pg, 'psql'), ['-h', socket, '-U', 'bodyguard_test', '-d',
    'bodyguard_test', '-w', '-X', '-A', '-t', '-c',
    "SELECT current_database(), current_user, current_setting('data_directory'), current_setting('listen_addresses'), current_setting('server_version_num'); SHOW TimeZone;"])
  await run('backend-related', path.join(backend, '.venv/bin/python'), ['-m', 'pytest', '-q',
    'tests/test_baselines.py', 'tests/test_baseline_races.py',
    'tests/test_baseline_web_binding.py', 'tests/test_summaries.py',
    'tests/test_summary_races.py', 'tests/test_summary_read_binding.py',
    'tests/test_summary_upload_binding.py', '--junitxml=' + path.join(proofRoot, 'backend.xml')])
  await run('browser-recordbaseline', path.join(backend, '.venv/bin/python'), ['-m', 'tests.run_browser', 'recordbaseline'])
  await run('sql-census', path.join(pg, 'psql'), ['-h', socket, '-U', 'bodyguard_test', '-d',
    'bodyguard_test', '-w', '-X', '-A', '-t', '-c',
    'SELECT (SELECT count(*) FROM baselines), (SELECT count(*) FROM baselines WHERE is_active), (SELECT count(*) FROM minute_summaries), (SELECT count(DISTINCT user_id) FROM minute_summaries);'])
  await run('browser-summaries', path.join(backend, '.venv/bin/python'), ['-m', 'tests.run_browser', 'summaries'])
  assert.deepEqual(hashes(), before, 'Executed source changed; do not claim latest-source validation')
} finally {
  if (pid) {
    guard()
    const f = fs.readFileSync(path.join(data, 'postmaster.pid'), 'utf8').split('\n')
    assert(Number(f[0]) === pid && f[1] === data)
    const comm = spawnSync('/bin/ps', ['-p', String(pid), '-o', 'comm='], { encoding: 'utf8' })
    const args = spawnSync('/bin/ps', ['-p', String(pid), '-o', 'args='], { encoding: 'utf8' })
    assert(comm.status === 0 && fs.realpathSync(comm.stdout.trim()) === path.join(pg, 'postgres'))
    assert(args.status === 0 && args.stdout.trim().startsWith(`${pg}/postgres -D ${data} `))
    await run('pg-stop', path.join(pg, 'pg_ctl'), ['-D', data, '-w', '-t', '30', '-m', 'fast', 'stop'])
    assert(!fs.existsSync(path.join(data, 'postmaster.pid')))
  }
  fs.writeFileSync(path.join(proofRoot, 'results.json'), JSON.stringify({ results,
    ownedPid: pid, stopped: pid ? !fs.existsSync(path.join(data, 'postmaster.pid')) : null,
    originalSources: before, finalSources: hashes(), preservesDataAndLogs: true }, null, 2))
}
