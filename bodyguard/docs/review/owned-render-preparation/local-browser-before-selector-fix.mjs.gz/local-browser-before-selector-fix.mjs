import assert from 'node:assert/strict'
import {spawnSync,execFileSync} from 'node:child_process'
import {readFileSync,writeFileSync,existsSync,realpathSync,statSync} from 'node:fs'
import {createHash} from 'node:crypto'
const work="/Applications/학교 내부/2026-2학기/오픈소스 AI SW 융합 프로젝트/BODYGUARD-native-main-thread-contention",proof="/private/tmp/bodyguard-native-feedback-proof.b0hre9",db='/private/tmp/bodyguard-auth-test.3ETJuU'
const [label,gender,mode]=process.argv.slice(2)
assert(/^[a-z][a-z0-9-]*$/.test(label));assert(['male','female'].includes(gender));assert(['prepared','baseline'].includes(mode))
const bin='/opt/homebrew/opt/postgresql@18/bin/',fe=work+'/bodyguard/frontend'
assert.equal(realpathSync(db),db);assert.equal(statSync(db).uid,process.getuid());assert(!existsSync(db+'/data/postmaster.pid'))
const sha=b=>createHash('sha256').update(b).digest('hex'),git=(...args)=>execFileSync('git',args,{cwd:work,encoding:'utf8'})
const source=()=>Object.fromEntries(git('ls-files','-z','--cached','--others','--exclude-standard','bodyguard/frontend/src','bodyguard/frontend/e2e','bodyguard/backend/tests/run_browser.py').split('\0').filter(Boolean).map(p=>[p,sha(readFileSync(work+'/'+p))]))
function run(suffix,cmd,args,options={}){
 const name=proof+'/'+label+'-'+suffix,start=new Date().toISOString()
 const r=spawnSync(cmd,args,{encoding:'utf8',maxBuffer:64*1024*1024,...options})
 for(const k of ['stdout','stderr'])writeFileSync(name+'.'+k+'.txt',r[k]??'',{flag:'wx'})
 writeFileSync(name+'.receipt.json',JSON.stringify({cmd,args,start,end:new Date().toISOString(),status:r.status,signal:r.signal},null,2)+'\n',{flag:'wx'})
 console.log(suffix,r.status);return r
}
let started=false
try{
 assert.equal(run('db-start',bin+'pg_ctl',['-D',db+'/data','-l',db+'/postgres.log','-o',"-k "+db+" -c listen_addresses='' -p 54329",'-w','start']).status,0);started=true
 assert.equal(run('identity',bin+'psql',['-h',db,'-p','54329','-U','bodyguard_test','-d','bodyguard_test','-At','-c',"SELECT current_database(),current_user,current_setting('server_version'),current_setting('listen_addresses');"]).status,0)
 const before=source();writeFileSync(proof+'/'+label+'-source-before.json',JSON.stringify({head:git('rev-parse','HEAD').trim(),sources:before},null,2),{flag:'wx'})
 const env={...process.env,PATH:proof+'/bin:'+fe+'/node_modules/.bin:'+process.env.PATH,BODYGUARD_TEST_NATIVE_FEEDBACK_PROBE:proof+'/probe-'+label,BODYGUARD_TEST_RENDER_PREPARATION:mode==='prepared'?'1':'',BODYGUARD_TEST_DATABASE_URL:'postgresql+psycopg://bodyguard_test@/bodyguard_test?host='+db+'&port=54329'}
 const r=run('browser',"/Applications/학교 내부/2026-2학기/오픈소스 AI SW 융합 프로젝트/BODYGUARD-record-dashboard/bodyguard/backend/.venv/bin/python",['-m','tests.run_browser','nativefeedback','--grep','^'+gender+' '],{cwd:work+'/bodyguard/backend',env})
 const after=source();writeFileSync(proof+'/'+label+'-source-after.json',JSON.stringify({sources:after},null,2),{flag:'wx'});assert.deepEqual(before,after)
 process.exitCode=r.status??1
}finally{
 if(started)assert.equal(run('db-stop',bin+'pg_ctl',['-D',db+'/data','-m','fast','-w','stop']).status,0)
 assert(!existsSync(db+'/data/postmaster.pid'))
}
