import assert from 'node:assert/strict'
import { spawnSync } from 'node:child_process'
import { createHash } from 'node:crypto'
import { existsSync, mkdirSync, readFileSync, readdirSync, writeFileSync } from 'node:fs'
import { join } from 'node:path'
import { gzipSync, gunzipSync } from 'node:zlib'
const root="/Applications/학교 내부/2026-2학기/오픈소스 AI SW 융합 프로젝트/BODYGUARD-dashboard-client/bodyguard/frontend", out="/Applications/학교 내부/2026-2학기/오픈소스 AI SW 융합 프로젝트/BODYGUARD-dashboard-client/bodyguard/docs/review/bounded-model-download", proof="/private/tmp/bodyguard-model-download.m2dVdgey"
const finalBuild="/private/tmp/bodyguard-owned-models.4yp39fpp", beforeBuild="/private/tmp/bodyguard-owned-models.RO9W2Gji", afterBuild="/private/tmp/bodyguard-owned-models.9C17Z9Qq", camera="/private/tmp/bodyguard-camera-preparation.roSHYFmO"
const entries=[["concurrent-red.json","/private/tmp/bodyguard-model-download.m2dVdgey/concurrent-red.json"],["related-first.json","/private/tmp/bodyguard-model-download.m2dVdgey/related-first.json"],["related-corrected.json","/private/tmp/bodyguard-model-download.m2dVdgey/related-corrected.json"],["frontend-first-final.json","/private/tmp/bodyguard-model-download.m2dVdgey/frontend-final.json"],["frontend-final-source.json","/private/tmp/bodyguard-model-download.m2dVdgey/frontend-final-source.json"],["final-quality.json","/private/tmp/bodyguard-model-download.m2dVdgey/final-quality.json"],["original-ownedModelAssets.ts","/private/tmp/bodyguard-model-download.m2dVdgey/original-ownedModelAssets.ts"],["run-final-quality.mjs","/private/tmp/bodyguard-model-download.m2dVdgey/run-final-quality.mjs"],["before-latency-repaired.json","/private/tmp/bodyguard-owned-models.yEhRWpYx/before-latency-repaired.json"],["before-latency-diagnosed.json","/private/tmp/bodyguard-owned-models.yEhRWpYx/before-latency-diagnosed.json"],["candidate-all.json","/private/tmp/bodyguard-owned-models.mL2gMCuN/candidate-all.json"],["current-clock-diagnostic.json","/private/tmp/bodyguard-owned-models.HZ339CVg/current-clock-diagnostic.json"],["before-current-frame.json","/private/tmp/bodyguard-owned-models.RO9W2Gji/before-current-frame.json"],["candidate-current-frame.json","/private/tmp/bodyguard-owned-models.9C17Z9Qq/candidate-current-frame.json"],["candidate-latency-isolated.json","/private/tmp/bodyguard-owned-models.9C17Z9Qq/candidate-latency-isolated.json"],["fixed-clock-paired.json","/private/tmp/bodyguard-owned-models.9C17Z9Qq/fixed-clock-paired.json"],["fixed-clock-isolated.json","/private/tmp/bodyguard-owned-models.9C17Z9Qq/fixed-clock-isolated.json"],["final-original-input.json","/private/tmp/bodyguard-owned-models.4yp39fpp/final-original-input.json"],["before-reader-provenance.json","/private/tmp/bodyguard-owned-models.RO9W2Gji/model-reader-provenance.json"],["after-reader-provenance.json","/private/tmp/bodyguard-owned-models.9C17Z9Qq/model-reader-provenance.json"],["final-reader-provenance.json","/private/tmp/bodyguard-owned-models.4yp39fpp/model-reader-provenance.json"],["concurrent-camera.json","/private/tmp/bodyguard-camera-preparation.roSHYFmO/concurrent-camera.json"],["native-worker.js","/private/tmp/bodyguard-owned-models.4yp39fpp/probe/assets/nativeInference.worker-uTAJCKN7.js"],["before-probe.js","/private/tmp/bodyguard-owned-models.RO9W2Gji/probe/assets/ownedModelProbe-BcENpS2q.js"],["final-probe.js","/private/tmp/bodyguard-owned-models.4yp39fpp/probe/assets/ownedModelProbe-CCSBpMt4.js"],["final-probe.html","/private/tmp/bodyguard-owned-models.4yp39fpp/probe/e2e/fixtures/ownedModelProbe.html"],["frontend.stdout.log","/private/tmp/bodyguard-model-download.m2dVdgey/frontend.stdout.log"],["frontend.stderr.log","/private/tmp/bodyguard-model-download.m2dVdgey/frontend.stderr.log"],["typecheck.stdout.log","/private/tmp/bodyguard-model-download.m2dVdgey/typecheck.stdout.log"],["typecheck.stderr.log","/private/tmp/bodyguard-model-download.m2dVdgey/typecheck.stderr.log"],["biome.stdout.log","/private/tmp/bodyguard-model-download.m2dVdgey/biome.stdout.log"],["biome.stderr.log","/private/tmp/bodyguard-model-download.m2dVdgey/biome.stderr.log"],["pinned-models.stdout.log","/private/tmp/bodyguard-model-download.m2dVdgey/pinned-models.stdout.log"],["pinned-models.stderr.log","/private/tmp/bodyguard-model-download.m2dVdgey/pinned-models.stderr.log"],["original-build.stdout.log","/private/tmp/bodyguard-model-download.m2dVdgey/original-build.stdout.log"],["original-build.stderr.log","/private/tmp/bodyguard-model-download.m2dVdgey/original-build.stderr.log"],["production-guard.stdout.log","/private/tmp/bodyguard-model-download.m2dVdgey/production-guard.stdout.log"],["production-guard.stderr.log","/private/tmp/bodyguard-model-download.m2dVdgey/production-guard.stderr.log"],["diff-check.stdout.log","/private/tmp/bodyguard-model-download.m2dVdgey/diff-check.stdout.log"],["diff-check.stderr.log","/private/tmp/bodyguard-model-download.m2dVdgey/diff-check.stderr.log"]]
const sha=b=>createHash('sha256').update(b).digest('hex')
const read=path=>readFileSync(path), json=path=>JSON.parse(read(path))
const quality=json(join(proof,'final-quality.json'))
assert(quality.sourceUnchanged && quality.steps.every(x=>x.exitCode===0))
for(const [path,hash] of Object.entries(quality.sourceAfter))assert.equal(sha(read(join(root,path))),hash)
const red=json(join(proof,'concurrent-red.json')), related=json(join(proof,'related-corrected.json')), full=json(join(proof,'frontend-final-source.json'))
assert.equal(red.numFailedTests,5)
assert.equal(related.numPassedTests,69)
assert.equal(related.numFailedTests,0)
assert(full.success && full.numPassedTests===1849 && full.testResults.length===102)
const original=read(join(proof,'original-ownedModelAssets.ts'))
const git=spawnSync('git',['show','fb8635ad98debc009329b08ef3c3516666e92e37:bodyguard/frontend/src/pose/ownedModelAssets.ts'],{cwd:root})
assert.equal(git.status,0)
assert.equal(sha(original),sha(git.stdout))
const before=json(join(beforeBuild,'before-current-frame.json')), after=json(join(afterBuild,'candidate-latency-isolated.json')), final=json(join(finalBuild,'final-original-input.json')), web=json(join(camera,'concurrent-camera.json'))
assert(!before.failure && !after.failure && !final.failure && !web.failure)
assert(before.readerProvenance.privateProbeOnlyOverride && before.readerProvenance.originalTransforms===1 && before.readerProvenance.productOverrides===0)
assert.equal(before.readerProvenance.readerSha256,sha(original))
assert.equal(before.readerProvenance.probeInputSha256,after.readerProvenance.probeInputSha256)
assert.equal(after.readerProvenance.readerSha256,quality.sourceAfter['src/pose/ownedModelAssets.ts'])
assert.equal(final.readerProvenance.probeInputSha256,quality.sourceAfter['e2e/fixtures/ownedModelProbe.ts'])
assert.equal(final.readerProvenance.readerSha256,quality.sourceAfter['src/pose/ownedModelAssets.ts'])
assert(!final.readerProvenance.privateProbeOnlyOverride && final.generatedInputClock==='fixed-1ms')
assert(final.results.length===6 && final.results.every(x=>x.phase==='complete' && x.workers===1 && x.closed===1 && x.storage===0 && x.final.state==='closed'))
assert(web.cases.length===8 && web.external===0 && web.avatars===0)
const artifacts=[]
assert(!existsSync(join(out,'evidence')),'Keep prior evidence')
mkdirSync(join(out,'evidence'),{recursive:true})
function archive(name,path) {
 const raw=read(path), packed=gzipSync(raw), target=join(out,'evidence',name+'.gz')
 writeFileSync(target,packed,{flag:'wx'})
 assert.equal(sha(gunzipSync(read(target))),sha(raw))
 artifacts.push({name:'evidence/'+name+'.gz',origin:path,bytes:raw.length,sha256:sha(raw),packedBytes:packed.length,packedSha256:sha(packed)})
}
for(const [name,path] of entries)archive(name,path)
archive('collector.mjs',process.argv[1])
for(const path of Object.keys(quality.sourceAfter))archive('final-source-'+path.replaceAll('/','--'),join(root,path))
for(const name of ['concurrent-camera-stopped-1440.png','concurrent-camera-denied-1440.png','concurrent-camera-stopped-800.png']){
 const bytes=read(join(camera,name))
 writeFileSync(join(out,name),bytes,{flag:'wx'})
 artifacts.push({name,origin:join(camera,name),bytes:bytes.length,sha256:sha(bytes)})
}
const outputs=[]
for(const [label,dir] of [['before',beforeBuild],['after',afterBuild],['final',finalBuild],['standard',join(root,'dist')]]) {
 const product=label==='standard'?dir:join(dir,'product')
 for(const name of readdirSync(join(product,'assets')).filter(x=>/\.(js|css)$/.test(x))) {
  const bytes=read(join(product,'assets',name))
  outputs.push({label,path:join(product,'assets',name),bytes:bytes.length,sha256:sha(bytes)})
 }
}
for(const ext of ['js','css'])assert.equal(new Set(outputs.filter(x=>x.path.endsWith('.'+ext)).map(x=>x.sha256)).size,1)
const workers=[beforeBuild,afterBuild,finalBuild].map(dir=>{
 const path=join(dir,'probe/assets/nativeInference.worker-uTAJCKN7.js'),bytes=read(path)
 return {path,bytes:bytes.length,sha256:sha(bytes)}
})
assert.equal(new Set(workers.map(x=>x.sha256)).size,1)
const comparisons=[]
for(const [label,run] of [['before',before],['after',after]])for(const row of run.results){
 const starts=run.requests.filter(x=>x.mode===row.name && x.path.endsWith('.task')).map(x=>x.requestedAt)
 assert.equal(starts.length,3)
 comparisons.push({label,mode:row.name,preparedMs:row.prepared.elapsedMs,firstInferenceMs:row.inferenceMs,requestStartSpanMs:Math.max(...starts)-Math.min(...starts),clock:'current-performance',browserVersion:run.browserVersion})
}
writeFileSync(join(out,'evidence-manifest.json'),JSON.stringify({generatedAt:new Date().toISOString(),baseMain:'fb8635ad98debc009329b08ef3c3516666e92e37',branch:'codex/bounded-model-download',artifacts,source:quality.sourceAfter,outputs,workers,comparisons,scope:{actualSDK:true,nativeFakeCamera:true,controlledLatencyMs:900,actualPeople:false,realProvider:false,realSQL:false,avatarWork:false,oldStartupP2Resolved:false,stages1to6Complete:false},missingRawEvidence:['initial proxy ECONNRESET no JSON written','initial Biome four errors not captured as separate raw log','intermediate scripts not snapshotted at each trial']},null,2)+'\n',{flag:'wx'})
console.log(JSON.stringify({out,artifacts:artifacts.length,comparisons,publicOutputUnchanged:true,workerOutputUnchanged:true}))

