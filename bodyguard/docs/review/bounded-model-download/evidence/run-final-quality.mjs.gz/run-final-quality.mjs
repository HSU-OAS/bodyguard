import assert from 'node:assert/strict'
import { spawnSync } from 'node:child_process'
import { createHash } from 'node:crypto'
import { readFileSync, writeFileSync } from 'node:fs'
import { join } from 'node:path'
const root = "/Applications/학교 내부/2026-2학기/오픈소스 AI SW 융합 프로젝트/BODYGUARD-dashboard-client/bodyguard/frontend"
const out = "/private/tmp/bodyguard-model-download.m2dVdgey"
const paths = ['src/pose/ownedModelAssets.ts', 'src/pose/ownedModelAssets.test.ts', 'src/pose/ownedModelAssets.concurrent.test.ts', 'src/pose/workerInference.ts', 'src/pose/workerInferenceRuntime.ts', 'src/pose/workerNativeEngine.ts', 'src/pose/inferenceWorker.ts', 'src/pose/nativeInference.worker.ts', 'src/pose/policyWorker.ts', 'src/pose/constants.ts', 'src/pose/cameraPreparation.ts', 'src/pages/CameraPreparation.tsx', 'e2e/fixtures/ownedModelProbe.ts', 'scripts/build-owned-model-preparation.mjs', 'scripts/test-owned-model-preparation.mjs', 'scripts/sdk-network-policy.ts', 'vite.config.ts', 'scripts/check-selection-production.mjs', 'scripts/check-owned-models.mjs']
const sha = b => createHash('sha256').update(b).digest('hex')
const snapshot = () => Object.fromEntries(paths.map(path => [path, sha(readFileSync(join(root,path)))]))
const before = snapshot()
const steps = [
 ['frontend', 'pnpm', ['exec','vitest','run','--reporter=json','--outputFile='+join(out,'frontend-final-source.json')]],
 ['typecheck','pnpm',['typecheck']],
 ['biome','pnpm',['check']],
 ['pinned-models','node',['scripts/check-owned-models.mjs']],
 ['original-build','pnpm',['build']],
 ['production-guard','node',['scripts/check-selection-production.mjs']],
 ['diff-check','git',['diff','--check']],
]
const results=[]
for (const [id,command,args] of steps) {
 const startedAt = new Date().toISOString()
 const run=spawnSync(command,args,{cwd:root,encoding:'utf8',maxBuffer:64*1024*1024})
 writeFileSync(join(out,id+'.stdout.log'),run.stdout??'',{flag:'wx'})
 writeFileSync(join(out,id+'.stderr.log'),run.stderr??'',{flag:'wx'})
 const result={id,command,args,startedAt,endedAt:new Date().toISOString(),exitCode:run.status,signal:run.signal,error:run.error?String(run.error):null}
 results.push(result)
 console.log(JSON.stringify(result))
}
const after=snapshot()
const report={generatedAt:new Date().toISOString(),root,sourceBefore:before,sourceAfter:after,sourceUnchanged:JSON.stringify(before)===JSON.stringify(after),steps:results,actualBackendTests:false,actualPeople:false,avatarWork:false,releaseComplete:false}
writeFileSync(join(out,'final-quality.json'),JSON.stringify(report,null,2)+'\n',{flag:'wx'})
assert(report.sourceUnchanged,'Source changed during quality gates')
assert(results.every(result=>result.exitCode===0),'Final quality command failed')
const unit=JSON.parse(readFileSync(join(out,'frontend-final-source.json'),'utf8'))
console.log(JSON.stringify({passed:unit.numPassedTests,failed:unit.numFailedTests,files:unit.testResults.length,pending:unit.numPendingTests}))

