import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import {execFileSync} from 'node:child_process'
import {createHash} from 'node:crypto'
import {gzipSync} from 'node:zlib'
const [work,proof,runtime]=process.argv.slice(2)
assert(work.endsWith('/BODYGUARD-observed-hands'));assert(/^\/private\/tmp\/bodyguard-hand-proof\.[A-Za-z0-9]+$/.test(proof))
const dir=path.join(work,'bodyguard/docs/review/observed-hands'),dst=path.join(dir,'evidence')
assert(!fs.existsSync(dst));fs.mkdirSync(dst,{recursive:true})
const sha=b=>createHash('sha256').update(b).digest('hex'),json=p=>JSON.parse(fs.readFileSync(p)), evidence=[]
function add(name,b,original){fs.writeFileSync(path.join(dst,name),b,{flag:'wx'});evidence.push({file:name,bytes:b.length,sha256:sha(b),...(original?{originalSha256:sha(original)}:{})})}
for(const n of fs.readdirSync(proof).filter(n=>/\.(json|mjs|py|txt|png)$/.test(n)).sort()){
 const b=fs.readFileSync(path.join(proof,n));if(/\.(mjs|json|txt)$/.test(n)){add(n+'.gz',gzipSync(b),b)}else add(n,b)
}
for(const n of fs.readdirSync(proof).filter(n=>n==='probe'||n.startsWith('probe-')).sort()){
 if(!fs.statSync(path.join(proof,n)).isDirectory())continue
 const b=fs.readFileSync(path.join(proof,n,'probe.js'));add(n+'-bundle.js.gz',gzipSync(b),b)
}
const sourceNames=['src/avatar/observedHandRig.ts','src/avatar/observedHandRig.test.ts','src/avatar/observedPoseRig.ts','src/avatar/ownedAvatarPair.ts','src/avatar/ownedAvatarPair.test.ts','src/avatar/headOrientationRig.ts','src/avatar/directionalRig.ts','src/avatar/eightWeightSkin.ts','src/pose/ownedPoseFrame.ts','e2e/fixtures/observedHandsProbe.ts','e2e/fixtures/hand-probe.config.ts','scripts/test-observed-hands-browser.mjs','scripts/check-selection-production.mjs','pnpm-lock.yaml']
const source=Object.fromEntries(sourceNames.map(n=>{const b=execFileSync('git',['show',runtime+':bodyguard/frontend/'+n],{cwd:work,maxBuffer:10000000});assert.equal(sha(b),sha(fs.readFileSync(path.join(work,'bodyguard/frontend',n))));return[n,sha(b)]}))
const checks=json(proof+'/final-checks-final.json');assert(checks.results.every(r=>r.exit===0));const unit=json(proof+'/frontend-final.json');assert.equal(unit.numFailedTests,0);assert.equal(unit.numPendingTests,0)
const browser=json(proof+'/browser-final.json'),receipt=json(proof+'/browser-final-receipt.json');assert.equal(browser.head,runtime);assert.equal(receipt.head,runtime);assert.equal(receipt.exit,0);assert.deepEqual(browser.sourceBefore,browser.sourceAfter);assert(browser.samples.length===2&&browser.samples.every(s=>s.passed));assert.equal(browser.camera,0);assert.equal(browser.external,0);assert.deepEqual(browser.errors,[])
const expected={js:'b5d4f81164c8d3c196e853b3404382bc15077986aa626cd0c3c72571b6325ac0',css:'043cb9bdb5d82a3baa9a8463c7a641cbe92ace213303f20c6c7f91e9a14ac82e'}
const publicDir=path.join(work,'bodyguard/frontend/dist'),files=fs.readdirSync(publicDir+'/assets').filter(n=>/\.(js|css)$/.test(n));assert.equal(files.length,2)
const publicAssets=files.map(n=>{const b=fs.readFileSync(publicDir+'/assets/'+n),s=sha(b);assert.equal(s,expected[n.split('.').at(-1)]);return{name:n,bytes:b.length,sha256:s}})
assert.equal(fs.readdirSync(publicDir,{recursive:true}).filter(n=>n.endsWith('.glb')).length,0)
const modelNames=fs.readdirSync(publicDir+'/models').filter(n=>n.endsWith('.task'));assert.equal(modelNames.length,5)
const models=modelNames.map(n=>{const b=fs.readFileSync(publicDir+'/models/'+n);assert.equal(sha(b),sha(fs.readFileSync(path.join(work,'../BODYGUARD-owned-alert-lifecycle/bodyguard/frontend/public/models',n))));return{name:n,bytes:b.length,sha256:sha(b)}})
const gitOriginal=execFileSync('git',['show','25a9bd6c7392890e3b5d5d6ae1046bb7087d56ad:bodyguard/assets/blender/bodyguard_avatar_candidate_a37.blend'],{cwd:work,maxBuffer:40000000});assert.equal(sha(gitOriginal),sha(fs.readFileSync(proof+'/a37.blend')))
const notices=path.join(dir,'notices');fs.mkdirSync(notices,{recursive:true});fs.copyFileSync(path.join(work,'bodyguard/frontend/node_modules/three/LICENSE'),path.join(notices,'three-MIT.txt'),fs.constants.COPYFILE_EXCL)
const summary={runtime,baseline:'815422b5d1aeb498d4440fe6a099af27266f7e05',source,evidence,frontend:{passed:unit.numPassedTests,failed:unit.numFailedTests,pending:unit.numPendingTests},checks:checks.results,browser:{version:browser.browser,samples:browser.samples.map(s=>({gender:s.gender,passed:s.passed,states:s.stages.length})),actualWebGL:true,synthetic:true,actualCamera:false,actualSDK:false},assets:browser.assets,blenderOriginal:{sha256:sha(gitOriginal),bytes:gitOriginal.length,unchanged:true,readOnly:true},publicAssets,models,unfinishedA37:true,newSculptOrGLB:false,publicUiChanged:false,productionSdkPolicyChanged:false,nativeHandConnection:false,clinicalThresholdsChanged:false,qualifiedReleaseMotions:0,stagesComplete:false,review:{kind:'author security/performance/correctness/acceptance review; not independent reviewer',unresolvedStoryP1P2:0},limitations:['supplied hand side is not matched person identity','21 landmarks have no per-point visibility proof','fingers swing only; no measured axial twist or metacarpal rotations','no physical camera/participant accuracy','no final appearance, approved public design or full1-6 gate']}
fs.writeFileSync(path.join(dir,'summary.json'),JSON.stringify(summary,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify({runtime,sources:sourceNames.length,evidence:evidence.length,frontend:summary.frontend,browser:summary.browser,publicAssets}))
