# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: restore.spec.ts >> AR-WEB actual cached failed-logout200 stays blocked then retry204
- Location: e2e/restore.spec.ts:144:3

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 0
Received: 2
```

# Page snapshot

```yaml
- generic [ref=f2e3]:
  - button "본문으로 이동" [ref=f2e4]
  - banner [ref=f2e5]:
    - link "BODYGUARD 서비스 소개" [ref=f2e6] [cursor=pointer]:
      - /url: /
      - text: BODYGUARD.
    - navigation "계정 메뉴" [ref=f2e7]:
      - link "내 시작" [ref=f2e8] [cursor=pointer]:
        - /url: /start
      - link "자세 기록" [ref=f2e9] [cursor=pointer]:
        - /url: /posture-records
      - link "수행 기록" [ref=f2e10] [cursor=pointer]:
        - /url: /records
      - link "내 계정" [ref=f2e11] [cursor=pointer]:
        - /url: /account
  - main [ref=f2e12]:
    - generic [ref=f2e13]:
      - paragraph [ref=f2e14]: MY BODYGUARD
      - heading "내 몸을 위한 시작" [active] [level=1] [ref=f2e15]
      - paragraph [ref=f2e16]: restore-a554cb5c-e923-42d8-b7ad-465593053025@example.com
      - link "스트레칭 시작 경로 선택" [ref=f2e17] [cursor=pointer]:
        - /url: /explore
      - paragraph [ref=f2e18]:
        - link "내 수행 기록 확인" [ref=f2e19] [cursor=pointer]:
          - /url: /records
      - paragraph [ref=f2e20]:
        - link "내 자세 기록 확인" [ref=f2e21] [cursor=pointer]:
          - /url: /posture-records
      - paragraph [ref=f2e22]:
        - link "계정 관리" [ref=f2e23] [cursor=pointer]:
          - /url: /account
      - generic [ref=f2e24]:
        - heading "첫 코칭 흐름을 준비하고 있습니다" [level=2] [ref=f2e25]
        - paragraph [ref=f2e26]: 동작 검증과 남녀 3D 아바타 제작이 끝나면 스트레칭 선택과 코칭을 이곳에 연결합니다. 지금은 계정 기능을 사용할 수 있습니다.
        - paragraph [ref=f2e27]: 카메라는 켜지지 않았습니다.
      - button "로그아웃" [ref=f2e28] [cursor=pointer]
  - contentinfo [ref=f2e29]:
    - generic [ref=f2e30]: BODYGUARD
    - paragraph [ref=f2e31]: 일상을 위한 스트레칭과 자세 코칭 · 출시 준비 중
    - navigation "서비스 안내" [ref=f2e32]:
      - link "도움말" [ref=f2e33] [cursor=pointer]:
        - /url: /help
      - link "카메라·데이터 안내" [ref=f2e34] [cursor=pointer]:
        - /url: /data
```

# Test source

```ts
  105 |     await protocol.detach()
  106 |     throw error
  107 |   }
  108 | }
  109 | async function post(context: BrowserContext, path: string, data: unknown) {
  110 |   const response = await context.request.get('/api/v1/auth/csrf')
  111 |   expect(response.status()).toBe(200)
  112 |   const csrf = await response.json()
  113 |   return context.request.post(`/api/v1${path}`, {
  114 |     headers: { Origin: origin, 'X-CSRF-Token': csrf.csrf_token },
  115 |     data,
  116 |   })
  117 | }
  118 | async function join(context: BrowserContext) {
  119 |   const email = `restore-${randomUUID()}@example.com`
  120 |   const response = await post(context, '/auth/signup', {
  121 |     email,
  122 |     password: '캐시 복원 시험 전용 비밀번호 12345',
  123 |   })
  124 |   expect(response.status()).toBe(202)
  125 |   let code = ''
  126 |   await expect
  127 |     .poll(() => {
  128 |       code = JSON.parse(readFileSync(mailbox as string, 'utf8'))[email] ?? ''
  129 |       return /^[0-9]{6}$/.test(code)
  130 |     })
  131 |     .toBe(true)
  132 |   expect(
  133 |     (
  134 |       await post(context, '/auth/verify', {
  135 |         challenge_id: (await response.json()).challenge_id,
  136 |         code,
  137 |       })
  138 |     ).status(),
  139 |   ).toBe(201)
  140 |   return email
  141 | }
  142 | 
  143 | for (const status of [200, 503]) {
  144 |   test(`AR-WEB actual cached failed-logout${status} stays blocked then retry204`, async ({
  145 |     page,
  146 |     context,
  147 |   }, info) => {
  148 |     const email = await join(context)
  149 |     await page.goto('/start')
  150 |     await expect(page.getByText(email, { exact: true })).toBeVisible()
  151 |     const old = (await context.cookies()).find((cookie) => cookie.name === 'bodyguard_session')
  152 |     expect(Boolean(old?.httpOnly)).toBe(true)
  153 |     await page.route('**/api/v1/auth/logout', (route) =>
  154 |       route.fulfill({ status, json: { logged_out: true } }),
  155 |     )
  156 |     await page.getByRole('button', { name: '로그아웃', exact: true }).click()
  157 |     await expect(
  158 |       page.getByRole('heading', { name: '로그아웃을 확인하지 못했습니다' }),
  159 |     ).toBeVisible()
  160 |     expect((await context.request.get('/api/v1/me')).status()).toBe(200)
  161 |     await page.unroute('**/api/v1/auth/logout')
  162 |     const documentId = await page.evaluate(() => {
  163 |       window.__accountRestoreProbe.blocked = true
  164 |       return window.__accountRestoreProbe.document
  165 |     })
  166 |     await page.goto('/help')
  167 |     expect(
  168 |       await page.evaluate((id) => window.__accountRestoreProbe.document !== id, documentId),
  169 |     ).toBe(true)
  170 |     const protocol = await back(page, context, documentId)
  171 |     try {
  172 |       const sameDocument = true
  173 |       await expect.poll(() => value(protocol, 'window.__accountRestoreProbe.settled')).toBe(true)
  174 |       const observation = await value<{ nativePersistedRestores: number; leaks: number }>(
  175 |         protocol,
  176 |         '({nativePersistedRestores: window.__accountRestoreProbe.restored, leaks: window.__accountRestoreProbe.leaks})',
  177 |       )
  178 |       const emailVisible = await value<boolean>(
  179 |         protocol,
  180 |         'Boolean(document.querySelector(".account-email")?.getClientRects().length)',
  181 |       )
  182 |       await info.attach('restored-boundary.json', {
  183 |         contentType: 'application/json',
  184 |         body: Buffer.from(
  185 |           JSON.stringify({
  186 |             statusInjected: status,
  187 |             sameDocument,
  188 |             ...observation,
  189 |             emailVisible,
  190 |             observationWindowMs: 500,
  191 |             actualWebHttpSql: true,
  192 |             actualCache: true,
  193 |             actualCamera: false,
  194 |             cameraCalls,
  195 |             unexpected,
  196 |             errors,
  197 |             browserVersion: context.browser()?.version(),
  198 |           }),
  199 |         ),
  200 |       })
  201 |       const screenshot = await protocol.send('Page.captureScreenshot', { format: 'png' })
  202 |       writeFileSync(info.outputPath('restored-page.png'), Buffer.from(screenshot.data, 'base64'), {
  203 |         flag: 'wx',
  204 |       })
> 205 |       expect(observation.leaks).toBe(0)
      |                                 ^ Error: expect(received).toBe(expected) // Object.is equality
  206 |       expect(
  207 |         await value(
  208 |           protocol,
  209 |           'document.querySelector("main h1")?.textContent === "로그아웃을 확인하지 못했습니다"',
  210 |         ),
  211 |       ).toBe(true)
  212 |       expect(emailVisible).toBe(false)
  213 |       let confirmed = false
  214 |       protocol.on('Network.responseReceived', (event) => {
  215 |         if (
  216 |           new URL(event.response.url).pathname === '/api/v1/auth/logout' &&
  217 |           event.response.status === 204
  218 |         )
  219 |           confirmed = true
  220 |       })
  221 |       await protocol.send('Network.enable')
  222 |       await value(
  223 |         protocol,
  224 |         'Array.from(document.querySelectorAll("button")).find(button => button.textContent === "로그아웃 다시 시도").click()',
  225 |       )
  226 |       await expect.poll(() => confirmed).toBe(true)
  227 |       await expect.poll(() => value(protocol, 'location.pathname === "/login"')).toBe(true)
  228 |       expect(
  229 |         (
  230 |           await context.request.get('/api/v1/me', {
  231 |             headers: { Cookie: `bodyguard_session=${old?.value}` },
  232 |           })
  233 |         ).status(),
  234 |       ).toBe(401)
  235 |       await info.attach('retry-confirmation.json', {
  236 |         contentType: 'application/json',
  237 |         body: Buffer.from(
  238 |           JSON.stringify({ actualLogout204: confirmed, loginRoute: true, oldCookieMe401: true }),
  239 |         ),
  240 |       })
  241 |     } finally {
  242 |       await protocol.detach()
  243 |     }
  244 |   })
  245 | }
  246 | 
  247 | test('AR-WEB actual cached ready page still rechecks a server-revoked old cookie', async ({
  248 |   page,
  249 |   context,
  250 |   request,
  251 | }, info) => {
  252 |   const email = await join(context)
  253 |   await page.goto('/start')
  254 |   await expect(page.getByText(email, { exact: true })).toBeVisible()
  255 |   const old = (await context.cookies()).find((cookie) => cookie.name === 'bodyguard_session')
  256 |   expect(Boolean(old?.httpOnly)).toBe(true)
  257 |   const documentId = await page.evaluate(() => window.__accountRestoreProbe.document)
  258 |   await page.goto('/help')
  259 |   // Isolated HTTP context revokes server session; original browser cookie is not modified.
  260 |   const cookie = `bodyguard_session=${old?.value}`
  261 |   const csrfResponse = await request.get('/api/v1/auth/csrf', { headers: { Cookie: cookie } })
  262 |   expect(csrfResponse.status()).toBe(200)
  263 |   const csrf = await csrfResponse.json()
  264 |   expect(
  265 |     (
  266 |       await request.post('/api/v1/auth/logout', {
  267 |         headers: {
  268 |           Cookie: cookie,
  269 |           Origin: origin,
  270 |           'X-CSRF-Token': csrf.csrf_token,
  271 |         },
  272 |       })
  273 |     ).status(),
  274 |   ).toBe(204)
  275 |   const unchanged = (await context.cookies()).find((value) => value.name === 'bodyguard_session')
  276 |   expect(Boolean(unchanged?.value && unchanged.value === old?.value)).toBe(true)
  277 |   const protocol = await back(page, context, documentId)
  278 |   try {
  279 |     const sameDocument = true
  280 |     await expect.poll(() => value(protocol, 'location.pathname === "/login"')).toBe(true)
  281 |     expect(await value(protocol, 'Boolean(document.querySelector(".account-email"))')).toBe(false)
  282 |     expect((await context.request.get('/api/v1/me')).status()).toBe(401)
  283 |     await info.attach('fresh-authority.json', {
  284 |       contentType: 'application/json',
  285 |       body: Buffer.from(
  286 |         JSON.stringify({
  287 |           sameDocument,
  288 |           nativePersistedRestores: 1,
  289 |           actualLogout204: true,
  290 |           unchangedBrowserCookie: true,
  291 |           nativeMe401: true,
  292 |           cameraCalls,
  293 |           unexpected,
  294 |           errors,
  295 |           browserVersion: context.browser()?.version(),
  296 |         }),
  297 |       ),
  298 |     })
  299 |   } finally {
  300 |     await protocol.detach()
  301 |   }
  302 | })
  303 | 
```