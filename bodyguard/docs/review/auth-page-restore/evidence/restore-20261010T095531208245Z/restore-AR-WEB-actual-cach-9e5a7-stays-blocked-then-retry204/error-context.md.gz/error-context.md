# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: restore.spec.ts >> AR-WEB actual cached failed-logout200 stays blocked then retry204
- Location: e2e/restore.spec.ts:109:3

# Error details

```
Test timeout of 30000ms exceeded.
```

```
Error: page.goBack: Test timeout of 30000ms exceeded.
Call log:
  - waiting for navigation until "load"
    - navigated to "http://localhost:4173/start"

```

# Page snapshot

```yaml
- generic [ref=f2e3]:
  - button "본문으로 이동" [ref=f2e4]
  - banner [ref=f2e5]:
    - link "BODYGUARD 서비스 소개" [ref=f2e6] [cursor=pointer]:
      - /url: /
      - text: BODYGUARD.
    - navigation "계정 메뉴" [ref=f2e7]:
      - link "내 시작" [ref=f2e8] [cursor=pointer]:
        - /url: /start
      - link "자세 기록" [ref=f2e9] [cursor=pointer]:
        - /url: /posture-records
      - link "수행 기록" [ref=f2e10] [cursor=pointer]:
        - /url: /records
      - link "내 계정" [ref=f2e11] [cursor=pointer]:
        - /url: /account
  - main [ref=f2e12]:
    - generic [ref=f2e13]:
      - paragraph [ref=f2e14]: MY BODYGUARD
      - heading "내 몸을 위한 시작" [active] [level=1] [ref=f2e15]
      - paragraph [ref=f2e16]: restore-54682561-0373-41cd-bf16-bf135dd35162@example.com
      - link "스트레칭 시작 경로 선택" [ref=f2e17] [cursor=pointer]:
        - /url: /explore
      - paragraph [ref=f2e18]:
        - link "내 수행 기록 확인" [ref=f2e19] [cursor=pointer]:
          - /url: /records
      - paragraph [ref=f2e20]:
        - link "내 자세 기록 확인" [ref=f2e21] [cursor=pointer]:
          - /url: /posture-records
      - paragraph [ref=f2e22]:
        - link "계정 관리" [ref=f2e23] [cursor=pointer]:
          - /url: /account
      - generic [ref=f2e24]:
        - heading "첫 코칭 흐름을 준비하고 있습니다" [level=2] [ref=f2e25]
        - paragraph [ref=f2e26]: 동작 검증과 남녀 3D 아바타 제작이 끝나면 스트레칭 선택과 코칭을 이곳에 연결합니다. 지금은 계정 기능을 사용할 수 있습니다.
        - paragraph [ref=f2e27]: 카메라는 켜지지 않았습니다.
      - button "로그아웃" [ref=f2e28] [cursor=pointer]
  - contentinfo [ref=f2e29]:
    - generic [ref=f2e30]: BODYGUARD
    - paragraph [ref=f2e31]: 일상을 위한 스트레칭과 자세 코칭 · 출시 준비 중
    - navigation "서비스 안내" [ref=f2e32]:
      - link "도움말" [ref=f2e33] [cursor=pointer]:
        - /url: /help
      - link "카메라·데이터 안내" [ref=f2e34] [cursor=pointer]:
        - /url: /data
```

# Test source

```ts
  35  |       unexpected.push(url.origin + url.pathname)
  36  |   })
  37  |   await context.exposeBinding('__restoreCamera', () => {
  38  |     cameraCalls++
  39  |   })
  40  |   await context.addInitScript(() => {
  41  |     navigator.mediaDevices.getUserMedia = () => {
  42  |       void (window as unknown as { __restoreCamera: () => Promise<void> }).__restoreCamera()
  43  |       return Promise.reject(new Error('Unexpected camera request'))
  44  |     }
  45  |     const probe = {
  46  |       document: crypto.randomUUID(),
  47  |       restored: 0,
  48  |       settled: false,
  49  |       blocked: false,
  50  |       leaks: 0,
  51  |     }
  52  |     window.__accountRestoreProbe = probe
  53  |     // Bounded observation: only a fixed selector presence/count, never DOM text or account data.
  54  |     const observer = new MutationObserver(() => {
  55  |       if (probe.restored && probe.blocked && document.querySelector('.account-email')) probe.leaks++
  56  |     })
  57  |     observer.observe(document, { subtree: true, childList: true })
  58  |     window.addEventListener('pageshow', (event) => {
  59  |       if (!event.persisted) return
  60  |       probe.restored++
  61  |       probe.settled = false
  62  |       setTimeout(() => {
  63  |         probe.settled = true
  64  |       }, 500)
  65  |     })
  66  |   })
  67  | })
  68  | test.afterEach(async ({ page }) => {
  69  |   expect(cameraCalls).toBe(0)
  70  |   expect(unexpected).toEqual([])
  71  |   expect(errors).toEqual([])
  72  |   expect(await page.evaluate(() => [localStorage.length, sessionStorage.length])).toEqual([0, 0])
  73  | })
  74  | async function post(context: BrowserContext, path: string, data: unknown) {
  75  |   const response = await context.request.get('/api/v1/auth/csrf')
  76  |   expect(response.status()).toBe(200)
  77  |   const csrf = await response.json()
  78  |   return context.request.post(`/api/v1${path}`, {
  79  |     headers: { Origin: origin, 'X-CSRF-Token': csrf.csrf_token },
  80  |     data,
  81  |   })
  82  | }
  83  | async function join(context: BrowserContext) {
  84  |   const email = `restore-${randomUUID()}@example.com`
  85  |   const response = await post(context, '/auth/signup', {
  86  |     email,
  87  |     password: '캐시 복원 시험 전용 비밀번호 12345',
  88  |   })
  89  |   expect(response.status()).toBe(202)
  90  |   let code = ''
  91  |   await expect
  92  |     .poll(() => {
  93  |       code = JSON.parse(readFileSync(mailbox as string, 'utf8'))[email] ?? ''
  94  |       return /^[0-9]{6}$/.test(code)
  95  |     })
  96  |     .toBe(true)
  97  |   expect(
  98  |     (
  99  |       await post(context, '/auth/verify', {
  100 |         challenge_id: (await response.json()).challenge_id,
  101 |         code,
  102 |       })
  103 |     ).status(),
  104 |   ).toBe(201)
  105 |   return email
  106 | }
  107 | 
  108 | for (const status of [200, 503]) {
  109 |   test(`AR-WEB actual cached failed-logout${status} stays blocked then retry204`, async ({
  110 |     page,
  111 |     context,
  112 |   }, info) => {
  113 |     const email = await join(context)
  114 |     await page.goto('/start')
  115 |     await expect(page.getByText(email, { exact: true })).toBeVisible()
  116 |     const old = (await context.cookies()).find((cookie) => cookie.name === 'bodyguard_session')
  117 |     expect(Boolean(old?.httpOnly)).toBe(true)
  118 |     await page.route('**/api/v1/auth/logout', (route) =>
  119 |       route.fulfill({ status, json: { logged_out: true } }),
  120 |     )
  121 |     await page.getByRole('button', { name: '로그아웃', exact: true }).click()
  122 |     await expect(
  123 |       page.getByRole('heading', { name: '로그아웃을 확인하지 못했습니다' }),
  124 |     ).toBeVisible()
  125 |     expect((await context.request.get('/api/v1/me')).status()).toBe(200)
  126 |     await page.unroute('**/api/v1/auth/logout')
  127 |     const documentId = await page.evaluate(() => {
  128 |       window.__accountRestoreProbe.blocked = true
  129 |       return window.__accountRestoreProbe.document
  130 |     })
  131 |     await page.goto('/help')
  132 |     expect(
  133 |       await page.evaluate((id) => window.__accountRestoreProbe.document !== id, documentId),
  134 |     ).toBe(true)
> 135 |     await page.goBack()
      |                ^ Error: page.goBack: Test timeout of 30000ms exceeded.
  136 |     await expect.poll(() => page.evaluate(() => window.__accountRestoreProbe.restored)).toBe(1)
  137 |     const sameDocument = await page.evaluate(
  138 |       (id) => window.__accountRestoreProbe.document === id,
  139 |       documentId,
  140 |     )
  141 |     expect(sameDocument).toBe(true)
  142 |     await expect.poll(() => page.evaluate(() => window.__accountRestoreProbe.settled)).toBe(true)
  143 |     const observation = await page.evaluate(() => ({
  144 |       nativePersistedRestores: window.__accountRestoreProbe.restored,
  145 |       leaks: window.__accountRestoreProbe.leaks,
  146 |     }))
  147 |     const emailVisible = await page.getByText(email, { exact: true }).isVisible()
  148 |     await info.attach('restored-boundary.json', {
  149 |       contentType: 'application/json',
  150 |       body: Buffer.from(
  151 |         JSON.stringify({
  152 |           statusInjected: status,
  153 |           sameDocument,
  154 |           ...observation,
  155 |           emailVisible,
  156 |           observationWindowMs: 500,
  157 |           actualWebHttpSql: true,
  158 |           actualCache: true,
  159 |           actualCamera: false,
  160 |           cameraCalls,
  161 |           unexpected,
  162 |           errors,
  163 |           browserVersion: context.browser()?.version(),
  164 |         }),
  165 |       ),
  166 |     })
  167 |     await page.screenshot({ path: info.outputPath('restored-page.png'), fullPage: true })
  168 |     expect(observation.leaks).toBe(0)
  169 |     await expect(
  170 |       page.getByRole('heading', { name: '로그아웃을 확인하지 못했습니다' }),
  171 |     ).toBeVisible()
  172 |     await expect(page.getByText(email, { exact: true })).toHaveCount(0)
  173 |     const confirmed = page.waitForResponse(
  174 |       (response) => new URL(response.url()).pathname === '/api/v1/auth/logout',
  175 |     )
  176 |     await page.getByRole('button', { name: '로그아웃 다시 시도' }).click()
  177 |     expect((await confirmed).status()).toBe(204)
  178 |     await expect(page).toHaveURL(/\/login/)
  179 |     expect(
  180 |       (
  181 |         await context.request.get('/api/v1/me', {
  182 |           headers: { Cookie: `bodyguard_session=${old?.value}` },
  183 |         })
  184 |       ).status(),
  185 |     ).toBe(401)
  186 |   })
  187 | }
  188 | 
  189 | test('AR-WEB actual cached ready page still rechecks a server-revoked old cookie', async ({
  190 |   page,
  191 |   context,
  192 |   request,
  193 | }, info) => {
  194 |   const email = await join(context)
  195 |   await page.goto('/start')
  196 |   await expect(page.getByText(email, { exact: true })).toBeVisible()
  197 |   const old = (await context.cookies()).find((cookie) => cookie.name === 'bodyguard_session')
  198 |   expect(Boolean(old?.httpOnly)).toBe(true)
  199 |   const documentId = await page.evaluate(() => window.__accountRestoreProbe.document)
  200 |   await page.goto('/help')
  201 |   // Isolated HTTP context revokes server session; original browser cookie is not modified.
  202 |   const cookie = `bodyguard_session=${old?.value}`
  203 |   const csrfResponse = await request.get('/api/v1/auth/csrf', { headers: { Cookie: cookie } })
  204 |   expect(csrfResponse.status()).toBe(200)
  205 |   const csrf = await csrfResponse.json()
  206 |   expect(
  207 |     (
  208 |       await request.post('/api/v1/auth/logout', {
  209 |         headers: {
  210 |           Cookie: cookie,
  211 |           Origin: origin,
  212 |           'X-CSRF-Token': csrf.csrf_token,
  213 |         },
  214 |       })
  215 |     ).status(),
  216 |   ).toBe(204)
  217 |   const unchanged = (await context.cookies()).find((value) => value.name === 'bodyguard_session')
  218 |   expect(Boolean(unchanged?.value && unchanged.value === old?.value)).toBe(true)
  219 |   await page.goBack()
  220 |   await expect.poll(() => page.evaluate(() => window.__accountRestoreProbe.restored)).toBe(1)
  221 |   const sameDocument = await page.evaluate(
  222 |     (id) => window.__accountRestoreProbe.document === id,
  223 |     documentId,
  224 |   )
  225 |   expect(sameDocument).toBe(true)
  226 |   await expect(page).toHaveURL(/\/login/)
  227 |   await expect(page.getByText(email, { exact: true })).toHaveCount(0)
  228 |   expect((await context.request.get('/api/v1/me')).status()).toBe(401)
  229 |   await info.attach('fresh-authority.json', {
  230 |     contentType: 'application/json',
  231 |     body: Buffer.from(
  232 |       JSON.stringify({
  233 |         sameDocument,
  234 |         nativePersistedRestores: 1,
  235 |         actualLogout204: true,
```