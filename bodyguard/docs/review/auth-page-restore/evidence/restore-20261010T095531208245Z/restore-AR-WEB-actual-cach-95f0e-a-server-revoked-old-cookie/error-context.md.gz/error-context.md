# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: restore.spec.ts >> AR-WEB actual cached ready page still rechecks a server-revoked old cookie
- Location: e2e/restore.spec.ts:189:1

# Error details

```
Test timeout of 30000ms exceeded.
```

```
Error: page.goBack: Test timeout of 30000ms exceeded.
Call log:
  - waiting for navigation until "load"
    - navigated to "http://localhost:4173/start"

```

# Page snapshot

```yaml
- generic [ref=f2e3]:
  - button "본문으로 이동" [ref=f2e4]
  - banner [ref=f2e5]:
    - link "BODYGUARD 서비스 소개" [ref=f2e6] [cursor=pointer]:
      - /url: /
      - text: BODYGUARD.
    - navigation "계정 메뉴" [ref=f2e7]:
      - link "로그인" [ref=f2e8] [cursor=pointer]:
        - /url: /login
  - main [ref=f2e9]:
    - generic [ref=f2e10]:
      - complementary [ref=f2e11]:
        - paragraph [ref=f2e12]: BODYGUARD / MY ACCOUNT
        - heading "일상에 맞춘 몸 돌보기." [level=2] [ref=f2e13]: 일상에 맞춘몸 돌보기.
        - paragraph [ref=f2e14]: 노트북 웹캠 한 대로 시작하는스트레칭과 자세 코칭.
        - generic [ref=f2e15]:
          - generic [ref=f2e16]: "01"
          - paragraph [ref=f2e17]: 카메라는 직접 시작할 때만 켜집니다.원본 영상은 저장하거나 전송하지 않습니다.
        - paragraph [ref=f2e18]: 현재 개발 중인 웹입니다.출시 전 기능·안전·개인정보 검증을 진행하고 있습니다.
      - generic [ref=f2e19]:
        - paragraph [ref=f2e20]: 로그인
        - heading "다시 만나 반갑습니다" [active] [level=1] [ref=f2e21]
        - paragraph [ref=f2e22]: 이메일로 내 계정에 로그인하세요.
        - generic [ref=f2e23]:
          - button "Google로 계속하기" [disabled] [ref=f2e24]
          - status [ref=f2e26]: 구글 연결을 준비하고 있습니다. 이메일로 계속해 주세요.
          - paragraph [ref=f2e27]: 또는 이메일로
        - generic [ref=f2e28]:
          - generic [ref=f2e29]:
            - text: 이메일
            - textbox "이메일" [ref=f2e30]
          - generic [ref=f2e31]: 비밀번호
          - generic [ref=f2e32]:
            - textbox "비밀번호" [ref=f2e33]
            - button "비밀번호 표시" [ref=f2e34] [cursor=pointer]: 표시
          - button "로그인" [ref=f2e35] [cursor=pointer]
        - paragraph [ref=f2e36]:
          - text: 처음 오셨나요?
          - link "이메일로 가입" [ref=f2e37] [cursor=pointer]:
            - /url: /signup?next=%2Fstart
        - paragraph [ref=f2e38]:
          - link "비밀번호를 잊으셨나요?" [ref=f2e39] [cursor=pointer]:
            - /url: /password/forgot
        - link "서비스 소개로 돌아가기" [ref=f2e40] [cursor=pointer]:
          - /url: /
  - contentinfo [ref=f2e41]:
    - generic [ref=f2e42]: BODYGUARD
    - paragraph [ref=f2e43]: 일상을 위한 스트레칭과 자세 코칭 · 출시 준비 중
    - navigation "서비스 안내" [ref=f2e44]:
      - link "도움말" [ref=f2e45] [cursor=pointer]:
        - /url: /help
      - link "카메라·데이터 안내" [ref=f2e46] [cursor=pointer]:
        - /url: /data
```

# Test source

```ts
  119 |       route.fulfill({ status, json: { logged_out: true } }),
  120 |     )
  121 |     await page.getByRole('button', { name: '로그아웃', exact: true }).click()
  122 |     await expect(
  123 |       page.getByRole('heading', { name: '로그아웃을 확인하지 못했습니다' }),
  124 |     ).toBeVisible()
  125 |     expect((await context.request.get('/api/v1/me')).status()).toBe(200)
  126 |     await page.unroute('**/api/v1/auth/logout')
  127 |     const documentId = await page.evaluate(() => {
  128 |       window.__accountRestoreProbe.blocked = true
  129 |       return window.__accountRestoreProbe.document
  130 |     })
  131 |     await page.goto('/help')
  132 |     expect(
  133 |       await page.evaluate((id) => window.__accountRestoreProbe.document !== id, documentId),
  134 |     ).toBe(true)
  135 |     await page.goBack()
  136 |     await expect.poll(() => page.evaluate(() => window.__accountRestoreProbe.restored)).toBe(1)
  137 |     const sameDocument = await page.evaluate(
  138 |       (id) => window.__accountRestoreProbe.document === id,
  139 |       documentId,
  140 |     )
  141 |     expect(sameDocument).toBe(true)
  142 |     await expect.poll(() => page.evaluate(() => window.__accountRestoreProbe.settled)).toBe(true)
  143 |     const observation = await page.evaluate(() => ({
  144 |       nativePersistedRestores: window.__accountRestoreProbe.restored,
  145 |       leaks: window.__accountRestoreProbe.leaks,
  146 |     }))
  147 |     const emailVisible = await page.getByText(email, { exact: true }).isVisible()
  148 |     await info.attach('restored-boundary.json', {
  149 |       contentType: 'application/json',
  150 |       body: Buffer.from(
  151 |         JSON.stringify({
  152 |           statusInjected: status,
  153 |           sameDocument,
  154 |           ...observation,
  155 |           emailVisible,
  156 |           observationWindowMs: 500,
  157 |           actualWebHttpSql: true,
  158 |           actualCache: true,
  159 |           actualCamera: false,
  160 |           cameraCalls,
  161 |           unexpected,
  162 |           errors,
  163 |           browserVersion: context.browser()?.version(),
  164 |         }),
  165 |       ),
  166 |     })
  167 |     await page.screenshot({ path: info.outputPath('restored-page.png'), fullPage: true })
  168 |     expect(observation.leaks).toBe(0)
  169 |     await expect(
  170 |       page.getByRole('heading', { name: '로그아웃을 확인하지 못했습니다' }),
  171 |     ).toBeVisible()
  172 |     await expect(page.getByText(email, { exact: true })).toHaveCount(0)
  173 |     const confirmed = page.waitForResponse(
  174 |       (response) => new URL(response.url()).pathname === '/api/v1/auth/logout',
  175 |     )
  176 |     await page.getByRole('button', { name: '로그아웃 다시 시도' }).click()
  177 |     expect((await confirmed).status()).toBe(204)
  178 |     await expect(page).toHaveURL(/\/login/)
  179 |     expect(
  180 |       (
  181 |         await context.request.get('/api/v1/me', {
  182 |           headers: { Cookie: `bodyguard_session=${old?.value}` },
  183 |         })
  184 |       ).status(),
  185 |     ).toBe(401)
  186 |   })
  187 | }
  188 | 
  189 | test('AR-WEB actual cached ready page still rechecks a server-revoked old cookie', async ({
  190 |   page,
  191 |   context,
  192 |   request,
  193 | }, info) => {
  194 |   const email = await join(context)
  195 |   await page.goto('/start')
  196 |   await expect(page.getByText(email, { exact: true })).toBeVisible()
  197 |   const old = (await context.cookies()).find((cookie) => cookie.name === 'bodyguard_session')
  198 |   expect(Boolean(old?.httpOnly)).toBe(true)
  199 |   const documentId = await page.evaluate(() => window.__accountRestoreProbe.document)
  200 |   await page.goto('/help')
  201 |   // Isolated HTTP context revokes server session; original browser cookie is not modified.
  202 |   const cookie = `bodyguard_session=${old?.value}`
  203 |   const csrfResponse = await request.get('/api/v1/auth/csrf', { headers: { Cookie: cookie } })
  204 |   expect(csrfResponse.status()).toBe(200)
  205 |   const csrf = await csrfResponse.json()
  206 |   expect(
  207 |     (
  208 |       await request.post('/api/v1/auth/logout', {
  209 |         headers: {
  210 |           Cookie: cookie,
  211 |           Origin: origin,
  212 |           'X-CSRF-Token': csrf.csrf_token,
  213 |         },
  214 |       })
  215 |     ).status(),
  216 |   ).toBe(204)
  217 |   const unchanged = (await context.cookies()).find((value) => value.name === 'bodyguard_session')
  218 |   expect(Boolean(unchanged?.value && unchanged.value === old?.value)).toBe(true)
> 219 |   await page.goBack()
      |              ^ Error: page.goBack: Test timeout of 30000ms exceeded.
  220 |   await expect.poll(() => page.evaluate(() => window.__accountRestoreProbe.restored)).toBe(1)
  221 |   const sameDocument = await page.evaluate(
  222 |     (id) => window.__accountRestoreProbe.document === id,
  223 |     documentId,
  224 |   )
  225 |   expect(sameDocument).toBe(true)
  226 |   await expect(page).toHaveURL(/\/login/)
  227 |   await expect(page.getByText(email, { exact: true })).toHaveCount(0)
  228 |   expect((await context.request.get('/api/v1/me')).status()).toBe(401)
  229 |   await info.attach('fresh-authority.json', {
  230 |     contentType: 'application/json',
  231 |     body: Buffer.from(
  232 |       JSON.stringify({
  233 |         sameDocument,
  234 |         nativePersistedRestores: 1,
  235 |         actualLogout204: true,
  236 |         unchangedBrowserCookie: true,
  237 |         nativeMe401: true,
  238 |         cameraCalls,
  239 |         unexpected,
  240 |         errors,
  241 |         browserVersion: context.browser()?.version(),
  242 |       }),
  243 |     ),
  244 |   })
  245 | })
  246 | 
```