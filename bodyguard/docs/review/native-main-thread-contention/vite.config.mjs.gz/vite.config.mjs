export default {
  root: "/Applications/학교 내부/2026-2학기/오픈소스 AI SW 융합 프로젝트/BODYGUARD-native-main-thread-contention/bodyguard/frontend",
  publicDir: false,
  worker: { format: 'iife' },
  build: {
    outDir: "/private/tmp/bodyguard-startup-failure-proof.PgbRzl/probe", emptyOutDir: false, minify: false,
    lib: { entry: 'e2e/fixtures/nativeContentionProbe.ts', formats: ['es'], fileName: () => 'probe.js' },
  },
}
