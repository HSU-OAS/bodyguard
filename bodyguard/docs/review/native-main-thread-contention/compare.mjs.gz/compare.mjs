// Private serial diagnostic. Only fixed labels, aggregate technical counts and timings.
import assert from 'node:assert/strict'
import { createServer } from 'node:http'
import { readFileSync, writeFileSync } from 'node:fs'
import { createHash } from 'node:crypto'
import { spawnSync } from 'node:child_process'
import { chromium } from "/Applications/학교 내부/2026-2학기/오픈소스 AI SW 융합 프로젝트/BODYGUARD-native-main-thread-contention/bodyguard/frontend/node_modules/@playwright/test/index.mjs"
const work="/Applications/학교 내부/2026-2학기/오픈소스 AI SW 융합 프로젝트/BODYGUARD-native-main-thread-contention", proof="/private/tmp/bodyguard-startup-failure-proof.PgbRzl", asset="/Applications/학교 내부/2026-2학기/오픈소스 AI SW 융합 프로젝트/BODYGUARD-captured-neck-input/bodyguard/frontend/public"
const sha = value => createHash('sha256').update(value).digest('hex')
const label=process.argv[2]
assert(/^[a-z-]+$/.test(label))
const probe=readFileSync(proof+'/probe/probe.js')
const workerFiles=[...new Set(probe.toString().match(/nativeInference\.worker-[\w-]+\.js/g)??[])]
assert.equal(workerFiles.length,1)
const worker=workerFiles[0]
const glbs={}
for(const gender of ['male','female']) {
  const result=spawnSync('git',['show','25a9bd6:bodyguard/frontend/src/avatar/models/bodyguard-'+gender+'-candidate-a37.glb'],{cwd:work,maxBuffer:20*1024*1024})
  assert.equal(result.status,0)
  glbs[gender]=result.stdout
}
const errors=[], external=[], results=[], requested=new Set()
const server=createServer((req,res)=>{
  const path=new URL(req.url,'http://localhost').pathname
  requested.add(path)
  res.setHeader('Content-Security-Policy',"connect-src 'self'; worker-src 'self'")
  if(path==='/') {
    res.setHeader('Content-Type','text/html')
    res.end('<!doctype html><html lang="ko"><body><canvas id="stage"></canvas><script type="module">import{mountNativeContentionProbe}from"/probe.js";window.mount=mountNativeContentionProbe</script></body></html>')
    return
  }
  let data, type='application/octet-stream'
  if(path==='/probe.js') { data=probe; type='application/javascript' }
  else if(path==='/assets/'+worker) { data=readFileSync(proof+'/probe/assets/'+worker); type='application/javascript' }
  else if(/^\/mediapipe\/wasm\/vision_wasm_(?:module_|nosimd_)?internal\.(?:js|wasm)$/.test(path)) {
    data=readFileSync(asset+path);type=path.endsWith('.js')?'application/javascript':'application/wasm'
  } else if(/^\/models\/(?:pose_landmarker_lite|face_landmarker|gesture_recognizer)\.task$/.test(path)) data=readFileSync(asset+path)
  else if(path==='/__private-native-male.glb')data=glbs.male
  else if(path==='/__private-native-female.glb')data=glbs.female
  else {res.writeHead(404);res.end();return}
  res.setHeader('Content-Type',type);res.end(data)
})
await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve))
const origin='http://127.0.0.1:'+server.address().port
const browser=await chromium.launch({channel:'chrome',args:['--use-fake-device-for-media-stream','--use-fake-ui-for-media-stream']})
// Order fixed before first execution. Separate contexts, one browser and zero retries.
const plan=[
  ['male','main',1],['male','worker',1],
  ['male','worker',4],['male','main',4],
  ['female','worker',1],['female','main',1],
  ['female','main',4],['female','worker',4],
]
let harnessFailed=false
try {
  for(const [gender,thread,rate] of plan) {
    const context=await browser.newContext({viewport:{width:1440,height:1000},permissions:['camera'],serviceWorkers:'block'})
    const page=await context.newPage(), cdp=await context.newCDPSession(page)
    const item={gender,thread,rate,harnessPassed:false}
    await context.route('**/*',route=>{
      if(route.request().url().startsWith(origin+'/'))return route.continue()
      external.push('blocked-external');return route.abort()
    })
    page.on('pageerror',e=>errors.push(e.name))
    await context.addInitScript(()=>{
      const get=navigator.mediaDevices.getUserMedia.bind(navigator.mediaDevices)
      const tracks=[]
      let cameras=0, workers=0, terminations=0
      navigator.mediaDevices.getUserMedia=async options=>{
        const stream=await get(options);cameras++
        tracks.push(...stream.getTracks());return stream
      }
      const NativeWorker=Worker
      globalThis.Worker=class extends NativeWorker {
        constructor(...args){super(...args);workers++}
        terminate(){terminations++;return super.terminate()}
      }
      window.cleanupSnapshot=()=>({cameras,workers,terminations,tracksEnded:tracks.length>0&&tracks.every(track=>track.readyState==='ended'),storageKeys:localStorage.length+sessionStorage.length})
    })
    try {
      await page.goto(origin)
      await page.waitForFunction(()=>typeof window.mount==='function',null,{timeout:5000})
      await cdp.send('Emulation.setCPUThrottlingRate',{rate})
      await page.evaluate(([gender,thread])=>{window.probe=window.mount(document.querySelector('canvas'),gender,thread);void window.probe.begin()},[gender,thread])
      // Observation only: acquisition waits don't replace the five-second post-ready window.
      await page.waitForFunction(()=>['running','failed'].includes(window.probe.snapshot().state),null,{timeout:30000})
      const ready=await page.evaluate(()=>window.probe.snapshot())
      item.ready=ready
      if(ready.state==='running') {
        const started=Date.now()
        await new Promise(resolve=>setTimeout(resolve,5000))
        item.observed=await page.evaluate(()=>window.probe.snapshot())
        item.nodeObservationMs=Date.now()-started
        item.thirdWithinWindow=item.observed.thirdMs!==null&&item.observed.thirdMs<=5000
      }else item.thirdWithinWindow=false
      item.final=await page.evaluate(()=>window.probe.close())
      item.cleanup=await page.evaluate(()=>window.cleanupSnapshot())
      assert.equal(item.cleanup.cameras,1)
      assert.equal(item.cleanup.workers,thread==='worker'?1:0)
      assert.equal(item.cleanup.terminations,item.cleanup.workers)
      assert(item.cleanup.tracksEnded)
      assert.equal(item.cleanup.storageKeys,0)
      assert(item.final.closed)
      // A measured latency or preparation failure is evidence, not a harness success claim.
      item.harnessPassed=true
    }catch(e){item.error=e.name;harnessFailed=true;await page.evaluate(()=>window.probe?.close()).catch(()=>{})}
    finally{await cdp.send('Emulation.setCPUThrottlingRate',{rate:1}).catch(()=>{});await context.close();results.push(item)}
  }
}finally{
  await browser.close();await new Promise(resolve=>server.close(resolve))
  const report={
    timestamp:new Date().toISOString(),scope:'private actual native ports / SDK / two original GLBs; fake camera / CDP slowdown; not Auth/PR90/human/physical notebook gate',
    source:sha(readFileSync(work+'/bodyguard/frontend/e2e/fixtures/nativeContentionProbe.ts')),
    probe:sha(probe),worker:{file:worker,sha256:sha(readFileSync(proof+'/probe/assets/'+worker))},
    glbs:Object.fromEntries(Object.entries(glbs).map(([key,bytes])=>[key,sha(bytes)])),
    plan,retries:0,results,externalRequests:external.length,pageErrors:errors,requestedPaths:[...requested],
    actualPeople:0,physicalCameras:0,originalNativeClosesGateRun:false,productDefaultChanged:false,
  }
  writeFileSync(proof+'/comparison-'+label+'.json',JSON.stringify(report,null,2)+'\n',{flag:'wx'})
  console.log(JSON.stringify(results.map(item=>({gender:item.gender,thread:item.thread,rate:item.rate,state:item.ready?.state,thirdMs:item.observed?.thirdMs,readyMs:item.ready?.readyMs,maxGapMs:item.observed?.maxGapMs,runningMaxGapMs:item.observed?.runningMaxGapMs,renders:item.observed?.renders,thirdWithinWindow:item.thirdWithinWindow,cleanup:item.cleanup,harnessPassed:item.harnessPassed,error:item.error}))))
}
if(harnessFailed||external.length||errors.length)process.exitCode=1
