// Mechanical lossless evidence packaging. Does not execute product or inspect camera values.
import assert from 'node:assert/strict'
import { createHash } from 'node:crypto'
import { readdirSync, readFileSync, mkdirSync, writeFileSync } from 'node:fs'
import { gzipSync } from 'node:zlib'
import { execFileSync } from 'node:child_process'
const root="/Applications/학교 내부/2026-2학기/오픈소스 AI SW 융합 프로젝트/BODYGUARD-native-main-thread-contention", proof="/private/tmp/bodyguard-startup-failure-proof.PgbRzl", out=root+'/bodyguard/docs/review/native-main-thread-contention'
const sha=bytes=>createHash('sha256').update(bytes).digest('hex')
mkdirSync(out,{recursive:true})
const files=[]
const evidence=readdirSync(proof).filter(name=>/\.(?:json|mjs|txt)$/.test(name)&&name!=='preserve.mjs')
evidence.push('preserve.mjs')
for(const name of evidence.sort()) {
  const bytes=readFileSync(proof+'/'+name), zipped=gzipSync(bytes,{level:9}), file=name+'.gz'
  writeFileSync(out+'/'+file,zipped,{flag:'wx'})
  files.push({source:proof+'/'+name,file,bytes:bytes.length,sha256:sha(bytes),compressedSha256:sha(zipped)})
}
const bundled=['probe/probe.js',...readdirSync(proof+'/probe/assets').map(name=>'probe/assets/'+name)]
for(const name of bundled) {
  const bytes=readFileSync(proof+'/'+name), zipped=gzipSync(bytes,{level:9}), file=name.replaceAll('/','-')+'.gz'
  writeFileSync(out+'/'+file,zipped,{flag:'wx'})
  files.push({source:proof+'/'+name,file,bytes:bytes.length,sha256:sha(bytes),compressedSha256:sha(zipped)})
}
const sourcePaths=[
  'bodyguard/frontend/e2e/fixtures/nativeContentionProbe.ts',
  'bodyguard/frontend/src/coaching/nativePlaybackResources.ts',
  'bodyguard/frontend/src/coaching/ownedPlaybackResources.ts',
  'bodyguard/frontend/src/avatar/ownedPosePlayback.ts',
  'bodyguard/frontend/src/avatar/ownedAvatarPair.ts',
  'bodyguard/frontend/src/pose/workerInference.ts',
  'bodyguard/frontend/src/pose/workerNativeEngine.ts',
  'bodyguard/frontend/src/pose/workerInferenceRuntime.ts',
  'bodyguard/frontend/src/pose/constants.ts',
  'bodyguard/frontend/src/pose/bodyHandVideoSource.ts',
  'bodyguard/frontend/src/pose/camera.ts',
]
const sources=sourcePaths.map(path=>{
  const bytes=readFileSync(root+'/'+path), file='source-'+path.split('/').at(-1)+'.gz', zipped=gzipSync(bytes,{level:9})
  writeFileSync(out+'/'+file,zipped,{flag:'wx'})
  const base=path.includes('/e2e/')?null:sha(execFileSync('git',['show','fc70b9d:'+path],{cwd:root}))
  if(base)assert.equal(sha(bytes),base)
  return {path,file,bytes:bytes.length,sha256:sha(bytes),compressedSha256:sha(zipped),baseSha256:base}
})
const assets=readdirSync(root+'/bodyguard/frontend/dist/assets').filter(name=>/\.(?:js|css)$/.test(name)).map(name=>{
  const bytes=readFileSync(root+'/bodyguard/frontend/dist/assets/'+name)
  return {path:'dist/assets/'+name,bytes:bytes.length,sha256:sha(bytes)}
})
assert(assets.some(value=>value.sha256==='b5d4f81164c8d3c196e853b3404382bc15077986aa626cd0c3c72571b6325ac0'))
assert(assets.some(value=>value.sha256==='043cb9bdb5d82a3baa9a8463c7a641cbe92ace213303f20c6c7f91e9a14ac82e'))
const manifest={timestamp:new Date().toISOString(),base:'fc70b9d919d2ed3e120eeb935e61f17da8a2e61f',files,sources,publicAssets:assets,productSourceChanged:false,originalNativeGateRun:false,actualPeople:0}
writeFileSync(out+'/manifest.json',JSON.stringify(manifest,null,2)+'\n',{flag:'wx'})
console.log(JSON.stringify({files:files.length,sources:sources.length,assets,productSourceChanged:false}))
