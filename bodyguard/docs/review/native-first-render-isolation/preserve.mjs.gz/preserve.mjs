// Mechanical lossless evidence packaging. No product execution or camera values.
import assert from 'node:assert/strict'
import { createHash } from 'node:crypto'
import { readdirSync, readFileSync, mkdirSync, writeFileSync } from 'node:fs'
import { gzipSync } from 'node:zlib'
import { execFileSync } from 'node:child_process'
const root="/Applications/학교 내부/2026-2학기/오픈소스 AI SW 융합 프로젝트/BODYGUARD-native-main-thread-contention", proof='/private/tmp/bodyguard-first-render-proof.Qk7UI0'
const out=root+'/bodyguard/docs/review/native-first-render-isolation'
const base='600f930d0ad5eda5fc975f497e575160f4b86f49'
const sha=bytes=>createHash('sha256').update(bytes).digest('hex')
mkdirSync(out,{recursive:true})
const files=[]
function preserve(name,bytes,source) {
  const file=name.replaceAll('/','-')+'.gz', compressed=gzipSync(bytes,{level:9})
  writeFileSync(out+'/'+file,compressed,{flag:'wx'})
  return {source,file,bytes:bytes.length,sha256:sha(bytes),compressedSha256:sha(compressed)}
}
for(const name of readdirSync(proof).filter(name=>/\.(?:json|mjs|txt|ts)$/.test(name)).sort())
  files.push(preserve(name,readFileSync(proof+'/'+name),proof+'/'+name))
for(const folder of ['probe-baseline','probe-shader-only','probe-reviewed','probe']) {
  for(const name of ['probe.js',...readdirSync(proof+'/'+folder+'/assets').map(name=>'assets/'+name)]) {
    const path=folder+'/'+name
    files.push(preserve(path,readFileSync(proof+'/'+path),proof+'/'+path))
  }
}
const changed=new Set([
  'bodyguard/frontend/e2e/fixtures/nativeContentionProbe.ts',
  'bodyguard/frontend/src/coaching/nativePlaybackResources.ts',
  'bodyguard/frontend/src/coaching/nativePlaybackResources.test.ts',
])
const paths=[...changed,
  'bodyguard/frontend/src/coaching/ownedPlaybackResources.ts',
  'bodyguard/frontend/src/coaching/resources.ts',
  'bodyguard/frontend/src/avatar/ownedAvatarPair.ts',
  'bodyguard/frontend/src/avatar/ownedPosePlayback.ts',
  'bodyguard/frontend/src/pose/workerInference.ts',
  'bodyguard/frontend/src/pose/workerNativeEngine.ts',
  'bodyguard/frontend/src/pose/workerInferenceRuntime.ts',
  'bodyguard/frontend/src/pose/bodyHandVideoSource.ts',
  'bodyguard/frontend/src/pose/camera.ts',
  'bodyguard/frontend/src/pose/constants.ts',
]
const sources=paths.map(path=>{
  const bytes=readFileSync(root+'/'+path)
  const old=execFileSync('git',['show',base+':'+path],{cwd:root})
  if(!changed.has(path))assert.equal(sha(bytes),sha(old))
  else files.push(preserve('base-'+path.split('/').at(-1),old,base+':'+path))
  return {...preserve('source-'+path.split('/').at(-1),bytes,path),path,baseSha256:sha(old),changed:sha(bytes)!==sha(old)}
})
const publicAssets=readdirSync(root+'/bodyguard/frontend/dist/assets').filter(name=>/\.(?:js|css)$/.test(name)).map(name=>{
  const bytes=readFileSync(root+'/bodyguard/frontend/dist/assets/'+name)
  return {path:'dist/assets/'+name,bytes:bytes.length,sha256:sha(bytes)}
})
assert(publicAssets.some(v=>v.bytes===355151&&v.sha256==='b5d4f81164c8d3c196e853b3404382bc15077986aa626cd0c3c72571b6325ac0'))
assert(publicAssets.some(v=>v.bytes===31199&&v.sha256==='043cb9bdb5d82a3baa9a8463c7a641cbe92ace213303f20c6c7f91e9a14ac82e'))
const sdkAssets=[]
const cache='/Applications/학교 내부/2026-2학기/오픈소스 AI SW 융합 프로젝트/BODYGUARD-captured-neck-input/bodyguard/frontend/public'
for(const folder of ['models','mediapipe/wasm'])
  for(const name of readdirSync(cache+'/'+folder).filter(n=>/\.(?:task|wasm|js)$/.test(n)).sort()) {
    const path=folder+'/'+name, original=readFileSync(cache+'/'+path)
    assert.equal(sha(readFileSync(root+'/bodyguard/frontend/public/'+path)),sha(original))
    sdkAssets.push({path,bytes:original.length,sha256:sha(original)})
  }
assert.equal(sdkAssets.filter(v=>v.path.endsWith('.task')).length,5)
assert.equal(sdkAssets.filter(v=>v.path.startsWith('mediapipe/wasm/')).length,6)
const glbs=['male','female'].map(gender=>{
  const path='bodyguard/frontend/src/avatar/models/bodyguard-'+gender+'-candidate-a37.glb'
  const original=execFileSync('git',['show','25a9bd6:'+path],{cwd:root,maxBuffer:32*1024*1024})
  assert.equal(sha(original),sha(execFileSync('git',['show',base+':'+path],{cwd:root,maxBuffer:32*1024*1024})))
  return {path,bytes:original.length,sha256:sha(original),source:'25a9bd6'}
})
const manifest={timestamp:new Date().toISOString(),base,files,sources,publicAssets,sdkAssets,glbs,productSourceChanged:true,productDefaultChanged:false,originalNativeGateRun:false,actualPeople:0,physicalCameras:0}
writeFileSync(out+'/manifest.json',JSON.stringify(manifest,null,2)+'\n',{flag:'wx'})
console.log(JSON.stringify({files:files.length,sources:sources.length,publicAssets,sdkAssets:sdkAssets.length,glbs,productSourceChanged:true}))
