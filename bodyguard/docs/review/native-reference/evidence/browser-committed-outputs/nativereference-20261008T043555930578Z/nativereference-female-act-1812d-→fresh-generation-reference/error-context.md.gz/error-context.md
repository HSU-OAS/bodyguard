# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: nativereference.spec.ts >> female actual owned phase→pause→fresh generation reference
- Location: e2e/nativehead.spec.ts:292:5

# Error details

```
Error: expect(received).toBeLessThan(expected)

Expected: < 0.000002
Received:   0.38881529027959577
```

# Page snapshot

```yaml
- generic [ref=e1]:
  - generic [ref=e3]:
    - button "본문으로 이동" [ref=e4]
    - banner [ref=e5]:
      - link "BODYGUARD 서비스 소개" [ref=e6] [cursor=pointer]:
        - /url: /
        - text: BODYGUARD.
      - navigation "계정 메뉴" [ref=e7]:
        - link "내 시작" [ref=e8] [cursor=pointer]:
          - /url: /start
        - link "자세 기록" [ref=e9] [cursor=pointer]:
          - /url: /posture-records
        - link "수행 기록" [ref=e10] [cursor=pointer]:
          - /url: /records
        - link "내 계정" [ref=e11] [cursor=pointer]:
          - /url: /account
    - main [ref=e12]:
      - generic [ref=e13]:
        - paragraph [ref=e14]: MY BODYGUARD
        - heading "내 몸을 위한 시작" [active] [level=1] [ref=e15]
        - paragraph [ref=e16]: native-auth-a7cd96b1-2580-4058-a1a3-3437bf231001@example.com
        - link "스트레칭 시작 경로 선택" [ref=e17] [cursor=pointer]:
          - /url: /explore
        - paragraph [ref=e18]:
          - link "내 수행 기록 확인" [ref=e19] [cursor=pointer]:
            - /url: /records
        - paragraph [ref=e20]:
          - link "내 자세 기록 확인" [ref=e21] [cursor=pointer]:
            - /url: /posture-records
        - paragraph [ref=e22]:
          - link "계정 관리" [ref=e23] [cursor=pointer]:
            - /url: /account
        - generic [ref=e24]:
          - heading "첫 코칭 흐름을 준비하고 있습니다" [level=2] [ref=e25]
          - paragraph [ref=e26]: 동작 검증과 남녀 3D 아바타 제작이 끝나면 스트레칭 선택과 코칭을 이곳에 연결합니다. 지금은 계정 기능을 사용할 수 있습니다.
          - paragraph [ref=e27]: 카메라는 켜지지 않았습니다.
        - button "로그아웃" [ref=e28] [cursor=pointer]
    - contentinfo [ref=e29]:
      - generic [ref=e30]: BODYGUARD
      - paragraph [ref=e31]: 일상을 위한 스트레칭과 자세 코칭 · 출시 준비 중
      - navigation "서비스 안내" [ref=e32]:
        - link "도움말" [ref=e33] [cursor=pointer]:
          - /url: /help
        - link "카메라·데이터 안내" [ref=e34] [cursor=pointer]:
          - /url: /data
  - paragraph [ref=e35]: 미완성 A37 · 가짜 카메라 · native 계정 시험 · 코칭 아님
```

# Test source

```ts
  218 |     nativeCalls: 0,
  219 |     models: 0,
  220 |   })
  221 |   expect(posts).toBe(0)
  222 | }
  223 | async function running(page: Page) {
  224 |   await page.evaluate(() => (window as unknown as PrivateWindow).nativeAuthProbe.start())
  225 |   await expect.poll(async () => (await state(page)).nativeCloses).toBeGreaterThanOrEqual(3)
  226 |   const value = await mark(page, 'native-running')
  227 |   expect(value.session).toBe('running')
  228 |   expect(value.resources?.status).toBe('running')
  229 |   expect(value.models).toBe(2)
  230 |   expect(value.framing).toEqual([true, true])
  231 |   expect(value.cameraLive && value.rawVideoHidden).toBe(true)
  232 |   expect(value.handsConfigured).toBe(withHands)
  233 |   expect(value.handCalls).toBe(withHands ? value.nativeCalls : 0)
  234 |   expect(value.nativeHandsMax).toBe(0)
  235 | }
  236 | async function hold(page: Page) {
  237 |   await page.evaluate(() => (window as unknown as PrivateWindow).nativeAuthProbe.holdNextResult())
  238 |   await expect.poll(() => state(page)).toMatchObject({ held: true })
  239 |   const value = await mark(page, 'native-result-held')
  240 |   expect(value.nativeCloses).toBe(value.nativeCalls - 1)
  241 |   expect(value.heldStage).toBe(withHands ? 'hands' : 'face')
  242 |   expect(value.faceCalls).toBe(value.nativeCalls)
  243 |   expect(value.handCalls).toBe(withHands ? value.nativeCalls : 0)
  244 | }
  245 | async function revokedWhileHeld(page: Page) {
  246 |   const value = await mark(page, 'authority-revoked-while-native-held')
  247 |   expect(value.owned).toBe(false)
  248 |   expect(value.cameraLive && value.held).toBe(true)
  249 |   if (withReference)
  250 |     expect(
  251 |       await page.evaluate(() => (window as unknown as PrivateWindow).nativeAuthProbe.oldCommand()),
  252 |     ).toBe(false)
  253 |   const renders = value.renderFrames,
  254 |     calls = value.nativeCalls
  255 |   await page.evaluate(
  256 |     () => new Promise((resolve) => requestAnimationFrame(() => requestAnimationFrame(resolve))),
  257 |   )
  258 |   expect(await state(page)).toMatchObject({
  259 |     renderFrames: renders,
  260 |     nativeCalls: calls,
  261 |     detectorCloses: 0,
  262 |     faceDetectorCloses: 0,
  263 |     handDetectorCloses: 0,
  264 |     handCalls: value.handCalls,
  265 |     faceCalls: value.faceCalls,
  266 |     cameraCloses: 0,
  267 |   })
  268 |   await page.evaluate(() => (window as unknown as PrivateWindow).nativeAuthProbe.beginOldActions())
  269 |   expect(posts).toBe(0)
  270 | }
  271 | async function release(page: Page) {
  272 |   await page.evaluate(() =>
  273 |     (window as unknown as PrivateWindow).nativeAuthProbe.releaseHeldResult(),
  274 |   )
  275 |   await expect
  276 |     .poll(() => state(page))
  277 |     .toMatchObject({
  278 |       held: false,
  279 |       tracksEnded: true,
  280 |       detectorCloses: 1,
  281 |       faceDetectorCloses: 1,
  282 |       handDetectorCloses: withHands ? 1 : 0,
  283 |       cameraCloses: 1,
  284 |       models: 0,
  285 |     })
  286 |   await mark(page, 'native-input-result-and-resources-closed')
  287 |   await page.evaluate(() => (window as unknown as PrivateWindow).nativeAuthProbe.finishOldActions())
  288 |   expect(posts).toBe(0)
  289 | }
  290 | for (const gender of ['male', 'female'] as const) {
  291 |   if (withReference)
  292 |     test(`${gender} actual owned phase→pause→fresh generation reference`, async ({
  293 |       page,
  294 |       context,
  295 |     }, info) => {
  296 |       await join(context)
  297 |       await mount(page, gender)
  298 |       await running(page)
  299 |       const pulse = async (ms: number) => {
  300 |         const end = Date.now() + ms
  301 |         while (Date.now() < end) {
  302 |           await page.evaluate(() => (window as unknown as PrivateWindow).nativeAuthProbe.tick())
  303 |           await page.waitForTimeout(80)
  304 |         }
  305 |       }
  306 |       await page.evaluate(() =>
  307 |         (window as unknown as PrivateWindow).nativeAuthProbe.observe('start'),
  308 |       )
  309 |       await pulse(1300)
  310 |       const seeking = await mark(page, 'owned-seeking-target-guide')
  311 |       expect(seeking).toMatchObject({
  312 |         phase: 'seeking-target',
  313 |         verifiedMs: 0,
  314 |         referenceMoved: true,
  315 |         userUnchanged: true,
  316 |       })
  317 |       expect(seeking.referenceTargetError).not.toBeNull()
> 318 |       expect(seeking.referenceTargetError as number).toBeLessThan(2e-6)
      |                                                      ^ Error: expect(received).toBeLessThan(expected)
  319 |       await page
  320 |         .locator('#native-avatar')
  321 |         .screenshot({ path: info.outputPath(`reference-${gender}-seeking.png`) })
  322 |       await page.evaluate(() =>
  323 |         (window as unknown as PrivateWindow).nativeAuthProbe.observe('target'),
  324 |       )
  325 |       await pulse(1300)
  326 |       const holding = await mark(page, 'owned-holding-guide-with-no-synthesized-progress')
  327 |       expect(holding).toMatchObject({ phase: 'holding', verifiedMs: 0, userUnchanged: true })
  328 |       expect(holding.referenceTargetError as number).toBeLessThan(2e-6)
  329 |       await page.waitForTimeout(700)
  330 |       await page.evaluate(() =>
  331 |         (window as unknown as PrivateWindow).nativeAuthProbe.markReference(),
  332 |       )
  333 |       await page.waitForTimeout(300)
  334 |       await expect.poll(() => state(page)).toMatchObject({ referenceFrozen: true, verifiedMs: 0 })
  335 |       await mark(page, 'cue-expired-guide-frozen')
  336 |       await page.evaluate(() =>
  337 |         (window as unknown as PrivateWindow).nativeAuthProbe.observe('target'),
  338 |       )
  339 |       expect(await state(page)).toMatchObject({ phase: 'waiting-return', verifiedMs: 2000 })
  340 |       await pulse(1300)
  341 |       const returned = await mark(page, 'owned-return-guide')
  342 |       expect(returned.referenceTargetError as number).toBeLessThan(2e-6)
  343 |       await page.evaluate(() => (window as unknown as PrivateWindow).nativeAuthProbe.pause())
  344 |       expect(await state(page)).toMatchObject({
  345 |         session: 'paused',
  346 |         models: 0,
  347 |         tracksEnded: true,
  348 |         verifiedMs: 2000,
  349 |       })
  350 |       await page.evaluate(() => (window as unknown as PrivateWindow).nativeAuthProbe.resume())
  351 |       await expect
  352 |         .poll(() => state(page))
  353 |         .toMatchObject({ session: 'running', sessionGeneration: 2, cameras: 2 })
  354 |       await pulse(300)
  355 |       expect(await state(page)).toMatchObject({
  356 |         phase: 'waiting-start',
  357 |         verifiedMs: 2000,
  358 |         userUnchanged: true,
  359 |       })
  360 |       await mark(page, 'fresh-generation-no-old-clip-resume')
  361 |     })
  362 |   test(`${gender} native start→stop→own interrupted record`, async ({ page, context }, info) => {
  363 |     await join(context)
  364 |     await mount(page, gender)
  365 |     await running(page)
  366 |     await page
  367 |       .locator('#native-avatar')
  368 |       .screenshot({ path: info.outputPath(`avatar-${gender}.png`) })
  369 |     await page.evaluate(() => (window as unknown as PrivateWindow).nativeAuthProbe.stop())
  370 |     const stopped = await mark(page, 'explicit-user-stop')
  371 |     expect(stopped.verifiedMs).toBe(0)
  372 |     expect(stopped.tracksEnded).toBe(true)
  373 |     expect(posts).toBe(0)
  374 |     await page.evaluate(() => (window as unknown as PrivateWindow).nativeAuthProbe.save())
  375 |     expect(await state(page)).toMatchObject({ record: 'saved' })
  376 |     expect(posts).toBe(1)
  377 |     const rows = (await (await context.request.get('/api/v1/records/stretch')).json()).items
  378 |     expect(rows).toHaveLength(1)
  379 |     expect(rows[0]).toMatchObject({
  380 |       id: stopped.recordId,
  381 |       outcome: 'interrupted',
  382 |       observed_ms: 0,
  383 |       repetitions: 0,
  384 |       provenance: 'client-reported',
  385 |     })
  386 |     await page.evaluate(() => (window as unknown as PrivateWindow).nativeAuthProbe.close())
  387 |     const closed = await mark(page, 'native-closed-before-public-record')
  388 |     expect(closed.tracksEnded && closed.detached && closed.allFramesClosed).toBe(true)
  389 |     expect(closed.frameCloses).toBe(closed.frames)
  390 |     expect(closed.nativeCloses).toBe(closed.nativeCalls)
  391 |     expect(closed.sameInput).toBe(true)
  392 |     expect(closed.faceCalls).toBe(closed.nativeCalls)
  393 |     expect(closed.faceDetectorCloses).toBe(closed.cameras)
  394 |     expect(closed.handCalls).toBe(withHands ? closed.nativeCalls : 0)
  395 |     expect(closed.handDetectorCloses).toBe(withHands ? closed.cameras : 0)
  396 |     expect(closed.nativeHandsMax).toBe(0)
  397 |     expect(closed.nativeFacesMax).toBe(0)
  398 |     expect(closed.productionAdapter).toBe(true)
  399 |     expect(closed.memory).toEqual(closed.baseline)
  400 |     await page.goto(`/records/${rows[0].id}`)
  401 |     await expect(page.getByRole('heading', { name: '수행 기록 상세', exact: true })).toBeVisible()
  402 |     await expect(page.getByText('중단', { exact: true })).toBeVisible()
  403 |     await page.screenshot({
  404 |       path: info.outputPath(`native-record-${gender}.png`),
  405 |       fullPage: true,
  406 |     })
  407 |   })
  408 |   test(`${gender} native held result→same-account refresh→new owner explicit restart`, async ({
  409 |     page,
  410 |     context,
  411 |   }) => {
  412 |     await join(context)
  413 |     await mount(page, gender)
  414 |     await running(page)
  415 |     await hold(page)
  416 |     await page.evaluate(() => (window as unknown as PrivateWindow).nativeAuthProbe.refresh())
  417 |     await expect
  418 |       .poll(() => state(page))
```