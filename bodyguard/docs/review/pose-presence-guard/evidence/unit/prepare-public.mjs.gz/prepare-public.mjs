import assert from 'node:assert/strict'
import {cpSync,existsSync,readdirSync,readFileSync,writeFileSync,mkdirSync} from 'node:fs'
import {createHash} from 'node:crypto'
import {join} from 'node:path'
const [previous,work,proof]=process.argv.slice(2);const sha=b=>createHash('sha256').update(b).digest('hex');
const report={assets:{},baseline:{}};
for(const part of ['mediapipe','models']){
const src=join(previous,'bodyguard/frontend/public',part),dst=join(work,'bodyguard/frontend/public',part);assert(existsSync(src));assert(!existsSync(dst));cpSync(src,dst,{recursive:true,errorOnExist:true,force:false});
for(const file of readdirSync(src,{recursive:true}).filter(f=>!f.endsWith('/')&&f.includes('.'))){
const source=join(src,file);if(file.endsWith('.task')||file.endsWith('.wasm')||file.endsWith('.js')){const bytes=readFileSync(source);assert(bytes.equals(readFileSync(join(dst,file))));report.assets[part+'/'+file]={bytes:bytes.length,sha:sha(bytes)};}}
}
mkdirSync(join(proof,'public-baseline'),{recursive:true});
for(const file of readdirSync(join(previous,'bodyguard/frontend/dist/assets')).filter(f=>/\.(js|css)$/.test(f))){
const bytes=readFileSync(join(previous,'bodyguard/frontend/dist/assets',file));writeFileSync(join(proof,'public-baseline',file),bytes,{flag:'wx'});report.baseline[file]={bytes:bytes.length,sha:sha(bytes)};}
writeFileSync(join(proof,'public-baseline.json'),JSON.stringify(report,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify(report));
