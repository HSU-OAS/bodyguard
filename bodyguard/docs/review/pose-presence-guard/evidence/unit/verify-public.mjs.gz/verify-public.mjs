import assert from 'node:assert/strict'
import {readFileSync,readdirSync,writeFileSync} from 'node:fs'
import {createHash} from 'node:crypto'
import {execFileSync} from 'node:child_process'
import {join} from 'node:path'
const [work,proof,browserProof]=process.argv.slice(2),sha=b=>createHash('sha256').update(b).digest('hex');
const frontend=join(work,'bodyguard/frontend'),baseline=JSON.parse(readFileSync(join(proof,'public-baseline.json'))),report={public:{},assets:{},glb:{}};
const actual=readdirSync(join(frontend,'dist/assets')).filter(f=>/\.(js|css)$/.test(f));assert.deepEqual(actual.sort(),Object.keys(baseline.baseline).sort());
for(const file of actual){const bytes=readFileSync(join(frontend,'dist/assets',file));assert(bytes.equals(readFileSync(join(proof,'public-baseline',file))));report.public[file]={bytes:bytes.length,sha:sha(bytes),unchanged:true};}
for(const [file,old] of Object.entries(baseline.assets)){const bytes=readFileSync(join(frontend,'public',file));assert.equal(sha(bytes),old.sha);report.assets[file]={...old,unchanged:true};}
for(const gender of ['male','female']){const bytes=readFileSync(join(browserProof,gender+'.glb'));const git=execFileSync('git',['show','25a9bd6c7392890e3b5d5d6ae1046bb7087d56ad:bodyguard/frontend/src/avatar/models/bodyguard-'+gender+'-candidate-a37.glb'],{cwd:work,maxBuffer:32*1024*1024});assert(bytes.equals(git));report.glb[gender]={sha:sha(bytes),unchanged:true};}
writeFileSync(join(proof,'public-verified.json'),JSON.stringify(report,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify(report));
