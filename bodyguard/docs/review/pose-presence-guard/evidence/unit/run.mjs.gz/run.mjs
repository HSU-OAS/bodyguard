import assert from 'node:assert/strict'
import {spawn} from 'node:child_process'
import {existsSync,writeFileSync} from 'node:fs'
import {dirname,join} from 'node:path'
import {fileURLToPath} from 'node:url'
const root=dirname(fileURLToPath(import.meta.url));
const [label,cwd,command,...args]=process.argv.slice(2);
assert(/^[a-z][a-z0-9-]*$/.test(label));
const prefix=join(root,label);
for(const suffix of ['.stdout.txt','.stderr.txt','.receipt.json'])assert(!existsSync(prefix+suffix));
const start=new Date().toISOString();let stdout='',stderr='';
const child=spawn(command,args,{cwd,env:process.env});
child.stdout.on('data',b=>{stdout+=b});child.stderr.on('data',b=>{stderr+=b});
const result=await new Promise(resolve=>{child.once('error',e=>resolve({exitCode:null,error:e.code}));child.once('close',(exitCode,signal)=>resolve({exitCode,signal}))});
writeFileSync(prefix+'.stdout.txt',stdout,{flag:'wx'});writeFileSync(prefix+'.stderr.txt',stderr,{flag:'wx'});
const receipt={label,cwd,command,args,start,end:new Date().toISOString(),...result};
writeFileSync(prefix+'.receipt.json',JSON.stringify(receipt,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify(receipt));if(stdout)console.log(stdout.slice(-5000));if(stderr)console.log(stderr.slice(-3000));
process.exitCode=result.exitCode===0?0:1;
