import assert from 'node:assert/strict'
import {execFileSync} from 'node:child_process'
import {createHash} from 'node:crypto'
import {writeFileSync,existsSync} from 'node:fs'
import {join} from 'node:path'
const [work,proof]=process.argv.slice(2);const hashes={};
for(const gender of ['male','female']){
const out=join(proof,gender+'.glb');assert(!existsSync(out));
const bytes=execFileSync('git',['show','25a9bd6c7392890e3b5d5d6ae1046bb7087d56ad:bodyguard/frontend/src/avatar/models/bodyguard-'+gender+'-candidate-a37.glb'],{cwd:work,maxBuffer:32*1024*1024});
writeFileSync(out,bytes,{flag:'wx'});hashes[gender]=createHash('sha256').update(bytes).digest('hex');}
writeFileSync(join(proof,'asset-sha.json'),JSON.stringify(hashes,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify(hashes));
