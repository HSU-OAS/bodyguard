import assert from 'node:assert/strict'
import {execFileSync} from 'node:child_process'
import {createHash} from 'node:crypto'
import {readFileSync,readdirSync,writeFileSync,mkdirSync,existsSync} from 'node:fs'
import {dirname,join} from 'node:path'
import {gzipSync,gunzipSync} from 'node:zlib'
const [work,proof,browserProof]=process.argv.slice(2),root=join(work,'bodyguard/docs/review/pose-presence-guard'),sha=b=>createHash('sha256').update(b).digest('hex');
assert(!existsSync(join(root,'manifest.json')));assert(!existsSync(join(root,'evidence')));
const entries=[];
function add(path,bytes,gzip=true){const packed=gzip?gzipSync(bytes):bytes;assert(!gzip||gunzipSync(packed).equals(bytes));const target=join(root,path+(gzip?'.gz':''));mkdirSync(dirname(target),{recursive:true});writeFileSync(target,packed,{flag:'wx'});entries.push({path:path+(gzip?'.gz':''),gzip,originalBytes:bytes.length,originalSha:sha(bytes),sha:sha(packed)});}
for(const file of readdirSync(proof).filter(f=>/\.(json|txt|mjs)$/.test(f))){add('evidence/unit/'+file,readFileSync(join(proof,file)));}
for(const file of ['browser-red.json','browser-green.json','asset-sha.json','red-male-deviation.png','green-male-deviation.png','green-female-deviation.png'])add('evidence/browser/'+file,readFileSync(join(browserProof,file)));
for(const label of ['red','green'])add('evidence/browser/probe-'+label+'/probe.js',readFileSync(join(browserProof,'probe-'+label,'probe.js')));
for(const file of readdirSync(join(proof,'public-baseline')))add('evidence/public-baseline/'+file,readFileSync(join(proof,'public-baseline',file)));
for(const file of readdirSync(join(work,'bodyguard/frontend/dist/assets')).filter(f=>/\.(js|css)$/.test(f)))add('evidence/public-final/'+file,readFileSync(join(work,'bodyguard/frontend/dist/assets',file)));
const names=['src/posture/landmarks.ts','src/posture/landmarks.test.ts','src/avatar/observedPoseRig.test.ts','src/avatar/observedTrunk.test.ts','e2e/fixtures/surfaceFeedbackProbe.ts','e2e/fixtures/surfaceFeedback.vite.ts','scripts/test-surface-feedback-browser.mjs','pnpm-lock.yaml'];
for(const name of names){const path='bodyguard/frontend/'+name;add('source/final/'+path,readFileSync(join(work,path)));add('source/base/'+path,execFileSync('git',['show','42cfa7d5e593486bc2b4b9a4f466d60013601c3a:'+path],{cwd:work,maxBuffer:10*1024*1024}));}
add('evidence/licenses/three-MIT.txt',readFileSync(join(work,'bodyguard/frontend/node_modules/three/LICENSE')),false);
const manifest={base:'42cfa7d5e593486bc2b4b9a4f466d60013601c3a',story:'S2.M3',created:new Date().toISOString(),actualChrome:true,actualWebGL:true,actualSDK:false,actualCamera:false,actualParticipant:false,releaseAvatar:false,qualifiedMotion:false,unitRedSourceSnapshotComplete:false,entries};
writeFileSync(join(root,'manifest.json'),JSON.stringify(manifest,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify({files:entries.length,bytes:entries.reduce((n,e)=>n+e.originalBytes,0)}));
