import {execFileSync, spawnSync} from 'node:child_process'
import {createHash} from 'node:crypto'
import {readFileSync,writeFileSync} from 'node:fs'
import {join} from 'node:path'
import assert from 'node:assert/strict'
const work=process.cwd(),proof='/private/tmp/bodyguard-neck-observation-proof.Rf3KVJ',front=join(work,'bodyguard/frontend'),tag=process.argv[2]??'final'
const sha=b=>createHash('sha256').update(b).digest('hex')
const head=execFileSync('git',['rev-parse','HEAD']).toString().trim()
const paths=execFileSync('git',['ls-files','bodyguard/frontend/src','bodyguard/frontend/e2e','bodyguard/frontend/scripts']).toString().trim().split('\n')
paths.push('bodyguard/frontend/src/posture/neckSideObservation.ts','bodyguard/frontend/src/posture/neckSideObservation.test.ts')
const sources=Object.fromEntries([...new Set(paths)].map(path=>[path,sha(readFileSync(join(work,path)))]))
writeFileSync(join(proof,tag+'-source-before.json'),JSON.stringify({head,sources},null,2),{flag:'wx'})
const commands=[
 ['unit','./node_modules/.bin/vitest',['run','--maxWorkers=1','--reporter=json','--outputFile='+join(proof,tag+'-unit-results.json')]],
 ['biome','./node_modules/.bin/biome',['check','.']],
 ['typecheck','./node_modules/.bin/tsc',['--noEmit']],
 ['build','./node_modules/.bin/vite',['build']],
 ['guard','node',['scripts/check-selection-production.mjs']],
]
for(const [label,cmd,args] of commands){
 const start=new Date().toISOString(),result=spawnSync(cmd,args,{cwd:front,encoding:'utf8',maxBuffer:32*1024*1024})
 for(const key of ['stdout','stderr'])writeFileSync(join(proof,tag+'-'+label+'.'+key),result[key]??'',{flag:'wx'})
 writeFileSync(join(proof,tag+'-'+label+'.receipt.json'),JSON.stringify({cmd,args,cwd:front,head,start,end:new Date().toISOString(),status:result.status,error:result.error?.code??null},null,2),{flag:'wx'})
 console.log(JSON.stringify({label,status:result.status}))
 assert.equal(result.status,0,label+' failed; original logs preserved')
}
const after=Object.fromEntries(Object.keys(sources).map(path=>[path,sha(readFileSync(join(work,path)))]))
assert.deepEqual(after,sources)
writeFileSync(join(proof,tag+'-source-after.json'),JSON.stringify({head,sources:after},null,2),{flag:'wx'})
const unit=JSON.parse(readFileSync(join(proof,tag+'-unit-results.json')))
assert.equal(unit.numFailedTests,0);assert.equal(unit.numPendingTests,0)
const previous=JSON.parse(readFileSync(join(work,'bodyguard/docs/review/native-trunk/summary.json')))
for(const asset of previous.assets){const bytes=readFileSync(join(front,'dist/assets',asset.name));assert.equal(bytes.length,asset.bytes);assert.equal(sha(bytes),asset.sha256)}
const summary={unit:{tests:unit.numTotalTests,passed:unit.numPassedTests,failed:unit.numFailedTests,pending:unit.numPendingTests},testedBase:head,testedSource:Object.keys(sources).length,publicBytesUnchanged:true,actualPeople:0,actualCamera:0,qualifiedMotions:0}
writeFileSync(join(proof,tag+'-summary.json'),JSON.stringify(summary,null,2),{flag:'wx'})
console.log(JSON.stringify(summary))
