# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: nativefeedback.spec.ts >> female native held result→same-account refresh→new owner explicit restart
- Location: e2e/nativehead.spec.ts:488:3

# Error details

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 3
Received:    2

Call Log:
- Timeout 5000ms exceeded while waiting on the predicate
```

# Page snapshot

```yaml
- generic [ref=e1]:
  - generic [ref=e3]:
    - button "본문으로 이동" [ref=e4]
    - banner [ref=e5]:
      - link "BODYGUARD 서비스 소개" [ref=e6] [cursor=pointer]:
        - /url: /
        - text: BODYGUARD.
      - navigation "계정 메뉴" [ref=e7]:
        - link "내 시작" [ref=e8] [cursor=pointer]:
          - /url: /start
        - link "자세 기록" [ref=e9] [cursor=pointer]:
          - /url: /posture-records
        - link "수행 기록" [ref=e10] [cursor=pointer]:
          - /url: /records
        - link "내 계정" [ref=e11] [cursor=pointer]:
          - /url: /account
    - main [ref=e12]:
      - generic [ref=e13]:
        - paragraph [ref=e14]: MY BODYGUARD
        - heading "내 몸을 위한 시작" [active] [level=1] [ref=e15]
        - paragraph [ref=e16]: native-auth-68492435-ac58-4366-a9cb-9615f81f1a1b@example.com
        - link "스트레칭 시작 경로 선택" [ref=e17] [cursor=pointer]:
          - /url: /explore
        - paragraph [ref=e18]:
          - link "내 수행 기록 확인" [ref=e19] [cursor=pointer]:
            - /url: /records
        - paragraph [ref=e20]:
          - link "내 자세 기록 확인" [ref=e21] [cursor=pointer]:
            - /url: /posture-records
        - paragraph [ref=e22]:
          - link "계정 관리" [ref=e23] [cursor=pointer]:
            - /url: /account
        - generic [ref=e24]:
          - heading "첫 코칭 흐름을 준비하고 있습니다" [level=2] [ref=e25]
          - paragraph [ref=e26]: 동작 검증과 남녀 3D 아바타 제작이 끝나면 스트레칭 선택과 코칭을 이곳에 연결합니다. 지금은 계정 기능을 사용할 수 있습니다.
          - paragraph [ref=e27]: 카메라는 켜지지 않았습니다.
        - button "로그아웃" [ref=e28] [cursor=pointer]
    - contentinfo [ref=e29]:
      - generic [ref=e30]: BODYGUARD
      - paragraph [ref=e31]: 일상을 위한 스트레칭과 자세 코칭 · 출시 준비 중
      - navigation "서비스 안내" [ref=e32]:
        - link "도움말" [ref=e33] [cursor=pointer]:
          - /url: /help
        - link "카메라·데이터 안내" [ref=e34] [cursor=pointer]:
          - /url: /data
  - paragraph [ref=e35]: 미완성 A37 · 가짜 카메라 · native 계정 시험 · 코칭 아님
```

# Test source

```ts
  138 |   }
  139 |   const file = info.outputPath(withHands ? 'native-hands-summary.json' : 'native-head-summary.json')
  140 |   writeFileSync(
  141 |     file,
  142 |     `${JSON.stringify(
  143 |       {
  144 |         browser: browser.version(),
  145 |         stages,
  146 |         final,
  147 |         counters,
  148 |         posts,
  149 |         external,
  150 |         errors,
  151 |         actualHuman: false,
  152 |         actualCamera: false,
  153 |         productPolicyApproved: false,
  154 |       },
  155 |       null,
  156 |       2,
  157 |     )}\n`,
  158 |   )
  159 |   await info.attach('native-head-summary', { path: file, contentType: 'application/json' })
  160 | })
  161 | async function join(context: BrowserContext) {
  162 |   const csrf = async () =>
  163 |     (await (await context.request.get('/api/v1/auth/csrf')).json()).csrf_token
  164 |   const email = `native-auth-${randomUUID()}@example.com`
  165 |   const response = await context.request.post('/api/v1/auth/signup', {
  166 |     headers: { Origin: origin, 'X-CSRF-Token': await csrf() },
  167 |     data: { email, password: '실제 계정 native 통합 시험 비밀번호 12345' },
  168 |   })
  169 |   expect(response.status()).toBe(202)
  170 |   let code = ''
  171 |   await expect
  172 |     .poll(() => {
  173 |       code = JSON.parse(readFileSync(mailbox as string, 'utf8'))[email] ?? ''
  174 |       return code
  175 |     })
  176 |     .toMatch(/^[0-9]{6}$/)
  177 |   expect(
  178 |     (
  179 |       await context.request.post('/api/v1/auth/verify', {
  180 |         headers: { Origin: origin, 'X-CSRF-Token': await csrf() },
  181 |         data: { challenge_id: (await response.json()).challenge_id, code },
  182 |       })
  183 |     ).status(),
  184 |   ).toBe(201)
  185 | }
  186 | const state = (page: Page) =>
  187 |   page.evaluate(() => (window as unknown as PrivateWindow).nativeAuthProbe.snapshot())
  188 | async function mark(page: Page, name: string) {
  189 |   const snapshot = await state(page)
  190 |   stages.push({ name, snapshot })
  191 |   return snapshot
  192 | }
  193 | async function mount(page: Page, gender: 'male' | 'female') {
  194 |   await page.goto('/start')
  195 |   await expect(page.getByRole('heading', { name: '내 몸을 위한 시작', exact: true })).toBeVisible()
  196 |   await page.evaluate(
  197 |     async ({ gender, withHands, withReference, withFeedback }) => {
  198 |       const path = '/__private-native-head-probe.js'
  199 |       const module = (await import(path)) as {
  200 |         mountNativeHeadAuthProbe: typeof mountNativeHeadAuthProbe
  201 |       }
  202 |       const text = document.createElement('p')
  203 |       text.textContent = '미완성 A37 · 가짜 카메라 · native 계정 시험 · 코칭 아님'
  204 |       document.body.append(text)
  205 |       const canvas = document.createElement('canvas')
  206 |       canvas.id = 'native-avatar'
  207 |       document.body.append(canvas)
  208 |       ;(window as unknown as PrivateWindow).nativeAuthProbe = module.mountNativeHeadAuthProbe(
  209 |         canvas,
  210 |         gender,
  211 |         // Synthetic display basis only. A blank fake camera cannot calibrate anatomy.
  212 |         withHands
  213 |           ? {
  214 |               cameraReferences: { left: [0, 0, 0, 1], right: [0, 0, 0, 1] },
  215 |               sceneFromCamera: [0, 0, 0, 1],
  216 |             }
  217 |           : undefined,
  218 |         withReference,
  219 |         withFeedback,
  220 |       )
  221 |     },
  222 |     { gender, withHands, withReference, withFeedback },
  223 |   )
  224 |   await expect
  225 |     .poll(() => state(page))
  226 |     .toMatchObject({ auth: 'ready', hook: 'idle', cameras: 0, nativeCalls: 0, renderFrames: 0 })
  227 |   await page.evaluate(() => (window as unknown as PrivateWindow).nativeAuthProbe.prepare())
  228 |   expect(await state(page)).toMatchObject({
  229 |     hook: 'prepared',
  230 |     cameras: 0,
  231 |     nativeCalls: 0,
  232 |     models: 0,
  233 |   })
  234 |   expect(posts).toBe(0)
  235 | }
  236 | async function running(page: Page) {
  237 |   await page.evaluate(() => (window as unknown as PrivateWindow).nativeAuthProbe.start())
> 238 |   await expect.poll(async () => (await state(page)).nativeCloses).toBeGreaterThanOrEqual(3)
      |                                                                   ^ Error: expect(received).toBeGreaterThanOrEqual(expected)
  239 |   const value = await mark(page, 'native-running')
  240 |   expect(value.session).toBe('running')
  241 |   expect(value.resources?.status).toBe('running')
  242 |   expect(value.models).toBe(2)
  243 |   expect(value.framing).toEqual([true, true])
  244 |   expect(value.cameraLive && value.rawVideoHidden).toBe(true)
  245 |   expect(value.handsConfigured).toBe(withHands)
  246 |   expect(value.handCalls).toBe(withHands ? value.nativeCalls : 0)
  247 |   expect(value.nativeHandsMax).toBe(0)
  248 | }
  249 | async function hold(page: Page) {
  250 |   await page.evaluate(() => (window as unknown as PrivateWindow).nativeAuthProbe.holdNextResult())
  251 |   await expect.poll(() => state(page)).toMatchObject({ held: true })
  252 |   const value = await mark(page, 'native-result-held')
  253 |   expect(value.nativeCloses).toBe(value.nativeCalls - 1)
  254 |   expect(value.heldStage).toBe(withHands ? 'hands' : 'face')
  255 |   expect(value.faceCalls).toBe(value.nativeCalls)
  256 |   expect(value.handCalls).toBe(withHands ? value.nativeCalls : 0)
  257 | }
  258 | async function revokedWhileHeld(page: Page) {
  259 |   const value = await mark(page, 'authority-revoked-while-native-held')
  260 |   expect(value.owned).toBe(false)
  261 |   expect(value.cameraLive && value.held).toBe(true)
  262 |   if (withReference)
  263 |     expect(
  264 |       await page.evaluate(() => (window as unknown as PrivateWindow).nativeAuthProbe.oldCommand()),
  265 |     ).toBe(false)
  266 |   const renders = value.renderFrames,
  267 |     calls = value.nativeCalls
  268 |   await page.evaluate(
  269 |     () => new Promise((resolve) => requestAnimationFrame(() => requestAnimationFrame(resolve))),
  270 |   )
  271 |   expect(await state(page)).toMatchObject({
  272 |     renderFrames: renders,
  273 |     nativeCalls: calls,
  274 |     detectorCloses: 0,
  275 |     faceDetectorCloses: 0,
  276 |     handDetectorCloses: 0,
  277 |     handCalls: value.handCalls,
  278 |     faceCalls: value.faceCalls,
  279 |     cameraCloses: 0,
  280 |   })
  281 |   await page.evaluate(() => (window as unknown as PrivateWindow).nativeAuthProbe.beginOldActions())
  282 |   expect(posts).toBe(0)
  283 | }
  284 | async function release(page: Page) {
  285 |   await page.evaluate(() =>
  286 |     (window as unknown as PrivateWindow).nativeAuthProbe.releaseHeldResult(),
  287 |   )
  288 |   await expect
  289 |     .poll(() => state(page))
  290 |     .toMatchObject({
  291 |       held: false,
  292 |       tracksEnded: true,
  293 |       detectorCloses: 1,
  294 |       faceDetectorCloses: 1,
  295 |       handDetectorCloses: withHands ? 1 : 0,
  296 |       cameraCloses: 1,
  297 |       models: 0,
  298 |     })
  299 |   await mark(page, 'native-input-result-and-resources-closed')
  300 |   await page.evaluate(() => (window as unknown as PrivateWindow).nativeAuthProbe.finishOldActions())
  301 |   expect(posts).toBe(0)
  302 | }
  303 | for (const gender of ['male', 'female'] as const) {
  304 |   if (withFeedback)
  305 |     test(`${gender} native delivery→current session→surface feedback→crop/multiple/none→recovery`, async ({
  306 |       page,
  307 |       context,
  308 |     }, info) => {
  309 |       await join(context)
  310 |       await mount(page, gender)
  311 |       await running(page)
  312 |       await page.evaluate(() =>
  313 |         (window as unknown as PrivateWindow).nativeAuthProbe.setFeedbackMode('error'),
  314 |       )
  315 |       await expect
  316 |         .poll(() => state(page))
  317 |         .toMatchObject({
  318 |           highlighted: true,
  319 |           feedbackConfigured: true,
  320 |           canvasHidden: false,
  321 |           verifiedMs: 0,
  322 |           phase: 'seeking-target',
  323 |         })
  324 |       const highlighted = await mark(page, 'generated-native-error-with-current-owner-state')
  325 |       expect(highlighted.syntheticBodyDeliveries).toBeGreaterThan(0)
  326 |       expect(highlighted.feedbackEvaluations).toBeGreaterThan(0)
  327 |       await expect
  328 |         .poll(() =>
  329 |           page.evaluate(
  330 |             () => (window as unknown as PrivateWindow).nativeAuthProbe.pixelCounts().right,
  331 |           ),
  332 |         )
  333 |         .toBeGreaterThan(0)
  334 |       const pixels = await page.evaluate(() =>
  335 |         (window as unknown as PrivateWindow).nativeAuthProbe.pixelCounts(),
  336 |       )
  337 |       expect(pixels).toMatchObject({ sampled: true, left: 0, error: 0 })
  338 |       writeFileSync(info.outputPath('feedback-pixels.json'), JSON.stringify(pixels))
```