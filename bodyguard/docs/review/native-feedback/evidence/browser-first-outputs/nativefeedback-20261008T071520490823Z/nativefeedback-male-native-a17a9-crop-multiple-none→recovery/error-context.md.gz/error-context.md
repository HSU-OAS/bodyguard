# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: nativefeedback.spec.ts >> male native delivery→current session→surface feedback→crop/multiple/none→recovery
- Location: e2e/nativehead.spec.ts:297:5

# Error details

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 3
Received:    0

Call Log:
- Timeout 5000ms exceeded while waiting on the predicate
```

```
Test timeout of 60000ms exceeded while running "afterEach" hook.
```

# Page snapshot

```yaml
- generic [ref=e1]:
  - generic [ref=e3]:
    - button "본문으로 이동" [ref=e4]
    - banner [ref=e5]:
      - link "BODYGUARD 서비스 소개" [ref=e6] [cursor=pointer]:
        - /url: /
        - text: BODYGUARD.
      - navigation "계정 메뉴" [ref=e7]:
        - link "내 시작" [ref=e8] [cursor=pointer]:
          - /url: /start
        - link "자세 기록" [ref=e9] [cursor=pointer]:
          - /url: /posture-records
        - link "수행 기록" [ref=e10] [cursor=pointer]:
          - /url: /records
        - link "내 계정" [ref=e11] [cursor=pointer]:
          - /url: /account
    - main [ref=e12]:
      - generic [ref=e13]:
        - paragraph [ref=e14]: MY BODYGUARD
        - heading "내 몸을 위한 시작" [active] [level=1] [ref=e15]
        - paragraph [ref=e16]: native-auth-98593996-6d71-4ba4-b2d7-0586cbf44358@example.com
        - link "스트레칭 시작 경로 선택" [ref=e17] [cursor=pointer]:
          - /url: /explore
        - paragraph [ref=e18]:
          - link "내 수행 기록 확인" [ref=e19] [cursor=pointer]:
            - /url: /records
        - paragraph [ref=e20]:
          - link "내 자세 기록 확인" [ref=e21] [cursor=pointer]:
            - /url: /posture-records
        - paragraph [ref=e22]:
          - link "계정 관리" [ref=e23] [cursor=pointer]:
            - /url: /account
        - generic [ref=e24]:
          - heading "첫 코칭 흐름을 준비하고 있습니다" [level=2] [ref=e25]
          - paragraph [ref=e26]: 동작 검증과 남녀 3D 아바타 제작이 끝나면 스트레칭 선택과 코칭을 이곳에 연결합니다. 지금은 계정 기능을 사용할 수 있습니다.
          - paragraph [ref=e27]: 카메라는 켜지지 않았습니다.
        - button "로그아웃" [ref=e28] [cursor=pointer]
    - contentinfo [ref=e29]:
      - generic [ref=e30]: BODYGUARD
      - paragraph [ref=e31]: 일상을 위한 스트레칭과 자세 코칭 · 출시 준비 중
      - navigation "서비스 안내" [ref=e32]:
        - link "도움말" [ref=e33] [cursor=pointer]:
          - /url: /help
        - link "카메라·데이터 안내" [ref=e34] [cursor=pointer]:
          - /url: /data
  - paragraph [ref=e35]: 미완성 A37 · 가짜 카메라 · native 계정 시험 · 코칭 아님
```

# Test source

```ts
  1   | // FR-U-04/FR-S-04·FR-R-03/NFR-07/08: native Chrome/API/SQL, fake camera/mail/motion gates.
  2   | import { randomUUID } from 'node:crypto'
  3   | import { readFileSync, writeFileSync } from 'node:fs'
  4   | import { type BrowserContext, expect, type Page, test } from '@playwright/test'
  5   | import type { mountNativeHeadAuthProbe } from './fixtures/nativeHeadAuthProbe'
  6   | 
  7   | const origin = 'http://localhost:4173'
  8   | const mailbox = process.env.BODYGUARD_TEST_MAILBOX
  9   | const withFeedback = Boolean(process.env.BODYGUARD_TEST_NATIVE_FEEDBACK_PROBE)
  10  | const withReference = withFeedback || Boolean(process.env.BODYGUARD_TEST_NATIVE_REFERENCE_PROBE)
  11  | const withHands = withReference || Boolean(process.env.BODYGUARD_TEST_NATIVE_HANDS_PROBE)
  12  | const bundle =
  13  |   process.env.BODYGUARD_TEST_NATIVE_FEEDBACK_PROBE ??
  14  |   process.env.BODYGUARD_TEST_NATIVE_REFERENCE_PROBE ??
  15  |   process.env.BODYGUARD_TEST_NATIVE_HANDS_PROBE ??
  16  |   process.env.BODYGUARD_TEST_NATIVE_HEAD_PROBE
  17  | if (
  18  |   !mailbox?.startsWith('/private/tmp/bodyguard-browser-') ||
  19  |   !bundle ||
  20  |   !(
  21  |     withFeedback
  22  |       ? /^\/private\/tmp\/bodyguard-native-feedback-proof\.[A-Za-z0-9]+\/probe-[a-z0-9-]+$/
  23  |       : withReference
  24  |         ? /^\/private\/tmp\/bodyguard-native-reference-proof\.[A-Za-z0-9]+\/probe-[a-z0-9-]+$/
  25  |         : withHands
  26  |           ? /^\/private\/tmp\/bodyguard-native-hands-proof\.[A-Za-z0-9]+\/probe$/
  27  |           : /^\/private\/tmp\/bodyguard-native-body-head-proof\.[A-Za-z0-9]+\/probe$/
  28  |   ).test(bundle)
  29  | )
  30  |   throw new Error('Owned native auth harness required')
  31  | type Probe = ReturnType<typeof mountNativeHeadAuthProbe>
  32  | type PrivateWindow = Window & { nativeAuthProbe: Probe; cameraCalls: number; cspAttempts: number }
  33  | type Snapshot = ReturnType<Probe['snapshot']>
  34  | let posts = 0,
  35  |   external = 0,
  36  |   errors: string[] = []
  37  | const stages: { name: string; snapshot: Snapshot }[] = []
  38  | test.setTimeout(60_000)
  39  | test.beforeEach(async ({ context, page }) => {
  40  |   posts = 0
  41  |   external = 0
  42  |   errors = []
  43  |   stages.length = 0
  44  |   page.on('pageerror', (error) => errors.push(error.name))
  45  |   context.on('request', (request) => {
  46  |     const url = new URL(request.url())
  47  |     if (url.pathname === '/api/v1/records/stretch' && request.method() === 'POST') posts++
  48  |   })
  49  |   await context.route('**/*', async (route) => {
  50  |     if (!route.request().url().startsWith(`${origin}/`)) {
  51  |       external++
  52  |       await route.abort()
  53  |       return
  54  |     }
  55  |     await route.continue()
  56  |   })
  57  |   await page.route('**/__private-native-head-probe.js', (route) =>
  58  |     route.fulfill({
  59  |       contentType: 'application/javascript',
  60  |       body: readFileSync(`${bundle}/probe.js`),
  61  |     }),
  62  |   )
  63  |   for (const gender of ['male', 'female']) {
  64  |     await page.route(`**/__private-native-${gender}.glb`, (route) =>
  65  |       route.fulfill({
  66  |         contentType: 'model/gltf-binary',
  67  |         body: readFileSync(`${bundle}/../${gender}.glb`),
  68  |       }),
  69  |     )
  70  |   }
  71  |   if (withReference)
  72  |     await page.route('**/__private-native-reference-fixture.json', (route) =>
  73  |       route.fulfill({
  74  |         contentType: 'application/json',
  75  |         body: readFileSync(`${bundle}/../authored-fixture.json`),
  76  |       }),
  77  |     )
  78  |   await page.route('**/start', async (route) => {
  79  |     const response = await route.fetch()
  80  |     await route.fulfill({
  81  |       response,
  82  |       headers: { ...response.headers(), 'Content-Security-Policy': "connect-src 'self'" },
  83  |     })
  84  |   })
  85  |   await context.addInitScript(() => {
  86  |     const current = window as unknown as PrivateWindow
  87  |     current.cameraCalls = 0
  88  |     current.cspAttempts = 0
  89  |     document.addEventListener('securitypolicyviolation', (event) => {
  90  |       if (event.violatedDirective === 'connect-src') current.cspAttempts++
  91  |     })
  92  |     const native = navigator.mediaDevices.getUserMedia.bind(navigator.mediaDevices)
  93  |     navigator.mediaDevices.getUserMedia = (constraints) => {
  94  |       current.cameraCalls++
  95  |       return native(constraints)
  96  |     }
  97  |   })
  98  | })
> 99  | test.afterEach(async ({ page, browser }, info) => {
      |      ^ Test timeout of 60000ms exceeded while running "afterEach" hook.
  100 |   const final = await page.evaluate(async () => {
  101 |     const p = (window as unknown as PrivateWindow).nativeAuthProbe
  102 |     return p ? await p.close() : null
  103 |   })
  104 |   expect(external).toBe(0)
  105 |   expect(errors).toEqual([])
  106 |   expect(await page.evaluate(() => [localStorage.length, sessionStorage.length])).toEqual([0, 0])
  107 |   const counters = await page.evaluate(() => {
  108 |     const w = window as unknown as PrivateWindow
  109 |     return { cameraCalls: w.cameraCalls, cspAttempts: w.cspAttempts }
  110 |   })
  111 |   if (final) {
  112 |     expect(final.tracksEnded && final.detached && final.allFramesClosed).toBe(true)
  113 |     expect(final.frameErrors).toBe(0)
  114 |     expect(final.frameCloses).toBe(final.frames)
  115 |     expect(final.nativeCloses).toBe(final.nativeCalls)
  116 |     expect(final.nativePeopleMax).toBe(0)
  117 |     expect(final.nativeFacesMax).toBe(0)
  118 |     expect(final.sameInput).toBe(true)
  119 |     expect(final.faceCalls).toBe(final.nativeCalls)
  120 |     expect(final.faceDetectorCloses).toBe(final.cameras)
  121 |     expect(final.handCalls).toBe(withHands ? final.nativeCalls : 0)
  122 |     expect(final.handDetectorCloses).toBe(withHands ? final.cameras : 0)
  123 |     expect(final.nativeHandsMax).toBe(0)
  124 |     expect(final.productionAdapter).toBe(true)
  125 |     expect(final.cameraCloses).toBe(final.cameras)
  126 |     expect(final.detectorCloses).toBe(final.cameras)
  127 |     expect(final.models).toBe(0)
  128 |     expect(final.failures).toEqual([])
  129 |     expect(final.memory).toEqual(final.baseline)
  130 |   }
  131 |   const file = info.outputPath(withHands ? 'native-hands-summary.json' : 'native-head-summary.json')
  132 |   writeFileSync(
  133 |     file,
  134 |     `${JSON.stringify(
  135 |       {
  136 |         browser: browser.version(),
  137 |         stages,
  138 |         final,
  139 |         counters,
  140 |         posts,
  141 |         external,
  142 |         errors,
  143 |         actualHuman: false,
  144 |         actualCamera: false,
  145 |         productPolicyApproved: false,
  146 |       },
  147 |       null,
  148 |       2,
  149 |     )}\n`,
  150 |   )
  151 |   await info.attach('native-head-summary', { path: file, contentType: 'application/json' })
  152 | })
  153 | async function join(context: BrowserContext) {
  154 |   const csrf = async () =>
  155 |     (await (await context.request.get('/api/v1/auth/csrf')).json()).csrf_token
  156 |   const email = `native-auth-${randomUUID()}@example.com`
  157 |   const response = await context.request.post('/api/v1/auth/signup', {
  158 |     headers: { Origin: origin, 'X-CSRF-Token': await csrf() },
  159 |     data: { email, password: '실제 계정 native 통합 시험 비밀번호 12345' },
  160 |   })
  161 |   expect(response.status()).toBe(202)
  162 |   let code = ''
  163 |   await expect
  164 |     .poll(() => {
  165 |       code = JSON.parse(readFileSync(mailbox as string, 'utf8'))[email] ?? ''
  166 |       return code
  167 |     })
  168 |     .toMatch(/^[0-9]{6}$/)
  169 |   expect(
  170 |     (
  171 |       await context.request.post('/api/v1/auth/verify', {
  172 |         headers: { Origin: origin, 'X-CSRF-Token': await csrf() },
  173 |         data: { challenge_id: (await response.json()).challenge_id, code },
  174 |       })
  175 |     ).status(),
  176 |   ).toBe(201)
  177 | }
  178 | const state = (page: Page) =>
  179 |   page.evaluate(() => (window as unknown as PrivateWindow).nativeAuthProbe.snapshot())
  180 | async function mark(page: Page, name: string) {
  181 |   const snapshot = await state(page)
  182 |   stages.push({ name, snapshot })
  183 |   return snapshot
  184 | }
  185 | async function mount(page: Page, gender: 'male' | 'female') {
  186 |   await page.goto('/start')
  187 |   await expect(page.getByRole('heading', { name: '내 몸을 위한 시작', exact: true })).toBeVisible()
  188 |   await page.evaluate(
  189 |     async ({ gender, withHands, withReference, withFeedback }) => {
  190 |       const path = '/__private-native-head-probe.js'
  191 |       const module = (await import(path)) as {
  192 |         mountNativeHeadAuthProbe: typeof mountNativeHeadAuthProbe
  193 |       }
  194 |       const text = document.createElement('p')
  195 |       text.textContent = '미완성 A37 · 가짜 카메라 · native 계정 시험 · 코칭 아님'
  196 |       document.body.append(text)
  197 |       const canvas = document.createElement('canvas')
  198 |       canvas.id = 'native-avatar'
  199 |       document.body.append(canvas)
```