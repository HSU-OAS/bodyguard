# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: nativefeedback.spec.ts >> male native held result→same-account refresh→new owner explicit restart
- Location: e2e/nativehead.spec.ts:463:3

# Error details

```
Error: Test timeout of 60000ms exceeded
```

# Page snapshot

```yaml
- generic [ref=e1]:
  - generic [ref=e3]:
    - button "본문으로 이동" [ref=e4]
    - banner [ref=e5]:
      - link "BODYGUARD 서비스 소개" [ref=e6] [cursor=pointer]:
        - /url: /
        - text: BODYGUARD.
      - navigation "계정 메뉴" [ref=e7]:
        - link "내 시작" [ref=e8] [cursor=pointer]:
          - /url: /start
        - link "자세 기록" [ref=e9] [cursor=pointer]:
          - /url: /posture-records
        - link "수행 기록" [ref=e10] [cursor=pointer]:
          - /url: /records
        - link "내 계정" [ref=e11] [cursor=pointer]:
          - /url: /account
    - main [ref=e12]:
      - generic [ref=e13]:
        - paragraph [ref=e14]: MY BODYGUARD
        - heading "내 몸을 위한 시작" [active] [level=1] [ref=e15]
        - paragraph [ref=e16]: native-auth-92ac73e0-a7fa-4da8-b526-99b3f7e74775@example.com
        - link "스트레칭 시작 경로 선택" [ref=e17] [cursor=pointer]:
          - /url: /explore
        - paragraph [ref=e18]:
          - link "내 수행 기록 확인" [ref=e19] [cursor=pointer]:
            - /url: /records
        - paragraph [ref=e20]:
          - link "내 자세 기록 확인" [ref=e21] [cursor=pointer]:
            - /url: /posture-records
        - paragraph [ref=e22]:
          - link "계정 관리" [ref=e23] [cursor=pointer]:
            - /url: /account
        - generic [ref=e24]:
          - heading "첫 코칭 흐름을 준비하고 있습니다" [level=2] [ref=e25]
          - paragraph [ref=e26]: 동작 검증과 남녀 3D 아바타 제작이 끝나면 스트레칭 선택과 코칭을 이곳에 연결합니다. 지금은 계정 기능을 사용할 수 있습니다.
          - paragraph [ref=e27]: 카메라는 켜지지 않았습니다.
        - button "로그아웃" [ref=e28] [cursor=pointer]
    - contentinfo [ref=e29]:
      - generic [ref=e30]: BODYGUARD
      - paragraph [ref=e31]: 일상을 위한 스트레칭과 자세 코칭 · 출시 준비 중
      - navigation "서비스 안내" [ref=e32]:
        - link "도움말" [ref=e33] [cursor=pointer]:
          - /url: /help
        - link "카메라·데이터 안내" [ref=e34] [cursor=pointer]:
          - /url: /data
  - paragraph [ref=e35]: 미완성 A37 · 가짜 카메라 · native 계정 시험 · 코칭 아님
```

# Test source

```ts
  379 |       )
  380 |       await pulse(1300)
  381 |       const holding = await mark(page, 'owned-holding-guide-with-no-synthesized-progress')
  382 |       expect(holding).toMatchObject({ phase: 'holding', verifiedMs: 0, userUnchanged: true })
  383 |       expect(holding.referenceTargetError as number).toBeLessThan(2e-6)
  384 |       await page.waitForTimeout(700)
  385 |       await page.evaluate(() =>
  386 |         (window as unknown as PrivateWindow).nativeAuthProbe.markReference(),
  387 |       )
  388 |       await page.waitForTimeout(300)
  389 |       await expect.poll(() => state(page)).toMatchObject({ referenceFrozen: true, verifiedMs: 0 })
  390 |       await mark(page, 'cue-expired-guide-frozen')
  391 |       await page.evaluate(() =>
  392 |         (window as unknown as PrivateWindow).nativeAuthProbe.observe('target'),
  393 |       )
  394 |       expect(await state(page)).toMatchObject({ phase: 'waiting-return', verifiedMs: 2000 })
  395 |       await pulse(1300)
  396 |       const returned = await mark(page, 'owned-return-guide')
  397 |       expect(returned.referenceTargetError as number).toBeLessThan(2e-6)
  398 |       await page.evaluate(() => (window as unknown as PrivateWindow).nativeAuthProbe.pause())
  399 |       expect(await state(page)).toMatchObject({
  400 |         session: 'paused',
  401 |         models: 0,
  402 |         tracksEnded: true,
  403 |         verifiedMs: 2000,
  404 |       })
  405 |       await page.evaluate(() => (window as unknown as PrivateWindow).nativeAuthProbe.resume())
  406 |       await expect
  407 |         .poll(() => state(page))
  408 |         .toMatchObject({ session: 'running', sessionGeneration: 2, cameras: 2 })
  409 |       await pulse(300)
  410 |       expect(await state(page)).toMatchObject({
  411 |         phase: 'waiting-start',
  412 |         verifiedMs: 2000,
  413 |         userUnchanged: true,
  414 |       })
  415 |       await mark(page, 'fresh-generation-no-old-clip-resume')
  416 |     })
  417 |   test(`${gender} native start→stop→own interrupted record`, async ({ page, context }, info) => {
  418 |     await join(context)
  419 |     await mount(page, gender)
  420 |     await running(page)
  421 |     await page
  422 |       .locator('#native-avatar')
  423 |       .screenshot({ path: info.outputPath(`avatar-${gender}.png`) })
  424 |     await page.evaluate(() => (window as unknown as PrivateWindow).nativeAuthProbe.stop())
  425 |     const stopped = await mark(page, 'explicit-user-stop')
  426 |     expect(stopped.verifiedMs).toBe(0)
  427 |     expect(stopped.tracksEnded).toBe(true)
  428 |     expect(posts).toBe(0)
  429 |     await page.evaluate(() => (window as unknown as PrivateWindow).nativeAuthProbe.save())
  430 |     expect(await state(page)).toMatchObject({ record: 'saved' })
  431 |     expect(posts).toBe(1)
  432 |     const rows = (await (await context.request.get('/api/v1/records/stretch')).json()).items
  433 |     expect(rows).toHaveLength(1)
  434 |     expect(rows[0]).toMatchObject({
  435 |       id: stopped.recordId,
  436 |       outcome: 'interrupted',
  437 |       observed_ms: 0,
  438 |       repetitions: 0,
  439 |       provenance: 'client-reported',
  440 |     })
  441 |     await page.evaluate(() => (window as unknown as PrivateWindow).nativeAuthProbe.close())
  442 |     const closed = await mark(page, 'native-closed-before-public-record')
  443 |     expect(closed.tracksEnded && closed.detached && closed.allFramesClosed).toBe(true)
  444 |     expect(closed.frameCloses).toBe(closed.frames)
  445 |     expect(closed.nativeCloses).toBe(closed.nativeCalls)
  446 |     expect(closed.sameInput).toBe(true)
  447 |     expect(closed.faceCalls).toBe(closed.nativeCalls)
  448 |     expect(closed.faceDetectorCloses).toBe(closed.cameras)
  449 |     expect(closed.handCalls).toBe(withHands ? closed.nativeCalls : 0)
  450 |     expect(closed.handDetectorCloses).toBe(withHands ? closed.cameras : 0)
  451 |     expect(closed.nativeHandsMax).toBe(0)
  452 |     expect(closed.nativeFacesMax).toBe(0)
  453 |     expect(closed.productionAdapter).toBe(true)
  454 |     expect(closed.memory).toEqual(closed.baseline)
  455 |     await page.goto(`/records/${rows[0].id}`)
  456 |     await expect(page.getByRole('heading', { name: '수행 기록 상세', exact: true })).toBeVisible()
  457 |     await expect(page.getByText('중단', { exact: true })).toBeVisible()
  458 |     await page.screenshot({
  459 |       path: info.outputPath(`native-record-${gender}.png`),
  460 |       fullPage: true,
  461 |     })
  462 |   })
  463 |   test(`${gender} native held result→same-account refresh→new owner explicit restart`, async ({
  464 |     page,
  465 |     context,
  466 |   }) => {
  467 |     await join(context)
  468 |     await mount(page, gender)
  469 |     await running(page)
  470 |     await hold(page)
  471 |     await page.evaluate(() => (window as unknown as PrivateWindow).nativeAuthProbe.refresh())
  472 |     await expect
  473 |       .poll(() => state(page))
  474 |       .toMatchObject({ auth: 'ready', hook: 'idle', owned: false })
  475 |     await revokedWhileHeld(page)
  476 |     await page.evaluate(() => (window as unknown as PrivateWindow).nativeAuthProbe.beginPrepare())
  477 |     await expect
  478 |       .poll(() => state(page))
> 479 |       .toMatchObject({ hook: 'preparing', prepareFinished: false })
      |        ^ Error: Test timeout of 60000ms exceeded
  480 |     expect(await state(page)).toMatchObject({ cameras: 1, held: true, owned: false })
  481 |     await release(page)
  482 |     await page.evaluate(() => (window as unknown as PrivateWindow).nativeAuthProbe.finishPrepare())
  483 |     expect(await state(page)).toMatchObject({ hook: 'prepared', cameras: 1 })
  484 |     const before = (await state(page)).nativeCalls
  485 |     await page.evaluate(() => (window as unknown as PrivateWindow).nativeAuthProbe.start())
  486 |     await expect.poll(async () => (await state(page)).nativeCloses).toBeGreaterThan(before + 2)
  487 |     expect(await state(page)).toMatchObject({
  488 |       cameras: 2,
  489 |       sessionGeneration: 1,
  490 |       session: 'running',
  491 |     })
  492 |     await mark(page, 'fresh-record-owner-fresh-native-bridge')
  493 |   })
  494 |   for (const revocation of ['logout', 'server401', 'pagehide', 'unmount'] as const) {
  495 |     test(`${gender} native held result→${revocation}→no old resume/save`, async ({
  496 |       page,
  497 |       context,
  498 |     }) => {
  499 |       await join(context)
  500 |       await mount(page, gender)
  501 |       await running(page)
  502 |       if (withFeedback) {
  503 |         await page.evaluate(() =>
  504 |           (window as unknown as PrivateWindow).nativeAuthProbe.setFeedbackMode('error'),
  505 |         )
  506 |         await expect
  507 |           .poll(() => state(page))
  508 |           .toMatchObject({ highlighted: true, canvasHidden: false, verifiedMs: 0 })
  509 |       }
  510 |       await hold(page)
  511 |       if (revocation === 'logout')
  512 |         await page.evaluate(() => (window as unknown as PrivateWindow).nativeAuthProbe.signOut())
  513 |       else if (revocation === 'server401') {
  514 |         const csrf = (await (await context.request.get('/api/v1/auth/csrf')).json()).csrf_token
  515 |         expect(
  516 |           (
  517 |             await context.request.post('/api/v1/auth/logout', {
  518 |               headers: { Origin: origin, 'X-CSRF-Token': csrf },
  519 |             })
  520 |           ).status(),
  521 |         ).toBe(204)
  522 |         await page.evaluate(() => (window as unknown as PrivateWindow).nativeAuthProbe.refresh())
  523 |       } else if (revocation === 'unmount')
  524 |         await page.evaluate(() => (window as unknown as PrivateWindow).nativeAuthProbe.unmount())
  525 |       else await page.evaluate(() => window.dispatchEvent(new PageTransitionEvent('pagehide')))
  526 |       await expect.poll(() => state(page)).toMatchObject({ owned: false })
  527 |       if (withFeedback)
  528 |         expect(await state(page)).toMatchObject({ canvasHidden: true, highlighted: false })
  529 |       if (revocation !== 'unmount') expect((await state(page)).hook).toBe('idle')
  530 |       await revokedWhileHeld(page)
  531 |       await release(page)
  532 |       await page.evaluate(() =>
  533 |         window.dispatchEvent(new PageTransitionEvent('pageshow', { persisted: true })),
  534 |       )
  535 |       expect(await state(page)).toMatchObject({
  536 |         cameras: 1,
  537 |         owned: false,
  538 |         nativePeopleMax: 0,
  539 |         verifiedMs: 0,
  540 |       })
  541 |       if (revocation === 'logout' || revocation === 'server401')
  542 |         expect((await context.request.get('/api/v1/me')).status()).toBe(401)
  543 |       await mark(page, 'no-automatic-restart')
  544 |     })
  545 |   }
  546 | }
  547 | 
```