# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: nativefeedback.spec.ts >> female native start→stop→own interrupted record
- Location: e2e/nativehead.spec.ts:782:3

# Error details

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 3
Received:    0

Call Log:
- Timeout 5000ms exceeded while waiting on the predicate
```

# Page snapshot

```yaml
- generic [ref=e1]:
  - generic [ref=e3]:
    - button "본문으로 이동" [ref=e4]
    - banner [ref=e5]:
      - link "BODYGUARD 서비스 소개" [ref=e6] [cursor=pointer]:
        - /url: /
        - text: BODYGUARD.
      - navigation "계정 메뉴" [ref=e7]:
        - link "내 시작" [ref=e8] [cursor=pointer]:
          - /url: /start
        - link "자세 기록" [ref=e9] [cursor=pointer]:
          - /url: /posture-records
        - link "수행 기록" [ref=e10] [cursor=pointer]:
          - /url: /records
        - link "내 계정" [ref=e11] [cursor=pointer]:
          - /url: /account
    - main [ref=e12]:
      - generic [ref=e13]:
        - paragraph [ref=e14]: MY BODYGUARD
        - heading "내 몸을 위한 시작" [active] [level=1] [ref=e15]
        - paragraph [ref=e16]: native-auth-21656ebd-d020-45a2-a2a0-e8950393e519@example.com
        - link "스트레칭 시작 경로 선택" [ref=e17] [cursor=pointer]:
          - /url: /explore
        - paragraph [ref=e18]:
          - link "내 수행 기록 확인" [ref=e19] [cursor=pointer]:
            - /url: /records
        - paragraph [ref=e20]:
          - link "내 자세 기록 확인" [ref=e21] [cursor=pointer]:
            - /url: /posture-records
        - paragraph [ref=e22]:
          - link "계정 관리" [ref=e23] [cursor=pointer]:
            - /url: /account
        - generic [ref=e24]:
          - heading "첫 코칭 흐름을 준비하고 있습니다" [level=2] [ref=e25]
          - paragraph [ref=e26]: 동작 검증과 남녀 3D 아바타 제작이 끝나면 스트레칭 선택과 코칭을 이곳에 연결합니다. 지금은 계정 기능을 사용할 수 있습니다.
          - paragraph [ref=e27]: 카메라는 켜지지 않았습니다.
        - button "로그아웃" [ref=e28] [cursor=pointer]
    - contentinfo [ref=e29]:
      - generic [ref=e30]: BODYGUARD
      - paragraph [ref=e31]: 일상을 위한 스트레칭과 자세 코칭 · 출시 준비 중
      - navigation "서비스 안내" [ref=e32]:
        - link "도움말" [ref=e33] [cursor=pointer]:
          - /url: /help
        - link "카메라·데이터 안내" [ref=e34] [cursor=pointer]:
          - /url: /data
  - paragraph [ref=e35]: 미완성 A37 · 가짜 카메라 · native 계정 시험 · 코칭 아님
```

# Test source

```ts
  169 |     headers: { Origin: origin, 'X-CSRF-Token': await csrf() },
  170 |     data: { email, password: '실제 계정 native 통합 시험 비밀번호 12345' },
  171 |   })
  172 |   expect(response.status()).toBe(202)
  173 |   let code = ''
  174 |   await expect
  175 |     .poll(() => {
  176 |       code = JSON.parse(readFileSync(mailbox as string, 'utf8'))[email] ?? ''
  177 |       return code
  178 |     })
  179 |     .toMatch(/^[0-9]{6}$/)
  180 |   expect(
  181 |     (
  182 |       await context.request.post('/api/v1/auth/verify', {
  183 |         headers: { Origin: origin, 'X-CSRF-Token': await csrf() },
  184 |         data: { challenge_id: (await response.json()).challenge_id, code },
  185 |       })
  186 |     ).status(),
  187 |   ).toBe(201)
  188 | }
  189 | const state = (page: Page) =>
  190 |   page.evaluate(() => (window as unknown as PrivateWindow).nativeAuthProbe.snapshot())
  191 | async function mark(page: Page, name: string) {
  192 |   const snapshot = await state(page)
  193 |   stages.push({ name, snapshot })
  194 |   return snapshot
  195 | }
  196 | async function mount(
  197 |   page: Page,
  198 |   gender: 'male' | 'female',
  199 |   withAdaptive = false,
  200 |   withTiming = false,
  201 |   withTrunk = false,
  202 | ) {
  203 |   await page.goto('/start')
  204 |   await expect(page.getByRole('heading', { name: '내 몸을 위한 시작', exact: true })).toBeVisible()
  205 |   await page.evaluate(
  206 |     async ({
  207 |       gender,
  208 |       withHands,
  209 |       withReference,
  210 |       withFeedback,
  211 |       withAdaptive,
  212 |       withTiming,
  213 |       withTrunk,
  214 |       withNeck,
  215 |     }) => {
  216 |       const path = '/__private-native-head-probe.js'
  217 |       const module = (await import(path)) as {
  218 |         mountNativeHeadAuthProbe: typeof mountNativeHeadAuthProbe
  219 |       }
  220 |       const text = document.createElement('p')
  221 |       text.textContent = '미완성 A37 · 가짜 카메라 · native 계정 시험 · 코칭 아님'
  222 |       document.body.append(text)
  223 |       const canvas = document.createElement('canvas')
  224 |       canvas.id = 'native-avatar'
  225 |       document.body.append(canvas)
  226 |       ;(window as unknown as PrivateWindow).nativeAuthProbe = module.mountNativeHeadAuthProbe(
  227 |         canvas,
  228 |         gender,
  229 |         // Synthetic display basis only. A blank fake camera cannot calibrate anatomy.
  230 |         withHands
  231 |           ? {
  232 |               cameraReferences: { left: [0, 0, 0, 1], right: [0, 0, 0, 1] },
  233 |               sceneFromCamera: [0, 0, 0, 1],
  234 |             }
  235 |           : undefined,
  236 |         withReference,
  237 |         withFeedback,
  238 |         withAdaptive,
  239 |         withTiming,
  240 |         withTrunk,
  241 |         withNeck,
  242 |       )
  243 |     },
  244 |     {
  245 |       gender,
  246 |       withHands,
  247 |       withReference,
  248 |       withFeedback,
  249 |       withAdaptive,
  250 |       withTiming,
  251 |       withTrunk,
  252 |       withNeck,
  253 |     },
  254 |   )
  255 |   await expect
  256 |     .poll(() => state(page))
  257 |     .toMatchObject({ auth: 'ready', hook: 'idle', cameras: 0, nativeCalls: 0, renderFrames: 0 })
  258 |   await page.evaluate(() => (window as unknown as PrivateWindow).nativeAuthProbe.prepare())
  259 |   expect(await state(page)).toMatchObject({
  260 |     hook: 'prepared',
  261 |     cameras: 0,
  262 |     nativeCalls: 0,
  263 |     models: 0,
  264 |   })
  265 |   expect(posts).toBe(0)
  266 | }
  267 | async function running(page: Page) {
  268 |   await page.evaluate(() => (window as unknown as PrivateWindow).nativeAuthProbe.start())
> 269 |   await expect.poll(async () => (await state(page)).nativeCloses).toBeGreaterThanOrEqual(3)
      |                                                                   ^ Error: expect(received).toBeGreaterThanOrEqual(expected)
  270 |   const value = await mark(page, 'native-running')
  271 |   expect(value.session).toBe('running')
  272 |   expect(value.resources?.status).toBe('running')
  273 |   expect(value.models).toBe(2)
  274 |   expect(value.framing).toEqual([true, true])
  275 |   expect(value.cameraLive && value.rawVideoHidden).toBe(true)
  276 |   expect(value.handsConfigured).toBe(withHands)
  277 |   expect(value.handCalls).toBe(withHands ? value.nativeCalls : 0)
  278 |   expect(value.nativeHandsMax).toBe(0)
  279 |   if (withNeck) expect(value.neckStatus).toBe('unavailable')
  280 | }
  281 | async function hold(page: Page) {
  282 |   await page.evaluate(() => (window as unknown as PrivateWindow).nativeAuthProbe.holdNextResult())
  283 |   await expect.poll(() => state(page)).toMatchObject({ held: true })
  284 |   const value = await mark(page, 'native-result-held')
  285 |   expect(value.nativeCloses).toBe(value.nativeCalls - 1)
  286 |   expect(value.heldStage).toBe(withHands ? 'hands' : 'face')
  287 |   expect(value.faceCalls).toBe(value.nativeCalls)
  288 |   expect(value.handCalls).toBe(withHands ? value.nativeCalls : 0)
  289 | }
  290 | async function revokedWhileHeld(page: Page) {
  291 |   const value = await mark(page, 'authority-revoked-while-native-held')
  292 |   expect(value.owned).toBe(false)
  293 |   if (withNeck) expect(value.neckStatus).toBe('unavailable')
  294 |   expect(value.cameraLive && value.held).toBe(true)
  295 |   if (withReference)
  296 |     expect(
  297 |       await page.evaluate(() => (window as unknown as PrivateWindow).nativeAuthProbe.oldCommand()),
  298 |     ).toBe(false)
  299 |   const renders = value.renderFrames,
  300 |     calls = value.nativeCalls
  301 |   await page.evaluate(
  302 |     () => new Promise((resolve) => requestAnimationFrame(() => requestAnimationFrame(resolve))),
  303 |   )
  304 |   expect(await state(page)).toMatchObject({
  305 |     renderFrames: renders,
  306 |     nativeCalls: calls,
  307 |     detectorCloses: 0,
  308 |     faceDetectorCloses: 0,
  309 |     handDetectorCloses: 0,
  310 |     handCalls: value.handCalls,
  311 |     faceCalls: value.faceCalls,
  312 |     cameraCloses: 0,
  313 |   })
  314 |   await page.evaluate(() => (window as unknown as PrivateWindow).nativeAuthProbe.beginOldActions())
  315 |   expect(posts).toBe(0)
  316 | }
  317 | async function release(page: Page) {
  318 |   await page.evaluate(() =>
  319 |     (window as unknown as PrivateWindow).nativeAuthProbe.releaseHeldResult(),
  320 |   )
  321 |   await expect
  322 |     .poll(() => state(page))
  323 |     .toMatchObject({
  324 |       held: false,
  325 |       tracksEnded: true,
  326 |       detectorCloses: 1,
  327 |       faceDetectorCloses: 1,
  328 |       handDetectorCloses: withHands ? 1 : 0,
  329 |       cameraCloses: 1,
  330 |       models: 0,
  331 |     })
  332 |   await mark(page, 'native-input-result-and-resources-closed')
  333 |   await page.evaluate(() => (window as unknown as PrivateWindow).nativeAuthProbe.finishOldActions())
  334 |   expect(posts).toBe(0)
  335 | }
  336 | for (const gender of ['male', 'female'] as const) {
  337 |   if (withNeck)
  338 |     test(`${gender} native neck captured aspect→presence→retirement→new generation`, async ({
  339 |       page,
  340 |       context,
  341 |     }) => {
  342 |       await join(context)
  343 |       await mount(page, gender)
  344 |       await running(page)
  345 |       expect(await state(page)).toMatchObject({
  346 |         neckConfigured: true,
  347 |         neckStatus: 'unavailable',
  348 |         nativePeopleMax: 0,
  349 |       })
  350 |       await mark(page, 'native-blank-no-observation')
  351 |       const mode = (mode: 'error' | 'crop' | 'multiple' | 'none') =>
  352 |         page.evaluate(
  353 |           (mode) => (window as unknown as PrivateWindow).nativeAuthProbe.setFeedbackMode(mode),
  354 |           mode,
  355 |         )
  356 |       await mode('error')
  357 |       await expect
  358 |         .poll(() => state(page))
  359 |         .toMatchObject({
  360 |           neckStatus: 'available',
  361 |           neckMatchesAuthoredAspect: true,
  362 |           neckCurrentGeneration: true,
  363 |           verifiedMs: 0,
  364 |         })
  365 |       await mark(page, 'authored-positive-same-captured-aspect-not-clinical')
  366 |       await page.evaluate(() =>
  367 |         (window as unknown as PrivateWindow).nativeAuthProbe.setNeckPresenceHidden(true),
  368 |       )
  369 |       await expect
```