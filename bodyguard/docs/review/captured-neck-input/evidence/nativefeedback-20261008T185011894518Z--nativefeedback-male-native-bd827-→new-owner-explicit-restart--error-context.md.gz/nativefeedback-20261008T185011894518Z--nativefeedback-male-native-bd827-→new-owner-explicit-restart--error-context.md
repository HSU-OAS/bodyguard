# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: nativefeedback.spec.ts >> male native held result→same-account refresh→new owner explicit restart
- Location: e2e/nativehead.spec.ts:730:3

# Error details

```
Error: ENOENT: no such file or directory, open '/private/tmp/bodyguard-native-feedback-proof.haIAU9/probe-main/../authored-fixture.json'
```

```
Error: page.evaluate: Test ended.
```

# Page snapshot

```yaml
- generic [ref=e1]:
  - generic [ref=e3]:
    - button "본문으로 이동" [ref=e4]
    - banner [ref=e5]:
      - link "BODYGUARD 서비스 소개" [ref=e6] [cursor=pointer]:
        - /url: /
        - text: BODYGUARD.
      - navigation "계정 메뉴" [ref=e7]:
        - link "내 시작" [ref=e8] [cursor=pointer]:
          - /url: /start
        - link "자세 기록" [ref=e9] [cursor=pointer]:
          - /url: /posture-records
        - link "수행 기록" [ref=e10] [cursor=pointer]:
          - /url: /records
        - link "내 계정" [ref=e11] [cursor=pointer]:
          - /url: /account
    - main [ref=e12]:
      - generic [ref=e13]:
        - paragraph [ref=e14]: MY BODYGUARD
        - heading "내 몸을 위한 시작" [active] [level=1] [ref=e15]
        - paragraph [ref=e16]: native-auth-cb051bf4-8ee3-4446-84e9-1405371d45a0@example.com
        - link "스트레칭 시작 경로 선택" [ref=e17] [cursor=pointer]:
          - /url: /explore
        - paragraph [ref=e18]:
          - link "내 수행 기록 확인" [ref=e19] [cursor=pointer]:
            - /url: /records
        - paragraph [ref=e20]:
          - link "내 자세 기록 확인" [ref=e21] [cursor=pointer]:
            - /url: /posture-records
        - paragraph [ref=e22]:
          - link "계정 관리" [ref=e23] [cursor=pointer]:
            - /url: /account
        - generic [ref=e24]:
          - heading "첫 코칭 흐름을 준비하고 있습니다" [level=2] [ref=e25]
          - paragraph [ref=e26]: 동작 검증과 남녀 3D 아바타 제작이 끝나면 스트레칭 선택과 코칭을 이곳에 연결합니다. 지금은 계정 기능을 사용할 수 있습니다.
          - paragraph [ref=e27]: 카메라는 켜지지 않았습니다.
        - button "로그아웃" [ref=e28] [cursor=pointer]
    - contentinfo [ref=e29]:
      - generic [ref=e30]: BODYGUARD
      - paragraph [ref=e31]: 일상을 위한 스트레칭과 자세 코칭 · 출시 준비 중
      - navigation "서비스 안내" [ref=e32]:
        - link "도움말" [ref=e33] [cursor=pointer]:
          - /url: /help
        - link "카메라·데이터 안내" [ref=e34] [cursor=pointer]:
          - /url: /data
  - paragraph [ref=e35]: 미완성 A37 · 가짜 카메라 · native 계정 시험 · 코칭 아님
```

# Test source

```ts
  146 |         browser: browser.version(),
  147 |         stages,
  148 |         final,
  149 |         counters,
  150 |         posts,
  151 |         external,
  152 |         errors,
  153 |         actualHuman: false,
  154 |         actualCamera: false,
  155 |         productPolicyApproved: false,
  156 |       },
  157 |       null,
  158 |       2,
  159 |     )}\n`,
  160 |   )
  161 |   await info.attach('native-head-summary', { path: file, contentType: 'application/json' })
  162 | })
  163 | async function join(context: BrowserContext) {
  164 |   const csrf = async () =>
  165 |     (await (await context.request.get('/api/v1/auth/csrf')).json()).csrf_token
  166 |   const email = `native-auth-${randomUUID()}@example.com`
  167 |   const response = await context.request.post('/api/v1/auth/signup', {
  168 |     headers: { Origin: origin, 'X-CSRF-Token': await csrf() },
  169 |     data: { email, password: '실제 계정 native 통합 시험 비밀번호 12345' },
  170 |   })
  171 |   expect(response.status()).toBe(202)
  172 |   let code = ''
  173 |   await expect
  174 |     .poll(() => {
  175 |       code = JSON.parse(readFileSync(mailbox as string, 'utf8'))[email] ?? ''
  176 |       return code
  177 |     })
  178 |     .toMatch(/^[0-9]{6}$/)
  179 |   expect(
  180 |     (
  181 |       await context.request.post('/api/v1/auth/verify', {
  182 |         headers: { Origin: origin, 'X-CSRF-Token': await csrf() },
  183 |         data: { challenge_id: (await response.json()).challenge_id, code },
  184 |       })
  185 |     ).status(),
  186 |   ).toBe(201)
  187 | }
  188 | const state = (page: Page) =>
  189 |   page.evaluate(() => (window as unknown as PrivateWindow).nativeAuthProbe.snapshot())
  190 | async function mark(page: Page, name: string) {
  191 |   const snapshot = await state(page)
  192 |   stages.push({ name, snapshot })
  193 |   return snapshot
  194 | }
  195 | async function mount(
  196 |   page: Page,
  197 |   gender: 'male' | 'female',
  198 |   withAdaptive = false,
  199 |   withTiming = false,
  200 |   withTrunk = false,
  201 | ) {
  202 |   await page.goto('/start')
  203 |   await expect(page.getByRole('heading', { name: '내 몸을 위한 시작', exact: true })).toBeVisible()
  204 |   await page.evaluate(
  205 |     async ({
  206 |       gender,
  207 |       withHands,
  208 |       withReference,
  209 |       withFeedback,
  210 |       withAdaptive,
  211 |       withTiming,
  212 |       withTrunk,
  213 |     }) => {
  214 |       const path = '/__private-native-head-probe.js'
  215 |       const module = (await import(path)) as {
  216 |         mountNativeHeadAuthProbe: typeof mountNativeHeadAuthProbe
  217 |       }
  218 |       const text = document.createElement('p')
  219 |       text.textContent = '미완성 A37 · 가짜 카메라 · native 계정 시험 · 코칭 아님'
  220 |       document.body.append(text)
  221 |       const canvas = document.createElement('canvas')
  222 |       canvas.id = 'native-avatar'
  223 |       document.body.append(canvas)
  224 |       ;(window as unknown as PrivateWindow).nativeAuthProbe = module.mountNativeHeadAuthProbe(
  225 |         canvas,
  226 |         gender,
  227 |         // Synthetic display basis only. A blank fake camera cannot calibrate anatomy.
  228 |         withHands
  229 |           ? {
  230 |               cameraReferences: { left: [0, 0, 0, 1], right: [0, 0, 0, 1] },
  231 |               sceneFromCamera: [0, 0, 0, 1],
  232 |             }
  233 |           : undefined,
  234 |         withReference,
  235 |         withFeedback,
  236 |         withAdaptive,
  237 |         withTiming,
  238 |         withTrunk,
  239 |       )
  240 |     },
  241 |     { gender, withHands, withReference, withFeedback, withAdaptive, withTiming, withTrunk },
  242 |   )
  243 |   await expect
  244 |     .poll(() => state(page))
  245 |     .toMatchObject({ auth: 'ready', hook: 'idle', cameras: 0, nativeCalls: 0, renderFrames: 0 })
> 246 |   await page.evaluate(() => (window as unknown as PrivateWindow).nativeAuthProbe.prepare())
      |              ^ Error: page.evaluate: Test ended.
  247 |   expect(await state(page)).toMatchObject({
  248 |     hook: 'prepared',
  249 |     cameras: 0,
  250 |     nativeCalls: 0,
  251 |     models: 0,
  252 |   })
  253 |   expect(posts).toBe(0)
  254 | }
  255 | async function running(page: Page) {
  256 |   await page.evaluate(() => (window as unknown as PrivateWindow).nativeAuthProbe.start())
  257 |   await expect.poll(async () => (await state(page)).nativeCloses).toBeGreaterThanOrEqual(3)
  258 |   const value = await mark(page, 'native-running')
  259 |   expect(value.session).toBe('running')
  260 |   expect(value.resources?.status).toBe('running')
  261 |   expect(value.models).toBe(2)
  262 |   expect(value.framing).toEqual([true, true])
  263 |   expect(value.cameraLive && value.rawVideoHidden).toBe(true)
  264 |   expect(value.handsConfigured).toBe(withHands)
  265 |   expect(value.handCalls).toBe(withHands ? value.nativeCalls : 0)
  266 |   expect(value.nativeHandsMax).toBe(0)
  267 | }
  268 | async function hold(page: Page) {
  269 |   await page.evaluate(() => (window as unknown as PrivateWindow).nativeAuthProbe.holdNextResult())
  270 |   await expect.poll(() => state(page)).toMatchObject({ held: true })
  271 |   const value = await mark(page, 'native-result-held')
  272 |   expect(value.nativeCloses).toBe(value.nativeCalls - 1)
  273 |   expect(value.heldStage).toBe(withHands ? 'hands' : 'face')
  274 |   expect(value.faceCalls).toBe(value.nativeCalls)
  275 |   expect(value.handCalls).toBe(withHands ? value.nativeCalls : 0)
  276 | }
  277 | async function revokedWhileHeld(page: Page) {
  278 |   const value = await mark(page, 'authority-revoked-while-native-held')
  279 |   expect(value.owned).toBe(false)
  280 |   expect(value.cameraLive && value.held).toBe(true)
  281 |   if (withReference)
  282 |     expect(
  283 |       await page.evaluate(() => (window as unknown as PrivateWindow).nativeAuthProbe.oldCommand()),
  284 |     ).toBe(false)
  285 |   const renders = value.renderFrames,
  286 |     calls = value.nativeCalls
  287 |   await page.evaluate(
  288 |     () => new Promise((resolve) => requestAnimationFrame(() => requestAnimationFrame(resolve))),
  289 |   )
  290 |   expect(await state(page)).toMatchObject({
  291 |     renderFrames: renders,
  292 |     nativeCalls: calls,
  293 |     detectorCloses: 0,
  294 |     faceDetectorCloses: 0,
  295 |     handDetectorCloses: 0,
  296 |     handCalls: value.handCalls,
  297 |     faceCalls: value.faceCalls,
  298 |     cameraCloses: 0,
  299 |   })
  300 |   await page.evaluate(() => (window as unknown as PrivateWindow).nativeAuthProbe.beginOldActions())
  301 |   expect(posts).toBe(0)
  302 | }
  303 | async function release(page: Page) {
  304 |   await page.evaluate(() =>
  305 |     (window as unknown as PrivateWindow).nativeAuthProbe.releaseHeldResult(),
  306 |   )
  307 |   await expect
  308 |     .poll(() => state(page))
  309 |     .toMatchObject({
  310 |       held: false,
  311 |       tracksEnded: true,
  312 |       detectorCloses: 1,
  313 |       faceDetectorCloses: 1,
  314 |       handDetectorCloses: withHands ? 1 : 0,
  315 |       cameraCloses: 1,
  316 |       models: 0,
  317 |     })
  318 |   await mark(page, 'native-input-result-and-resources-closed')
  319 |   await page.evaluate(() => (window as unknown as PrivateWindow).nativeAuthProbe.finishOldActions())
  320 |   expect(posts).toBe(0)
  321 | }
  322 | for (const gender of ['male', 'female'] as const) {
  323 |   if (withFeedback)
  324 |     test(`${gender} native first-start stage timing without raw input`, async ({
  325 |       page,
  326 |       context,
  327 |     }, info) => {
  328 |       await join(context)
  329 |       await mount(page, gender, false, true)
  330 |       await running(page)
  331 |       const timing = (await mark(page, 'native-startup-timed')).startupTiming
  332 |       expect(timing).not.toBeNull()
  333 |       if (!timing) throw new Error('Native startup timing unavailable')
  334 |       writeFileSync(info.outputPath('native-startup-timing.json'), JSON.stringify(timing, null, 2))
  335 |       expect(timing.invalid).toBe(false)
  336 |       expect(timing.events.length).toBeLessThanOrEqual(30)
  337 |       for (const stage of [
  338 |         'camera',
  339 |         'body-sdk',
  340 |         'face-sdk',
  341 |         'hands-sdk',
  342 |         'avatar',
  343 |         'render',
  344 |         'body',
  345 |         'face',
  346 |         'hands',
```