//#region src/pose/constants.ts
var WASM_BASE_PATH = "/mediapipe/wasm";
var POSE_MODELS = {
	lite: {
		label: "lite (5.5MB)",
		path: "/models/pose_landmarker_lite.task"
	},
	full: {
		label: "full (9.0MB)",
		path: "/models/pose_landmarker_full.task"
	},
	heavy: {
		label: "heavy (29.2MB)",
		path: "/models/pose_landmarker_heavy.task"
	}
};
var CAMERA_CONSTRAINTS = {
	audio: false,
	video: {
		width: { ideal: 640 },
		height: { ideal: 480 },
		facingMode: "user"
	}
};
//#endregion
//#region src/pose/camera.ts
async function openCamera(video, signal) {
	signal.throwIfAborted();
	const stream = await navigator.mediaDevices.getUserMedia(CAMERA_CONSTRAINTS);
	const close = () => closeCamera(video, stream);
	try {
		signal.throwIfAborted();
		signal.addEventListener("abort", close, { once: true });
		video.srcObject = stream;
		await video.play();
		signal.throwIfAborted();
		return stream;
	} catch (error) {
		close();
		throw error;
	} finally {
		signal.removeEventListener("abort", close);
	}
}
function closeCamera(video, stream) {
	for (const track of stream?.getTracks() ?? []) track.stop();
	if (video && video.srcObject === stream) video.srcObject = null;
}
//#endregion
//#region node_modules/.pnpm/@mediapipe+tasks-vision@1.0.1/node_modules/@mediapipe/tasks-vision/vision_bundle.mjs
var t = "undefined" != typeof self ? self : {};
function e(e, r) {
	t: {
		for (var n = ["CLOSURE_FLAGS"], i = t, s = 0; s < n.length; s++) if (null == (i = i[n[s]])) {
			n = null;
			break t;
		}
		n = i;
	}
	return null != (e = n && n[e]) ? e : r;
}
function r(e, r) {
	e = e.split(".");
	for (var n, i = t; e.length && (n = e.shift());) e.length || void 0 === r ? i = i[n] && i[n] !== Object.prototype[n] ? i[n] : i[n] = {} : i[n] = r;
}
function n() {
	throw Error("Invalid UTF8");
}
function i(t, e) {
	return e = String.fromCharCode.apply(null, e), null == t ? e : t + e;
}
var s;
var o;
var a = void 0;
var h = "undefined" != typeof TextDecoder;
var u = "undefined" != typeof TextEncoder;
function c(t) {
	if (u) t = (o ||= new TextEncoder()).encode(t);
	else {
		let r = 0, n = new Uint8Array(3 * t.length);
		for (let i = 0; i < t.length; i++) {
			var e = t.charCodeAt(i);
			if (e < 128) n[r++] = e;
			else {
				if (e < 2048) n[r++] = e >> 6 | 192;
				else {
					if (e >= 55296 && e <= 57343) {
						if (e <= 56319 && i < t.length) {
							let s = t.charCodeAt(++i);
							if (s >= 56320 && s <= 57343) {
								e = 1024 * (e - 55296) + s - 56320 + 65536, n[r++] = e >> 18 | 240, n[r++] = e >> 12 & 63 | 128, n[r++] = e >> 6 & 63 | 128, n[r++] = 63 & e | 128;
								continue;
							}
							i--;
						}
						e = 65533;
					}
					n[r++] = e >> 12 | 224, n[r++] = e >> 6 & 63 | 128;
				}
				n[r++] = 63 & e | 128;
			}
		}
		t = r === n.length ? n : n.subarray(0, r);
	}
	return t;
}
function l(e) {
	t.setTimeout(() => {
		throw e;
	}, 0);
}
var d = e(610401301, !1);
var f = e(748402147, !0);
function p() {
	var e = t.navigator;
	return e && (e = e.userAgent) ? e : "";
}
var g;
var m = t.navigator;
function v(t) {
	return v[" "](t), t;
}
g = m && m.userAgentData || null, v[" "] = function() {};
var _ = {};
var y = null;
function E(t) {
	var e = t.length, r = 3 * e / 4;
	r % 3 ? r = Math.floor(r) : -1 != "=.".indexOf(t[e - 1]) && (r = -1 != "=.".indexOf(t[e - 2]) ? r - 2 : r - 1);
	var n = new Uint8Array(r), i = 0;
	return function(t, e) {
		function r(e) {
			for (; n < t.length;) {
				let e = t.charAt(n++), r = y[e];
				if (null != r) return r;
				if (!/^[\s\xa0]*$/.test(e)) throw Error("Unknown base64 encoding at char: " + e);
			}
			return e;
		}
		A();
		for (var n = 0;;) {
			let t = r(-1), n = r(0), i = r(64), s = r(64);
			if (64 === s && -1 === t) break;
			e(t << 2 | n >> 4), 64 != i && (e(n << 4 & 240 | i >> 2), 64 != s && e(i << 6 & 192 | s));
		}
	}(t, function(t) {
		n[i++] = t;
	}), i !== r ? n.subarray(0, i) : n;
}
function A() {
	if (!y) {
		y = {};
		var t = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789".split(""), e = [
			"+/=",
			"+/",
			"-_=",
			"-_.",
			"-_"
		];
		for (let r = 0; r < 5; r++) {
			let n = t.concat(e[r].split(""));
			_[r] = n;
			for (let t = 0; t < n.length; t++) {
				let e = n[t];
				void 0 === y[e] && (y[e] = t);
			}
		}
	}
}
var w = "undefined" != typeof Uint8Array;
var b = !(!(d && g && g.brands.length > 0) && (-1 != p().indexOf("Trident") || -1 != p().indexOf("MSIE"))) && "function" == typeof btoa;
var T = /[-_.]/g;
var k = {
	"-": "+",
	_: "/",
	".": "="
};
function S(t) {
	return k[t] || "";
}
function L(t) {
	if (!b) return E(t);
	t = T.test(t) ? t.replace(T, S) : t, t = atob(t);
	var e = new Uint8Array(t.length);
	for (let r = 0; r < t.length; r++) e[r] = t.charCodeAt(r);
	return e;
}
function x(t) {
	return w && null != t && t instanceof Uint8Array;
}
var R = {};
function I() {
	return C ||= new N(null, R);
}
function F(t) {
	M(R);
	var e = t.g;
	return null == (e = null == e || x(e) ? e : "string" == typeof e ? L(e) : null) ? e : t.g = e;
}
var C;
var N = class {
	h() {
		return new Uint8Array(F(this) || 0);
	}
	constructor(t, e) {
		if (M(e), this.g = t, null != t && 0 === t.length) throw Error("ByteString should be constructed with non-empty values");
	}
};
function M(t) {
	if (t !== R) throw Error("illegal external caller");
}
function O(t, e) {
	t.__closure__error__context__984382 || (t.__closure__error__context__984382 = {}), t.__closure__error__context__984382.severity = e;
}
var D = void 0;
function P(t) {
	return O(t = Error(t), "warning"), t;
}
function $(t, e) {
	if (null != t) {
		var r = D ??= {}, n = r[t] || 0;
		n >= e || (r[t] = n + 1, O(t = Error(), "incident"), l(t));
	}
}
function U() {
	return "function" == typeof BigInt;
}
var B = "function" == typeof Symbol && "symbol" == typeof Symbol();
function G(t, e, r = !1) {
	return "function" == typeof Symbol && "symbol" == typeof Symbol() ? r && Symbol.for && t ? Symbol.for(t) : null != t ? Symbol(t) : Symbol() : e;
}
var j;
var V = G("jas", void 0, !0);
var H = G(void 0, "0di");
var K = G(void 0, "1oa");
var X = G(void 0, Symbol());
var W = G(void 0, "0ub");
var z = G(void 0, "0ubs");
var Y = G(void 0, "0ubsb");
var q = G(void 0, "0actk");
var J = G("m_m", "kb", !0);
var Z = G();
var Q = { Va: {
	value: 0,
	configurable: !0,
	writable: !0,
	enumerable: !1
} };
var tt = Object.defineProperties;
var et = B ? V : "Va";
var rt = [];
function nt(t, e) {
	B || et in t || tt(t, Q), t[et] |= e;
}
function it(t, e) {
	B || et in t || tt(t, Q), t[et] = e;
}
function st(t) {
	return nt(t, 34), t;
}
function ot(t) {
	return nt(t, 8192), t;
}
it(rt, 7), j = Object.freeze(rt);
var at = {};
function ht(t, e) {
	return void 0 === e ? t.h !== ut && !!(2 & t.A[et]) : !!(2 & e) && t.h !== ut;
}
var ut = {};
function ct(t, e) {
	if (null != t) {
		if ("string" == typeof t) t = t ? new N(t, R) : I();
		else if (t.constructor !== N) if (x(t)) t = t.length ? new N(new Uint8Array(t), R) : I();
		else {
			if (!e) throw Error();
			t = void 0;
		}
	}
	return t;
}
var lt = class {
	constructor(t, e, r) {
		this.g = t, this.h = e, this.j = r;
	}
	next() {
		var t = this.g.next();
		return t.done || (t.value = this.h.call(this.j, t.value)), t;
	}
	[Symbol.iterator]() {
		return this;
	}
};
var dt = Object.freeze({});
function ft(t, e, r) {
	var n, i = 128 & e ? 0 : -1, s = t.length;
	(n = !!s) && (n = null != (n = t[s - 1]) && "object" == typeof n && n.constructor === Object);
	var o = s + (n ? -1 : 0);
	for (e = 128 & e ? 1 : 0; e < o; e++) r(e - i, t[e]);
	if (n) {
		t = t[s - 1];
		for (let e in t) !isNaN(e) && r(+e, t[e]);
	}
}
var pt = {};
function gt(t) {
	return 128 & t ? pt : void 0;
}
function mt(t) {
	return t.ib = !0, t;
}
var vt = mt((t) => "number" == typeof t);
var _t = mt((t) => "string" == typeof t);
var yt = mt((t) => "boolean" == typeof t);
var Et = "function" == typeof t.BigInt && "bigint" == typeof t.BigInt(0);
function At(t) {
	var e = t;
	if (_t(e)) {
		if (!/^\s*(?:-?[1-9]\d*|0)?\s*$/.test(e)) throw Error(String(e));
	} else if (vt(e) && !Number.isSafeInteger(e)) throw Error(String(e));
	return Et ? BigInt(t) : t = yt(t) ? t ? "1" : "0" : _t(t) ? t.trim() || "0" : String(t);
}
var wt = mt((t) => Et ? t >= Tt && t <= St : "-" === t[0] ? Lt(t, bt) : Lt(t, kt));
var bt = Number.MIN_SAFE_INTEGER.toString();
var Tt = Et ? BigInt(Number.MIN_SAFE_INTEGER) : void 0;
var kt = Number.MAX_SAFE_INTEGER.toString();
var St = Et ? BigInt(Number.MAX_SAFE_INTEGER) : void 0;
function Lt(t, e) {
	if (t.length > e.length) return !1;
	if (t.length < e.length || t === e) return !0;
	for (let r = 0; r < t.length; r++) {
		let n = t[r], i = e[r];
		if (n > i) return !1;
		if (n < i) return !0;
	}
}
var xt;
var Rt = "function" == typeof Uint8Array.prototype.slice;
var It = 0;
var Ft = 0;
function Ct(t) {
	var e = t >>> 0;
	It = e, Ft = (t - e) / 4294967296 >>> 0;
}
function Nt(t) {
	if (t < 0) {
		Ct(-t);
		let [e, r] = jt(It, Ft);
		It = e >>> 0, Ft = r >>> 0;
	} else Ct(t);
}
function Mt(t) {
	var e = xt ||= /* @__PURE__ */ new DataView(/* @__PURE__ */ new ArrayBuffer(8));
	e.setFloat32(0, +t, !0), Ft = 0, It = e.getUint32(0, !0);
}
function Ot(t, e) {
	var r = 4294967296 * e + (t >>> 0);
	return Number.isSafeInteger(r) ? r : $t(t, e);
}
function Dt(t, e) {
	return At(U() ? BigInt.asUintN(64, (BigInt(e >>> 0) << BigInt(32)) + BigInt(t >>> 0)) : $t(t, e));
}
function Pt(t, e) {
	return U() ? At(BigInt.asIntN(64, (BigInt.asUintN(32, BigInt(e)) << BigInt(32)) + BigInt.asUintN(32, BigInt(t)))) : At(Bt(t, e));
}
function $t(t, e) {
	if (t >>>= 0, (e >>>= 0) <= 2097151) var r = "" + (4294967296 * e + t);
	else U() ? r = "" + (BigInt(e) << BigInt(32) | BigInt(t)) : (t = (16777215 & t) + 6777216 * (r = 16777215 & (t >>> 24 | e << 8)) + 6710656 * (e = e >> 16 & 65535), r += 8147497 * e, e *= 2, t >= 1e7 && (r += t / 1e7 >>> 0, t %= 1e7), r >= 1e7 && (e += r / 1e7 >>> 0, r %= 1e7), r = e + Ut(r) + Ut(t));
	return r;
}
function Ut(t) {
	return t = String(t), "0000000".slice(t.length) + t;
}
function Bt(t, e) {
	if (2147483648 & e) if (U()) t = "" + (BigInt(0 | e) << BigInt(32) | BigInt(t >>> 0));
	else {
		let [r, n] = jt(t, e);
		t = "-" + $t(r, n);
	}
	else t = $t(t, e);
	return t;
}
function Gt(t) {
	if (t.length < 16) Nt(Number(t));
	else if (U()) t = BigInt(t), It = Number(t & BigInt(4294967295)) >>> 0, Ft = Number(t >> BigInt(32) & BigInt(4294967295));
	else {
		let e = +("-" === t[0]);
		Ft = It = 0;
		let r = t.length;
		for (let n = e, i = (r - e) % 6 + e; i <= r; n = i, i += 6) {
			let e = Number(t.slice(n, i));
			Ft *= 1e6, (It = 1e6 * It + e) >= 4294967296 && (Ft += Math.trunc(It / 4294967296), Ft >>>= 0, It >>>= 0);
		}
		if (e) {
			let [t, e] = jt(It, Ft);
			It = t, Ft = e;
		}
	}
}
function jt(t, e) {
	return e = ~e, t ? t = 1 + ~t : e += 1, [t, e];
}
function Vt(t) {
	return Array.prototype.slice.call(t);
}
var Ht = "function" == typeof BigInt ? BigInt.asIntN : void 0;
var Kt = "function" == typeof BigInt ? BigInt.asUintN : void 0;
var Xt = Number.isSafeInteger;
var Wt = Number.isFinite;
var zt = Math.trunc;
var Yt = At(0);
function qt(t) {
	if ("number" != typeof t) throw Error(`Value of float/double field must be a number, found ${typeof t}: ${t}`);
	return t;
}
function Jt(t) {
	return null == t || "number" == typeof t ? t : "NaN" === t || "Infinity" === t || "-Infinity" === t ? Number(t) : void 0;
}
function Zt(t) {
	if ("boolean" != typeof t) {
		var e = typeof t;
		throw Error(`Expected boolean but got ${"object" != e ? e : t ? Array.isArray(t) ? "array" : e : "null"}: ${t}`);
	}
	return t;
}
var Qt = /^-?([1-9][0-9]*|0)(\.[0-9]+)?$/;
function te(t) {
	switch (typeof t) {
		case "bigint": return !0;
		case "number": return Wt(t);
		case "string": return Qt.test(t);
		default: return !1;
	}
}
function ee(t) {
	if (null != t) {
		if (!Wt(t)) throw P("enum");
		t |= 0;
	}
	return t;
}
function re(t) {
	if (null == t) return t;
	if ("string" == typeof t && t) t = +t;
	else if ("number" != typeof t) return;
	return Wt(t) ? 0 | t : void 0;
}
function ne(t) {
	if (null == t) return t;
	if ("string" == typeof t && t) t = +t;
	else if ("number" != typeof t) return;
	return Wt(t) ? t >>> 0 : void 0;
}
function ie(t, e) {
	if (e ??= 1024, !te(t)) throw P("int64");
	var r = typeof t;
	switch (e) {
		case 512: switch (r) {
			case "string": return ce(t);
			case "bigint": return String(Ht(64, t));
			default: return ue(t);
		}
		case 1024: switch (r) {
			case "string": return le(t);
			case "bigint": return At(Ht(64, t));
			default: return de(t);
		}
		case 0: switch (r) {
			case "string": return ce(t);
			case "bigint": return At(Ht(64, t));
			default: return ae(t);
		}
		default: return function(t, e = `unexpected value ${t}!`) {
			throw Error(e);
		}(e, "Unknown format requested type for int64");
	}
}
function se(t) {
	var e = t.length;
	return ("-" === t[0] ? e < 20 || 20 === e && t <= "-9223372036854775808" : e < 19 || 19 === e && t <= "9223372036854775807") ? t : (Gt(t), Bt(It, Ft));
}
function oe(t) {
	if ("-" === t[0]) var e = !1;
	else e = (e = t.length) < 20 || 20 === e && t <= "18446744073709551615";
	return e ? t : (Gt(t), $t(It, Ft));
}
function ae(t) {
	if (t = zt(t), !Xt(t)) {
		Nt(t);
		var e = It, r = Ft;
		(t = 2147483648 & r) && (r = ~r >>> 0, 0 == (e = 1 + ~e >>> 0) && (r = r + 1 >>> 0)), t = "number" == typeof (e = Ot(e, r)) ? t ? -e : e : t ? "-" + e : e;
	}
	return t;
}
function he(t) {
	return (t = zt(t)) >= 0 && Xt(t) || (Nt(t), t = Ot(It, Ft)), t;
}
function ue(t) {
	return t = zt(t), Xt(t) ? t = String(t) : (Nt(t), t = Bt(It, Ft)), t;
}
function ce(t) {
	var e = zt(Number(t));
	return Xt(e) ? String(e) : (-1 !== (e = t.indexOf(".")) && (t = t.substring(0, e)), se(t));
}
function le(t) {
	var e = zt(Number(t));
	return Xt(e) ? At(e) : (-1 !== (e = t.indexOf(".")) && (t = t.substring(0, e)), U() ? At(Ht(64, BigInt(t))) : At(se(t)));
}
function de(t) {
	return Xt(t) ? At(ae(t)) : At(ue(t));
}
function fe(t) {
	var e = typeof t;
	return null == t ? t : "bigint" === e ? At(Ht(64, t)) : te(t) ? "string" === e ? le(t) : de(t) : void 0;
}
function pe(t) {
	if (null == t) return t;
	var e = typeof t;
	if ("bigint" === e) return String(Ht(64, t));
	if (te(t)) {
		if ("string" === e) return ce(t);
		if ("number" === e) return ae(t);
	}
}
function ge(t) {
	if (null == t || "string" == typeof t || t instanceof N) return t;
}
function me(t) {
	if ("string" != typeof t) throw Error();
	return t;
}
function ve(t) {
	if (null != t && "string" != typeof t) throw Error();
	return t;
}
function _e(t) {
	return null == t || "string" == typeof t ? t : void 0;
}
function ye(t, e, r, n) {
	return null != t && t[J] === at ? t : Array.isArray(t) ? ((n = (r = 0 | t[et]) | 32 & n | 2 & n) !== r && it(t, n), new e(t)) : (r ? 2 & n ? ((t = e[H]) || (st((t = new e()).A), t = e[H] = t), e = t) : e = new e() : e = void 0, e);
}
function Ee(t, e, r) {
	return null == (t = e ? ie(t, 1024) : fe(t)) ? r ? Yt : void 0 : t;
}
function Ae(t) {
	return t;
}
var we = {};
var be = function() {
	try {
		return v(new class extends Map {
			constructor() {
				super();
			}
		}()), !1;
	} catch {
		return !0;
	}
}();
var Te = class {
	constructor() {
		this.g = /* @__PURE__ */ new Map();
	}
	get(t) {
		return this.g.get(t);
	}
	set(t, e) {
		return this.g.set(t, e), this.size = this.g.size, this;
	}
	delete(t) {
		return t = this.g.delete(t), this.size = this.g.size, t;
	}
	clear() {
		this.g.clear(), this.size = this.g.size;
	}
	has(t) {
		return this.g.has(t);
	}
	entries() {
		return this.g.entries();
	}
	keys() {
		return this.g.keys();
	}
	values() {
		return this.g.values();
	}
	forEach(t, e) {
		return this.g.forEach(t, e);
	}
	[Symbol.iterator]() {
		return this.entries();
	}
};
var ke = be ? (Object.setPrototypeOf(Te.prototype, Map.prototype), Object.defineProperties(Te.prototype, { size: {
	value: 0,
	configurable: !0,
	enumerable: !0,
	writable: !0
} }), Te) : class extends Map {
	constructor() {
		super();
	}
};
function Se(t) {
	return t;
}
function Le(t) {
	if (2 & t.M) throw Error("Cannot mutate an immutable Map");
}
var xe;
var Re = class extends ke {
	constructor(t, e, r = Se, n = Se) {
		super(), this.M = 0 | t[et], this.N = e, this.ba = r, this.na = this.N ? Ie : n;
		for (let i = 0; i < t.length; i++) {
			let s = t[i], o = r(s[0], !1, !0), a = s[1];
			e ? void 0 === a && (a = null) : a = n(s[1], !1, !0, void 0, void 0, this.M), super.set(o, a);
		}
	}
	ea(t) {
		return ot(Array.from(super.entries(), t));
	}
	clear() {
		Le(this), super.clear();
	}
	delete(t) {
		return Le(this), super.delete(this.ba(t, !0, !1));
	}
	entries() {
		if (this.N) {
			var t = super.keys();
			t = new lt(t, Fe, this);
		} else t = super.entries();
		return t;
	}
	values() {
		if (this.N) {
			var t = super.keys();
			t = new lt(t, Re.prototype.get, this);
		} else t = super.values();
		return t;
	}
	forEach(t, e) {
		this.N ? super.forEach((r, n, i) => {
			t.call(e, i.get(n), n, i);
		}) : super.forEach(t, e);
	}
	set(t, e) {
		return Le(this), null == (t = this.ba(t, !0, !1)) ? this : null == e ? (super.delete(t), this) : super.set(t, this.na(e, !0, !0, this.N, !1, this.M));
	}
	gb(t) {
		var e = this.ba(t[0], !1, !0);
		t = t[1], t = this.N ? void 0 === t ? null : t : this.na(t, !1, !0, void 0, !1, this.M), super.set(e, t);
	}
	has(t) {
		return super.has(this.ba(t, !1, !1));
	}
	get(t) {
		t = this.ba(t, !1, !1);
		var e = super.get(t);
		if (void 0 !== e) {
			var r = this.N;
			return r ? ((r = this.na(e, !1, !0, r, this.Fa, this.M)) !== e && super.set(t, r), r) : e;
		}
	}
	[Symbol.iterator]() {
		return this.entries();
	}
};
function Ie(t, e, r, n, i, s) {
	return t = ye(t, n, r, s), i && (t = Ze(t)), t;
}
function Fe(t) {
	return [t, this.get(t)];
}
function Ce() {
	return xe ||= new Re(st([]), void 0, void 0, void 0, we);
}
function Ne(t) {
	return X ? t[X] : void 0;
}
function Me(t, e) {
	for (let r in t) !isNaN(r) && e(t, +r, t[r]);
}
Re.prototype.toJSON = void 0;
var De;
var Pe;
var $e = class {};
var Ue = { cb: !0 };
function Be(t, e) {
	e < 100 || $(z, 1);
}
function Ge(t, e, r, n) {
	var i = void 0 !== n;
	n = !!n;
	var s, o = X;
	!i && B && o && (s = t[o]) && Me(s, Be), o = [];
	var a = t.length;
	s = 4294967295;
	var h = !1, u = !!(64 & e), c = u ? 128 & e ? 0 : -1 : void 0;
	if (!(1 & e)) {
		var l = a && t[a - 1];
		null != l && "object" == typeof l && l.constructor === Object ? s = --a : l = void 0, !u || 128 & e || i || (h = !0, s = Ae(s - c, c, t, l, void 0) + c);
	}
	e = void 0;
	for (var d = 0; d < a; d++) {
		let i = t[d];
		if (null != i && null != (i = r(i, n))) if (u && d >= s) {
			let t = d - c;
			(e ??= {})[t] = i;
		} else o[d] = i;
	}
	if (l) for (let t in l) {
		if (null == (a = l[t]) || null == (a = r(a, n))) continue;
		let i;
		d = +t, u && !Number.isNaN(d) && (i = d + c) < s ? o[i] = a : (e ??= {})[t] = a;
	}
	return e && (h ? o.push(e) : o[s] = e), i && X && (t = Ne(t)) && t instanceof $e && (o[X] = function(t) {
		var e = new $e();
		return Me(t, (t, r, n) => {
			e[r] = Vt(n);
		}), e.ka = t.ka, e;
	}(t)), o;
}
function je(t) {
	return t[0] = Ve(t[0]), t[1] = Ve(t[1]), t;
}
function Ve(t) {
	switch (typeof t) {
		case "number": return Number.isFinite(t) ? t : "" + t;
		case "bigint": return wt(t) ? Number(t) : "" + t;
		case "boolean": return t ? 1 : 0;
		case "object":
			if (Array.isArray(t)) {
				var e = 0 | t[et];
				return 0 === t.length && 1 & e ? void 0 : Ge(t, e, Ve);
			}
			if (null != t && t[J] === at) return He(t);
			if (t instanceof N) {
				if (null == (e = t.g)) t = "";
				else if ("string" == typeof e) t = e;
				else {
					if (b) {
						for (var r = "", n = 0, i = e.length - 10240; n < i;) r += String.fromCharCode.apply(null, e.subarray(n, n += 10240));
						r += String.fromCharCode.apply(null, n ? e.subarray(n) : e), e = btoa(r);
					} else {
						void 0 === r && (r = 0), A(), r = _[r], n = Array(Math.floor(e.length / 3)), i = r[64] || "";
						let t = 0, u = 0;
						for (; t < e.length - 2; t += 3) {
							var s = e[t], o = e[t + 1], a = e[t + 2], h = r[s >> 2];
							s = r[(3 & s) << 4 | o >> 4], o = r[(15 & o) << 2 | a >> 6], a = r[63 & a], n[u++] = h + s + o + a;
						}
						switch (h = 0, a = i, e.length - t) {
							case 2: a = r[(15 & (h = e[t + 1])) << 2] || i;
							case 1: e = e[t], n[u] = r[e >> 2] + r[(3 & e) << 4 | h >> 4] + a + i;
						}
						e = n.join("");
					}
					t = t.g = e;
				}
				return t;
			}
			return t instanceof Re ? t = 0 !== t.size ? t.ea(je) : void 0 : void 0;
	}
	return t;
}
function He(t) {
	return Ge(t = t.A, 0 | t[et], Ve);
}
function Ke(t, e) {
	return Xe(t, e[0], e[1]);
}
function Xe(t, e, r, n = 0) {
	if (null == t) {
		var i = 32;
		r ? (t = [r], i |= 128) : t = [], e && (i = -16760833 & i | (1023 & e) << 14);
	} else {
		if (!Array.isArray(t)) throw Error("narr");
		if (i = 0 | t[et], f && 1 & i) throw Error("rfarr");
		if (2048 & i && !(2 & i) && function() {
			if (f) throw Error("carr");
			$(q, 5);
		}(), 256 & i) throw Error("farr");
		if (64 & i) return (i | n) !== i && it(t, i | n), t;
		if (r && (i |= 128, r !== t[0])) throw Error("mid");
		t: {
			i |= 64;
			var s = (r = t).length;
			if (s) {
				var o = s - 1;
				let t = r[o];
				if (null != t && "object" == typeof t && t.constructor === Object) {
					if ((o -= e = 128 & i ? 0 : -1) >= 1024) throw Error("pvtlmt");
					for (var a in t) (s = +a) < o && (r[s + e] = t[a], delete t[a]);
					i = -16760833 & i | (1023 & o) << 14;
					break t;
				}
			}
			if (e) {
				if ((a = Math.max(e, s - (128 & i ? 0 : -1))) > 1024) throw Error("spvt");
				i = -16760833 & i | (1023 & a) << 14;
			}
		}
	}
	return it(t, 64 | i | n), t;
}
function We(t, e) {
	if ("object" != typeof t) return t;
	if (Array.isArray(t)) {
		var r = 0 | t[et];
		return 0 === t.length && 1 & r ? void 0 : ze(t, r, e);
	}
	if (null != t && t[J] === at) return qe(t);
	if (t instanceof Re) {
		if (2 & (e = t.M)) return t;
		if (!t.size) return;
		if (r = st(t.ea()), t.N) for (t = 0; t < r.length; t++) {
			let n = r[t], i = n[1];
			i = null == i || "object" != typeof i ? void 0 : null != i && i[J] === at ? qe(i) : Array.isArray(i) ? ze(i, 0 | i[et], !!(32 & e)) : void 0, n[1] = i;
		}
		return r;
	}
	return t instanceof N ? t : void 0;
}
function ze(t, e, r) {
	return 2 & e || (!r || 4096 & e || 16 & e ? t = Je(t, e, !1, r && !(16 & e)) : (nt(t, 34), 4 & e && Object.freeze(t))), t;
}
function Ye(t, e, r) {
	return t = new t.constructor(e), r && (t.h = ut), t.m = ut, t;
}
function qe(t) {
	var e = t.A, r = 0 | e[et];
	return ht(t, r) ? t : rr(t, e, r) ? Ye(t, e) : Je(e, r);
}
function Je(t, e, r, n) {
	return n ??= !!(34 & e), t = Ge(t, e, We, n), n = 32, r && (n |= 2), it(t, e = 16769217 & e | n), t;
}
function Ze(t) {
	var e = t.A, r = 0 | e[et];
	return ht(t, r) ? rr(t, e, r) ? Ye(t, e, !0) : new t.constructor(Je(e, r, !1)) : t;
}
function Qe(t) {
	if (t.h !== ut) return !1;
	var e = t.A;
	return nt(e = Je(e, 0 | e[et]), 2048), t.A = e, t.h = void 0, t.m = void 0, !0;
}
function tr(t) {
	if (!Qe(t) && ht(t, 0 | t.A[et])) throw Error();
}
function er(t, e) {
	void 0 === e && (e = 0 | t[et]), 32 & e && !(4096 & e) && it(t, 4096 | e);
}
function rr(t, e, r) {
	return !!(2 & r) || !(!(32 & r) || 4096 & r) && (it(e, 2 | r), t.h = ut, !0);
}
var nr = At(0);
var ir = {};
function sr(t, e, r, n) {
	if (null !== (e = or(t.A, e, void 0, n)) || r && t.m !== ut) return e;
}
function or(t, e, r, n) {
	if (-1 === e) return null;
	var i = e + (r ? 0 : -1), s = t.length - 1;
	if (!(s < 1 + (r ? 0 : -1))) {
		if (i >= s) {
			var o = t[s];
			if (null != o && "object" == typeof o && o.constructor === Object) {
				r = o[e];
				var a = !0;
			} else {
				if (i !== s) return;
				r = o;
			}
		} else r = t[i];
		if (n && null != r) {
			if (null == (n = n(r))) return n;
			if (!Object.is(n, r)) return a ? o[e] = n : t[i] = n, n;
		}
		return r;
	}
}
function ar(t, e, r, n) {
	tr(t);
	var i = t.A;
	return hr(i, 0 | i[et], e, r, n), t;
}
function hr(t, e, r, n, i) {
	var s = r + (i ? 0 : -1), o = t.length - 1;
	if (o >= 1 + (i ? 0 : -1) && s >= o) {
		let i = t[o];
		if (null != i && "object" == typeof i && i.constructor === Object) return i[r] = n, e;
	}
	return s <= o ? (t[s] = n, e) : (void 0 !== n && (r >= (o = (e ??= 0 | t[et]) >> 14 & 1023 || 536870912) ? null != n && (t[o + (i ? 0 : -1)] = { [r]: n }) : t[s] = n), e);
}
function ur(t, e, r, n) {
	var i = t.A;
	return void 0 !== kr(i, 0 | i[et], e, t = Er(t, n) === r ? r : -1);
}
function cr() {
	return void 0 === dt ? 2 : 4;
}
function lr(t, e, r, n, i) {
	var s = t.A, o = 0 | s[et];
	n = ht(t, o) ? 1 : n, i = !!i || 3 === n, 2 === n && Qe(t) && (o = 0 | (s = t.A)[et]);
	var a = (t = fr(s, e)) === j ? 7 : 0 | t[et], h = pr(a, o), u = !(4 & h);
	if (u) {
		4 & h && (t = Vt(t), a = 0, h = Nr(h, o), o = hr(s, o, e, t));
		let n = 0, i = 0;
		for (; n < t.length; n++) {
			let e = r(t[n]);
			null != e && (t[i++] = e);
		}
		i < n && (t.length = i), r = -513 & h | 4, h = r &= -1025, h &= -4097;
	}
	return h !== a && (it(t, h), 2 & h && Object.freeze(t)), dr(t, h, s, o, e, n, u, i);
}
function dr(t, e, r, n, i, s, o, a) {
	var h = e;
	return 1 === s || 4 === s && (2 & e || !(16 & e) && 32 & n) ? gr(e) || ((e |= !t.length || o && !(4096 & e) || 32 & n && !(4096 & e || 16 & e) ? 2 : 256) !== h && it(t, e), Object.freeze(t)) : (2 === s && gr(e) && (t = Vt(t), h = 0, e = Nr(e, n), n = hr(r, n, i, t)), gr(e) || (a || (e |= 16), e !== h && it(t, e))), 2 & e || !(4096 & e || 16 & e) || er(r, n), t;
}
function fr(t, e, r) {
	return t = or(t, e, r), Array.isArray(t) ? t : j;
}
function pr(t, e) {
	return 2 & e && (t |= 2), 1 | t;
}
function gr(t) {
	return !!(2 & t) && !!(4 & t) || !!(256 & t);
}
function mr(t) {
	return ct(t, !0);
}
function vr(t) {
	t = Vt(t);
	for (let e = 0; e < t.length; e++) {
		let r = t[e] = Vt(t[e]);
		Array.isArray(r[1]) && (r[1] = st(r[1]));
	}
	return ot(t);
}
function _r(t, e, r, n) {
	tr(t), hr(t = t.A, 0 | t[et], e, ("0" === n ? 0 === Number(r) : r === n) ? void 0 : r);
}
function yr(t, e, r) {
	if (2 & e) throw Error();
	var n = gt(e), i = fr(t, r, n), s = i === j ? 7 : 0 | i[et], o = pr(s, e);
	return (2 & o || gr(o) || 16 & o) && (o === s || gr(o) || it(i, o), i = Vt(i), s = 0, o = Nr(o, e), hr(t, e, r, i, n)), (o &= -13) !== s && it(i, o), i;
}
function Er(t, e) {
	return br(Ar(t = t.A), t, void 0, e);
}
function Ar(t) {
	if (B) return t[K] ?? (t[K] = /* @__PURE__ */ new Map());
	if (K in t) return t[K];
	var e = /* @__PURE__ */ new Map();
	return Object.defineProperty(t, K, { value: e }), e;
}
function wr(t, e, r, n, i) {
	var s = Ar(t), o = br(s, t, e, r, i);
	return o !== n && (o && (e = hr(t, e, o, void 0, i)), s.set(r, n)), e;
}
function br(t, e, r, n, i) {
	var s = t.get(n);
	if (null != s) return s;
	s = 0;
	for (let t = 0; t < n.length; t++) {
		let o = n[t];
		null != or(e, o, i) && (0 !== s && (r = hr(e, r, s, void 0, i)), s = o);
	}
	return t.set(n, s), s;
}
function Tr(t, e, r) {
	var n = 0 | t[et], i = gt(n), s = or(t, r, i);
	if (null != s && s[J] === at) {
		if (!ht(s)) return Qe(s), s.A;
		var o = s.A;
	} else Array.isArray(s) && (o = s);
	if (o) {
		let t = 0 | o[et];
		2 & t && (o = Je(o, t));
	}
	return (o = Ke(o, e)) !== s && hr(t, n, r, o, i), o;
}
function kr(t, e, r, n, i) {
	var s = !1;
	if (null != (n = or(t, n, i, (t) => {
		var n = ye(t, r, !1, e);
		return s = n !== t && null != n, n;
	}))) return s && !ht(n) && er(t, e), n;
}
function Sr(t, e, r, n) {
	var i = t.A, s = 0 | i[et];
	if (null == (e = kr(i, s, e, r, n))) return e;
	if (!ht(t, s = 0 | i[et])) {
		let o = Ze(e);
		o !== e && (Qe(t) && (s = 0 | (i = t.A)[et]), er(i, s = hr(i, s, r, e = o, n)));
	}
	return e;
}
function Lr(t, e, r, n, i, s, o, a) {
	var h = ht(t, r);
	s = h ? 1 : s, o = !!o || 3 === s, h = a && !h, (2 === s || h) && Qe(t) && (r = 0 | (e = t.A)[et]);
	var u = (t = fr(e, i)) === j ? 7 : 0 | t[et], c = pr(u, r);
	if (a = !(4 & c)) {
		var l = t, d = r;
		let e = !!(2 & c);
		e && (d |= 2);
		let i = !e, s = !0, o = 0, a = 0;
		for (; o < l.length; o++) {
			let t = ye(l[o], n, !1, d);
			if (t instanceof n) {
				if (!e) {
					let e = ht(t);
					i &&= !e, s &&= e;
				}
				l[a++] = t;
			}
		}
		a < o && (l.length = a), c |= 4, c = s ? -4097 & c : 4096 | c, c = i ? 8 | c : -9 & c;
	}
	if (c !== u && (it(t, c), 2 & c && Object.freeze(t)), h && !(8 & c || !t.length && (1 === s || 4 === s && (2 & c || !(16 & c) && 32 & r)))) {
		for (gr(c) && (t = Vt(t), c = Nr(c, r), r = hr(e, r, i, t)), n = t, h = c, u = 0; u < n.length; u++) (l = n[u]) !== (c = Ze(l)) && (n[u] = c);
		h |= 8, it(t, c = h = n.length ? 4096 | h : -4097 & h);
	}
	return dr(t, c, e, r, i, s, a, o);
}
function xr(t, e, r) {
	var n = t.A;
	return Lr(t, n, 0 | n[et], e, r, cr(), !1, !0);
}
function Rr(t) {
	return t ??= void 0, t;
}
function Ir(t, e, r, n, i) {
	return ar(t, r, n = Rr(n), i), n && !ht(n) && er(t.A), t;
}
function Fr(t, e, r, n) {
	t: {
		var i = n = Rr(n);
		tr(t);
		let s = t.A, o = 0 | s[et];
		if (null == i) {
			let t = Ar(s);
			if (br(t, s, o, r) !== e) break t;
			t.set(r, 0);
		} else o = wr(s, o, r, e);
		hr(s, o, e, i);
	}
	return n && !ht(n) && er(t.A), t;
}
function Cr(t, e, r) {
	tr(t);
	var n = t.A, i = 0 | n[et];
	if (null == r) return hr(n, i, e), t;
	var s = r === j ? 7 : 0 | r[et], o = s, a = gr(s), h = a || Object.isFrozen(r), u = !0, c = !0;
	for (let t = 0; t < r.length; t++) {
		var l = r[t];
		a || (l = ht(l), u &&= !l, c &&= l);
	}
	return a || (s = u ? 13 : 5, s = c ? -4097 & s : 4096 | s), h && s === o || (r = Vt(r), o = 0, s = Nr(s, i)), s !== o && it(r, s), i = hr(n, i, e, r), 2 & s || !(4096 & s || 16 & s) || er(n, i), t;
}
function Nr(t, e) {
	return -273 & (2 & e ? 2 | t : -3 & t);
}
function Mr(t, e, r, n) {
	var i = n;
	tr(t), t = Lr(t, n = t.A, 0 | n[et], r, e, 2, !0), i = null != i ? i : new r(), t.push(i), e = r = t === j ? 7 : 0 | t[et], (i = ht(i)) ? (r &= -9, 1 === t.length && (r &= -4097)) : r |= 4096, r !== e && it(t, r), i || er(n);
}
function Or(t, e, r) {
	return re(sr(t, e, r));
}
function Dr(t, e) {
	return sr(t, e, void 0, Jt) ?? 0;
}
function Pr(t, e, r) {
	return Sr(t, e, r = Er(t, Uo) === r ? r : -1, void 0);
}
function $r(t, e) {
	_r(t, 3, null == e ? e : Zt(e), !1);
}
function Ur(t, e, r) {
	if (null != r) {
		if ("number" != typeof r) throw P("int32");
		if (!Wt(r)) throw P("int32");
		r |= 0;
	}
	ar(t, e, r);
}
function Br(t, e, r) {
	return ar(t, e, null == r ? r : ie(r));
}
function Gr(t, e, r) {
	return ar(t, e, null == r ? r : function(t) {
		if (!te(t)) throw P("uint64");
		switch (typeof t) {
			case "string":
				var e = zt(Number(t));
				return Xt(e) && e >= 0 ? t = At(e) : (-1 !== (e = t.indexOf(".")) && (t = t.substring(0, e)), t = U() ? At(Kt(64, BigInt(t))) : At(oe(t))), t;
			case "bigint": return At(Kt(64, t));
			default: return Xt(t) ? t = At(he(t)) : ((t = zt(t)) >= 0 && Xt(t) ? t = String(t) : (Nt(t), t = $t(It, Ft)), t = At(t)), t;
		}
	}(r));
}
function jr(t, e, r) {
	ar(t, e, null == r ? r : qt(r));
}
function Vr(t, e, r) {
	_r(t, e, null == r ? r : qt(r), 0);
}
function Hr(t, e, r) {
	_r(t, e, ve(r), "");
}
function Kr(t, e, r) {
	{
		tr(t);
		let o = t.A, a = 0 | o[et];
		if (null == r) hr(o, a, e);
		else {
			var n = t = r === j ? 7 : 0 | r[et], i = gr(t), s = i || Object.isFrozen(r);
			for (i || (t = 0), s || (r = Vt(r), n = 0, t = Nr(t, a), s = !1), t |= 5, t |= (4 & t ? 512 & t ? 512 : 1024 & t ? 1024 : 0 : void 0) ?? 1024, i = 0; i < r.length; i++) {
				let e = r[i], o = me(e);
				Object.is(e, o) || (s && (r = Vt(r), n = 0, t = Nr(t, a), s = !1), r[i] = o);
			}
			t !== n && (s && (r = Vt(r), t = Nr(t, a)), it(r, t)), hr(o, a, e, r);
		}
	}
}
function Xr(t, e, r) {
	tr(t), lr(t, e, _e, 2, !0).push(me(r));
}
var Wr = class {
	constructor(t, e, r) {
		if (this.buffer = t, r && !e) throw Error();
		this.g = e;
	}
};
function zr(t, e) {
	if ("string" == typeof t) return new Wr(L(t), e);
	if (Array.isArray(t)) return new Wr(new Uint8Array(t), e);
	if (t.constructor === Uint8Array) return new Wr(t, !1);
	if (t.constructor === ArrayBuffer) return t = new Uint8Array(t), new Wr(t, !1);
	if (t.constructor === N) return e = F(t) || /* @__PURE__ */ new Uint8Array(0), new Wr(e, !0, t);
	if (t instanceof Uint8Array) return t = t.constructor === Uint8Array ? t : new Uint8Array(t.buffer, t.byteOffset, t.byteLength), new Wr(t, !1);
	throw Error();
}
function Yr(t, e) {
	var r = 0, n = 0, i = 0, s = t.h, o = t.g;
	do {
		var a = s[o++];
		r |= (127 & a) << i, i += 7;
	} while (i < 32 && 128 & a);
	if (i > 32) for (n |= (127 & a) >> 4, i = 3; i < 32 && 128 & a; i += 7) n |= (127 & (a = s[o++])) << i;
	if (nn(t, o), !(128 & a)) return e(r >>> 0, n >>> 0);
	throw Error();
}
function qr(t) {
	for (var e = 0, r = t.g, n = r + 10, i = t.h; r < n;) {
		let n = i[r++];
		if (e |= n, !(128 & n)) return nn(t, r), !!(127 & e);
	}
	throw Error();
}
function Jr(t) {
	var e = t.h, r = t.g, n = e[r++], i = 127 & n;
	if (128 & n && (i |= (127 & (n = e[r++])) << 7, 128 & n && (i |= (127 & (n = e[r++])) << 14, 128 & n && (i |= (127 & (n = e[r++])) << 21, 128 & n && (i |= (n = e[r++]) << 28, 128 & n && 128 & e[r++] && 128 & e[r++] && 128 & e[r++] && 128 & e[r++] && 128 & e[r++]))))) throw Error();
	return nn(t, r), i;
}
function Zr(t) {
	return Jr(t) >>> 0;
}
function Qr(t) {
	return Yr(t, Pt);
}
function tn(t) {
	var e = t.h, r = t.g, n = e[r], i = e[r + 1], s = e[r + 2];
	return e = e[r + 3], nn(t, t.g + 4), (n | i << 8 | s << 16 | e << 24) >>> 0;
}
function en(t) {
	var e = tn(t);
	t = 2 * (e >> 31) + 1;
	var r = e >>> 23 & 255;
	return e &= 8388607, 255 == r ? e ? NaN : t * (1 / 0) : 0 == r ? 1401298464324817e-60 * t * e : t * Math.pow(2, r - 150) * (e + 8388608);
}
function rn(t) {
	return Jr(t);
}
function nn(t, e) {
	if (t.g = e, e > t.j) throw Error();
}
function sn(t, e) {
	if (e < 0) throw Error();
	var r = t.g;
	if ((e = r + e) > t.j) throw Error();
	return t.g = e, r;
}
function on(t, e) {
	if (0 == e) return I();
	var r = sn(t, e);
	return t.fa && t.o ? r = t.h.subarray(r, r + e) : (t = t.h, r = r === (e = r + e) ? /* @__PURE__ */ new Uint8Array(0) : Rt ? t.slice(r, e) : new Uint8Array(t.subarray(r, e))), 0 == r.length ? I() : new N(r, R);
}
var an = class {
	constructor(t, e, r, n) {
		this.h = null, this.o = !1, this.g = this.j = this.m = 0, this.init(t, e, r, n);
	}
	init(t, e, r, { fa: n = !1, ma: i = !1 } = {}) {
		this.fa = n, this.ma = i, t && (t = zr(t, this.ma), this.h = t.buffer, this.o = t.g, this.m = e || 0, this.j = void 0 !== r ? this.m + r : this.h.length, this.g = this.m);
	}
	clear() {
		this.h = null, this.o = !1, this.g = this.j = this.m = 0, this.fa = !1;
	}
};
var hn = [];
var un = 0;
function cn(t, e, r, n) {
	if (En.length) {
		let i = En.pop();
		return i.v(n), i.g.init(t, e, r, n), i;
	}
	return new yn(t, e, r, n);
}
function ln(t) {
	t.g.clear(), t.j = -1, t.h = -1, En.length < 100 && En.push(t);
}
function dn(t) {
	var e = t.g;
	if (e.g == e.j) return !1;
	t.m = t.g.g;
	var r = Zr(t.g);
	if (e = r >>> 3, !((r &= 7) >= 0 && r <= 5)) throw Error();
	if (e < 1) throw Error();
	return t.j = e, t.h = r, !0;
}
function fn(t) {
	try {
		switch (t.h) {
			case 0:
				0 != t.h ? fn(t) : qr(t.g);
				break;
			case 1:
				var e = t.g;
				nn(e, e.g + 8);
				break;
			case 2:
				if (2 != t.h) fn(t);
				else {
					var r = Zr(t.g), n = t.g;
					nn(n, n.g + r);
				}
				break;
			case 5:
				var i = t.g;
				nn(i, i.g + 4);
				break;
			case 3:
				pn();
				let s = t.j;
				try {
					for (;;) {
						if (!dn(t)) throw Error();
						if (4 == t.h) {
							if (t.j != s) throw Error();
							break;
						}
						fn(t);
					}
				} catch (t) {
					if (t instanceof RangeError) throw new SyntaxError();
					throw t;
				} finally {
					un > 0 && un--;
				}
				break;
			default: throw Error();
		}
	} catch (t) {
		if (t instanceof RangeError) throw new SyntaxError();
		throw t;
	}
}
function pn() {
	if (un >= 100) throw new SyntaxError();
	un++;
}
function gn(t, e, r) {
	var n = t.g.j, i = Zr(t.g), s = (i = t.g.g + i) - n;
	if (s <= 0 && (t.g.j = i, r(e, t, void 0, void 0, void 0), s = i - t.g.g), s) throw Error();
	return t.g.g = i, t.g.j = n, e;
}
function mn(t) {
	var e = Zr(t.g), r = sn(t = t.g, e);
	if (t = t.h, h) {
		var o, u = t;
		(o = s) || (o = s = new TextDecoder("utf-8", { fatal: !0 })), e = r + e, u = 0 === r && e === u.length ? u : u.subarray(r, e);
		try {
			var c = o.decode(u);
		} catch (t) {
			if (void 0 === a) {
				try {
					o.decode(new Uint8Array([128]));
				} catch (t) {}
				try {
					o.decode(new Uint8Array([97])), a = !0;
				} catch (t) {
					a = !1;
				}
			}
			throw !a && (s = void 0), t;
		}
	} else {
		e = (c = r) + e, r = [];
		let s, a = null;
		for (; c < e;) {
			var l = t[c++];
			l < 128 ? r.push(l) : l < 224 ? c >= e ? n() : (s = t[c++], l < 194 || 128 != (192 & s) ? (c--, n()) : r.push((31 & l) << 6 | 63 & s)) : l < 240 ? c >= e - 1 ? n() : (s = t[c++], 128 != (192 & s) || 224 === l && s < 160 || 237 === l && s >= 160 || 128 != (192 & (o = t[c++])) ? (c--, n()) : r.push((15 & l) << 12 | (63 & s) << 6 | 63 & o)) : l <= 244 ? c >= e - 2 ? n() : (s = t[c++], 128 != (192 & s) || s - 144 + (l << 28) >> 30 || 128 != (192 & (o = t[c++])) || 128 != (192 & (u = t[c++])) ? (c--, n()) : (l = (7 & l) << 18 | (63 & s) << 12 | (63 & o) << 6 | 63 & u, l -= 65536, r.push(55296 + (l >> 10 & 1023), 56320 + (1023 & l)))) : n(), r.length >= 8192 && (a = i(a, r), r.length = 0);
		}
		c = i(a, r);
	}
	return c;
}
function vn(t) {
	var e = Zr(t.g);
	return on(t.g, e);
}
function _n(t, e, r) {
	var n = Zr(t.g);
	for (n = t.g.g + n; t.g.g < n;) r.push(e(t.g));
}
var yn = class {
	constructor(t, e, r, n) {
		if (hn.length) {
			let i = hn.pop();
			i.init(t, e, r, n), t = i;
		} else t = new an(t, e, r, n);
		this.g = t, this.m = this.g.g, this.h = this.j = -1, this.v(n);
	}
	v({ ra: t = !1 } = {}) {
		this.ra = t;
	}
};
var En = [];
function An(t) {
	return new Tn(4294967295 & t, Math.floor(t / 4294967296));
}
function wn(t) {
	return t ? /^\d+$/.test(t) ? (Gt(t), new Tn(It, Ft)) : null : bn ||= new Tn(0, 0);
}
var bn;
var Tn = class {
	constructor(t, e) {
		this.h = t >>> 0, this.g = e >>> 0;
	}
};
function kn(t) {
	return new On(4294967295 & t, Math.floor(t / 4294967296));
}
function Sn(t) {
	return t ? /^-?\d+$/.test(t) ? (Gt(t), new On(It, Ft)) : null : Ln ||= new On(0, 0);
}
var Ln;
var xn;
var Rn;
var In;
var Fn;
var Cn;
var Nn;
var Mn;
var On = class {
	constructor(t, e) {
		this.h = t >>> 0, this.g = e >>> 0;
	}
};
function Dn(t, e, r) {
	return "undefined" != typeof BigInt64Array ? (Nn || (Nn = /* @__PURE__ */ new BigInt64Array(1), Mn = new Uint32Array(Nn.buffer), Nn[0] = BigInt(1), Cn = 1 === Mn[0]), Nn[0] = t, new e(Mn[t = Cn ? 0 : 1], Mn[1 - t])) : (Fn || (xn = BigInt(Number.MIN_SAFE_INTEGER), Rn = BigInt(Number.MAX_SAFE_INTEGER), In = BigInt(4294967295), Fn = BigInt(32)), t >= xn && t <= Rn ? r(Number(t)) : (t = BigInt.asUintN(64, t), new e(Number(t & In), Number(t >> Fn))));
}
function Pn(t, e, r) {
	for (; r > 0 || e > 127;) t.g.push(127 & e | 128), e = (e >>> 7 | r << 25) >>> 0, r >>>= 7;
	t.g.push(e);
}
function $n(t, e) {
	for (; e > 127;) t.g.push(127 & e | 128), e >>>= 7;
	t.g.push(e);
}
function Un(t, e) {
	if (e >= 0) $n(t, e);
	else {
		for (let r = 0; r < 9; r++) t.g.push(127 & e | 128), e >>= 7;
		t.g.push(1);
	}
}
function Bn(t, e) {
	Gt(e), function(t) {
		var e = Ft >> 31;
		t(It << 1 ^ e, (Ft << 1 | It >>> 31) ^ e);
	}((e, r) => {
		Pn(t, e >>> 0, r >>> 0);
	});
}
function Gn(t, e) {
	t.g.push(e >>> 0 & 255), t.g.push(e >>> 8 & 255), t.g.push(e >>> 16 & 255), t.g.push(e >>> 24 & 255);
}
var jn = class {
	constructor() {
		this.g = [];
	}
	length() {
		return this.g.length;
	}
	end() {
		var t = this.g;
		return this.g = [], t;
	}
};
function Vn(t, e) {
	0 !== e.length && (t.j.push(e), t.h += e.length);
}
function Hn(t, e, r) {
	$n(t.g, 8 * e + r);
}
function Kn(t, e) {
	return Hn(t, e, 2), e = t.g.end(), Vn(t, e), e.push(t.h), e;
}
function Xn(t, e) {
	var r = e.pop();
	for (r = t.h + t.g.length() - r; r > 127;) e.push(127 & r | 128), r >>>= 7, t.h++;
	e.push(r), t.h++;
}
function Wn(t, e, r) {
	if (null != r) switch (Hn(t, e, 0), typeof r) {
		case "number":
			t = t.g, Nt(r), Pn(t, It, Ft);
			break;
		case "bigint":
			r = Dn(r, On, kn), Pn(t.g, r.h, r.g);
			break;
		default: r = Sn(r), Pn(t.g, r.h, r.g);
	}
}
function zn(t, e, r) {
	Hn(t, e, 2), $n(t.g, r.length), Vn(t, t.g.end()), Vn(t, r);
}
function Yn(t, e, r, n) {
	null != r && (e = Kn(t, e), n(r, t), Xn(t, e));
}
var qn = class {
	constructor() {
		this.j = [], this.h = 0, this.g = new jn();
	}
};
function Jn(t) {
	if ("string" == typeof t) Sn(t);
}
function Zn() {
	var t = class {
		constructor() {
			throw Error();
		}
	};
	return Object.setPrototypeOf(t, t.prototype), t;
}
var Qn = Zn();
var ti = Zn();
var ei = Zn();
var ri = Zn();
var ni = Zn();
var ii = Zn();
var si = Zn();
var oi = Zn();
var ai = Zn();
var hi = Zn();
var ui = Zn();
var ci = Zn();
function li(t, e, r) {
	var n = t.A;
	X && X in n && (n = n[X]) && delete n[e.g], e.h ? e.o(t, e.h, e.g, r, e.j) : e.o(t, e.g, r, e.j);
}
var di = class {
	constructor(t, e) {
		this.A = Xe(t, e, void 0, 2048);
	}
	toJSON() {
		return He(this);
	}
	o() {
		var t = Ca, e = this.A, r = t.g, n = X;
		if (B && n && null != e[n]?.[r] && $(W, 3), e = t.g, Z && X && void 0 === Z && (n = (r = this.A)[X]) && (n = n.ka)) try {
			n(r, e, Ue);
		} catch (t) {
			l(t);
		}
		return t.h ? t.m(this, t.h, t.g, t.j) : t.m(this, t.g, t.defaultValue, t.j);
	}
	clone() {
		var t = this.A, e = 0 | t[et];
		return rr(this, t, e) ? Ye(this, t, !0) : new this.constructor(Je(t, e, !1));
	}
};
di.prototype[J] = at, di.prototype.toString = function() {
	return this.A.toString();
};
var fi = class {
	constructor(t, e, r) {
		this.g = t, this.h = e, t = Qn, this.j = !!t && r === t || !1;
	}
};
function pi(t, e) {
	return new fi(t, e, Qn);
}
function gi(t, e, r, n, i) {
	Yn(t, r, Li(e, n), i);
}
var mi;
var vi;
var _i = pi(function(t, e, r, n, i) {
	return 2 === t.h && (gn(t, Tr(e, n, r), i), !0);
}, gi);
var yi = pi(function(t, e, r, n, i) {
	return 2 === t.h && (gn(t, Tr(e, n, r), i), !0);
}, gi);
var Ei = Symbol();
var Ai = Symbol();
var wi = Symbol();
var bi = Symbol();
var Ti = Symbol();
function ki(t, e, r, n) {
	var i = n[t];
	if (i) return i;
	(i = {}).Ea = n, i.ca = function(t) {
		switch (typeof t) {
			case "boolean": return De ||= [
				0,
				void 0,
				!0
			];
			case "number": return t > 0 ? void 0 : 0 === t ? Pe ||= [0, void 0] : [-t, void 0];
			case "string": return [0, t];
			case "object": return t;
		}
	}(n[0]);
	var s = n[1], o = 1;
	s && s.constructor === Object && (i.ia = s, "function" == typeof (s = n[++o]) && (i.wa = !0, mi ??= s, vi ??= n[o + 1], s = n[o += 2]));
	for (var a = {}; s && Array.isArray(s) && s.length && "number" == typeof s[0] && s[0] > 0;) {
		for (var h = 0; h < s.length; h++) a[s[h]] = s;
		s = n[++o];
	}
	for (h = 1; void 0 !== s;) {
		let t;
		"number" == typeof s && (h += s, s = n[++o]);
		var u = void 0;
		if (s instanceof fi ? t = s : (t = _i, o--), t?.j) {
			s = n[++o], u = n;
			var c = o;
			"function" == typeof s && (s = s(), u[c] = s), u = s;
		}
		for (c = h + 1, "number" == typeof (s = n[++o]) && s < 0 && (c -= s, s = n[++o]); h < c; h++) {
			let n = a[h];
			u ? r(i, h, t, u, n) : e(i, h, t, n);
		}
	}
	return n[t] = i;
}
function Si(t) {
	return Array.isArray(t) ? t[0] instanceof fi ? t : [yi, t] : [t, void 0];
}
function Li(t, e) {
	return t instanceof di ? t.A : Array.isArray(t) ? Ke(t, e) : void 0;
}
function xi(t, e, r, n) {
	var i = r.g;
	t[e] = n ? (t, e, r) => i(t, e, r, n) : i;
}
function Ri(t, e, r, n, i) {
	var s, o, a = r.g;
	t[e] = (t, e, r) => a(t, e, r, o ||= ki(Ai, xi, Ri, n).ca, s ||= Ii(n), i);
}
function Ii(t) {
	var e = t[wi];
	if (null != e) return e;
	var r = ki(Ai, xi, Ri, t);
	return e = r.wa ? (t, e) => mi(t, e, r) : (t, e) => {
		t: {
			pn();
			try {
				for (; dn(e) && 4 != e.h;) {
					let h = e.j, u = r[h];
					if (null == u) {
						let t = r.ia;
						if (t) {
							let e = t[h];
							if (e) {
								let t = Ci(e);
								null != t && (u = r[h] = t);
							}
						}
					}
					if (null == u || !u(e, t, h)) {
						var n = e;
						let r = n.m;
						if (fn(n), n.ra) var i = void 0;
						else {
							let t = n.g.g - r;
							n.g.g = r, i = on(n.g, t);
						}
						n = void 0;
						var s = t, o = h, a = i;
						a && ((n = s[X] ?? (s[X] = new $e()))[o] ?? (n[o] = [])).push(a);
					}
				}
				let u = Ne(t);
				u && (u.ka = r.Ea[Ti]);
				var h = !0;
				break t;
			} catch (t) {
				if (t instanceof RangeError) throw new SyntaxError();
				throw t;
			} finally {
				un > 0 && un--;
			}
		}
		return h;
	}, t[wi] = e, t[Ti] = Fi.bind(t), e;
}
function Fi(t, e, r, n) {
	var i = this[Ai], s = this[wi], o = Ke(void 0, i.ca), a = Ne(t);
	if (a) {
		var h = !1, u = i.ia;
		if (u) {
			if (i = (e, r, i) => {
				if (0 !== i.length) if (u[r]) for (let t of i) {
					e = cn(t);
					try {
						h = !0, s(o, e);
					} finally {
						ln(e);
					}
				}
				else n?.(t, r, i);
			}, null == e) Me(a, i);
			else if (null != a) {
				let t = a[e];
				t && i(a, e, t);
			}
			if (h) {
				let n = 0 | t[et];
				if (2 & n && 2048 & n && !r?.cb) throw Error();
				let i = gt(n), s = (e, s) => {
					if (null != or(t, e, i)) {
						if (1 === r?.lb) return;
						throw Error();
					}
					null != s && (n = hr(t, n, e, s, i)), delete a[e];
				};
				null == e ? ft(o, 0 | o[et], (t, e) => {
					s(t, e);
				}) : s(e, or(o, e, i));
			}
		}
	}
}
function Ci(t) {
	var e = (t = Si(t))[0].g;
	if (t = t[1]) {
		let r = Ii(t), n = ki(Ai, xi, Ri, t).ca;
		return (t, i, s) => e(t, i, s, n, r);
	}
	return e;
}
function Ni(t, e, r) {
	t[e] = r.h;
}
function Mi(t, e, r, n) {
	var i, s, o = r.h;
	t[e] = (t, e, r) => o(t, e, r, s ||= ki(Ei, Ni, Mi, n).ca, i ||= Oi(n));
}
function Oi(t) {
	var e = t[bi];
	if (!e) {
		let r = ki(Ei, Ni, Mi, t);
		e = (t, e) => Di(t, e, r), t[bi] = e;
	}
	return e;
}
function Di(t, e, r) {
	ft(t, 0 | t[et], (t, n) => {
		if (null != n) {
			var i = function(t, e) {
				var r = t[e];
				if (r) return r;
				if ((r = t.ia) && (r = r[e])) {
					var n = (r = Si(r))[0].h;
					if (r = r[1]) {
						let e = Oi(r), i = ki(Ei, Ni, Mi, r).ca;
						r = t.wa ? vi(i, e) : (t, r, s) => n(t, r, s, i, e);
					} else r = n;
					return t[e] = r;
				}
			}(r, t);
			i ? i(e, n, t) : t < 500 || $(Y, 3);
		}
	}), (t = Ne(t)) && Me(t, (t, r, n) => {
		for (Vn(e, e.g.end()), t = 0; t < n.length; t++) Vn(e, F(n[t]) || /* @__PURE__ */ new Uint8Array(0));
	});
}
var Pi = At(0);
function $i(t, e, r) {
	if (Array.isArray(e)) {
		var n = 0 | e[et];
		if (4 & n) return e;
		for (var i = 0, s = 0; i < e.length; i++) {
			let r = t(e[i]);
			null != r && (e[s++] = r);
		}
		return s < i && (e.length = s), t = 1 | n, r && (t = -1537 & t | 4), t !== n && it(e, t), r && 2 & t && Object.freeze(e), e;
	}
}
var Ui = (t, e) => {
	var r = new qn();
	Di(t.A, r, ki(Ei, Ni, Mi, e)), Vn(r, r.g.end()), t = new Uint8Array(r.h);
	var n = (e = r.j).length, i = 0;
	for (let r = 0; r < n; r++) {
		let n = e[r];
		t.set(n, i), i += n.length;
	}
	return r.j = [t], t;
};
function Bi(t, e, r) {
	return new fi(t, e, r);
}
function Gi(t, e, r) {
	return new fi(t, e, r);
}
function ji(t, e, r) {
	hr(t, 0 | t[et], e, r, gt(0 | t[et]));
}
var Vi = pi(function(t, e, r, n, i) {
	if (2 !== t.h) return !1;
	if (t = Vt(t = gn(t, Ke([void 0, void 0], n), i)), i = gt(n = 0 | e[et]), 2 & n) throw Error();
	var s = or(e, r, i);
	if (s instanceof Re) 2 & s.M ? ((s = s.ea()).push(t), hr(e, n, r, s, i)) : s.gb(t);
	else if (Array.isArray(s)) {
		var o = 0 | s[et];
		8192 & o || it(s, o |= 8192), 2 & o && hr(e, n, r, s = vr(s), i), s.push(t);
	} else hr(e, n, r, ot([t]), i);
	return !0;
}, function(t, e, r, n, i) {
	if (e instanceof Re) e.forEach((e, s) => {
		Yn(t, r, Ke([s, e], n), i);
	});
	else if (Array.isArray(e)) {
		for (let s = 0; s < e.length; s++) {
			let o = e[s];
			Array.isArray(o) && Yn(t, r, Ke(o, n), i);
		}
		ot(e);
	}
});
function Hi(t, e, r) {
	null != (e = Jt(e)) && (Hn(t, r, 5), t = t.g, Mt(e), Gn(t, It));
}
function Ki(t, e, r) {
	null != (e = pe(e)) && (Jn(e), Wn(t, r, e));
}
function Xi(t, e, r) {
	null != (e = re(e)) && null != e && (Hn(t, r, 0), Un(t.g, e));
}
function Wi(t, e, r) {
	null != (e = null == e || "boolean" == typeof e ? e : "number" == typeof e ? !!e : void 0) && (Hn(t, r, 0), t.g.g.push(e ? 1 : 0));
}
function zi(t, e, r) {
	null != (e = _e(e)) && zn(t, r, c(e));
}
function Yi(t, e, r, n, i) {
	Yn(t, r, Li(e, n), i);
}
function qi(t, e, r) {
	null != (e = ge(e)) && zn(t, r, zr(e, !0).buffer);
}
function Ji(t, e, r) {
	null != (e = ne(e)) && null != e && (Hn(t, r, 0), $n(t.g, e));
}
function Zi(t, e, r) {
	null != (e = re(e)) && (e = parseInt(e, 10), Hn(t, r, 0), Un(t.g, e));
}
function Qi(t, e, r) {
	return (5 === t.h || 2 === t.h) && (e = yr(e, 0 | e[et], r), 2 == t.h ? _n(t, en, e) : e.push(en(t.g)), !0);
}
function ts(t, e, r) {
	return 0 === t.h && (ji(e, r, Qr(t.g)), !0);
}
function es(t, e, r) {
	return (0 === t.h || 2 === t.h) && (e = yr(e, 0 | e[et], r), 2 == t.h ? _n(t, Jr, e) : e.push(Jr(t.g)), !0);
}
function rs(t, e, r) {
	return 2 === t.h && (ji(e, r, (t = vn(t)) === I() ? void 0 : t), !0);
}
var ns = Bi(function(t, e, r) {
	if (1 !== t.h) return !1;
	var n = t.g;
	t = tn(n);
	var i = tn(n);
	n = 2 * (i >> 31) + 1;
	var s = i >>> 20 & 2047;
	return t = 4294967296 * (1048575 & i) + t, ji(e, r, 2047 == s ? t ? NaN : n * (1 / 0) : 0 == s ? 5e-324 * n * t : n * Math.pow(2, s - 1075) * (t + 4503599627370496)), !0;
}, function(t, e, r) {
	null != (e = Jt(e)) && (Hn(t, r, 1), t = t.g, (r = xt ||= /* @__PURE__ */ new DataView(/* @__PURE__ */ new ArrayBuffer(8))).setFloat64(0, +e, !0), It = r.getUint32(0, !0), Ft = r.getUint32(4, !0), Gn(t, It), Gn(t, Ft));
}, hi);
var is = Bi(function(t, e, r) {
	return 5 === t.h && (ji(e, r, en(t.g)), !0);
}, Hi, ai);
var ss = Gi(Qi, function(t, e, r) {
	if (null != (e = $i(Jt, e, !0))) for (let o = 0; o < e.length; o++) {
		var n = t, i = r, s = e[o];
		null != s && (Hn(n, i, 5), n = n.g, Mt(s), Gn(n, It));
	}
}, ai);
var os = Gi(Qi, function(t, e, r) {
	if (null != (e = $i(Jt, e, !0)) && e.length) {
		Hn(t, r, 2), $n(t.g, 4 * e.length);
		for (let n = 0; n < e.length; n++) r = t.g, Mt(e[n]), Gn(r, It);
	}
}, ai);
var as = Bi(function(t, e, r) {
	return 5 === t.h && (ji(e, r, 0 === (t = en(t.g)) ? void 0 : t), !0);
}, Hi, ai);
var hs = Bi(function(t, e, r) {
	return ts(t, e, r);
}, Ki, ii);
var us = Bi(function(t, e, r) {
	return ts(t, e, r);
}, Ki, ii);
var cs = Gi(function(t, e, r) {
	return 0 !== t.h && 2 !== t.h ? t = !1 : (e = yr(e, 0 | e[et], r), 2 == t.h ? _n(t, Qr, e) : e.push(Qr(t.g)), t = !0), t;
}, function(t, e, r) {
	if (null != (e = $i(pe, e, !1))) for (let n = 0; n < e.length; n++) Wn(t, r, e[n]);
}, ii);
var ls = Bi(function(t, e, r) {
	return 0 !== t.h ? e = !1 : (ji(e, r, (t = Qr(t.g)) === Pi ? void 0 : t), e = !0), e;
}, Ki, ii);
var ds = Bi(function(t, e, r) {
	return 0 !== t.h ? t = !1 : (ji(e, r, Yr(t.g, Dt)), t = !0), t;
}, function(t, e, r) {
	if (e = function(t) {
		if (null == t) return t;
		var e = typeof t;
		if ("bigint" === e) return String(Kt(64, t));
		if (te(t)) {
			if ("string" === e) return e = zt(Number(t)), Xt(e) && e >= 0 ? t = String(e) : (-1 !== (e = t.indexOf(".")) && (t = t.substring(0, e)), t = oe(t)), t;
			if ("number" === e) return he(t);
		}
	}(e), null != e) {
		if ("string" == typeof e) wn(e);
		if (null != e) switch (Hn(t, r, 0), typeof e) {
			case "number":
				t = t.g, Nt(e), Pn(t, It, Ft);
				break;
			case "bigint":
				r = Dn(e, Tn, An), Pn(t.g, r.h, r.g);
				break;
			default: r = wn(e), Pn(t.g, r.h, r.g);
		}
	}
}, si);
var fs = Bi(function(t, e, r) {
	return 0 === t.h && (ji(e, r, Jr(t.g)), !0);
}, Xi, ri);
var ps = Gi(es, function(t, e, r) {
	if (null != (e = $i(re, e, !0))) for (let o = 0; o < e.length; o++) {
		var n = t, i = r, s = e[o];
		null != s && (Hn(n, i, 0), Un(n.g, s));
	}
}, ri);
var gs = Gi(es, function(t, e, r) {
	if (null != (e = $i(re, e, !0)) && e.length) {
		r = Kn(t, r);
		for (let r = 0; r < e.length; r++) Un(t.g, e[r]);
		Xn(t, r);
	}
}, ri);
var ms = Bi(function(t, e, r) {
	return 0 === t.h && (ji(e, r, 0 === (t = Jr(t.g)) ? void 0 : t), !0);
}, Xi, ri);
var vs = Bi(function(t, e, r) {
	return 0 === t.h && (ji(e, r, qr(t.g)), !0);
}, Wi, ti);
var _s = Bi(function(t, e, r) {
	return 0 === t.h && (ji(e, r, !1 === (t = qr(t.g)) ? void 0 : t), !0);
}, Wi, ti);
var ys = Gi(function(t, e, r) {
	return 2 === t.h && (t = mn(t), yr(e, 0 | e[et], r).push(t), !0);
}, function(t, e, r) {
	if (null != (e = $i(_e, e, !0))) for (let o = 0; o < e.length; o++) {
		var n = t, i = r, s = e[o];
		null != s && zn(n, i, c(s));
	}
}, ei);
var Es = Bi(function(t, e, r) {
	return 2 === t.h && (ji(e, r, "" === (t = mn(t)) ? void 0 : t), !0);
}, zi, ei);
var As = Bi(function(t, e, r) {
	return 2 === t.h && (ji(e, r, mn(t)), !0);
}, zi, ei);
var ws = function(t, e, r = Qn) {
	return new fi(t, e, r);
}(function(t, e, r, n, i) {
	return 2 === t.h && (n = Ke(void 0, n), yr(e, 0 | e[et], r).push(n), gn(t, n, i), !0);
}, function(t, e, r, n, i) {
	if (Array.isArray(e)) {
		for (let s = 0; s < e.length; s++) Yi(t, e[s], r, n, i);
		1 & (t = 0 | e[et]) || it(e, 1 | t);
	}
});
var bs = pi(function(t, e, r, n, i, s) {
	if (2 !== t.h) return !1;
	var o = 0 | e[et];
	return wr(e, o, s, r, gt(o)), gn(t, e = Tr(e, n, r), i), !0;
}, Yi);
var Ts = Bi(function(t, e, r) {
	return 2 === t.h && (ji(e, r, vn(t)), !0);
}, qi, ui);
var ks = Gi(function(t, e, r) {
	return 2 === t.h && (t = vn(t), yr(e, 0 | e[et], r).push(t), !0);
}, function(t, e, r) {
	if (null != (e = $i(ge, e, !1))) for (let o = 0; o < e.length; o++) {
		var n = t, i = r, s = e[o];
		null != s && zn(n, i, zr(s, !0).buffer);
	}
}, ui);
var Ss = Bi(function(t, e, r) {
	return 0 === t.h && (ji(e, r, Zr(t.g)), !0);
}, Ji, ni);
var Ls = Gi(function(t, e, r) {
	return (0 === t.h || 2 === t.h) && (e = yr(e, 0 | e[et], r), 2 == t.h ? _n(t, Zr, e) : e.push(Zr(t.g)), !0);
}, function(t, e, r) {
	if (null != (e = $i(ne, e, !0))) for (let o = 0; o < e.length; o++) {
		var n = t, i = r, s = e[o];
		null != s && (Hn(n, i, 0), $n(n.g, s));
	}
}, ni);
var xs = Bi(function(t, e, r) {
	return 0 === t.h && (ji(e, r, 0 === (t = Zr(t.g)) ? void 0 : t), !0);
}, Ji, ni);
var Rs = Bi(function(t, e, r) {
	return 0 === t.h && (ji(e, r, Jr(t.g)), !0);
}, Zi, ci);
var Is = Bi(function(t, e, r) {
	return 0 === t.h && (ji(e, r, 0 === (t = Jr(t.g)) ? void 0 : t), !0);
}, Zi, ci);
var Fs = Bi(function(t, e, r) {
	return 0 !== t.h ? t = !1 : (ji(e, r, function(t) {
		return Yr(t, (t, e) => {
			var r = -(1 & t);
			return Pt(t = (t >>> 1 | e << 31) ^ r, e >>> 1 ^ r);
		});
	}(t.g)), t = !0), t;
}, function(t, e, r) {
	if (null != (e = pe(e)) && (Jn(e), null != e)) switch (Hn(t, r, 0), typeof e) {
		case "number":
			t = t.g, e = (r = e) < 0, Ct(r = 2 * Math.abs(r)), r = It;
			let n = Ft;
			e && (0 == r ? 0 == n ? n = r = 4294967295 : (n--, r = 4294967295) : r--), Pn(t, It = r, Ft = n);
			break;
		case "bigint":
			t = t.g, e = e << BigInt(1) ^ e >> BigInt(63), It = Number(BigInt.asUintN(32, e)), Ft = Number(BigInt.asUintN(32, e >> BigInt(32))), Pn(t, It, Ft);
			break;
		default: Bn(t.g, e);
	}
}, oi);
var Cs = class {
	constructor(t, e) {
		var r = no;
		this.g = t, this.h = e, this.m = Sr, this.o = Ir, this.defaultValue = void 0, this.j = null != r.jb ? pt : void 0;
	}
	register() {
		v(this);
	}
};
function Ns(t, e) {
	return new Cs(t, e);
}
function Ms(t, e) {
	return (r, n) => {
		t: {
			let s = { ma: !0 };
			n && Object.assign(s, n), r = cn(r, void 0, void 0, s);
			try {
				let n = new t(), s = n.A;
				Ii(e)(s, r);
				var i = n;
				break t;
			} catch (t) {
				if (t instanceof RangeError) throw new SyntaxError();
				throw t;
			} finally {
				ln(r);
			}
		}
		return i;
	};
}
function Os(t) {
	return (e) => Ui(e, t);
}
function Ds(t) {
	return function() {
		return Ui(this, t);
	};
}
var Ps = [
	0,
	Ts,
	ks,
	vs,
	As
];
var $s = [
	0,
	Es,
	[
		0,
		Is,
		[
			0,
			ls,
			ms
		],
		Is,
		-1,
		[0, Rs],
		Is,
		-1
	],
	Bi(rs, qi, ui)
];
var Us;
var Bs = class extends di {
	constructor(t) {
		super(t);
	}
};
var Gs = [
	0,
	Es,
	Bi(rs, function(t, e, r) {
		if (null != e) {
			if (e instanceof di) {
				let n = e.mb;
				n ? (e = n(e), null != e && zn(t, r, zr(e, !0).buffer)) : $(Y, 3);
				return;
			}
			if (Array.isArray(e)) return void $(Y, 3);
		}
		qi(t, e, r);
	}, ui)
];
var js = [
	0,
	1,
	[
		0,
		12,
		fs,
		10,
		vs
	],
	[
		0,
		7,
		[
			0,
			fs,
			-1
		]
	]
];
var Vs = globalThis.trustedTypes;
var Hs = class {
	constructor(t) {
		this.g = t;
	}
	toString() {
		return this.g + "";
	}
};
function Ks(t) {
	var e;
	return void 0 === Us && (Us = function() {
		var t = null;
		if (!Vs) return t;
		try {
			let e = (t) => t;
			t = Vs.createPolicy("goog#html", {
				createHTML: e,
				createScript: e,
				createScriptURL: e
			});
		} catch (t) {}
		return t;
	}()), t = (e = Us) ? e.createScriptURL(t) : t, new Hs(t);
}
function Xs(t, ...e) {
	if (0 === e.length) return Ks(t[0]);
	var r = t[0];
	for (let n = 0; n < e.length; n++) r += encodeURIComponent(e[n]) + t[n + 1];
	return Ks(r);
}
var Ws = [
	0,
	fs,
	Rs,
	vs,
	-1,
	gs,
	Rs,
	-1,
	vs,
	-1
];
var zs = [
	0,
	Rs,
	-1,
	vs
];
var Ys = class extends di {
	constructor(t) {
		super(t);
	}
};
var qs = [
	0,
	vs,
	As,
	vs,
	Rs,
	-1,
	Gi(function(t, e, r) {
		return (0 === t.h || 2 === t.h) && (e = yr(e, 0 | e[et], r), 2 == t.h ? _n(t, rn, e) : e.push(Jr(t.g)), !0);
	}, function(t, e, r) {
		if (null != (e = $i(re, e, !0)) && e.length) {
			r = Kn(t, r);
			for (let r = 0; r < e.length; r++) Un(t.g, e[r]);
			Xn(t, r);
		}
	}, ci),
	As,
	-1,
	[
		0,
		vs,
		-1
	],
	Rs,
	vs,
	-1,
	zs
];
var Js = [
	0,
	3,
	vs,
	-1,
	2,
	[
		0,
		[2],
		fs,
		bs,
		[0, Ss]
	],
	[
		0,
		Rs,
		vs,
		Rs,
		vs,
		Rs,
		4,
		[
			0,
			vs,
			As,
			-1,
			vs
		]
	],
	[
		0,
		[3, 4],
		As,
		-1,
		bs,
		[0, fs],
		bs,
		[
			0,
			Rs,
			-1
		]
	],
	[0]
];
var Zs = [
	0,
	As,
	-2
];
var Qs = class extends di {
	constructor(t) {
		super(t);
	}
};
var to = [0];
var eo = class extends di {
	constructor(t) {
		super(t);
	}
};
var ro = [
	0,
	fs,
	vs,
	1,
	vs,
	-4
];
var no = class extends di {
	constructor(t) {
		super(t, 2);
	}
};
var io = {};
io[336783863] = [
	0,
	As,
	vs,
	-1,
	fs,
	[
		0,
		[
			1,
			2,
			3,
			4,
			5,
			6,
			7,
			8,
			9
		],
		bs,
		to,
		bs,
		qs,
		bs,
		Zs,
		bs,
		ro,
		bs,
		Ws,
		bs,
		[
			0,
			As,
			-2
		],
		bs,
		[
			0,
			As,
			Rs
		],
		bs,
		Js,
		bs,
		zs
	],
	[0, As],
	vs,
	[
		0,
		[1, 3],
		[2, 4],
		bs,
		[0, gs],
		-1,
		bs,
		[0, ys],
		-1,
		ws,
		[
			0,
			As,
			-1
		]
	],
	As
];
var so = [
	0,
	ls,
	-1,
	_s,
	-3,
	ls,
	gs,
	Es,
	ms,
	ls,
	-1,
	_s,
	ms,
	_s,
	-2,
	Es
];
function oo(t, e) {
	Xr(t, 3, e);
}
function ao(t, e) {
	Xr(t, 4, e);
}
var ho = class extends di {
	constructor(t) {
		super(t, 500);
	}
	v(t) {
		return Ir(this, 0, 7, t);
	}
};
var uo = [-1, {}];
var co = [
	0,
	As,
	1,
	uo
];
var lo = [
	0,
	As,
	ys,
	uo
];
function fo(t, e) {
	Mr(t, 1, ho, e);
}
function po(t, e) {
	Xr(t, 10, e);
}
function go(t, e) {
	Xr(t, 15, e);
}
var mo = class extends di {
	constructor(t) {
		super(t, 500);
	}
	v(t) {
		return Ir(this, 0, 1001, t);
	}
};
var vo = [
	-500,
	ws,
	[
		-500,
		Es,
		-1,
		ys,
		-3,
		[
			-2,
			io,
			vs
		],
		ws,
		Gs,
		ms,
		-1,
		co,
		lo,
		ws,
		[
			0,
			Es,
			_s
		],
		Es,
		so,
		ms,
		ys,
		987,
		ys
	],
	4,
	ws,
	[
		-500,
		As,
		-1,
		[-1, {}],
		998,
		As
	],
	ws,
	[
		-500,
		As,
		ys,
		-1,
		[
			-2,
			{},
			vs
		],
		997,
		ys,
		-1
	],
	ms,
	ws,
	[
		-500,
		As,
		ys,
		uo,
		998,
		ys
	],
	ys,
	ms,
	co,
	lo,
	ws,
	[
		0,
		Es,
		-1,
		uo
	],
	ys,
	-2,
	so,
	Es,
	-1,
	_s,
	[
		0,
		_s,
		xs
	],
	978,
	uo,
	ws,
	Gs
];
mo.prototype.g = Ds(vo);
var _o = Ms(mo, vo);
var yo = class extends di {
	constructor(t) {
		super(t);
	}
};
var Eo = class extends di {
	constructor(t) {
		super(t);
	}
	g() {
		return xr(this, yo, 1);
	}
};
var Ao = [
	0,
	ws,
	[
		0,
		fs,
		is,
		As,
		-1
	]
];
var wo = Ms(Eo, Ao);
var bo = class extends di {
	constructor(t) {
		super(t);
	}
};
var To = class extends di {
	constructor(t) {
		super(t);
	}
};
var ko = class extends di {
	constructor(t) {
		super(t);
	}
	j() {
		return Sr(this, bo, 2);
	}
	g() {
		return xr(this, To, 5);
	}
};
var So = Ms(class extends di {
	constructor(t) {
		super(t);
	}
}, [
	0,
	ys,
	gs,
	os,
	[
		0,
		Rs,
		[
			0,
			fs,
			-3
		],
		[
			0,
			is,
			-3
		],
		[
			0,
			fs,
			-1,
			[
				0,
				ws,
				[
					0,
					fs,
					-2
				]
			]
		],
		ws,
		[
			0,
			is,
			-1,
			As,
			is
		]
	],
	As,
	-1,
	us,
	ws,
	[
		0,
		fs,
		is
	],
	ys,
	us
]);
var Lo = class extends di {
	constructor(t) {
		super(t);
	}
};
var xo = Ms(class extends di {
	constructor(t) {
		super(t);
	}
}, [
	0,
	ws,
	[
		0,
		is,
		-4
	]
]);
var Ro = class extends di {
	constructor(t) {
		super(t);
	}
};
var Io = Ms(class extends di {
	constructor(t) {
		super(t);
	}
}, [
	0,
	ws,
	[
		0,
		is,
		-4
	]
]);
var Fo = class extends di {
	constructor(t) {
		super(t);
	}
};
var Co = [
	0,
	fs,
	-1,
	os,
	Rs
];
var No = class extends di {
	constructor(t) {
		super(t);
	}
};
No.prototype.g = Ds([
	0,
	is,
	-4,
	us
]);
var Mo = class extends di {
	constructor(t) {
		super(t);
	}
};
var Oo = Ms(class extends di {
	constructor(t) {
		super(t);
	}
}, [
	0,
	ws,
	[
		0,
		1,
		fs,
		As,
		Ao
	],
	us
]);
var Do = class extends di {
	constructor(t) {
		super(t);
	}
};
var Po = class extends di {
	constructor(t) {
		super(t);
	}
	g() {
		var t = sr(this, 1, void 0, mr);
		return null == t ? I() : t;
	}
};
var $o = class extends di {
	constructor(t) {
		super(t);
	}
};
var Uo = [1, 2];
var Bo = Ms(class extends di {
	constructor(t) {
		super(t);
	}
}, [
	0,
	ws,
	[
		0,
		Uo,
		bs,
		[0, os],
		bs,
		[0, Ts],
		fs,
		As
	],
	us
]);
var Go = class extends di {
	constructor(t) {
		super(t);
	}
};
var jo = [
	0,
	As,
	fs,
	is,
	ys,
	-1
];
var Vo = class extends di {
	constructor(t) {
		super(t);
	}
};
var Ho = [
	0,
	vs,
	-1
];
var Ko = class extends di {
	constructor(t) {
		super(t);
	}
	g() {
		return ur(this, Ys, 2, Xo);
	}
};
var Xo = [
	1,
	2,
	3,
	4,
	5,
	6
];
var Wo = class extends di {
	constructor(t) {
		super(t);
	}
	g() {
		return null != sr(this, 1, void 0, mr);
	}
	j() {
		return null != _e(sr(this, 2));
	}
};
var zo = class extends di {
	constructor(t) {
		super(t);
	}
};
var Yo = [
	0,
	Ts,
	As,
	[
		0,
		fs,
		us,
		-1
	],
	[
		0,
		ds,
		us
	]
];
var qo = [
	0,
	Yo,
	vs,
	[
		0,
		Xo,
		bs,
		ro,
		bs,
		qs,
		bs,
		Ws,
		bs,
		to,
		bs,
		Zs,
		bs,
		Js
	],
	Rs
];
var Jo = Os(qo);
var Zo = class extends di {
	constructor(t) {
		super(t);
	}
};
var Qo = [
	0,
	qo,
	is,
	-1,
	fs
];
var ta = Ns(502141897, Zo);
io[502141897] = Qo;
var ea = Ms(class extends di {
	constructor(t) {
		super(t);
	}
}, [
	0,
	[
		0,
		Rs,
		-1,
		ss,
		Ls
	],
	Co
]);
var ra = class extends di {
	constructor(t) {
		super(t);
	}
};
var na = class extends di {
	constructor(t) {
		super(t);
	}
};
var ia = [
	0,
	qo,
	is,
	[0, qo],
	vs
];
var sa = Ns(508968150, na);
io[508968150] = [
	0,
	qo,
	Qo,
	ia,
	is,
	[0, [0, Yo]]
], io[508968149] = ia;
var oa = class extends di {
	constructor(t) {
		super(t);
	}
	j() {
		return Sr(this, Go, 2);
	}
	g() {
		ar(this, 2);
	}
};
var aa = [
	0,
	qo,
	jo
];
io[478825465] = aa;
var ha = class extends di {
	constructor(t) {
		super(t);
	}
};
var ua = class extends di {
	constructor(t) {
		super(t);
	}
};
var ca = class extends di {
	constructor(t) {
		super(t);
	}
};
var la = class extends di {
	constructor(t) {
		super(t);
	}
};
var da = class extends di {
	constructor(t) {
		super(t);
	}
};
var fa = [
	0,
	qo,
	[0, qo],
	aa,
	-1
];
var pa = [
	0,
	qo,
	is,
	fs
];
var ga = [
	0,
	qo,
	is
];
var ma = [
	0,
	qo,
	pa,
	ga,
	is
];
var va = Ns(479097054, da);
io[479097054] = [
	0,
	qo,
	ma,
	fa
], io[463370452] = fa, io[464864288] = pa;
var _a = Ns(462713202, la);
io[462713202] = ma, io[474472470] = ga;
var ya = class extends di {
	constructor(t) {
		super(t);
	}
};
var Ea = class extends di {
	constructor(t) {
		super(t);
	}
};
var Aa = class extends di {
	constructor(t) {
		super(t);
	}
};
var wa = class extends di {
	constructor(t) {
		super(t);
	}
};
var ba = [
	0,
	qo,
	is,
	-1,
	fs
];
var Ta = [
	0,
	qo,
	is,
	vs
];
wa.prototype.g = Ds([
	0,
	qo,
	ga,
	[0, qo],
	Qo,
	ia,
	ba,
	Ta
]);
var ka = class extends di {
	constructor(t) {
		super(t);
	}
};
var Sa = Ns(456383383, ka);
io[456383383] = [
	0,
	qo,
	jo
];
var La = class extends di {
	constructor(t) {
		super(t);
	}
};
var xa = Ns(476348187, La);
io[476348187] = [
	0,
	qo,
	Ho
];
var Ra = class extends di {
	constructor(t) {
		super(t);
	}
};
var Ia = class extends di {
	constructor(t) {
		super(t);
	}
};
var Fa = [
	0,
	Rs,
	-1
];
var Ca = Ns(458105876, class extends di {
	constructor(t) {
		super(t);
	}
	g() {
		var t = this.A, e = 0 | t[et], r = ht(this, e);
		return t = function(t, e, r, n) {
			var i = Ia;
			!n && Qe(t) && (r = 0 | (e = t.A)[et]);
			var s = or(e, 2);
			if (t = !1, null == s) {
				if (n) return Ce();
				s = [];
			} else if (s.constructor === Re) {
				if (!(2 & s.M) || n) return s;
				s = s.ea();
			} else Array.isArray(s) ? t = !!(2 & s[et]) : s = [];
			if (n) {
				if (!s.length) return Ce();
				t || (t = !0, st(s));
			} else t && (t = !1, ot(s), s = vr(s));
			return !t && 32 & r && nt(s, 32), r = hr(e, r, 2, n = new Re(s, i, Ee, void 0)), t || er(e, r), n;
		}(this, t, e, r), !r && Ia && (t.Fa = !0), t;
	}
});
io[458105876] = [
	0,
	Fa,
	Vi,
	[
		!0,
		us,
		[
			0,
			As,
			-1,
			ys
		]
	],
	[
		0,
		gs,
		vs,
		Rs
	],
	vs
];
var Na = class extends di {
	constructor(t) {
		super(t);
	}
};
var Ma = Ns(458105758, Na);
io[458105758] = [
	0,
	qo,
	As,
	Fa
];
var Oa = class extends di {
	constructor(t) {
		super(t);
	}
};
var Da = class extends di {
	constructor(t) {
		super(t);
	}
};
var Pa = class extends di {
	constructor(t) {
		super(t);
	}
};
var $a = Os([
	0,
	ws,
	[
		0,
		Is,
		ws,
		[
			0,
			as,
			-1
		],
		_s
	]
]);
var Ua = class extends di {
	constructor(t) {
		super(t);
	}
};
var Ba = [
	0,
	as,
	-1,
	_s
];
var Ga = class extends di {
	constructor(t) {
		super(t);
	}
};
var ja = class extends di {
	constructor(t) {
		super(t);
	}
};
var Va = [1, 2];
ja.prototype.g = Ds([
	0,
	Va,
	bs,
	Ba,
	bs,
	[
		0,
		ws,
		Ba
	]
]);
var Ha = class extends di {
	constructor(t) {
		super(t);
	}
};
var Ka = Ns(443442058, Ha);
io[443442058] = [
	0,
	qo,
	As,
	fs,
	is,
	ys,
	-1,
	vs,
	is
], io[514774813] = ba;
var Xa = class extends di {
	constructor(t) {
		super(t);
	}
};
var Wa = Ns(516587230, Xa);
function za(t, e) {
	return e = e ? e.clone() : new Go(), void 0 !== t.displayNamesLocale ? ar(e, 1, ve(t.displayNamesLocale)) : void 0 === t.displayNamesLocale && ar(e, 1), void 0 !== t.maxResults ? Ur(e, 2, t.maxResults) : "maxResults" in t && ar(e, 2), void 0 !== t.scoreThreshold ? jr(e, 3, t.scoreThreshold) : "scoreThreshold" in t && ar(e, 3), void 0 !== t.categoryAllowlist ? Kr(e, 4, t.categoryAllowlist) : "categoryAllowlist" in t && ar(e, 4), void 0 !== t.categoryDenylist ? Kr(e, 5, t.categoryDenylist) : "categoryDenylist" in t && ar(e, 5), e;
}
function Ya(t) {
	var e = Number(t);
	return Number.isSafeInteger(e) ? e : String(t);
}
function qa(t, e = -1, r = "") {
	return {
		categories: t.map((t) => ({
			index: Or(t, 1) ?? 0 ?? -1,
			score: Dr(t, 2) ?? 0,
			categoryName: _e(sr(t, 3)) ?? "" ?? "",
			displayName: _e(sr(t, 4)) ?? "" ?? ""
		})),
		headIndex: e,
		headName: r
	};
}
function Ja(t) {
	var e = { classifications: xr(t, Mo, 1).map((t) => qa(Sr(t, Eo, 4)?.g() ?? [], Or(t, 2) ?? 0, _e(sr(t, 3)) ?? "")) };
	return null != function(t) {
		return null == t ? t : "bigint" == typeof t ? (wt(t) ? t = Number(t) : (t = Ht(64, t), t = wt(t) ? Number(t) : String(t)), t) : te(t) ? "number" == typeof t ? ae(t) : ce(t) : void 0;
	}(sr(t, 2, void 0, fe)) && (e.timestampMs = Ya(sr(t, 2, void 0, fe) ?? nr)), e;
}
function Za(t) {
	var e = lr(t, 3, Jt, cr()), r = lr(t, 2, re, cr()), n = lr(t, 1, _e, cr()), i = lr(t, 9, _e, cr()), s = {
		categories: [],
		keypoints: []
	};
	for (let t = 0; t < e.length; t++) s.categories.push({
		score: e[t],
		index: r[t] ?? -1,
		categoryName: n[t] ?? "",
		displayName: i[t] ?? ""
	});
	if ((e = Sr(t, ko, 4)?.j()) && (s.boundingBox = {
		originX: Or(e, 1, ir) ?? 0,
		originY: Or(e, 2, ir) ?? 0,
		width: Or(e, 3, ir) ?? 0,
		height: Or(e, 4, ir) ?? 0,
		angle: 0
	}), Sr(t, ko, 4)?.g().length) for (let e of Sr(t, ko, 4).g()) s.keypoints.push({
		x: sr(e, 1, ir, Jt) ?? 0,
		y: sr(e, 2, ir, Jt) ?? 0,
		score: sr(e, 4, ir, Jt) ?? 0,
		label: _e(sr(e, 3, ir)) ?? ""
	});
	return s;
}
function Qa(t) {
	var e = [];
	for (let r of xr(t, Ro, 1)) e.push({
		x: Dr(r, 1) ?? 0,
		y: Dr(r, 2) ?? 0,
		z: Dr(r, 3) ?? 0,
		visibility: Dr(r, 4) ?? 0
	});
	return e;
}
function th(t) {
	var e = [];
	for (let r of xr(t, Lo, 1)) e.push({
		x: Dr(r, 1) ?? 0,
		y: Dr(r, 2) ?? 0,
		z: Dr(r, 3) ?? 0,
		visibility: Dr(r, 4) ?? 0
	});
	return e;
}
function eh(t) {
	return Array.from(t, (t) => t > 127 ? t - 256 : t);
}
function rh(t, e) {
	if (t.length !== e.length) throw Error(`Cannot compute cosine similarity between embeddings of different sizes (${t.length} vs. ${e.length}).`);
	var r = 0, n = 0, i = 0;
	for (let s = 0; s < t.length; s++) r += t[s] * e[s], n += t[s] * t[s], i += e[s] * e[s];
	if (n <= 0 || i <= 0) throw Error("Cannot compute cosine similarity on embedding with 0 norm.");
	return r / Math.sqrt(n * i);
}
io[516587230] = [
	0,
	qo,
	ba,
	Ta,
	is
], io[518928384] = Ta;
var nh;
var ih = new Uint8Array([
	0,
	97,
	115,
	109,
	1,
	0,
	0,
	0,
	1,
	5,
	1,
	96,
	0,
	1,
	123,
	3,
	2,
	1,
	0,
	10,
	10,
	1,
	8,
	0,
	65,
	0,
	253,
	15,
	253,
	98,
	11
]);
async function sh(t) {
	if (t) return !0;
	if (void 0 === nh) try {
		await WebAssembly.instantiate(ih), nh = !0;
	} catch {
		nh = !1;
	}
	return nh;
}
async function oh(t, e, r) {
	return {
		wasmLoaderPath: `${e}/${t}_${r = `wasm${r ? "_module" : ""}${await sh(r) ? "" : "_nosimd"}_internal`}.js`,
		wasmBinaryPath: `${e}/${t}_${r}.wasm`
	};
}
var ah = class {};
function hh(t) {
	return ar(new uh(), 1, ee(t));
}
ah.forVisionTasks = function(t, e = !1) {
	return oh("vision", t ?? Xs``, e);
}, ah.forTextTasks = function(t, e = !1) {
	return oh("text", t ?? Xs``, e);
}, ah.forGenAiTasks = function(t, e = !1) {
	return oh("genai", t ?? Xs``, e);
}, ah.forAudioTasks = function(t, e = !1) {
	return oh("audio", t ?? Xs``, e);
}, ah.isSimdSupported = function(t = !1) {
	return sh(t);
};
var uh = class extends di {
	constructor(t) {
		super(t);
	}
};
var ch = class extends di {
	constructor(t) {
		super(t);
	}
};
var lh = [
	0,
	Rs,
	2,
	ds,
	-2,
	us,
	ws,
	[
		0,
		Rs,
		us
	]
];
var dh = class extends di {
	constructor(t) {
		super(t);
	}
};
var fh = class extends di {
	constructor(t) {
		super(t);
	}
};
function ph(t, e) {
	return ar(t, 1, ee(e));
}
function gh(t, e) {
	return ar(t, 2, ee(e));
}
var mh = class extends di {
	constructor(t) {
		super(t);
	}
};
var vh = [
	3,
	4,
	5,
	6,
	7
];
var _h = class extends di {
	constructor(t) {
		super(t);
	}
};
var yh = class extends di {
	constructor(t) {
		super(t);
	}
};
yh.prototype.g = Ds([
	0,
	[
		0,
		Rs,
		As,
		-3,
		Rs
	],
	[
		0,
		vh,
		Rs,
		-1,
		bs,
		[
			0,
			Rs,
			As,
			ds
		],
		bs,
		lh,
		bs,
		[
			0,
			1,
			lh
		],
		bs,
		[0, Rs],
		bs,
		[
			0,
			Rs,
			As,
			ds
		]
	]
]);
var Eh = class {
	constructor() {
		this.g = "undefined" != typeof AbortController;
	}
	async send(t, e, r) {
		var n = this.g ? new AbortController() : void 0, i = n && t.la > 0 ? setTimeout(() => {
			n.abort();
		}, t.la) : void 0;
		try {
			let i = await fetch(t.url, {
				method: t.bb,
				headers: { ...t.ab },
				...t.body && { body: t.body },
				...t.withCredentials && { credentials: "include" },
				signal: t.la && n ? n.signal : null
			});
			200 === i.status ? e?.(await i.text()) : r?.(i.status);
		} catch (t) {
			if ("AbortError" === t?.name) r?.(408);
			else r?.(400);
		} finally {
			clearTimeout(i);
		}
	}
};
var Ah = class extends di {
	constructor(t) {
		super(t, 37);
	}
};
var wh = [
	-4,
	{},
	js,
	Rs,
	$s
];
var bh = [
	0,
	As,
	Rs,
	1,
	As,
	-1,
	Rs,
	1,
	Rs,
	1,
	us
];
var Th = [
	0,
	Rs,
	As,
	-2
];
var kh = [
	0,
	As,
	Rs
];
var Sh = [
	0,
	As,
	Rs
];
var Lh = [
	0,
	vs,
	-3
];
var xh = [
	0,
	Rs,
	As,
	-1,
	us,
	fs,
	-1,
	As,
	-5,
	ws,
	[
		0,
		As,
		-4
	],
	-1,
	vs,
	[
		0,
		vs,
		-3
	],
	Rs
];
var Rh = class extends di {
	constructor(t) {
		super(t, 19);
	}
};
var Ih = Os([
	-19,
	{},
	[
		0,
		Rs,
		1,
		[
			0,
			As,
			-6,
			us,
			fs,
			As,
			-1,
			us
		],
		1,
		[
			0,
			As,
			1,
			As,
			-5
		],
		As,
		-1,
		[
			0,
			Rs,
			As,
			-8
		],
		[
			0,
			As,
			-3
		],
		[
			0,
			As,
			Rs,
			As,
			-2
		],
		[
			0,
			As,
			-1,
			Rs,
			As,
			-1,
			Rs,
			As,
			-1,
			[
				0,
				ws,
				[
					0,
					As,
					-1
				],
				vs,
				As,
				-5
			],
			[
				0,
				Rs,
				vs,
				fs,
				-2
			]
		],
		us,
		[
			0,
			As,
			-3,
			us,
			fs,
			As,
			-1
		],
		[
			0,
			Rs,
			As,
			-1
		],
		[
			0,
			As,
			-9
		],
		[
			0,
			As,
			-6,
			Rs,
			As,
			1,
			As,
			vs,
			Rs,
			-1,
			vs,
			As,
			-2,
			Rs,
			As,
			Rs,
			As,
			fs,
			-1
		],
		1,
		[0, Rs],
		1,
		[
			0,
			As,
			-4
		],
		1,
		bh,
		[
			0,
			[
				1,
				2,
				3,
				4,
				5,
				6
			],
			bs,
			bh,
			bs,
			kh,
			bs,
			Sh,
			bs,
			[0, Rs],
			bs,
			xh,
			bs,
			Th
		],
		kh,
		Sh,
		xh,
		[
			0,
			[
				0,
				Rs,
				As,
				-1,
				us,
				fs,
				-1,
				As,
				-4,
				ws,
				[
					0,
					As,
					-4
				],
				-1,
				1,
				Lh
			],
			[
				0,
				Rs,
				As,
				-1,
				us,
				fs,
				-1,
				As,
				-4,
				Lh
			]
		],
		Th,
		[
			0,
			As,
			[
				0,
				fs,
				-3,
				Rs
			],
			Rs,
			-2,
			[
				0,
				fs,
				-1
			],
			vs
		],
		4,
		[
			0,
			As,
			Rs,
			As,
			-1,
			us,
			Rs,
			As,
			-1,
			Rs,
			fs,
			-1
		]
	],
	Rs,
	ws,
	[
		-37,
		{},
		hs,
		As,
		ws,
		[
			0,
			As,
			-1
		],
		Ts,
		1,
		Ts,
		[
			0,
			ys,
			-1,
			ps,
			cs,
			-1
		],
		As,
		[
			0,
			fs,
			As,
			-1
		],
		vs,
		fs,
		us,
		As,
		-1,
		Fs,
		Ps,
		hs,
		Ts,
		Rs,
		ps,
		us,
		-1,
		[
			0,
			Rs,
			-1
		],
		As,
		vs,
		As,
		gs,
		As,
		-1,
		ns,
		1,
		ns,
		wh,
		vs,
		[
			0,
			Rs,
			[
				0,
				is,
				fs,
				-2
			],
			[0, is]
		],
		[
			0,
			Rs,
			us
		]
	],
	hs,
	ks,
	As,
	-1,
	hs,
	Rs,
	-1,
	[
		0,
		vs,
		-1,
		Rs,
		vs
	],
	[
		0,
		us,
		-1,
		As
	],
	[
		0,
		hs,
		vs,
		us
	],
	us,
	1,
	Ss,
	1,
	wh
]);
var Fh = class {
	constructor(t) {
		this.h = [], this.m = new Eh(), this.j = t ?? "", this.g = setInterval(() => {
			this.flush();
		}, 6e4);
	}
	close() {
		void 0 !== this.g && (clearInterval(this.g), this.g = void 0), this.flush();
	}
	flush(t, e) {
		if (this.error) e?.("net-send-failed");
		else if (0 === this.h.length) t?.();
		else {
			var r = this.h;
			this.h = [], r = function(t) {
				var e = new Rh();
				return Cr(e = ar(e, 2, ee(1786)), 3, t);
			}(r), r = Ih(r), this.m.send({
				url: "https://odml.pa.googleapis.com/v1/log",
				bb: "POST",
				la: 1e4,
				body: r,
				hb: 2,
				ab: {
					"Content-Type": "application/x-protobuf",
					"x-goog-api-key": this.j
				},
				withCredentials: !1
			}, () => {
				t?.();
			}, (t) => {
				this.error = Error(`Logging failed with HTTP error: ${t}`), this.h = [], void 0 !== this.g && (clearInterval(this.g), this.g = void 0), e?.("net-send-failed", t);
			});
		}
	}
};
var Ch = class {
	constructor() {
		this.aa = this.U = this.X = this.R = this.V = this.T = this.P = 0;
	}
};
function Nh(t, e) {
	var r = new yh();
	r = Ir(r, 0, 1, t.B), r = Ir(r, 0, 2, e), e = ar(e = new Ah(), 6, ct(r = r.g(), !1)), (t = t.l).error || t.h.push(e);
}
function Mh(t, e) {
	var r = {
		P: e.P - t.j.P,
		T: e.T - t.j.T,
		V: e.V - t.j.V,
		R: e.R - t.j.R,
		X: e.X - t.j.X,
		U: e.U,
		aa: e.aa
	}, n = gh(ph(new mh(), t.C), 1);
	r = Oh(t, r), Nh(t, n = Fr(n, 4, vh, r)), t.j = e;
}
function Oh(t, e) {
	var r = new ch();
	return t = Gr(t = Br(t = ar(r, 1, ee(t.D)), 7, e.R), 5, e.U), t = Gr(t, 6, e.aa), e.V > 0 && Gr(t, 4, e.X / e.V), 0 !== e.P && (r = Br(r = hh(3), 2, e.P), Mr(t, 8, uh, r)), 0 !== e.T && (e = Br(r = hh(4), 2, e.T), Mr(t, 8, uh, e)), t;
}
var Dh = class {
	constructor(t, e, r) {
		this.u = performance.now(), this.m = performance.now(), this.h = /* @__PURE__ */ new Map(), this.o = 0, this.g = new Ch(), this.j = new Ch(), this.l = new Fh(r), this.C = function(t) {
			switch (t) {
				case "AudioClassifier": return 4;
				case "AudioEmbedder": return 5;
				case "TextClassifier": return 6;
				case "TextEmbedder": return 7;
				case "GestureRecognizer": return 8;
				case "HandDetector": return 9;
				case "HandLandmarker": return 10;
				case "ImageClassifier": return 11;
				case "ImageEmbedder": return 12;
				case "ImageSegmenter": return 13;
				case "ObjectDetector": return 14;
				case "FaceDetector": return 15;
				case "FaceLandmarker": return 16;
				case "InteractiveSegmenter":
				case "InteractiveSegmenterLegacy": return 18;
				case "HolisticLandmarker": return 20;
				case "LlmInference": return 21;
				case "LanguageDetector": return 22;
				case "PoseLandmarker": return 23;
				default: return 0;
			}
		}(t), this.D = function(t) {
			switch (t) {
				case "IMAGE": return 11;
				case "VIDEO": return 12;
				case "LIVE_STREAM": return 13;
				case "AUDIO_CLIPS": return 14;
				case "AUDIO_STREAM": return 15;
				default: return 10;
			}
		}(e), t = new _h(), "undefined" == typeof window ? e = 0 : (e = navigator.userAgent, e = /Android/i.test(e) ? 1 : /iPhone|iPad|iPod/i.test(e) ? 2 : /Windows/i.test(e) ? 5 : /Macintosh/i.test(e) ? 4 : /Linux/i.test(e) ? 3 : 0), t = ar(t, 1, ee(e)), t = ar(t, 2, ve("")), t = ar(t, 3, ve("")), t = ar(t, 4, ve("1.0.1")), t = ar(t, 5, ve("")), this.B = ar(t, 6, ee(4));
	}
	ya() {
		var t = new fh();
		t = Gr(t = ar(t, 1, ee(this.D)), 3, performance.now() - this.u), Nh(this, t = Fr(gh(ph(new mh(), this.C), 0), 3, vh, t)), this.m = performance.now();
	}
	za(t) {
		var e = this.h.get(t);
		if (void 0 !== e && (this.h.delete(t), t = performance.now() - e, ++this.g.V, this.g.X += t, this.g.U = Math.max(this.g.U, t), this.o = Math.max(this.o, t), performance.now() > this.m + 3e4)) {
			for (let [r, n] of this.h.entries()) t = r, n < e && (this.g.R++, this.h.delete(t));
			e = {
				...this.g,
				aa: performance.now() - this.m
			}, this.g.U = 0, this.m = performance.now(), Mh(this, e);
		}
	}
	xa() {
		var t = {
			...this.g,
			R: this.g.R + this.h.size,
			U: this.o,
			aa: performance.now() - this.u
		};
		Mh(this, t);
		var e = new dh();
		e = Ir(e, 0, 2, t = Oh(this, t)), Nh(this, e = Fr(t = gh(ph(new mh(), this.C), 2), 5, vh, e));
	}
	close() {
		var t = this.l;
		"function" == typeof t.close ? t.close() : t.flush();
	}
};
function Ph() {
	var t = navigator;
	return "undefined" != typeof OffscreenCanvas && (!function(t = navigator) {
		return (t = t.userAgent).includes("Safari") && !t.includes("Chrome");
	}(t) || !!((t = t.userAgent.match(/Version\/([\d]+).*Safari/)) && t.length >= 1 && Number(t[1]) >= 17));
}
async function $h(t) {
	if ("function" != typeof importScripts) {
		let e = document.createElement("script");
		return e.src = t.toString(), e.crossOrigin = "anonymous", new Promise((t, r) => {
			e.addEventListener("load", () => {
				t();
			}, !1), e.addEventListener("error", (t) => {
				r(t);
			}, !1), document.body.appendChild(e);
		});
	}
	try {
		importScripts(t.toString());
	} catch (e) {
		if (!(e instanceof TypeError)) throw e;
		{
			let e = self.import;
			e ? await e(t.toString()) : await import(t.toString());
		}
	}
}
function Uh(t) {
	return void 0 !== t.videoWidth ? [t.videoWidth, t.videoHeight] : void 0 !== t.naturalWidth ? [t.naturalWidth, t.naturalHeight] : void 0 !== t.displayWidth ? [t.displayWidth, t.displayHeight] : [t.width, t.height];
}
function Bh(t, e, r) {
	t.m || console.error("No wasm multistream support detected: ensure dependency inclusion of :gl_graph_runner_internal_multi_input target"), r(e = t.i.stringToNewUTF8(e)), t.i._free(e);
}
function Gh(t, e, r) {
	if (!t.i.canvas) throw Error("No OpenGL canvas configured.");
	if (r ? t.i._bindTextureToStream(r) : t.i._bindTextureToCanvas(), !(r = t.i.canvas.getContext("webgl2") || t.i.canvas.getContext("webgl"))) throw Error("Failed to obtain WebGL context from the provided canvas. `getContext()` should only be invoked with `webgl` or `webgl2`.");
	t.i.gpuOriginForWebTexturesIsBottomLeft && r.pixelStorei(r.UNPACK_FLIP_Y_WEBGL, !0), r.texImage2D(r.TEXTURE_2D, 0, r.RGBA, r.RGBA, r.UNSIGNED_BYTE, e), t.i.gpuOriginForWebTexturesIsBottomLeft && r.pixelStorei(r.UNPACK_FLIP_Y_WEBGL, !1);
	var [n, i] = Uh(e);
	return !t.j || n === t.i.canvas.width && i === t.i.canvas.height || (t.i.canvas.width = n, t.i.canvas.height = i), [n, i];
}
function jh(t, e, r) {
	t.m || console.error("No wasm multistream support detected: ensure dependency inclusion of :gl_graph_runner_internal_multi_input target");
	var n = new Uint32Array(e.length);
	for (let r = 0; r < e.length; r++) n[r] = t.i.stringToNewUTF8(e[r]);
	e = t.i._malloc(4 * n.length), t.i.HEAPU32.set(n, e >> 2), r(e);
	for (let e of n) t.i._free(e);
	t.i._free(e);
}
function Vh(t, e, r) {
	t.i.simpleListeners = t.i.simpleListeners || {}, t.i.simpleListeners[e] = r;
}
function Hh(t, e, r) {
	var n = [];
	t.i.simpleListeners = t.i.simpleListeners || {}, t.i.simpleListeners[e] = (t, e, i) => {
		e ? (r(n, i), n = []) : n.push(t);
	};
}
var Kh = class {
	constructor(t, e) {
		this.j = !0, this.i = t, this.g = null, this.h = 0, this.m = "function" == typeof this.i._addIntToInputStream, void 0 !== e ? this.i.canvas = e : Ph() ? this.i.canvas = new OffscreenCanvas(1, 1) : (console.warn("OffscreenCanvas not supported and GraphRunner constructor glCanvas parameter is undefined. Creating backup canvas."), this.i.canvas = document.createElement("canvas"));
	}
	async initializeGraph(t) {
		var e = await (await fetch(t)).arrayBuffer();
		t = !(t.endsWith(".pbtxt") || t.endsWith(".textproto")), this.setGraph(new Uint8Array(e), t);
	}
	setGraphFromString(t) {
		this.setGraph(new TextEncoder().encode(t), !1);
	}
	setGraph(t, e) {
		var r = t.length, n = this.i._malloc(r);
		this.i.HEAPU8.set(t, n), e ? this.i._changeBinaryGraph(r, n) : this.i._changeTextGraph(r, n), this.i._free(n);
	}
	configureAudio(t, e, r, n, i) {
		this.i._configureAudio || console.warn("Attempting to use configureAudio without support for input audio. Is build dep \":gl_graph_runner_audio\" missing?"), Bh(this, n || "input_audio", (n) => {
			Bh(this, i = i || "audio_header", (i) => {
				this.i._configureAudio(n, i, t, e ?? 0, r);
			});
		});
	}
	setAutoResizeCanvas(t) {
		this.j = t;
	}
	setAutoRenderToScreen(t) {
		this.i._setAutoRenderToScreen(t);
	}
	setGpuBufferVerticalFlip(t) {
		this.i.gpuOriginForWebTexturesIsBottomLeft = t;
	}
	ja(t) {
		Vh(this, "__graph_config__", (e) => {
			t(e);
		}), Bh(this, "__graph_config__", (t) => {
			this.i._getGraphConfig(t, void 0);
		}), delete this.i.simpleListeners.__graph_config__;
	}
	attachErrorListener(t) {
		this.i.errorListener = t;
	}
	attachEmptyPacketListener(t, e) {
		this.i.emptyPacketListeners = this.i.emptyPacketListeners || {}, this.i.emptyPacketListeners[t] = e;
	}
	addAudioToStream(t, e, r) {
		this.addAudioToStreamWithShape(t, 0, 0, e, r);
	}
	addAudioToStreamWithShape(t, e, r, n, i) {
		var s = 4 * t.length;
		this.h !== s && (this.g && this.i._free(this.g), this.g = this.i._malloc(s), this.h = s), this.i.HEAPF32.set(t, this.g / 4), Bh(this, n, (t) => {
			this.i._addAudioToInputStream(this.g, e, r, t, i);
		});
	}
	addGpuBufferToStream(t, e, r) {
		Bh(this, e, (e) => {
			var [n, i] = Gh(this, t, e);
			this.i._addBoundTextureToStream(e, n, i, r);
		});
	}
	addBoolToStream(t, e, r) {
		Bh(this, e, (e) => {
			this.i._addBoolToInputStream(t, e, r);
		});
	}
	addDoubleToStream(t, e, r) {
		Bh(this, e, (e) => {
			this.i._addDoubleToInputStream(t, e, r);
		});
	}
	addFloatToStream(t, e, r) {
		Bh(this, e, (e) => {
			this.i._addFloatToInputStream(t, e, r);
		});
	}
	addIntToStream(t, e, r) {
		Bh(this, e, (e) => {
			this.i._addIntToInputStream(t, e, r);
		});
	}
	addUintToStream(t, e, r) {
		Bh(this, e, (e) => {
			this.i._addUintToInputStream(t, e, r);
		});
	}
	addStringToStream(t, e, r) {
		Bh(this, e, (e) => {
			Bh(this, t, (t) => {
				this.i._addStringToInputStream(t, e, r);
			});
		});
	}
	addStringRecordToStream(t, e, r) {
		Bh(this, e, (e) => {
			jh(this, Object.keys(t), (n) => {
				jh(this, Object.values(t), (i) => {
					this.i._addFlatHashMapToInputStream(n, i, Object.keys(t).length, e, r);
				});
			});
		});
	}
	addProtoToStream(t, e, r, n) {
		Bh(this, r, (r) => {
			Bh(this, e, (e) => {
				var i = this.i._malloc(t.length);
				this.i.HEAPU8.set(t, i), this.i._addProtoToInputStream(i, t.length, e, r, n), this.i._free(i);
			});
		});
	}
	addEmptyPacketToStream(t, e) {
		Bh(this, t, (t) => {
			this.i._addEmptyPacketToInputStream(t, e);
		});
	}
	addBoolVectorToStream(t, e, r) {
		Bh(this, e, (e) => {
			var n = this.i._allocateBoolVector(t.length);
			if (!n) throw Error("Unable to allocate new bool vector on heap.");
			for (let e of t) this.i._addBoolVectorEntry(n, e);
			this.i._addBoolVectorToInputStream(n, e, r);
		});
	}
	addDoubleVectorToStream(t, e, r) {
		Bh(this, e, (e) => {
			var n = this.i._allocateDoubleVector(t.length);
			if (!n) throw Error("Unable to allocate new double vector on heap.");
			for (let e of t) this.i._addDoubleVectorEntry(n, e);
			this.i._addDoubleVectorToInputStream(n, e, r);
		});
	}
	addFloatVectorToStream(t, e, r) {
		Bh(this, e, (e) => {
			var n = this.i._allocateFloatVector(t.length);
			if (!n) throw Error("Unable to allocate new float vector on heap.");
			for (let e of t) this.i._addFloatVectorEntry(n, e);
			this.i._addFloatVectorToInputStream(n, e, r);
		});
	}
	addIntVectorToStream(t, e, r) {
		Bh(this, e, (e) => {
			var n = this.i._allocateIntVector(t.length);
			if (!n) throw Error("Unable to allocate new int vector on heap.");
			for (let e of t) this.i._addIntVectorEntry(n, e);
			this.i._addIntVectorToInputStream(n, e, r);
		});
	}
	addUintVectorToStream(t, e, r) {
		Bh(this, e, (e) => {
			var n = this.i._allocateUintVector(t.length);
			if (!n) throw Error("Unable to allocate new unsigned int vector on heap.");
			for (let e of t) this.i._addUintVectorEntry(n, e);
			this.i._addUintVectorToInputStream(n, e, r);
		});
	}
	addStringVectorToStream(t, e, r) {
		Bh(this, e, (e) => {
			var n = this.i._allocateStringVector(t.length);
			if (!n) throw Error("Unable to allocate new string vector on heap.");
			for (let e of t) Bh(this, e, (t) => {
				this.i._addStringVectorEntry(n, t);
			});
			this.i._addStringVectorToInputStream(n, e, r);
		});
	}
	addBoolToInputSidePacket(t, e) {
		Bh(this, e, (e) => {
			this.i._addBoolToInputSidePacket(t, e);
		});
	}
	addDoubleToInputSidePacket(t, e) {
		Bh(this, e, (e) => {
			this.i._addDoubleToInputSidePacket(t, e);
		});
	}
	addFloatToInputSidePacket(t, e) {
		Bh(this, e, (e) => {
			this.i._addFloatToInputSidePacket(t, e);
		});
	}
	addIntToInputSidePacket(t, e) {
		Bh(this, e, (e) => {
			this.i._addIntToInputSidePacket(t, e);
		});
	}
	addUintToInputSidePacket(t, e) {
		Bh(this, e, (e) => {
			this.i._addUintToInputSidePacket(t, e);
		});
	}
	addStringToInputSidePacket(t, e) {
		Bh(this, e, (e) => {
			Bh(this, t, (t) => {
				this.i._addStringToInputSidePacket(t, e);
			});
		});
	}
	addProtoToInputSidePacket(t, e, r) {
		Bh(this, r, (r) => {
			Bh(this, e, (e) => {
				var n = this.i._malloc(t.length);
				this.i.HEAPU8.set(t, n), this.i._addProtoToInputSidePacket(n, t.length, e, r), this.i._free(n);
			});
		});
	}
	addBoolVectorToInputSidePacket(t, e) {
		Bh(this, e, (e) => {
			var r = this.i._allocateBoolVector(t.length);
			if (!r) throw Error("Unable to allocate new bool vector on heap.");
			for (let e of t) this.i._addBoolVectorEntry(r, e);
			this.i._addBoolVectorToInputSidePacket(r, e);
		});
	}
	addDoubleVectorToInputSidePacket(t, e) {
		Bh(this, e, (e) => {
			var r = this.i._allocateDoubleVector(t.length);
			if (!r) throw Error("Unable to allocate new double vector on heap.");
			for (let e of t) this.i._addDoubleVectorEntry(r, e);
			this.i._addDoubleVectorToInputSidePacket(r, e);
		});
	}
	addFloatVectorToInputSidePacket(t, e) {
		Bh(this, e, (e) => {
			var r = this.i._allocateFloatVector(t.length);
			if (!r) throw Error("Unable to allocate new float vector on heap.");
			for (let e of t) this.i._addFloatVectorEntry(r, e);
			this.i._addFloatVectorToInputSidePacket(r, e);
		});
	}
	addIntVectorToInputSidePacket(t, e) {
		Bh(this, e, (e) => {
			var r = this.i._allocateIntVector(t.length);
			if (!r) throw Error("Unable to allocate new int vector on heap.");
			for (let e of t) this.i._addIntVectorEntry(r, e);
			this.i._addIntVectorToInputSidePacket(r, e);
		});
	}
	addUintVectorToInputSidePacket(t, e) {
		Bh(this, e, (e) => {
			var r = this.i._allocateUintVector(t.length);
			if (!r) throw Error("Unable to allocate new unsigned int vector on heap.");
			for (let e of t) this.i._addUintVectorEntry(r, e);
			this.i._addUintVectorToInputSidePacket(r, e);
		});
	}
	addStringVectorToInputSidePacket(t, e) {
		Bh(this, e, (e) => {
			var r = this.i._allocateStringVector(t.length);
			if (!r) throw Error("Unable to allocate new string vector on heap.");
			for (let e of t) Bh(this, e, (t) => {
				this.i._addStringVectorEntry(r, t);
			});
			this.i._addStringVectorToInputSidePacket(r, e);
		});
	}
	attachBoolListener(t, e) {
		Vh(this, t, e), Bh(this, t, (t) => {
			this.i._attachBoolListener(t);
		});
	}
	attachBoolVectorListener(t, e) {
		Hh(this, t, e), Bh(this, t, (t) => {
			this.i._attachBoolVectorListener(t);
		});
	}
	attachIntListener(t, e) {
		Vh(this, t, e), Bh(this, t, (t) => {
			this.i._attachIntListener(t);
		});
	}
	attachIntVectorListener(t, e) {
		Hh(this, t, e), Bh(this, t, (t) => {
			this.i._attachIntVectorListener(t);
		});
	}
	attachUintListener(t, e) {
		Vh(this, t, e), Bh(this, t, (t) => {
			this.i._attachUintListener(t);
		});
	}
	attachUintVectorListener(t, e) {
		Hh(this, t, e), Bh(this, t, (t) => {
			this.i._attachUintVectorListener(t);
		});
	}
	attachDoubleListener(t, e) {
		Vh(this, t, e), Bh(this, t, (t) => {
			this.i._attachDoubleListener(t);
		});
	}
	attachDoubleVectorListener(t, e) {
		Hh(this, t, e), Bh(this, t, (t) => {
			this.i._attachDoubleVectorListener(t);
		});
	}
	attachFloatListener(t, e) {
		Vh(this, t, e), Bh(this, t, (t) => {
			this.i._attachFloatListener(t);
		});
	}
	attachFloatVectorListener(t, e) {
		Hh(this, t, e), Bh(this, t, (t) => {
			this.i._attachFloatVectorListener(t);
		});
	}
	attachStringListener(t, e) {
		Vh(this, t, e), Bh(this, t, (t) => {
			this.i._attachStringListener(t);
		});
	}
	attachStringVectorListener(t, e) {
		Hh(this, t, e), Bh(this, t, (t) => {
			this.i._attachStringVectorListener(t);
		});
	}
	attachProtoListener(t, e, r) {
		Vh(this, t, e), Bh(this, t, (t) => {
			this.i._attachProtoListener(t, r || !1);
		});
	}
	attachProtoVectorListener(t, e, r) {
		Hh(this, t, e), Bh(this, t, (t) => {
			this.i._attachProtoVectorListener(t, r || !1);
		});
	}
	attachAudioListener(t, e, r) {
		this.i._attachAudioListener || console.warn("Attempting to use attachAudioListener without support for output audio. Is build dep \":gl_graph_runner_audio_out\" missing?"), Vh(this, t, (t, r) => {
			t = new Float32Array(t.buffer, t.byteOffset, t.length / 4), e(t, r);
		}), Bh(this, t, (t) => {
			this.i._attachAudioListener(t, r || !1);
		});
	}
	finishProcessing() {
		this.i._waitUntilIdle();
	}
	closeGraph() {
		this.i._closeGraph(), this.i.simpleListeners = void 0, this.i.emptyPacketListeners = void 0;
	}
};
function Xh(t) {
	return class extends t {
		get pa() {
			return this.i;
		}
		Sa() {
			if ("function" == typeof this.pa._mediapipeLoggerGetEncodedApiKey) {
				let t = this.pa._mediapipeLoggerGetEncodedApiKey();
				return this.pa._decodeBase64(t);
			}
		}
	};
}
function Wh(t) {
	return class extends t {
		Za() {
			this.i._registerModelResourcesGraphService();
		}
	};
}
var zh = Xh(Wh(Kh));
var Yh = class extends zh {};
async function qh(t, e, r, n) {
	return t = await (async (t, e, r, n, i) => {
		if (e && await $h(e), !self.ModuleFactory) throw Error("ModuleFactory not set.");
		if (r && (await $h(r), !self.ModuleFactory)) throw Error("ModuleFactory not set.");
		return self.Module && i && ((e = self.Module).locateFile = i.locateFile, i.mainScriptUrlOrBlob && (e.mainScriptUrlOrBlob = i.mainScriptUrlOrBlob)), i = await self.ModuleFactory(self.Module || i), self.ModuleFactory = self.Module = void 0, new t(i, n);
	})(t, r.wasmLoaderPath, r.assetLoaderPath, e, { locateFile: (t) => t.endsWith(".wasm") ? r.wasmBinaryPath.toString() : r.assetBinaryPath && t.endsWith(".data") ? r.assetBinaryPath.toString() : t }), function(t, e) {
		e = e.runningMode ?? "";
		var r = t.g.Sa();
		t.m = new Dh(t.C(), e, r);
	}(t, n), await t.v(n), t;
}
async function Jh(t, e, r, n) {
	return qh(t, e, r, n);
}
function Zh(t, e) {
	var r = Sr(t.baseOptions, Wo, 1) || new Wo();
	"string" == typeof e ? (ar(r, 2, ve(e)), ar(r, 1)) : e instanceof Uint8Array && (ar(r, 1, ct(e, !1)), ar(r, 2)), Ir(t.baseOptions, 0, 1, r);
}
function Qh(t) {
	try {
		let e = t.K.length;
		if (1 === e) throw Error(t.K[0].message);
		if (e > 1) throw Error("Encountered multiple errors: " + t.K.map((t) => t.message).join(", "));
	} finally {
		t.K = [];
	}
}
function tu(t, e) {
	t.I = Math.max(t.I, e);
}
function eu(t, e) {
	t.D = new ho(), Hr(t.D, 2, "PassThroughCalculator"), oo(t.D, "free_memory"), ao(t.D, "free_memory_unused_out"), po(e, "free_memory"), fo(e, t.D);
}
function ru(t, e) {
	oo(t.D, e), ao(t.D, e + "_unused_out");
}
function nu(t) {
	t.g.addBoolToStream(!0, "free_memory", t.I);
}
var iu = class {
	constructor(t) {
		this.g = t, this.K = [], this.I = 0, this.g.setAutoRenderToScreen(!1);
	}
	j(t, e = !0) {
		if (e) {
			let e = t.baseOptions || {};
			if (t.baseOptions?.modelAssetBuffer && t.baseOptions?.modelAssetPath) throw Error("Cannot set both baseOptions.modelAssetPath and baseOptions.modelAssetBuffer");
			if (!(Sr(this.baseOptions, Wo, 1)?.g() || Sr(this.baseOptions, Wo, 1)?.j() || t.baseOptions?.modelAssetBuffer || t.baseOptions?.modelAssetPath)) throw Error("Either baseOptions.modelAssetPath or baseOptions.modelAssetBuffer must be set");
			if (function(t, e) {
				var r = Sr(t.baseOptions, Ko, 3);
				if (!r) {
					var n = r = new Ko(), i = new Qs();
					Fr(n, 4, Xo, i);
				}
				"delegate" in e && ("GPU" === e.delegate ? (e = r, n = new Ys(), Fr(e, 2, Xo, n)) : (e = r, n = new Qs(), Fr(e, 4, Xo, n))), Ir(t.baseOptions, 0, 3, r);
			}(this, e), e.modelAssetPath) return fetch(e.modelAssetPath.toString()).then((t) => {
				if (t.ok) return t.arrayBuffer();
				throw Error(`Failed to fetch model: ${e.modelAssetPath} (${t.status})`);
			}).then((t) => {
				try {
					this.g.i.FS_unlink("/model.dat");
				} catch {}
				this.g.i.FS_createDataFile("/", "model.dat", new Uint8Array(t), !0, !1, !1), Zh(this, "/model.dat"), this.o(), this.L();
			});
			if (e.modelAssetBuffer instanceof Uint8Array) Zh(this, e.modelAssetBuffer);
			else if (e.modelAssetBuffer) return async function(t) {
				for (var e = [], r = 0;;) {
					let { done: n, value: i } = await t.read();
					if (n) break;
					e.push(i), r += i.length;
				}
				if (0 === e.length) return /* @__PURE__ */ new Uint8Array(0);
				if (1 === e.length) return e[0];
				t = new Uint8Array(r), r = 0;
				for (let n of e) t.set(n, r), r += n.length;
				return t;
			}(e.modelAssetBuffer).then((t) => {
				Zh(this, t), this.o(), this.L();
			});
		}
		return this.o(), this.L(), Promise.resolve();
	}
	L() {}
	ja() {
		var t;
		if (this.g.ja((e) => {
			t = _o(e);
		}), !t) throw Error("Failed to retrieve CalculatorGraphConfig");
		return t;
	}
	setGraph(t, e) {
		this.g.attachErrorListener((t, e) => {
			this.K.push(Error(e));
		}), this.g.Za(), this.g.setGraph(t, e), this.m?.ya(), this.D = void 0, Qh(this);
	}
	finishProcessing(t) {
		this.g.finishProcessing(), Qh(this), this.m && void 0 !== t && this.m.za(t);
	}
	close() {
		this.D = void 0, this.m?.xa(), this.m?.close(), this.g.closeGraph();
	}
};
function su(t, e) {
	if (!t) throw Error(`Unable to obtain required WebGL resource: ${e}`);
	return t;
}
iu.prototype.close = iu.prototype.close;
var ou = class {
	constructor(t, e, r, n) {
		this.g = t, this.h = e, this.m = r, this.j = n;
	}
	bind() {
		this.g.bindVertexArray(this.h);
	}
	close() {
		this.g.deleteVertexArray(this.h), this.g.deleteBuffer(this.m), this.g.deleteBuffer(this.j);
	}
};
function au(t, e, r) {
	var n = t.g;
	if (r = su(n.createShader(r), "Failed to create WebGL shader"), n.shaderSource(r, e), n.compileShader(r), !n.getShaderParameter(r, n.COMPILE_STATUS)) throw Error(`Could not compile WebGL shader: ${n.getShaderInfoLog(r)}`);
	return n.attachShader(t.h, r), r;
}
function hu(t, e) {
	var r = t.g, n = su(r.createVertexArray(), "Failed to create vertex array");
	r.bindVertexArray(n);
	var i = su(r.createBuffer(), "Failed to create buffer");
	r.bindBuffer(r.ARRAY_BUFFER, i), r.enableVertexAttribArray(t.F), r.vertexAttribPointer(t.F, 2, r.FLOAT, !1, 0, 0), r.bufferData(r.ARRAY_BUFFER, new Float32Array([
		-1,
		-1,
		-1,
		1,
		1,
		1,
		1,
		-1
	]), r.STATIC_DRAW);
	var s = su(r.createBuffer(), "Failed to create buffer");
	return r.bindBuffer(r.ARRAY_BUFFER, s), r.enableVertexAttribArray(t.K), r.vertexAttribPointer(t.K, 2, r.FLOAT, !1, 0, 0), r.bufferData(r.ARRAY_BUFFER, new Float32Array(e ? [
		0,
		1,
		0,
		0,
		1,
		0,
		1,
		1
	] : [
		0,
		0,
		0,
		1,
		1,
		1,
		1,
		0
	]), r.STATIC_DRAW), r.bindBuffer(r.ARRAY_BUFFER, null), r.bindVertexArray(null), new ou(r, n, i, s);
}
function uu(t, e) {
	if (t.g) {
		if (e !== t.g) throw Error("Cannot change GL context once initialized");
	} else t.g = e;
}
function cu(t, e, r, n) {
	return uu(t, e), t.h || (t.m(), t.I()), r ? (t.l || (t.l = hu(t, !0)), r = t.l) : (t.D || (t.D = hu(t, !1)), r = t.D), e.useProgram(t.h), r.bind(), t.j(), t = n(), r.g.bindVertexArray(null), t;
}
function lu(t, e, r) {
	return uu(t, e), t = su(e.createTexture(), "Failed to create texture"), e.bindTexture(e.TEXTURE_2D, t), e.texParameteri(e.TEXTURE_2D, e.TEXTURE_WRAP_S, e.CLAMP_TO_EDGE), e.texParameteri(e.TEXTURE_2D, e.TEXTURE_WRAP_T, e.CLAMP_TO_EDGE), e.texParameteri(e.TEXTURE_2D, e.TEXTURE_MIN_FILTER, r ?? e.LINEAR), e.texParameteri(e.TEXTURE_2D, e.TEXTURE_MAG_FILTER, r ?? e.LINEAR), e.bindTexture(e.TEXTURE_2D, null), t;
}
function du(t, e, r) {
	uu(t, e), t.C || (t.C = su(e.createFramebuffer(), "Failed to create framebuffe.")), e.bindFramebuffer(e.FRAMEBUFFER, t.C), e.framebufferTexture2D(e.FRAMEBUFFER, e.COLOR_ATTACHMENT0, e.TEXTURE_2D, r, 0);
}
function fu(t) {
	t.g?.bindFramebuffer(t.g.FRAMEBUFFER, null);
}
var pu = class {
	B() {
		return "\n  precision mediump float;\n  varying vec2 vTex;\n  uniform sampler2D inputTexture;\n  void main() {\n    gl_FragColor = texture2D(inputTexture, vTex);\n  }\n ";
	}
	m() {
		var t = this.g;
		if (this.h = su(t.createProgram(), "Failed to create WebGL program"), this.da = au(this, "\n  attribute vec2 aVertex;\n  attribute vec2 aTex;\n  varying vec2 vTex;\n  void main(void) {\n    gl_Position = vec4(aVertex, 0.0, 1.0);\n    vTex = aTex;\n  }", t.VERTEX_SHADER), this.Z = au(this, this.B(), t.FRAGMENT_SHADER), t.linkProgram(this.h), !t.getProgramParameter(this.h, t.LINK_STATUS)) throw Error(`Error during program linking: ${t.getProgramInfoLog(this.h)}`);
		this.F = t.getAttribLocation(this.h, "aVertex"), this.K = t.getAttribLocation(this.h, "aTex");
	}
	I() {}
	j() {}
	close() {
		if (this.h) {
			let t = this.g;
			t.deleteProgram(this.h), t.deleteShader(this.da), t.deleteShader(this.Z);
		}
		this.C && this.g.deleteFramebuffer(this.C), this.D && this.D.close(), this.l && this.l.close();
	}
};
var gu = class extends pu {
	B() {
		return "\n  precision mediump float;\n  uniform sampler2D backgroundTexture;\n  uniform sampler2D maskTexture;\n  uniform sampler2D colorMappingTexture;\n  varying vec2 vTex;\n  void main() {\n    vec4 backgroundColor = texture2D(backgroundTexture, vTex);\n    float category = texture2D(maskTexture, vTex).r;\n    vec4 categoryColor = texture2D(colorMappingTexture, vec2(category, 0.0));\n    gl_FragColor = mix(backgroundColor, categoryColor, categoryColor.a);\n  }\n ";
	}
	I() {
		var t = this.g;
		t.activeTexture(t.TEXTURE1), this.u = lu(this, t, t.LINEAR), t.activeTexture(t.TEXTURE2), this.o = lu(this, t, t.NEAREST);
	}
	m() {
		super.m();
		var t = this.g;
		this.O = su(t.getUniformLocation(this.h, "backgroundTexture"), "Uniform location"), this.Y = su(t.getUniformLocation(this.h, "colorMappingTexture"), "Uniform location"), this.L = su(t.getUniformLocation(this.h, "maskTexture"), "Uniform location");
	}
	j() {
		super.j();
		var t = this.g;
		t.uniform1i(this.L, 0), t.uniform1i(this.O, 1), t.uniform1i(this.Y, 2);
	}
	close() {
		this.u && this.g.deleteTexture(this.u), this.o && this.g.deleteTexture(this.o), super.close();
	}
};
var mu = class extends pu {
	B() {
		return "\n  precision mediump float;\n  uniform sampler2D maskTexture;\n  uniform sampler2D defaultTexture;\n  uniform sampler2D overlayTexture;\n  varying vec2 vTex;\n  void main() {\n    float confidence = texture2D(maskTexture, vTex).r;\n    vec4 defaultColor = texture2D(defaultTexture, vTex);\n    vec4 overlayColor = texture2D(overlayTexture, vTex);\n    // Apply the alpha from the overlay and merge in the default color\n    overlayColor = mix(defaultColor, overlayColor, overlayColor.a);\n    gl_FragColor = mix(defaultColor, overlayColor, confidence);\n  }\n ";
	}
	I() {
		var t = this.g;
		t.activeTexture(t.TEXTURE1), this.o = lu(this, t), t.activeTexture(t.TEXTURE2), this.u = lu(this, t);
	}
	m() {
		super.m();
		var t = this.g;
		this.L = su(t.getUniformLocation(this.h, "defaultTexture"), "Uniform location"), this.O = su(t.getUniformLocation(this.h, "overlayTexture"), "Uniform location"), this.J = su(t.getUniformLocation(this.h, "maskTexture"), "Uniform location");
	}
	j() {
		super.j();
		var t = this.g;
		t.uniform1i(this.J, 0), t.uniform1i(this.L, 1), t.uniform1i(this.O, 2);
	}
	close() {
		this.o && this.g.deleteTexture(this.o), this.u && this.g.deleteTexture(this.u), super.close();
	}
};
function vu(t, e) {
	switch (e) {
		case 0: return t.g.find((t) => t instanceof Uint8Array);
		case 1: return t.g.find((t) => t instanceof Float32Array);
		case 2: return t.g.find((t) => "undefined" != typeof WebGLTexture && t instanceof WebGLTexture);
		default: throw Error(`Type is not supported: ${e}`);
	}
}
function _u(t) {
	var e = vu(t, 1);
	if (!e) {
		if (e = vu(t, 0)) e = new Float32Array(e).map((t) => t / 255);
		else {
			e = new Float32Array(t.width * t.height);
			let n = Eu(t);
			var r = wu(t);
			if (du(r, n, yu(t)), "iPad Simulator;iPhone Simulator;iPod Simulator;iPad;iPhone;iPod".split(";").includes(navigator.platform) || navigator.userAgent.includes("Mac") && "document" in self && "ontouchend" in self.document) {
				r = new Float32Array(t.width * t.height * 4), n.readPixels(0, 0, t.width, t.height, n.RGBA, n.FLOAT, r);
				for (let t = 0, n = 0; t < e.length; ++t, n += 4) e[t] = r[n];
			} else n.readPixels(0, 0, t.width, t.height, n.RED, n.FLOAT, e);
		}
		t.g.push(e);
	}
	return e;
}
function yu(t) {
	var e = vu(t, 2);
	if (!e) {
		let r = Eu(t);
		e = bu(t);
		let n = _u(t), i = Au(t);
		r.texImage2D(r.TEXTURE_2D, 0, i, t.width, t.height, 0, r.RED, r.FLOAT, n), Tu(t);
	}
	return e;
}
function Eu(t) {
	if (!t.canvas) throw Error("Conversion to different image formats require that a canvas is passed when initializing the image.");
	return t.h || (t.h = su(t.canvas.getContext("webgl2"), "You cannot use a canvas that is already bound to a different type of rendering context.")), t.h;
}
function Au(t) {
	if (t = Eu(t), !ku) if (t.getExtension("EXT_color_buffer_float") && t.getExtension("OES_texture_float_linear") && t.getExtension("EXT_float_blend")) ku = t.R32F;
	else {
		if (!t.getExtension("EXT_color_buffer_half_float")) throw Error("GPU does not fully support 4-channel float32 or float16 formats");
		ku = t.R16F;
	}
	return ku;
}
function wu(t) {
	return t.j || (t.j = new pu()), t.j;
}
function bu(t) {
	var e = Eu(t);
	e.viewport(0, 0, t.width, t.height), e.activeTexture(e.TEXTURE0);
	var r = vu(t, 2);
	return r || (r = lu(wu(t), e, t.m ? e.LINEAR : e.NEAREST), t.g.push(r), t.o = !0), e.bindTexture(e.TEXTURE_2D, r), r;
}
function Tu(t) {
	t.h.bindTexture(t.h.TEXTURE_2D, null);
}
var ku;
var Su = class {
	constructor(t, e, r, n, i, s, o) {
		this.g = t, this.m = e, this.o = r, this.canvas = n, this.j = i, this.width = s, this.height = o, this.o && 0 === --Lu && console.error("You seem to be creating MPMask instances without invoking .close(). This leaks resources.");
	}
	Ua() {
		return !!vu(this, 0);
	}
	ua() {
		return !!vu(this, 1);
	}
	W() {
		return !!vu(this, 2);
	}
	ta() {
		return (e = vu(t = this, 0)) || (e = _u(t), e = new Uint8Array(e.map((t) => Math.round(255 * t))), t.g.push(e)), e;
		var t, e;
	}
	sa() {
		return _u(this);
	}
	S() {
		return yu(this);
	}
	clone() {
		var t = [];
		for (let e of this.g) {
			let r;
			if (e instanceof Uint8Array) r = new Uint8Array(e);
			else if (e instanceof Float32Array) r = new Float32Array(e);
			else {
				if (!(e instanceof WebGLTexture)) throw Error(`Type is not supported: ${e}`);
				{
					let t = Eu(this), e = wu(this);
					t.activeTexture(t.TEXTURE1), r = lu(e, t, this.m ? t.LINEAR : t.NEAREST), t.bindTexture(t.TEXTURE_2D, r);
					let n = Au(this);
					t.texImage2D(t.TEXTURE_2D, 0, n, this.width, this.height, 0, t.RED, t.FLOAT, null), t.bindTexture(t.TEXTURE_2D, null), du(e, t, r), cu(e, t, !1, () => {
						bu(this), t.clearColor(0, 0, 0, 0), t.clear(t.COLOR_BUFFER_BIT), t.drawArrays(t.TRIANGLE_FAN, 0, 4), Tu(this);
					}), fu(e), Tu(this);
				}
			}
			t.push(r);
		}
		return new Su(t, this.m, this.W(), this.canvas, this.j, this.width, this.height);
	}
	close() {
		this.o && Eu(this).deleteTexture(vu(this, 2)), Lu = -1;
	}
};
Su.prototype.close = Su.prototype.close, Su.prototype.clone = Su.prototype.clone, Su.prototype.getAsWebGLTexture = Su.prototype.S, Su.prototype.getAsFloat32Array = Su.prototype.sa, Su.prototype.getAsUint8Array = Su.prototype.ta, Su.prototype.hasWebGLTexture = Su.prototype.W, Su.prototype.hasFloat32Array = Su.prototype.ua, Su.prototype.hasUint8Array = Su.prototype.Ua;
var Lu = 250;
var xu = {
	color: "white",
	lineWidth: 4,
	radius: 6
};
function Ru(t) {
	return {
		...xu,
		fillColor: (t = t || {}).color,
		...t
	};
}
function Iu(t, e) {
	return t instanceof Function ? t(e) : t;
}
function Fu(t, e, r) {
	return Math.max(Math.min(e, r), Math.min(Math.max(e, r), t));
}
function Cu(t) {
	if (!t.j) throw Error("CPU rendering requested but CanvasRenderingContext2D not provided.");
	return t.j;
}
function Nu(t) {
	if (!t.o) throw Error("GPU rendering requested but WebGL2RenderingContext not provided.");
	return t.o;
}
function Mu(t, e, r) {
	if (e.W()) r(e.S());
	else {
		let n = e.ua() ? e.sa() : e.ta();
		t.m = t.m ?? new pu();
		let i = Nu(t);
		r((t = new Su([n], e.m, !1, i.canvas, t.m, e.width, e.height)).S()), t.close();
	}
}
function Ou(t, e, r, n) {
	var i = function(t) {
		return t.g || (t.g = new gu()), t.g;
	}(t), s = Nu(t), o = Array.isArray(r) ? new ImageData(new Uint8ClampedArray(r), 1, 1) : r;
	cu(i, s, !0, () => {
		(function(t, e, r, n) {
			var i = t.g;
			if (i.activeTexture(i.TEXTURE0), i.bindTexture(i.TEXTURE_2D, e), i.activeTexture(i.TEXTURE1), i.bindTexture(i.TEXTURE_2D, t.u), i.texImage2D(i.TEXTURE_2D, 0, i.RGBA, i.RGBA, i.UNSIGNED_BYTE, r), t.J && function(t, e) {
				if (t !== e) return !1;
				t = t.entries(), e = e.entries();
				for (let [r, n] of t) {
					t = r;
					let i = n, s = e.next();
					if (s.done) return !1;
					let [o, a] = s.value;
					if (t !== o || i[0] !== a[0] || i[1] !== a[1] || i[2] !== a[2] || i[3] !== a[3]) return !1;
				}
				return !!e.next().done;
			}(t.J, n)) i.activeTexture(i.TEXTURE2), i.bindTexture(i.TEXTURE_2D, t.o);
			else {
				t.J = n;
				let e = Array(1024).fill(0);
				n.forEach((t, r) => {
					if (4 !== t.length) throw Error(`Color at index ${r} is not a four-channel value.`);
					e[4 * r] = t[0], e[4 * r + 1] = t[1], e[4 * r + 2] = t[2], e[4 * r + 3] = t[3];
				}), i.activeTexture(i.TEXTURE2), i.bindTexture(i.TEXTURE_2D, t.o), i.texImage2D(i.TEXTURE_2D, 0, i.RGBA, 256, 1, 0, i.RGBA, i.UNSIGNED_BYTE, new Uint8Array(e));
			}
		})(i, e, o, n), s.clearColor(0, 0, 0, 0), s.clear(s.COLOR_BUFFER_BIT), s.drawArrays(s.TRIANGLE_FAN, 0, 4);
		var t = i.g;
		t.activeTexture(t.TEXTURE0), t.bindTexture(t.TEXTURE_2D, null), t.activeTexture(t.TEXTURE1), t.bindTexture(t.TEXTURE_2D, null), t.activeTexture(t.TEXTURE2), t.bindTexture(t.TEXTURE_2D, null);
	});
}
function Du(t, e, r, n) {
	var i = Nu(t), s = function(t) {
		return t.h || (t.h = new mu()), t.h;
	}(t), o = Array.isArray(r) ? new ImageData(new Uint8ClampedArray(r), 1, 1) : r, a = Array.isArray(n) ? new ImageData(new Uint8ClampedArray(n), 1, 1) : n;
	cu(s, i, !0, () => {
		var t = s.g;
		t.activeTexture(t.TEXTURE0), t.bindTexture(t.TEXTURE_2D, e), t.activeTexture(t.TEXTURE1), t.bindTexture(t.TEXTURE_2D, s.o), t.texImage2D(t.TEXTURE_2D, 0, t.RGBA, t.RGBA, t.UNSIGNED_BYTE, o), t.activeTexture(t.TEXTURE2), t.bindTexture(t.TEXTURE_2D, s.u), t.texImage2D(t.TEXTURE_2D, 0, t.RGBA, t.RGBA, t.UNSIGNED_BYTE, a), i.clearColor(0, 0, 0, 0), i.clear(i.COLOR_BUFFER_BIT), i.drawArrays(i.TRIANGLE_FAN, 0, 4), i.bindTexture(i.TEXTURE_2D, null), (t = s.g).activeTexture(t.TEXTURE0), t.bindTexture(t.TEXTURE_2D, null), t.activeTexture(t.TEXTURE1), t.bindTexture(t.TEXTURE_2D, null), t.activeTexture(t.TEXTURE2), t.bindTexture(t.TEXTURE_2D, null);
	});
}
var Pu = class {
	constructor(t, e) {
		"undefined" != typeof CanvasRenderingContext2D && t instanceof CanvasRenderingContext2D || t instanceof OffscreenCanvasRenderingContext2D ? (this.j = t, this.o = e) : this.o = t;
	}
	Ma(t, e) {
		if (t) {
			var r = Cu(this);
			e = Ru(e), r.save();
			var n = r.canvas, i = 0;
			for (let s of t) r.fillStyle = Iu(e.fillColor, {
				index: i,
				from: s
			}), r.strokeStyle = Iu(e.color, {
				index: i,
				from: s
			}), r.lineWidth = Iu(e.lineWidth, {
				index: i,
				from: s
			}), (t = new Path2D()).arc(s.x * n.width, s.y * n.height, Iu(e.radius, {
				index: i,
				from: s
			}), 0, 2 * Math.PI), r.fill(t), r.stroke(t), ++i;
			r.restore();
		}
	}
	La(t, e, r) {
		if (t && e) {
			var n = Cu(this);
			r = Ru(r), n.save();
			var i = n.canvas, s = 0;
			for (let o of e) {
				n.beginPath(), e = t[o.start];
				let a = t[o.end];
				e && a && (n.strokeStyle = Iu(r.color, {
					index: s,
					from: e,
					to: a
				}), n.lineWidth = Iu(r.lineWidth, {
					index: s,
					from: e,
					to: a
				}), n.moveTo(e.x * i.width, e.y * i.height), n.lineTo(a.x * i.width, a.y * i.height)), ++s, n.stroke();
			}
			n.restore();
		}
	}
	Ia(t, e) {
		var r = Cu(this);
		e = Ru(e), r.save(), r.beginPath(), r.lineWidth = Iu(e.lineWidth, {}), r.strokeStyle = Iu(e.color, {}), r.fillStyle = Iu(e.fillColor, {}), r.moveTo(t.originX, t.originY), r.lineTo(t.originX + t.width, t.originY), r.lineTo(t.originX + t.width, t.originY + t.height), r.lineTo(t.originX, t.originY + t.height), r.lineTo(t.originX, t.originY), r.stroke(), r.fill(), r.restore();
	}
	Ja(t, e, r = [
		0,
		0,
		0,
		255
	]) {
		this.j ? function(t, e, r, n) {
			var i = Nu(t);
			Mu(t, e, (e) => {
				Ou(t, e, r, n), (e = Cu(t)).drawImage(i.canvas, 0, 0, e.canvas.width, e.canvas.height);
			});
		}(this, t, r, e) : Ou(this, t.S(), r, e);
	}
	Ka(t, e, r) {
		this.j ? function(t, e, r, n) {
			var i = Nu(t);
			Mu(t, e, (e) => {
				Du(t, e, r, n), (e = Cu(t)).drawImage(i.canvas, 0, 0, e.canvas.width, e.canvas.height);
			});
		}(this, t, e, r) : Du(this, t.S(), e, r);
	}
	close() {
		this.g?.close(), this.g = void 0, this.h?.close(), this.h = void 0, this.m?.close(), this.m = void 0;
	}
};
function $u(t, e) {
	switch (e) {
		case 0: return t.g.find((t) => t instanceof ImageData);
		case 1: return t.g.find((t) => "undefined" != typeof ImageBitmap && t instanceof ImageBitmap);
		case 2: return t.g.find((t) => "undefined" != typeof WebGLTexture && t instanceof WebGLTexture);
		default: throw Error(`Type is not supported: ${e}`);
	}
}
function Uu(t) {
	var e = $u(t, 0);
	if (!e) {
		e = Gu(t);
		let r = ju(t), n = new Uint8Array(t.width * t.height * 4);
		du(r, e, Bu(t)), e.readPixels(0, 0, t.width, t.height, e.RGBA, e.UNSIGNED_BYTE, n), fu(r), e = new ImageData(new Uint8ClampedArray(n.buffer), t.width, t.height), t.g.push(e);
	}
	return e;
}
function Bu(t) {
	var e = $u(t, 2);
	if (!e) {
		let r = Gu(t);
		e = Vu(t);
		let n = $u(t, 1) || Uu(t);
		r.texImage2D(r.TEXTURE_2D, 0, r.RGBA, r.RGBA, r.UNSIGNED_BYTE, n), Hu(t);
	}
	return e;
}
function Gu(t) {
	if (!t.canvas) throw Error("Conversion to different image formats require that a canvas is passed when initializing the image.");
	return t.h || (t.h = su(t.canvas.getContext("webgl2"), "You cannot use a canvas that is already bound to a different type of rendering context.")), t.h;
}
function ju(t) {
	return t.j || (t.j = new pu()), t.j;
}
function Vu(t) {
	var e = Gu(t);
	e.viewport(0, 0, t.width, t.height), e.activeTexture(e.TEXTURE0);
	var r = $u(t, 2);
	return r || (r = lu(ju(t), e), t.g.push(r), t.m = !0), e.bindTexture(e.TEXTURE_2D, r), r;
}
function Hu(t) {
	t.h.bindTexture(t.h.TEXTURE_2D, null);
}
function Ku(t) {
	var e = Gu(t);
	return cu(ju(t), e, !0, () => function(t, e) {
		var r = t.canvas;
		if (r.width === t.width && r.height === t.height) return e();
		var n = r.width, i = r.height;
		return r.width = t.width, r.height = t.height, t = e(), r.width = n, r.height = i, t;
	}(t, () => {
		if (e.bindFramebuffer(e.FRAMEBUFFER, null), e.clearColor(0, 0, 0, 0), e.clear(e.COLOR_BUFFER_BIT), e.drawArrays(e.TRIANGLE_FAN, 0, 4), !(t.canvas instanceof OffscreenCanvas)) throw Error("Conversion to ImageBitmap requires that the MediaPipe Tasks is initialized with an OffscreenCanvas");
		return t.canvas.transferToImageBitmap();
	}));
}
Pu.prototype.close = Pu.prototype.close, Pu.prototype.drawConfidenceMask = Pu.prototype.Ka, Pu.prototype.drawCategoryMask = Pu.prototype.Ja, Pu.prototype.drawBoundingBox = Pu.prototype.Ia, Pu.prototype.drawConnectors = Pu.prototype.La, Pu.prototype.drawLandmarks = Pu.prototype.Ma, Pu.lerp = function(t, e, r, n, i) {
	return Fu(n * (1 - (t - e) / (r - e)) + i * (1 - (r - t) / (r - e)), n, i);
}, Pu.clamp = Fu;
var Xu = class {
	constructor(t, e, r, n, i, s, o) {
		this.g = t, this.o = e, this.m = r, this.canvas = n, this.j = i, this.width = s, this.height = o, (this.o || this.m) && 0 === --Wu && console.error("You seem to be creating MPImage instances without invoking .close(). This leaks resources.");
	}
	Ta() {
		return !!$u(this, 0);
	}
	va() {
		return !!$u(this, 1);
	}
	W() {
		return !!$u(this, 2);
	}
	Qa() {
		return Uu(this);
	}
	Pa() {
		var t = $u(this, 1);
		return t || (Bu(this), Vu(this), t = Ku(this), Hu(this), this.g.push(t), this.o = !0), t;
	}
	S() {
		return Bu(this);
	}
	clone() {
		var t = [];
		for (let e of this.g) {
			let r;
			if (e instanceof ImageData) r = new ImageData(e.data, this.width, this.height);
			else if (e instanceof WebGLTexture) {
				let t = Gu(this), e = ju(this);
				t.activeTexture(t.TEXTURE1), r = lu(e, t), t.bindTexture(t.TEXTURE_2D, r), t.texImage2D(t.TEXTURE_2D, 0, t.RGBA, this.width, this.height, 0, t.RGBA, t.UNSIGNED_BYTE, null), t.bindTexture(t.TEXTURE_2D, null), du(e, t, r), cu(e, t, !1, () => {
					Vu(this), t.clearColor(0, 0, 0, 0), t.clear(t.COLOR_BUFFER_BIT), t.drawArrays(t.TRIANGLE_FAN, 0, 4), Hu(this);
				}), fu(e), Hu(this);
			} else {
				if (!(e instanceof ImageBitmap)) throw Error(`Type is not supported: ${e}`);
				Bu(this), Vu(this), r = Ku(this), Hu(this);
			}
			t.push(r);
		}
		return new Xu(t, this.va(), this.W(), this.canvas, this.j, this.width, this.height);
	}
	close() {
		this.o && $u(this, 1).close(), this.m && Gu(this).deleteTexture($u(this, 2)), Wu = -1;
	}
};
Xu.prototype.close = Xu.prototype.close, Xu.prototype.clone = Xu.prototype.clone, Xu.prototype.getAsWebGLTexture = Xu.prototype.S, Xu.prototype.getAsImageBitmap = Xu.prototype.Pa, Xu.prototype.getAsImageData = Xu.prototype.Qa, Xu.prototype.hasWebGLTexture = Xu.prototype.W, Xu.prototype.hasImageBitmap = Xu.prototype.va, Xu.prototype.hasImageData = Xu.prototype.Ta;
var Wu = 250;
function zu(...t) {
	return t.map(([t, e]) => ({
		start: t,
		end: e
	}));
}
var Yu;
var qu = Wh((Yu = Xh(Kh), class extends Yu {
	get oa() {
		return this.i;
	}
	Da(t, e, r) {
		Bh(this, e, (e) => {
			var [n, i] = Gh(this, t, e);
			this.oa._addBoundTextureAsImageToStream(e, n, i, r);
		});
	}
	ga(t, e) {
		Vh(this, t, e), Bh(this, t, (t) => {
			this.oa._attachImageListener(t);
		});
	}
	ha(t, e) {
		Hh(this, t, e), Bh(this, t, (t) => {
			this.oa._attachImageVectorListener(t);
		});
	}
}));
var Ju = class extends qu {};
async function Zu(t, e, r) {
	return Jh(t, r.canvas ?? (Ph() ? void 0 : document.createElement("canvas")), e, r);
}
function Qu(t, e, r, n) {
	if (t.m && void 0 !== n) if (Sr(t.baseOptions, Ko, 3)?.g()) {
		var i = t.m;
		++i.g.T, i.h.set(n, performance.now());
	} else ++(i = t.m).g.P, i.h.set(n, performance.now());
	if (t.qa) {
		if (i = new No(), r?.regionOfInterest) {
			if (!t.Ca) throw Error("This task doesn't support region-of-interest.");
			var s = r.regionOfInterest;
			if (s.left >= s.right || s.top >= s.bottom) throw Error("Expected RectF with left < right and top < bottom.");
			if (s.left < 0 || s.top < 0 || s.right > 1 || s.bottom > 1) throw Error("Expected RectF values to be in [0,1].");
			jr(i, 1, (s.left + s.right) / 2), jr(i, 2, (s.top + s.bottom) / 2), jr(i, 4, s.right - s.left), jr(i, 3, s.bottom - s.top);
		} else jr(i, 1, .5), jr(i, 2, .5), jr(i, 4, 1), jr(i, 3, 1);
		if (r?.rotationDegrees) {
			if (r?.rotationDegrees % 90 != 0) throw Error("Expected rotation to be a multiple of 90°.");
			if (jr(i, 5, -Math.PI * r.rotationDegrees / 180), r?.rotationDegrees % 180 != 0) {
				let [t, n] = Uh(e);
				r = Dr(i, 3) * n / t, s = Dr(i, 4) * t / n, jr(i, 4, r), jr(i, 3, s);
			}
		}
		t.g.addProtoToStream(i.g(), "mediapipe.NormalizedRect", t.qa, n);
	}
	t.g.Da(e, t.Ba, n ?? performance.now()), t.finishProcessing(n);
}
function tc(t, e, r) {
	if (t.J) throw Error("Task is not initialized with image mode. 'runningMode' must be set to 'IMAGE'.");
	Qu(t, e, r, t.I + 1);
}
function ec(t, e, r, n) {
	if (!t.J) throw Error("Task is not initialized with video mode. 'runningMode' must be set to 'VIDEO'.");
	Qu(t, e, r, n);
}
function rc(t, e, r, n) {
	var i = e.data, s = e.width, o = s * (e = e.height);
	if ((i instanceof Uint8Array || i instanceof Float32Array) && i.length !== o) throw Error("Unsupported channel count: " + i.length / o);
	return t = new Su([i], r, !1, t.g.i.canvas, t.da, s, e), n ? t.clone() : t;
}
var nc = class extends iu {
	constructor(t, e, r, n) {
		super(t), this.g = t, this.Ba = e, this.qa = r, this.Ca = n, this.da = new pu(), this.J = !1;
	}
	j(t, e = !0) {
		if ("runningMode" in t) {
			var r = this.J = !!t.runningMode && "IMAGE" !== t.runningMode;
			ar(this.baseOptions, 2, null == r ? r : Zt(r));
		}
		if (void 0 !== t.canvas && this.g.i.canvas !== t.canvas) throw Error("You must create a new task to reset the canvas.");
		return super.j(t, e);
	}
	close() {
		this.da.close(), super.close();
	}
};
nc.prototype.close = nc.prototype.close;
var ic = class extends nc {
	constructor(t, e) {
		super(new Ju(t, e), "image_in", "norm_rect_in", !1), this.l = { detections: [] }, Ir(t = this.h = new Zo(), 0, 1, e = new zo()), jr(this.h, 2, .5), jr(this.h, 3, .3);
	}
	C() {
		return "FaceDetector";
	}
	get baseOptions() {
		return Sr(this.h, zo, 1);
	}
	set baseOptions(t) {
		Ir(this.h, 0, 1, t);
	}
	v(t) {
		return "minDetectionConfidence" in t && jr(this.h, 2, t.minDetectionConfidence ?? .5), "minSuppressionThreshold" in t && jr(this.h, 3, t.minSuppressionThreshold ?? .3), this.j(t);
	}
	G(t, e) {
		return this.l = { detections: [] }, tc(this, t, e), this.l;
	}
	H(t, e, r) {
		return this.l = { detections: [] }, ec(this, t, r, e), this.l;
	}
	o() {
		var t = new mo();
		po(t, "image_in"), po(t, "norm_rect_in"), go(t, "detections");
		var e = new no();
		li(e, ta, this.h);
		var r = new ho();
		Hr(r, 2, "mediapipe.tasks.vision.face_detector.FaceDetectorGraph"), oo(r, "IMAGE:image_in"), oo(r, "NORM_RECT:norm_rect_in"), ao(r, "DETECTIONS:detections"), r.v(e), fo(t, r), this.g.attachProtoVectorListener("detections", (t, e) => {
			for (let e of t) t = So(e), this.l.detections.push(Za(t));
			tu(this, e);
		}), this.g.attachEmptyPacketListener("detections", (t) => {
			tu(this, t);
		}), t = t.g(), this.setGraph(new Uint8Array(t), !0);
	}
};
ic.prototype.detectForVideo = ic.prototype.H, ic.prototype.detect = ic.prototype.G, ic.prototype.setOptions = ic.prototype.v, ic.createFromModelPath = async function(t, e) {
	return Zu(ic, t, { baseOptions: { modelAssetPath: e } });
}, ic.createFromModelBuffer = function(t, e) {
	return Zu(ic, t, { baseOptions: { modelAssetBuffer: e } });
}, ic.createFromOptions = function(t, e) {
	return Zu(ic, t, e);
};
var sc = zu([61, 146], [146, 91], [91, 181], [181, 84], [84, 17], [17, 314], [314, 405], [405, 321], [321, 375], [375, 291], [61, 185], [185, 40], [40, 39], [39, 37], [37, 0], [0, 267], [267, 269], [269, 270], [270, 409], [409, 291], [78, 95], [95, 88], [88, 178], [178, 87], [87, 14], [14, 317], [317, 402], [402, 318], [318, 324], [324, 308], [78, 191], [191, 80], [80, 81], [81, 82], [82, 13], [13, 312], [312, 311], [311, 310], [310, 415], [415, 308]);
var oc = zu([263, 249], [249, 390], [390, 373], [373, 374], [374, 380], [380, 381], [381, 382], [382, 362], [263, 466], [466, 388], [388, 387], [387, 386], [386, 385], [385, 384], [384, 398], [398, 362]);
var ac = zu([276, 283], [283, 282], [282, 295], [295, 285], [300, 293], [293, 334], [334, 296], [296, 336]);
var hc = zu([474, 475], [475, 476], [476, 477], [477, 474]);
var uc = zu([33, 7], [7, 163], [163, 144], [144, 145], [145, 153], [153, 154], [154, 155], [155, 133], [33, 246], [246, 161], [161, 160], [160, 159], [159, 158], [158, 157], [157, 173], [173, 133]);
var cc = zu([46, 53], [53, 52], [52, 65], [65, 55], [70, 63], [63, 105], [105, 66], [66, 107]);
var lc = zu([469, 470], [470, 471], [471, 472], [472, 469]);
var dc = zu([10, 338], [338, 297], [297, 332], [332, 284], [284, 251], [251, 389], [389, 356], [356, 454], [454, 323], [323, 361], [361, 288], [288, 397], [397, 365], [365, 379], [379, 378], [378, 400], [400, 377], [377, 152], [152, 148], [148, 176], [176, 149], [149, 150], [150, 136], [136, 172], [172, 58], [58, 132], [132, 93], [93, 234], [234, 127], [127, 162], [162, 21], [21, 54], [54, 103], [103, 67], [67, 109], [109, 10]);
var fc = [
	...sc,
	...oc,
	...ac,
	...uc,
	...cc,
	...dc
];
var pc = zu([127, 34], [34, 139], [139, 127], [11, 0], [0, 37], [37, 11], [232, 231], [231, 120], [120, 232], [72, 37], [37, 39], [39, 72], [128, 121], [121, 47], [47, 128], [232, 121], [121, 128], [128, 232], [104, 69], [69, 67], [67, 104], [175, 171], [171, 148], [148, 175], [118, 50], [50, 101], [101, 118], [73, 39], [39, 40], [40, 73], [9, 151], [151, 108], [108, 9], [48, 115], [115, 131], [131, 48], [194, 204], [204, 211], [211, 194], [74, 40], [40, 185], [185, 74], [80, 42], [42, 183], [183, 80], [40, 92], [92, 186], [186, 40], [230, 229], [229, 118], [118, 230], [202, 212], [212, 214], [214, 202], [83, 18], [18, 17], [17, 83], [76, 61], [61, 146], [146, 76], [160, 29], [29, 30], [30, 160], [56, 157], [157, 173], [173, 56], [106, 204], [204, 194], [194, 106], [135, 214], [214, 192], [192, 135], [203, 165], [165, 98], [98, 203], [21, 71], [71, 68], [68, 21], [51, 45], [45, 4], [4, 51], [144, 24], [24, 23], [23, 144], [77, 146], [146, 91], [91, 77], [205, 50], [50, 187], [187, 205], [201, 200], [200, 18], [18, 201], [91, 106], [106, 182], [182, 91], [90, 91], [91, 181], [181, 90], [85, 84], [84, 17], [17, 85], [206, 203], [203, 36], [36, 206], [148, 171], [171, 140], [140, 148], [92, 40], [40, 39], [39, 92], [193, 189], [189, 244], [244, 193], [159, 158], [158, 28], [28, 159], [247, 246], [246, 161], [161, 247], [236, 3], [3, 196], [196, 236], [54, 68], [68, 104], [104, 54], [193, 168], [168, 8], [8, 193], [117, 228], [228, 31], [31, 117], [189, 193], [193, 55], [55, 189], [98, 97], [97, 99], [99, 98], [126, 47], [47, 100], [100, 126], [166, 79], [79, 218], [218, 166], [155, 154], [154, 26], [26, 155], [209, 49], [49, 131], [131, 209], [135, 136], [136, 150], [150, 135], [47, 126], [126, 217], [217, 47], [223, 52], [52, 53], [53, 223], [45, 51], [51, 134], [134, 45], [211, 170], [170, 140], [140, 211], [67, 69], [69, 108], [108, 67], [43, 106], [106, 91], [91, 43], [230, 119], [119, 120], [120, 230], [226, 130], [130, 247], [247, 226], [63, 53], [53, 52], [52, 63], [238, 20], [20, 242], [242, 238], [46, 70], [70, 156], [156, 46], [78, 62], [62, 96], [96, 78], [46, 53], [53, 63], [63, 46], [143, 34], [34, 227], [227, 143], [123, 117], [117, 111], [111, 123], [44, 125], [125, 19], [19, 44], [236, 134], [134, 51], [51, 236], [216, 206], [206, 205], [205, 216], [154, 153], [153, 22], [22, 154], [39, 37], [37, 167], [167, 39], [200, 201], [201, 208], [208, 200], [36, 142], [142, 100], [100, 36], [57, 212], [212, 202], [202, 57], [20, 60], [60, 99], [99, 20], [28, 158], [158, 157], [157, 28], [35, 226], [226, 113], [113, 35], [160, 159], [159, 27], [27, 160], [204, 202], [202, 210], [210, 204], [113, 225], [225, 46], [46, 113], [43, 202], [202, 204], [204, 43], [62, 76], [76, 77], [77, 62], [137, 123], [123, 116], [116, 137], [41, 38], [38, 72], [72, 41], [203, 129], [129, 142], [142, 203], [64, 98], [98, 240], [240, 64], [49, 102], [102, 64], [64, 49], [41, 73], [73, 74], [74, 41], [212, 216], [216, 207], [207, 212], [42, 74], [74, 184], [184, 42], [169, 170], [170, 211], [211, 169], [170, 149], [149, 176], [176, 170], [105, 66], [66, 69], [69, 105], [122, 6], [6, 168], [168, 122], [123, 147], [147, 187], [187, 123], [96, 77], [77, 90], [90, 96], [65, 55], [55, 107], [107, 65], [89, 90], [90, 180], [180, 89], [101, 100], [100, 120], [120, 101], [63, 105], [105, 104], [104, 63], [93, 137], [137, 227], [227, 93], [15, 86], [86, 85], [85, 15], [129, 102], [102, 49], [49, 129], [14, 87], [87, 86], [86, 14], [55, 8], [8, 9], [9, 55], [100, 47], [47, 121], [121, 100], [145, 23], [23, 22], [22, 145], [88, 89], [89, 179], [179, 88], [6, 122], [122, 196], [196, 6], [88, 95], [95, 96], [96, 88], [138, 172], [172, 136], [136, 138], [215, 58], [58, 172], [172, 215], [115, 48], [48, 219], [219, 115], [42, 80], [80, 81], [81, 42], [195, 3], [3, 51], [51, 195], [43, 146], [146, 61], [61, 43], [171, 175], [175, 199], [199, 171], [81, 82], [82, 38], [38, 81], [53, 46], [46, 225], [225, 53], [144, 163], [163, 110], [110, 144], [52, 65], [65, 66], [66, 52], [229, 228], [228, 117], [117, 229], [34, 127], [127, 234], [234, 34], [107, 108], [108, 69], [69, 107], [109, 108], [108, 151], [151, 109], [48, 64], [64, 235], [235, 48], [62, 78], [78, 191], [191, 62], [129, 209], [209, 126], [126, 129], [111, 35], [35, 143], [143, 111], [117, 123], [123, 50], [50, 117], [222, 65], [65, 52], [52, 222], [19, 125], [125, 141], [141, 19], [221, 55], [55, 65], [65, 221], [3, 195], [195, 197], [197, 3], [25, 7], [7, 33], [33, 25], [220, 237], [237, 44], [44, 220], [70, 71], [71, 139], [139, 70], [122, 193], [193, 245], [245, 122], [247, 130], [130, 33], [33, 247], [71, 21], [21, 162], [162, 71], [170, 169], [169, 150], [150, 170], [188, 174], [174, 196], [196, 188], [216, 186], [186, 92], [92, 216], [2, 97], [97, 167], [167, 2], [141, 125], [125, 241], [241, 141], [164, 167], [167, 37], [37, 164], [72, 38], [38, 12], [12, 72], [38, 82], [82, 13], [13, 38], [63, 68], [68, 71], [71, 63], [226, 35], [35, 111], [111, 226], [101, 50], [50, 205], [205, 101], [206, 92], [92, 165], [165, 206], [209, 198], [198, 217], [217, 209], [165, 167], [167, 97], [97, 165], [220, 115], [115, 218], [218, 220], [133, 112], [112, 243], [243, 133], [239, 238], [238, 241], [241, 239], [214, 135], [135, 169], [169, 214], [190, 173], [173, 133], [133, 190], [171, 208], [208, 32], [32, 171], [125, 44], [44, 237], [237, 125], [86, 87], [87, 178], [178, 86], [85, 86], [86, 179], [179, 85], [84, 85], [85, 180], [180, 84], [83, 84], [84, 181], [181, 83], [201, 83], [83, 182], [182, 201], [137, 93], [93, 132], [132, 137], [76, 62], [62, 183], [183, 76], [61, 76], [76, 184], [184, 61], [57, 61], [61, 185], [185, 57], [212, 57], [57, 186], [186, 212], [214, 207], [207, 187], [187, 214], [34, 143], [143, 156], [156, 34], [79, 239], [239, 237], [237, 79], [123, 137], [137, 177], [177, 123], [44, 1], [1, 4], [4, 44], [201, 194], [194, 32], [32, 201], [64, 102], [102, 129], [129, 64], [213, 215], [215, 138], [138, 213], [59, 166], [166, 219], [219, 59], [242, 99], [99, 97], [97, 242], [2, 94], [94, 141], [141, 2], [75, 59], [59, 235], [235, 75], [24, 110], [110, 228], [228, 24], [25, 130], [130, 226], [226, 25], [23, 24], [24, 229], [229, 23], [22, 23], [23, 230], [230, 22], [26, 22], [22, 231], [231, 26], [112, 26], [26, 232], [232, 112], [189, 190], [190, 243], [243, 189], [221, 56], [56, 190], [190, 221], [28, 56], [56, 221], [221, 28], [27, 28], [28, 222], [222, 27], [29, 27], [27, 223], [223, 29], [30, 29], [29, 224], [224, 30], [247, 30], [30, 225], [225, 247], [238, 79], [79, 20], [20, 238], [166, 59], [59, 75], [75, 166], [60, 75], [75, 240], [240, 60], [147, 177], [177, 215], [215, 147], [20, 79], [79, 166], [166, 20], [187, 147], [147, 213], [213, 187], [112, 233], [233, 244], [244, 112], [233, 128], [128, 245], [245, 233], [128, 114], [114, 188], [188, 128], [114, 217], [217, 174], [174, 114], [131, 115], [115, 220], [220, 131], [217, 198], [198, 236], [236, 217], [198, 131], [131, 134], [134, 198], [177, 132], [132, 58], [58, 177], [143, 35], [35, 124], [124, 143], [110, 163], [163, 7], [7, 110], [228, 110], [110, 25], [25, 228], [356, 389], [389, 368], [368, 356], [11, 302], [302, 267], [267, 11], [452, 350], [350, 349], [349, 452], [302, 303], [303, 269], [269, 302], [357, 343], [343, 277], [277, 357], [452, 453], [453, 357], [357, 452], [333, 332], [332, 297], [297, 333], [175, 152], [152, 377], [377, 175], [347, 348], [348, 330], [330, 347], [303, 304], [304, 270], [270, 303], [9, 336], [336, 337], [337, 9], [278, 279], [279, 360], [360, 278], [418, 262], [262, 431], [431, 418], [304, 408], [408, 409], [409, 304], [310, 415], [415, 407], [407, 310], [270, 409], [409, 410], [410, 270], [450, 348], [348, 347], [347, 450], [422, 430], [430, 434], [434, 422], [313, 314], [314, 17], [17, 313], [306, 307], [307, 375], [375, 306], [387, 388], [388, 260], [260, 387], [286, 414], [414, 398], [398, 286], [335, 406], [406, 418], [418, 335], [364, 367], [367, 416], [416, 364], [423, 358], [358, 327], [327, 423], [251, 284], [284, 298], [298, 251], [281, 5], [5, 4], [4, 281], [373, 374], [374, 253], [253, 373], [307, 320], [320, 321], [321, 307], [425, 427], [427, 411], [411, 425], [421, 313], [313, 18], [18, 421], [321, 405], [405, 406], [406, 321], [320, 404], [404, 405], [405, 320], [315, 16], [16, 17], [17, 315], [426, 425], [425, 266], [266, 426], [377, 400], [400, 369], [369, 377], [322, 391], [391, 269], [269, 322], [417, 465], [465, 464], [464, 417], [386, 257], [257, 258], [258, 386], [466, 260], [260, 388], [388, 466], [456, 399], [399, 419], [419, 456], [284, 332], [332, 333], [333, 284], [417, 285], [285, 8], [8, 417], [346, 340], [340, 261], [261, 346], [413, 441], [441, 285], [285, 413], [327, 460], [460, 328], [328, 327], [355, 371], [371, 329], [329, 355], [392, 439], [439, 438], [438, 392], [382, 341], [341, 256], [256, 382], [429, 420], [420, 360], [360, 429], [364, 394], [394, 379], [379, 364], [277, 343], [343, 437], [437, 277], [443, 444], [444, 283], [283, 443], [275, 440], [440, 363], [363, 275], [431, 262], [262, 369], [369, 431], [297, 338], [338, 337], [337, 297], [273, 375], [375, 321], [321, 273], [450, 451], [451, 349], [349, 450], [446, 342], [342, 467], [467, 446], [293, 334], [334, 282], [282, 293], [458, 461], [461, 462], [462, 458], [276, 353], [353, 383], [383, 276], [308, 324], [324, 325], [325, 308], [276, 300], [300, 293], [293, 276], [372, 345], [345, 447], [447, 372], [352, 345], [345, 340], [340, 352], [274, 1], [1, 19], [19, 274], [456, 248], [248, 281], [281, 456], [436, 427], [427, 425], [425, 436], [381, 256], [256, 252], [252, 381], [269, 391], [391, 393], [393, 269], [200, 199], [199, 428], [428, 200], [266, 330], [330, 329], [329, 266], [287, 273], [273, 422], [422, 287], [250, 462], [462, 328], [328, 250], [258, 286], [286, 384], [384, 258], [265, 353], [353, 342], [342, 265], [387, 259], [259, 257], [257, 387], [424, 431], [431, 430], [430, 424], [342, 353], [353, 276], [276, 342], [273, 335], [335, 424], [424, 273], [292, 325], [325, 307], [307, 292], [366, 447], [447, 345], [345, 366], [271, 303], [303, 302], [302, 271], [423, 266], [266, 371], [371, 423], [294, 455], [455, 460], [460, 294], [279, 278], [278, 294], [294, 279], [271, 272], [272, 304], [304, 271], [432, 434], [434, 427], [427, 432], [272, 407], [407, 408], [408, 272], [394, 430], [430, 431], [431, 394], [395, 369], [369, 400], [400, 395], [334, 333], [333, 299], [299, 334], [351, 417], [417, 168], [168, 351], [352, 280], [280, 411], [411, 352], [325, 319], [319, 320], [320, 325], [295, 296], [296, 336], [336, 295], [319, 403], [403, 404], [404, 319], [330, 348], [348, 349], [349, 330], [293, 298], [298, 333], [333, 293], [323, 454], [454, 447], [447, 323], [15, 16], [16, 315], [315, 15], [358, 429], [429, 279], [279, 358], [14, 15], [15, 316], [316, 14], [285, 336], [336, 9], [9, 285], [329, 349], [349, 350], [350, 329], [374, 380], [380, 252], [252, 374], [318, 402], [402, 403], [403, 318], [6, 197], [197, 419], [419, 6], [318, 319], [319, 325], [325, 318], [367, 364], [364, 365], [365, 367], [435, 367], [367, 397], [397, 435], [344, 438], [438, 439], [439, 344], [272, 271], [271, 311], [311, 272], [195, 5], [5, 281], [281, 195], [273, 287], [287, 291], [291, 273], [396, 428], [428, 199], [199, 396], [311, 271], [271, 268], [268, 311], [283, 444], [444, 445], [445, 283], [373, 254], [254, 339], [339, 373], [282, 334], [334, 296], [296, 282], [449, 347], [347, 346], [346, 449], [264, 447], [447, 454], [454, 264], [336, 296], [296, 299], [299, 336], [338, 10], [10, 151], [151, 338], [278, 439], [439, 455], [455, 278], [292, 407], [407, 415], [415, 292], [358, 371], [371, 355], [355, 358], [340, 345], [345, 372], [372, 340], [346, 347], [347, 280], [280, 346], [442, 443], [443, 282], [282, 442], [19, 94], [94, 370], [370, 19], [441, 442], [442, 295], [295, 441], [248, 419], [419, 197], [197, 248], [263, 255], [255, 359], [359, 263], [440, 275], [275, 274], [274, 440], [300, 383], [383, 368], [368, 300], [351, 412], [412, 465], [465, 351], [263, 467], [467, 466], [466, 263], [301, 368], [368, 389], [389, 301], [395, 378], [378, 379], [379, 395], [412, 351], [351, 419], [419, 412], [436, 426], [426, 322], [322, 436], [2, 164], [164, 393], [393, 2], [370, 462], [462, 461], [461, 370], [164, 0], [0, 267], [267, 164], [302, 11], [11, 12], [12, 302], [268, 12], [12, 13], [13, 268], [293, 300], [300, 301], [301, 293], [446, 261], [261, 340], [340, 446], [330, 266], [266, 425], [425, 330], [426, 423], [423, 391], [391, 426], [429, 355], [355, 437], [437, 429], [391, 327], [327, 326], [326, 391], [440, 457], [457, 438], [438, 440], [341, 382], [382, 362], [362, 341], [459, 457], [457, 461], [461, 459], [434, 430], [430, 394], [394, 434], [414, 463], [463, 362], [362, 414], [396, 369], [369, 262], [262, 396], [354, 461], [461, 457], [457, 354], [316, 403], [403, 402], [402, 316], [315, 404], [404, 403], [403, 315], [314, 405], [405, 404], [404, 314], [313, 406], [406, 405], [405, 313], [421, 418], [418, 406], [406, 421], [366, 401], [401, 361], [361, 366], [306, 408], [408, 407], [407, 306], [291, 409], [409, 408], [408, 291], [287, 410], [410, 409], [409, 287], [432, 436], [436, 410], [410, 432], [434, 416], [416, 411], [411, 434], [264, 368], [368, 383], [383, 264], [309, 438], [438, 457], [457, 309], [352, 376], [376, 401], [401, 352], [274, 275], [275, 4], [4, 274], [421, 428], [428, 262], [262, 421], [294, 327], [327, 358], [358, 294], [433, 416], [416, 367], [367, 433], [289, 455], [455, 439], [439, 289], [462, 370], [370, 326], [326, 462], [2, 326], [326, 370], [370, 2], [305, 460], [460, 455], [455, 305], [254, 449], [449, 448], [448, 254], [255, 261], [261, 446], [446, 255], [253, 450], [450, 449], [449, 253], [252, 451], [451, 450], [450, 252], [256, 452], [452, 451], [451, 256], [341, 453], [453, 452], [452, 341], [413, 464], [464, 463], [463, 413], [441, 413], [413, 414], [414, 441], [258, 442], [442, 441], [441, 258], [257, 443], [443, 442], [442, 257], [259, 444], [444, 443], [443, 259], [260, 445], [445, 444], [444, 260], [467, 342], [342, 445], [445, 467], [459, 458], [458, 250], [250, 459], [289, 392], [392, 290], [290, 289], [290, 328], [328, 460], [460, 290], [376, 433], [433, 435], [435, 376], [250, 290], [290, 392], [392, 250], [411, 416], [416, 433], [433, 411], [341, 463], [463, 464], [464, 341], [453, 464], [464, 465], [465, 453], [357, 465], [465, 412], [412, 357], [343, 412], [412, 399], [399, 343], [360, 363], [363, 440], [440, 360], [437, 399], [399, 456], [456, 437], [420, 456], [456, 363], [363, 420], [401, 435], [435, 288], [288, 401], [372, 383], [383, 353], [353, 372], [339, 255], [255, 249], [249, 339], [448, 261], [261, 255], [255, 448], [133, 243], [243, 190], [190, 133], [133, 155], [155, 112], [112, 133], [33, 246], [246, 247], [247, 33], [33, 130], [130, 25], [25, 33], [398, 384], [384, 286], [286, 398], [362, 398], [398, 414], [414, 362], [362, 463], [463, 341], [341, 362], [263, 359], [359, 467], [467, 263], [263, 249], [249, 255], [255, 263], [466, 467], [467, 260], [260, 466], [75, 60], [60, 166], [166, 75], [238, 239], [239, 79], [79, 238], [162, 127], [127, 139], [139, 162], [72, 11], [11, 37], [37, 72], [121, 232], [232, 120], [120, 121], [73, 72], [72, 39], [39, 73], [114, 128], [128, 47], [47, 114], [233, 232], [232, 128], [128, 233], [103, 104], [104, 67], [67, 103], [152, 175], [175, 148], [148, 152], [119, 118], [118, 101], [101, 119], [74, 73], [73, 40], [40, 74], [107, 9], [9, 108], [108, 107], [49, 48], [48, 131], [131, 49], [32, 194], [194, 211], [211, 32], [184, 74], [74, 185], [185, 184], [191, 80], [80, 183], [183, 191], [185, 40], [40, 186], [186, 185], [119, 230], [230, 118], [118, 119], [210, 202], [202, 214], [214, 210], [84, 83], [83, 17], [17, 84], [77, 76], [76, 146], [146, 77], [161, 160], [160, 30], [30, 161], [190, 56], [56, 173], [173, 190], [182, 106], [106, 194], [194, 182], [138, 135], [135, 192], [192, 138], [129, 203], [203, 98], [98, 129], [54, 21], [21, 68], [68, 54], [5, 51], [51, 4], [4, 5], [145, 144], [144, 23], [23, 145], [90, 77], [77, 91], [91, 90], [207, 205], [205, 187], [187, 207], [83, 201], [201, 18], [18, 83], [181, 91], [91, 182], [182, 181], [180, 90], [90, 181], [181, 180], [16, 85], [85, 17], [17, 16], [205, 206], [206, 36], [36, 205], [176, 148], [148, 140], [140, 176], [165, 92], [92, 39], [39, 165], [245, 193], [193, 244], [244, 245], [27, 159], [159, 28], [28, 27], [30, 247], [247, 161], [161, 30], [174, 236], [236, 196], [196, 174], [103, 54], [54, 104], [104, 103], [55, 193], [193, 8], [8, 55], [111, 117], [117, 31], [31, 111], [221, 189], [189, 55], [55, 221], [240, 98], [98, 99], [99, 240], [142, 126], [126, 100], [100, 142], [219, 166], [166, 218], [218, 219], [112, 155], [155, 26], [26, 112], [198, 209], [209, 131], [131, 198], [169, 135], [135, 150], [150, 169], [114, 47], [47, 217], [217, 114], [224, 223], [223, 53], [53, 224], [220, 45], [45, 134], [134, 220], [32, 211], [211, 140], [140, 32], [109, 67], [67, 108], [108, 109], [146, 43], [43, 91], [91, 146], [231, 230], [230, 120], [120, 231], [113, 226], [226, 247], [247, 113], [105, 63], [63, 52], [52, 105], [241, 238], [238, 242], [242, 241], [124, 46], [46, 156], [156, 124], [95, 78], [78, 96], [96, 95], [70, 46], [46, 63], [63, 70], [116, 143], [143, 227], [227, 116], [116, 123], [123, 111], [111, 116], [1, 44], [44, 19], [19, 1], [3, 236], [236, 51], [51, 3], [207, 216], [216, 205], [205, 207], [26, 154], [154, 22], [22, 26], [165, 39], [39, 167], [167, 165], [199, 200], [200, 208], [208, 199], [101, 36], [36, 100], [100, 101], [43, 57], [57, 202], [202, 43], [242, 20], [20, 99], [99, 242], [56, 28], [28, 157], [157, 56], [124, 35], [35, 113], [113, 124], [29, 160], [160, 27], [27, 29], [211, 204], [204, 210], [210, 211], [124, 113], [113, 46], [46, 124], [106, 43], [43, 204], [204, 106], [96, 62], [62, 77], [77, 96], [227, 137], [137, 116], [116, 227], [73, 41], [41, 72], [72, 73], [36, 203], [203, 142], [142, 36], [235, 64], [64, 240], [240, 235], [48, 49], [49, 64], [64, 48], [42, 41], [41, 74], [74, 42], [214, 212], [212, 207], [207, 214], [183, 42], [42, 184], [184, 183], [210, 169], [169, 211], [211, 210], [140, 170], [170, 176], [176, 140], [104, 105], [105, 69], [69, 104], [193, 122], [122, 168], [168, 193], [50, 123], [123, 187], [187, 50], [89, 96], [96, 90], [90, 89], [66, 65], [65, 107], [107, 66], [179, 89], [89, 180], [180, 179], [119, 101], [101, 120], [120, 119], [68, 63], [63, 104], [104, 68], [234, 93], [93, 227], [227, 234], [16, 15], [15, 85], [85, 16], [209, 129], [129, 49], [49, 209], [15, 14], [14, 86], [86, 15], [107, 55], [55, 9], [9, 107], [120, 100], [100, 121], [121, 120], [153, 145], [145, 22], [22, 153], [178, 88], [88, 179], [179, 178], [197, 6], [6, 196], [196, 197], [89, 88], [88, 96], [96, 89], [135, 138], [138, 136], [136, 135], [138, 215], [215, 172], [172, 138], [218, 115], [115, 219], [219, 218], [41, 42], [42, 81], [81, 41], [5, 195], [195, 51], [51, 5], [57, 43], [43, 61], [61, 57], [208, 171], [171, 199], [199, 208], [41, 81], [81, 38], [38, 41], [224, 53], [53, 225], [225, 224], [24, 144], [144, 110], [110, 24], [105, 52], [52, 66], [66, 105], [118, 229], [229, 117], [117, 118], [227, 34], [34, 234], [234, 227], [66, 107], [107, 69], [69, 66], [10, 109], [109, 151], [151, 10], [219, 48], [48, 235], [235, 219], [183, 62], [62, 191], [191, 183], [142, 129], [129, 126], [126, 142], [116, 111], [111, 143], [143, 116], [118, 117], [117, 50], [50, 118], [223, 222], [222, 52], [52, 223], [94, 19], [19, 141], [141, 94], [222, 221], [221, 65], [65, 222], [196, 3], [3, 197], [197, 196], [45, 220], [220, 44], [44, 45], [156, 70], [70, 139], [139, 156], [188, 122], [122, 245], [245, 188], [139, 71], [71, 162], [162, 139], [149, 170], [170, 150], [150, 149], [122, 188], [188, 196], [196, 122], [206, 216], [216, 92], [92, 206], [164, 2], [2, 167], [167, 164], [242, 141], [141, 241], [241, 242], [0, 164], [164, 37], [37, 0], [11, 72], [72, 12], [12, 11], [12, 38], [38, 13], [13, 12], [70, 63], [63, 71], [71, 70], [31, 226], [226, 111], [111, 31], [36, 101], [101, 205], [205, 36], [203, 206], [206, 165], [165, 203], [126, 209], [209, 217], [217, 126], [98, 165], [165, 97], [97, 98], [237, 220], [220, 218], [218, 237], [237, 239], [239, 241], [241, 237], [210, 214], [214, 169], [169, 210], [140, 171], [171, 32], [32, 140], [241, 125], [125, 237], [237, 241], [179, 86], [86, 178], [178, 179], [180, 85], [85, 179], [179, 180], [181, 84], [84, 180], [180, 181], [182, 83], [83, 181], [181, 182], [194, 201], [201, 182], [182, 194], [177, 137], [137, 132], [132, 177], [184, 76], [76, 183], [183, 184], [185, 61], [61, 184], [184, 185], [186, 57], [57, 185], [185, 186], [216, 212], [212, 186], [186, 216], [192, 214], [214, 187], [187, 192], [139, 34], [34, 156], [156, 139], [218, 79], [79, 237], [237, 218], [147, 123], [123, 177], [177, 147], [45, 44], [44, 4], [4, 45], [208, 201], [201, 32], [32, 208], [98, 64], [64, 129], [129, 98], [192, 213], [213, 138], [138, 192], [235, 59], [59, 219], [219, 235], [141, 242], [242, 97], [97, 141], [97, 2], [2, 141], [141, 97], [240, 75], [75, 235], [235, 240], [229, 24], [24, 228], [228, 229], [31, 25], [25, 226], [226, 31], [230, 23], [23, 229], [229, 230], [231, 22], [22, 230], [230, 231], [232, 26], [26, 231], [231, 232], [233, 112], [112, 232], [232, 233], [244, 189], [189, 243], [243, 244], [189, 221], [221, 190], [190, 189], [222, 28], [28, 221], [221, 222], [223, 27], [27, 222], [222, 223], [224, 29], [29, 223], [223, 224], [225, 30], [30, 224], [224, 225], [113, 247], [247, 225], [225, 113], [99, 60], [60, 240], [240, 99], [213, 147], [147, 215], [215, 213], [60, 20], [20, 166], [166, 60], [192, 187], [187, 213], [213, 192], [243, 112], [112, 244], [244, 243], [244, 233], [233, 245], [245, 244], [245, 128], [128, 188], [188, 245], [188, 114], [114, 174], [174, 188], [134, 131], [131, 220], [220, 134], [174, 217], [217, 236], [236, 174], [236, 198], [198, 134], [134, 236], [215, 177], [177, 58], [58, 215], [156, 143], [143, 124], [124, 156], [25, 110], [110, 7], [7, 25], [31, 228], [228, 25], [25, 31], [264, 356], [356, 368], [368, 264], [0, 11], [11, 267], [267, 0], [451, 452], [452, 349], [349, 451], [267, 302], [302, 269], [269, 267], [350, 357], [357, 277], [277, 350], [350, 452], [452, 357], [357, 350], [299, 333], [333, 297], [297, 299], [396, 175], [175, 377], [377, 396], [280, 347], [347, 330], [330, 280], [269, 303], [303, 270], [270, 269], [151, 9], [9, 337], [337, 151], [344, 278], [278, 360], [360, 344], [424, 418], [418, 431], [431, 424], [270, 304], [304, 409], [409, 270], [272, 310], [310, 407], [407, 272], [322, 270], [270, 410], [410, 322], [449, 450], [450, 347], [347, 449], [432, 422], [422, 434], [434, 432], [18, 313], [313, 17], [17, 18], [291, 306], [306, 375], [375, 291], [259, 387], [387, 260], [260, 259], [424, 335], [335, 418], [418, 424], [434, 364], [364, 416], [416, 434], [391, 423], [423, 327], [327, 391], [301, 251], [251, 298], [298, 301], [275, 281], [281, 4], [4, 275], [254, 373], [373, 253], [253, 254], [375, 307], [307, 321], [321, 375], [280, 425], [425, 411], [411, 280], [200, 421], [421, 18], [18, 200], [335, 321], [321, 406], [406, 335], [321, 320], [320, 405], [405, 321], [314, 315], [315, 17], [17, 314], [423, 426], [426, 266], [266, 423], [396, 377], [377, 369], [369, 396], [270, 322], [322, 269], [269, 270], [413, 417], [417, 464], [464, 413], [385, 386], [386, 258], [258, 385], [248, 456], [456, 419], [419, 248], [298, 284], [284, 333], [333, 298], [168, 417], [417, 8], [8, 168], [448, 346], [346, 261], [261, 448], [417, 413], [413, 285], [285, 417], [326, 327], [327, 328], [328, 326], [277, 355], [355, 329], [329, 277], [309, 392], [392, 438], [438, 309], [381, 382], [382, 256], [256, 381], [279, 429], [429, 360], [360, 279], [365, 364], [364, 379], [379, 365], [355, 277], [277, 437], [437, 355], [282, 443], [443, 283], [283, 282], [281, 275], [275, 363], [363, 281], [395, 431], [431, 369], [369, 395], [299, 297], [297, 337], [337, 299], [335, 273], [273, 321], [321, 335], [348, 450], [450, 349], [349, 348], [359, 446], [446, 467], [467, 359], [283, 293], [293, 282], [282, 283], [250, 458], [458, 462], [462, 250], [300, 276], [276, 383], [383, 300], [292, 308], [308, 325], [325, 292], [283, 276], [276, 293], [293, 283], [264, 372], [372, 447], [447, 264], [346, 352], [352, 340], [340, 346], [354, 274], [274, 19], [19, 354], [363, 456], [456, 281], [281, 363], [426, 436], [436, 425], [425, 426], [380, 381], [381, 252], [252, 380], [267, 269], [269, 393], [393, 267], [421, 200], [200, 428], [428, 421], [371, 266], [266, 329], [329, 371], [432, 287], [287, 422], [422, 432], [290, 250], [250, 328], [328, 290], [385, 258], [258, 384], [384, 385], [446, 265], [265, 342], [342, 446], [386, 387], [387, 257], [257, 386], [422, 424], [424, 430], [430, 422], [445, 342], [342, 276], [276, 445], [422, 273], [273, 424], [424, 422], [306, 292], [292, 307], [307, 306], [352, 366], [366, 345], [345, 352], [268, 271], [271, 302], [302, 268], [358, 423], [423, 371], [371, 358], [327, 294], [294, 460], [460, 327], [331, 279], [279, 294], [294, 331], [303, 271], [271, 304], [304, 303], [436, 432], [432, 427], [427, 436], [304, 272], [272, 408], [408, 304], [395, 394], [394, 431], [431, 395], [378, 395], [395, 400], [400, 378], [296, 334], [334, 299], [299, 296], [6, 351], [351, 168], [168, 6], [376, 352], [352, 411], [411, 376], [307, 325], [325, 320], [320, 307], [285, 295], [295, 336], [336, 285], [320, 319], [319, 404], [404, 320], [329, 330], [330, 349], [349, 329], [334, 293], [293, 333], [333, 334], [366, 323], [323, 447], [447, 366], [316, 15], [15, 315], [315, 316], [331, 358], [358, 279], [279, 331], [317, 14], [14, 316], [316, 317], [8, 285], [285, 9], [9, 8], [277, 329], [329, 350], [350, 277], [253, 374], [374, 252], [252, 253], [319, 318], [318, 403], [403, 319], [351, 6], [6, 419], [419, 351], [324, 318], [318, 325], [325, 324], [397, 367], [367, 365], [365, 397], [288, 435], [435, 397], [397, 288], [278, 344], [344, 439], [439, 278], [310, 272], [272, 311], [311, 310], [248, 195], [195, 281], [281, 248], [375, 273], [273, 291], [291, 375], [175, 396], [396, 199], [199, 175], [312, 311], [311, 268], [268, 312], [276, 283], [283, 445], [445, 276], [390, 373], [373, 339], [339, 390], [295, 282], [282, 296], [296, 295], [448, 449], [449, 346], [346, 448], [356, 264], [264, 454], [454, 356], [337, 336], [336, 299], [299, 337], [337, 338], [338, 151], [151, 337], [294, 278], [278, 455], [455, 294], [308, 292], [292, 415], [415, 308], [429, 358], [358, 355], [355, 429], [265, 340], [340, 372], [372, 265], [352, 346], [346, 280], [280, 352], [295, 442], [442, 282], [282, 295], [354, 19], [19, 370], [370, 354], [285, 441], [441, 295], [295, 285], [195, 248], [248, 197], [197, 195], [457, 440], [440, 274], [274, 457], [301, 300], [300, 368], [368, 301], [417, 351], [351, 465], [465, 417], [251, 301], [301, 389], [389, 251], [394, 395], [395, 379], [379, 394], [399, 412], [412, 419], [419, 399], [410, 436], [436, 322], [322, 410], [326, 2], [2, 393], [393, 326], [354, 370], [370, 461], [461, 354], [393, 164], [164, 267], [267, 393], [268, 302], [302, 12], [12, 268], [312, 268], [268, 13], [13, 312], [298, 293], [293, 301], [301, 298], [265, 446], [446, 340], [340, 265], [280, 330], [330, 425], [425, 280], [322, 426], [426, 391], [391, 322], [420, 429], [429, 437], [437, 420], [393, 391], [391, 326], [326, 393], [344, 440], [440, 438], [438, 344], [458, 459], [459, 461], [461, 458], [364, 434], [434, 394], [394, 364], [428, 396], [396, 262], [262, 428], [274, 354], [354, 457], [457, 274], [317, 316], [316, 402], [402, 317], [316, 315], [315, 403], [403, 316], [315, 314], [314, 404], [404, 315], [314, 313], [313, 405], [405, 314], [313, 421], [421, 406], [406, 313], [323, 366], [366, 361], [361, 323], [292, 306], [306, 407], [407, 292], [306, 291], [291, 408], [408, 306], [291, 287], [287, 409], [409, 291], [287, 432], [432, 410], [410, 287], [427, 434], [434, 411], [411, 427], [372, 264], [264, 383], [383, 372], [459, 309], [309, 457], [457, 459], [366, 352], [352, 401], [401, 366], [1, 274], [274, 4], [4, 1], [418, 421], [421, 262], [262, 418], [331, 294], [294, 358], [358, 331], [435, 433], [433, 367], [367, 435], [392, 289], [289, 439], [439, 392], [328, 462], [462, 326], [326, 328], [94, 2], [2, 370], [370, 94], [289, 305], [305, 455], [455, 289], [339, 254], [254, 448], [448, 339], [359, 255], [255, 446], [446, 359], [254, 253], [253, 449], [449, 254], [253, 252], [252, 450], [450, 253], [252, 256], [256, 451], [451, 252], [256, 341], [341, 452], [452, 256], [414, 413], [413, 463], [463, 414], [286, 441], [441, 414], [414, 286], [286, 258], [258, 441], [441, 286], [258, 257], [257, 442], [442, 258], [257, 259], [259, 443], [443, 257], [259, 260], [260, 444], [444, 259], [260, 467], [467, 445], [445, 260], [309, 459], [459, 250], [250, 309], [305, 289], [289, 290], [290, 305], [305, 290], [290, 460], [460, 305], [401, 376], [376, 435], [435, 401], [309, 250], [250, 392], [392, 309], [376, 411], [411, 433], [433, 376], [453, 341], [341, 464], [464, 453], [357, 453], [453, 465], [465, 357], [343, 357], [357, 412], [412, 343], [437, 343], [343, 399], [399, 437], [344, 360], [360, 440], [440, 344], [420, 437], [437, 456], [456, 420], [360, 420], [420, 363], [363, 360], [361, 401], [401, 288], [288, 361], [265, 372], [372, 353], [353, 265], [390, 339], [339, 249], [249, 390], [339, 448], [448, 255], [255, 339]);
function gc(t) {
	t.l = {
		faceLandmarks: [],
		faceBlendshapes: [],
		facialTransformationMatrixes: []
	};
}
var mc = class extends nc {
	constructor(t, e) {
		super(new Ju(t, e), "image_in", "norm_rect", !1), this.l = {
			faceLandmarks: [],
			faceBlendshapes: [],
			facialTransformationMatrixes: []
		}, this.outputFacialTransformationMatrixes = this.outputFaceBlendshapes = !1, Ir(t = this.h = new na(), 0, 1, e = new zo()), this.B = new ra(), Ir(this.h, 0, 3, this.B), this.u = new Zo(), Ir(this.h, 0, 2, this.u), Ur(this.u, 4, 1), jr(this.u, 2, .5), jr(this.B, 2, .5), jr(this.h, 4, .5);
	}
	C() {
		return "FaceLandmarker";
	}
	get baseOptions() {
		return Sr(this.h, zo, 1);
	}
	set baseOptions(t) {
		Ir(this.h, 0, 1, t);
	}
	v(t) {
		return "numFaces" in t && Ur(this.u, 4, t.numFaces ?? 1), "minFaceDetectionConfidence" in t && jr(this.u, 2, t.minFaceDetectionConfidence ?? .5), "minTrackingConfidence" in t && jr(this.h, 4, t.minTrackingConfidence ?? .5), "minFacePresenceConfidence" in t && jr(this.B, 2, t.minFacePresenceConfidence ?? .5), "outputFaceBlendshapes" in t && (this.outputFaceBlendshapes = !!t.outputFaceBlendshapes), "outputFacialTransformationMatrixes" in t && (this.outputFacialTransformationMatrixes = !!t.outputFacialTransformationMatrixes), this.j(t);
	}
	G(t, e) {
		return gc(this), tc(this, t, e), this.l;
	}
	H(t, e, r) {
		return gc(this), ec(this, t, r, e), this.l;
	}
	o() {
		var t = new mo();
		po(t, "image_in"), po(t, "norm_rect"), go(t, "face_landmarks");
		var e = new no();
		li(e, sa, this.h);
		var r = new ho();
		Hr(r, 2, "mediapipe.tasks.vision.face_landmarker.FaceLandmarkerGraph"), oo(r, "IMAGE:image_in"), oo(r, "NORM_RECT:norm_rect"), ao(r, "NORM_LANDMARKS:face_landmarks"), r.v(e), fo(t, r), this.g.attachProtoVectorListener("face_landmarks", (t, e) => {
			for (let e of t) t = Io(e), this.l.faceLandmarks.push(Qa(t));
			tu(this, e);
		}), this.g.attachEmptyPacketListener("face_landmarks", (t) => {
			tu(this, t);
		}), this.outputFaceBlendshapes && (go(t, "blendshapes"), ao(r, "BLENDSHAPES:blendshapes"), this.g.attachProtoVectorListener("blendshapes", (t, e) => {
			if (this.outputFaceBlendshapes) for (let e of t) t = wo(e), this.l.faceBlendshapes.push(qa(t.g() ?? []));
			tu(this, e);
		}), this.g.attachEmptyPacketListener("blendshapes", (t) => {
			tu(this, t);
		})), this.outputFacialTransformationMatrixes && (go(t, "face_geometry"), ao(r, "FACE_GEOMETRY:face_geometry"), this.g.attachProtoVectorListener("face_geometry", (t, e) => {
			if (this.outputFacialTransformationMatrixes) for (let e of t) (t = Sr(t = ea(e), Fo, 2)) && this.l.facialTransformationMatrixes.push({
				rows: Or(t, 1) ?? 0 ?? 0,
				columns: Or(t, 2) ?? 0 ?? 0,
				data: lr(t, 3, Jt, cr()).slice() ?? []
			});
			tu(this, e);
		}), this.g.attachEmptyPacketListener("face_geometry", (t) => {
			tu(this, t);
		})), t = t.g(), this.setGraph(new Uint8Array(t), !0);
	}
};
mc.prototype.detectForVideo = mc.prototype.H, mc.prototype.detect = mc.prototype.G, mc.prototype.setOptions = mc.prototype.v, mc.createFromModelPath = function(t, e) {
	return Zu(mc, t, { baseOptions: { modelAssetPath: e } });
}, mc.createFromModelBuffer = function(t, e) {
	return Zu(mc, t, { baseOptions: { modelAssetBuffer: e } });
}, mc.createFromOptions = function(t, e) {
	return Zu(mc, t, e);
}, mc.FACE_LANDMARKS_LIPS = sc, r("module$exports$google3$third_party$mediapipe$tasks$web$vision$face_landmarker$face_landmarker.FaceLandmarker.FACE_LANDMARKS_LIPS", mc.FACE_LANDMARKS_LIPS), mc.FACE_LANDMARKS_LEFT_EYE = oc, r("module$exports$google3$third_party$mediapipe$tasks$web$vision$face_landmarker$face_landmarker.FaceLandmarker.FACE_LANDMARKS_LEFT_EYE", mc.FACE_LANDMARKS_LEFT_EYE), mc.FACE_LANDMARKS_LEFT_EYEBROW = ac, r("module$exports$google3$third_party$mediapipe$tasks$web$vision$face_landmarker$face_landmarker.FaceLandmarker.FACE_LANDMARKS_LEFT_EYEBROW", mc.FACE_LANDMARKS_LEFT_EYEBROW), mc.FACE_LANDMARKS_LEFT_IRIS = hc, r("module$exports$google3$third_party$mediapipe$tasks$web$vision$face_landmarker$face_landmarker.FaceLandmarker.FACE_LANDMARKS_LEFT_IRIS", mc.FACE_LANDMARKS_LEFT_IRIS), mc.FACE_LANDMARKS_RIGHT_EYE = uc, r("module$exports$google3$third_party$mediapipe$tasks$web$vision$face_landmarker$face_landmarker.FaceLandmarker.FACE_LANDMARKS_RIGHT_EYE", mc.FACE_LANDMARKS_RIGHT_EYE), mc.FACE_LANDMARKS_RIGHT_EYEBROW = cc, r("module$exports$google3$third_party$mediapipe$tasks$web$vision$face_landmarker$face_landmarker.FaceLandmarker.FACE_LANDMARKS_RIGHT_EYEBROW", mc.FACE_LANDMARKS_RIGHT_EYEBROW), mc.FACE_LANDMARKS_RIGHT_IRIS = lc, r("module$exports$google3$third_party$mediapipe$tasks$web$vision$face_landmarker$face_landmarker.FaceLandmarker.FACE_LANDMARKS_RIGHT_IRIS", mc.FACE_LANDMARKS_RIGHT_IRIS), mc.FACE_LANDMARKS_FACE_OVAL = dc, r("module$exports$google3$third_party$mediapipe$tasks$web$vision$face_landmarker$face_landmarker.FaceLandmarker.FACE_LANDMARKS_FACE_OVAL", mc.FACE_LANDMARKS_FACE_OVAL), mc.FACE_LANDMARKS_CONTOURS = fc, r("module$exports$google3$third_party$mediapipe$tasks$web$vision$face_landmarker$face_landmarker.FaceLandmarker.FACE_LANDMARKS_CONTOURS", mc.FACE_LANDMARKS_CONTOURS), mc.FACE_LANDMARKS_TESSELATION = pc, r("module$exports$google3$third_party$mediapipe$tasks$web$vision$face_landmarker$face_landmarker.FaceLandmarker.FACE_LANDMARKS_TESSELATION", mc.FACE_LANDMARKS_TESSELATION);
var vc = zu([0, 1], [1, 2], [2, 3], [3, 4], [0, 5], [5, 6], [6, 7], [7, 8], [5, 9], [9, 10], [10, 11], [11, 12], [9, 13], [13, 14], [14, 15], [15, 16], [13, 17], [0, 17], [17, 18], [18, 19], [19, 20]);
function _c(t) {
	t.gestures = [], t.landmarks = [], t.worldLandmarks = [], t.handedness = [];
}
function yc(t) {
	return 0 === t.gestures.length ? {
		gestures: [],
		landmarks: [],
		worldLandmarks: [],
		handedness: [],
		handednesses: []
	} : {
		gestures: t.gestures,
		landmarks: t.landmarks,
		worldLandmarks: t.worldLandmarks,
		handedness: t.handedness,
		handednesses: t.handedness
	};
}
function Ec(t, e = !0) {
	var r = [];
	for (let i of t) {
		var n = wo(i);
		t = [];
		for (let r of n.g()) n = e && null != Or(r, 1) ? Or(r, 1) ?? 0 : -1, t.push({
			score: Dr(r, 2) ?? 0,
			index: n,
			categoryName: _e(sr(r, 3)) ?? "" ?? "",
			displayName: _e(sr(r, 4)) ?? "" ?? ""
		});
		r.push(t);
	}
	return r;
}
var Ac = class extends nc {
	constructor(t, e) {
		super(new Ju(t, e), "image_in", "norm_rect", !1), this.gestures = [], this.landmarks = [], this.worldLandmarks = [], this.handedness = [], Ir(t = this.l = new da(), 0, 1, e = new zo()), this.u = new la(), Ir(this.l, 0, 2, this.u), this.F = new ca(), Ir(this.u, 0, 3, this.F), this.B = new ua(), Ir(this.u, 0, 2, this.B), this.h = new ha(), Ir(this.l, 0, 3, this.h), jr(this.B, 2, .5), jr(this.u, 4, .5), jr(this.F, 2, .5);
	}
	C() {
		return "GestureRecognizer";
	}
	get baseOptions() {
		return Sr(this.l, zo, 1);
	}
	set baseOptions(t) {
		Ir(this.l, 0, 1, t);
	}
	v(t) {
		if (Ur(this.B, 3, t.numHands ?? 1), "minHandDetectionConfidence" in t && jr(this.B, 2, t.minHandDetectionConfidence ?? .5), "minTrackingConfidence" in t && jr(this.u, 4, t.minTrackingConfidence ?? .5), "minHandPresenceConfidence" in t && jr(this.F, 2, t.minHandPresenceConfidence ?? .5), t.cannedGesturesClassifierOptions) {
			var e = new oa(), r = e, n = za(t.cannedGesturesClassifierOptions, Sr(this.h, oa, 3)?.j());
			Ir(r, 0, 2, n), Ir(this.h, 0, 3, e);
		} else void 0 === t.cannedGesturesClassifierOptions && Sr(this.h, oa, 3)?.g();
		return t.customGesturesClassifierOptions ? (Ir(r = e = new oa(), 0, 2, n = za(t.customGesturesClassifierOptions, Sr(this.h, oa, 4)?.j())), Ir(this.h, 0, 4, e)) : void 0 === t.customGesturesClassifierOptions && Sr(this.h, oa, 4)?.g(), this.j(t);
	}
	Xa(t, e) {
		return _c(this), tc(this, t, e), yc(this);
	}
	Ya(t, e, r) {
		return _c(this), ec(this, t, r, e), yc(this);
	}
	o() {
		var t = new mo();
		po(t, "image_in"), po(t, "norm_rect"), go(t, "hand_gestures"), go(t, "hand_landmarks"), go(t, "world_hand_landmarks"), go(t, "handedness");
		var e = new no();
		li(e, va, this.l);
		var r = new ho();
		Hr(r, 2, "mediapipe.tasks.vision.gesture_recognizer.GestureRecognizerGraph"), oo(r, "IMAGE:image_in"), oo(r, "NORM_RECT:norm_rect"), ao(r, "HAND_GESTURES:hand_gestures"), ao(r, "LANDMARKS:hand_landmarks"), ao(r, "WORLD_LANDMARKS:world_hand_landmarks"), ao(r, "HANDEDNESS:handedness"), r.v(e), fo(t, r), this.g.attachProtoVectorListener("hand_landmarks", (t, e) => {
			for (let e of t) {
				t = Io(e);
				let r = [];
				for (let e of xr(t, Ro, 1)) r.push({
					x: Dr(e, 1) ?? 0,
					y: Dr(e, 2) ?? 0,
					z: Dr(e, 3) ?? 0,
					visibility: Dr(e, 4) ?? 0
				});
				this.landmarks.push(r);
			}
			tu(this, e);
		}), this.g.attachEmptyPacketListener("hand_landmarks", (t) => {
			tu(this, t);
		}), this.g.attachProtoVectorListener("world_hand_landmarks", (t, e) => {
			for (let e of t) {
				t = xo(e);
				let r = [];
				for (let e of xr(t, Lo, 1)) r.push({
					x: Dr(e, 1) ?? 0,
					y: Dr(e, 2) ?? 0,
					z: Dr(e, 3) ?? 0,
					visibility: Dr(e, 4) ?? 0
				});
				this.worldLandmarks.push(r);
			}
			tu(this, e);
		}), this.g.attachEmptyPacketListener("world_hand_landmarks", (t) => {
			tu(this, t);
		}), this.g.attachProtoVectorListener("hand_gestures", (t, e) => {
			this.gestures.push(...Ec(t, !1)), tu(this, e);
		}), this.g.attachEmptyPacketListener("hand_gestures", (t) => {
			tu(this, t);
		}), this.g.attachProtoVectorListener("handedness", (t, e) => {
			this.handedness.push(...Ec(t)), tu(this, e);
		}), this.g.attachEmptyPacketListener("handedness", (t) => {
			tu(this, t);
		}), t = t.g(), this.setGraph(new Uint8Array(t), !0);
	}
};
function wc(t) {
	return {
		landmarks: t.landmarks,
		worldLandmarks: t.worldLandmarks,
		handednesses: t.handedness,
		handedness: t.handedness
	};
}
Ac.prototype.recognizeForVideo = Ac.prototype.Ya, Ac.prototype.recognize = Ac.prototype.Xa, Ac.prototype.setOptions = Ac.prototype.v, Ac.createFromModelPath = function(t, e) {
	return Zu(Ac, t, { baseOptions: { modelAssetPath: e } });
}, Ac.createFromModelBuffer = function(t, e) {
	return Zu(Ac, t, { baseOptions: { modelAssetBuffer: e } });
}, Ac.createFromOptions = function(t, e) {
	return Zu(Ac, t, e);
}, Ac.HAND_CONNECTIONS = vc, r("module$exports$google3$third_party$mediapipe$tasks$web$vision$gesture_recognizer$gesture_recognizer.GestureRecognizer.HAND_CONNECTIONS", Ac.HAND_CONNECTIONS);
var bc = class extends nc {
	constructor(t, e) {
		super(new Ju(t, e), "image_in", "norm_rect", !1), this.landmarks = [], this.worldLandmarks = [], this.handedness = [], Ir(t = this.h = new la(), 0, 1, e = new zo()), this.u = new ca(), Ir(this.h, 0, 3, this.u), this.l = new ua(), Ir(this.h, 0, 2, this.l), Ur(this.l, 3, 1), jr(this.l, 2, .5), jr(this.u, 2, .5), jr(this.h, 4, .5);
	}
	C() {
		return "HandLandmarker";
	}
	get baseOptions() {
		return Sr(this.h, zo, 1);
	}
	set baseOptions(t) {
		Ir(this.h, 0, 1, t);
	}
	v(t) {
		return "numHands" in t && Ur(this.l, 3, t.numHands ?? 1), "minHandDetectionConfidence" in t && jr(this.l, 2, t.minHandDetectionConfidence ?? .5), "minTrackingConfidence" in t && jr(this.h, 4, t.minTrackingConfidence ?? .5), "minHandPresenceConfidence" in t && jr(this.u, 2, t.minHandPresenceConfidence ?? .5), this.j(t);
	}
	G(t, e) {
		return this.landmarks = [], this.worldLandmarks = [], this.handedness = [], tc(this, t, e), wc(this);
	}
	H(t, e, r) {
		return this.landmarks = [], this.worldLandmarks = [], this.handedness = [], ec(this, t, r, e), wc(this);
	}
	o() {
		var t = new mo();
		po(t, "image_in"), po(t, "norm_rect"), go(t, "hand_landmarks"), go(t, "world_hand_landmarks"), go(t, "handedness");
		var e = new no();
		li(e, _a, this.h);
		var r = new ho();
		Hr(r, 2, "mediapipe.tasks.vision.hand_landmarker.HandLandmarkerGraph"), oo(r, "IMAGE:image_in"), oo(r, "NORM_RECT:norm_rect"), ao(r, "LANDMARKS:hand_landmarks"), ao(r, "WORLD_LANDMARKS:world_hand_landmarks"), ao(r, "HANDEDNESS:handedness"), r.v(e), fo(t, r), this.g.attachProtoVectorListener("hand_landmarks", (t, e) => {
			for (let e of t) t = Io(e), this.landmarks.push(Qa(t));
			tu(this, e);
		}), this.g.attachEmptyPacketListener("hand_landmarks", (t) => {
			tu(this, t);
		}), this.g.attachProtoVectorListener("world_hand_landmarks", (t, e) => {
			for (let e of t) t = xo(e), this.worldLandmarks.push(th(t));
			tu(this, e);
		}), this.g.attachEmptyPacketListener("world_hand_landmarks", (t) => {
			tu(this, t);
		}), this.g.attachProtoVectorListener("handedness", (t, e) => {
			var r = this.handedness, n = r.push, i = [];
			for (let e of t) {
				t = wo(e);
				let r = [];
				for (let e of t.g()) r.push({
					score: Dr(e, 2) ?? 0,
					index: Or(e, 1) ?? 0 ?? -1,
					categoryName: _e(sr(e, 3)) ?? "" ?? "",
					displayName: _e(sr(e, 4)) ?? "" ?? ""
				});
				i.push(r);
			}
			n.call(r, ...i), tu(this, e);
		}), this.g.attachEmptyPacketListener("handedness", (t) => {
			tu(this, t);
		}), t = t.g(), this.setGraph(new Uint8Array(t), !0);
	}
};
bc.prototype.detectForVideo = bc.prototype.H, bc.prototype.detect = bc.prototype.G, bc.prototype.setOptions = bc.prototype.v, bc.createFromModelPath = function(t, e) {
	return Zu(bc, t, { baseOptions: { modelAssetPath: e } });
}, bc.createFromModelBuffer = function(t, e) {
	return Zu(bc, t, { baseOptions: { modelAssetBuffer: e } });
}, bc.createFromOptions = function(t, e) {
	return Zu(bc, t, e);
}, bc.HAND_CONNECTIONS = vc, r("module$exports$google3$third_party$mediapipe$tasks$web$vision$hand_landmarker$hand_landmarker.HandLandmarker.HAND_CONNECTIONS", bc.HAND_CONNECTIONS);
var Tc = zu([0, 1], [1, 2], [2, 3], [3, 7], [0, 4], [4, 5], [5, 6], [6, 8], [9, 10], [11, 12], [11, 13], [13, 15], [15, 17], [15, 19], [15, 21], [17, 19], [12, 14], [14, 16], [16, 18], [16, 20], [16, 22], [18, 20], [11, 23], [12, 24], [23, 24], [23, 25], [24, 26], [25, 27], [26, 28], [27, 29], [28, 30], [29, 31], [30, 32], [27, 31], [28, 32]);
function kc(t) {
	t.h = {
		faceLandmarks: [],
		faceBlendshapes: [],
		poseLandmarks: [],
		poseWorldLandmarks: [],
		poseSegmentationMasks: [],
		leftHandLandmarks: [],
		leftHandWorldLandmarks: [],
		rightHandLandmarks: [],
		rightHandWorldLandmarks: []
	};
}
function Sc(t) {
	try {
		if (!t.F) return t.h;
		t.F(t.h);
	} finally {
		nu(t);
	}
}
function Lc(t, e) {
	t = Io(t), e.push(Qa(t));
}
var xc = class extends nc {
	constructor(t, e) {
		super(new Ju(t, e), "input_frames_image", null, !1), this.h = {
			faceLandmarks: [],
			faceBlendshapes: [],
			poseLandmarks: [],
			poseWorldLandmarks: [],
			poseSegmentationMasks: [],
			leftHandLandmarks: [],
			leftHandWorldLandmarks: [],
			rightHandLandmarks: [],
			rightHandWorldLandmarks: []
		}, this.outputPoseSegmentationMasks = this.outputFaceBlendshapes = !1, Ir(t = this.l = new wa(), 0, 1, e = new zo()), this.Y = new ca(), Ir(this.l, 0, 2, this.Y), this.Aa = new ya(), Ir(this.l, 0, 3, this.Aa), this.u = new Zo(), Ir(this.l, 0, 4, this.u), this.O = new ra(), Ir(this.l, 0, 5, this.O), this.B = new Ea(), Ir(this.l, 0, 6, this.B), this.Z = new Aa(), Ir(this.l, 0, 7, this.Z), jr(this.u, 2, .5), jr(this.u, 3, .3), jr(this.O, 2, .5), jr(this.B, 2, .5), jr(this.B, 3, .3), jr(this.Z, 2, .5), jr(this.Y, 2, .5);
	}
	C() {
		return "HolisticLandmarker";
	}
	get baseOptions() {
		return Sr(this.l, zo, 1);
	}
	set baseOptions(t) {
		Ir(this.l, 0, 1, t);
	}
	v(t) {
		return "minFaceDetectionConfidence" in t && jr(this.u, 2, t.minFaceDetectionConfidence ?? .5), "minFaceSuppressionThreshold" in t && jr(this.u, 3, t.minFaceSuppressionThreshold ?? .3), "minFacePresenceConfidence" in t && jr(this.O, 2, t.minFacePresenceConfidence ?? .5), "outputFaceBlendshapes" in t && (this.outputFaceBlendshapes = !!t.outputFaceBlendshapes), "minPoseDetectionConfidence" in t && jr(this.B, 2, t.minPoseDetectionConfidence ?? .5), "minPoseSuppressionThreshold" in t && jr(this.B, 3, t.minPoseSuppressionThreshold ?? .3), "minPosePresenceConfidence" in t && jr(this.Z, 2, t.minPosePresenceConfidence ?? .5), "outputPoseSegmentationMasks" in t && (this.outputPoseSegmentationMasks = !!t.outputPoseSegmentationMasks), "minHandLandmarksConfidence" in t && jr(this.Y, 2, t.minHandLandmarksConfidence ?? .5), this.j(t);
	}
	G(t, e, r) {
		var n = "function" != typeof e ? e : {};
		return this.F = "function" == typeof e ? e : r, kc(this), tc(this, t, n), Sc(this);
	}
	H(t, e, r, n) {
		var i = "function" != typeof r ? r : {};
		return this.F = "function" == typeof r ? r : n, kc(this), ec(this, t, i, e), Sc(this);
	}
	o() {
		var t = new mo();
		po(t, "input_frames_image"), go(t, "pose_landmarks"), go(t, "pose_world_landmarks"), go(t, "face_landmarks"), go(t, "left_hand_landmarks"), go(t, "left_hand_world_landmarks"), go(t, "right_hand_landmarks"), go(t, "right_hand_world_landmarks");
		var e = new no(), r = new Bs();
		Hr(r, 1, "type.googleapis.com/mediapipe.tasks.vision.holistic_landmarker.proto.HolisticLandmarkerGraphOptions"), function(t, e) {
			if (null != e) if (Array.isArray(e)) ar(t, 2, Ge(e, 0, Ve));
			else {
				if (!("string" == typeof e || e instanceof N || x(e))) throw Error("invalid value in Any.value field: " + e + " expected a ByteString, a base64 encoded string, a Uint8Array or a jspb array");
				_r(t, 2, ct(e, !1), I());
			}
		}(r, this.l.g());
		var n = new ho();
		Hr(n, 2, "mediapipe.tasks.vision.holistic_landmarker.HolisticLandmarkerGraph"), Mr(n, 8, Bs, r), oo(n, "IMAGE:input_frames_image"), ao(n, "POSE_LANDMARKS:pose_landmarks"), ao(n, "POSE_WORLD_LANDMARKS:pose_world_landmarks"), ao(n, "FACE_LANDMARKS:face_landmarks"), ao(n, "LEFT_HAND_LANDMARKS:left_hand_landmarks"), ao(n, "LEFT_HAND_WORLD_LANDMARKS:left_hand_world_landmarks"), ao(n, "RIGHT_HAND_LANDMARKS:right_hand_landmarks"), ao(n, "RIGHT_HAND_WORLD_LANDMARKS:right_hand_world_landmarks"), n.v(e), fo(t, n), eu(this, t), this.g.attachProtoListener("pose_landmarks", (t, e) => {
			Lc(t, this.h.poseLandmarks), tu(this, e);
		}), this.g.attachEmptyPacketListener("pose_landmarks", (t) => {
			tu(this, t);
		}), this.g.attachProtoListener("pose_world_landmarks", (t, e) => {
			var r = this.h.poseWorldLandmarks;
			t = xo(t), r.push(th(t)), tu(this, e);
		}), this.g.attachEmptyPacketListener("pose_world_landmarks", (t) => {
			tu(this, t);
		}), this.outputPoseSegmentationMasks && (ao(n, "POSE_SEGMENTATION_MASK:pose_segmentation_mask"), ru(this, "pose_segmentation_mask"), this.g.ga("pose_segmentation_mask", (t, e) => {
			this.h.poseSegmentationMasks = [rc(this, t, !0, !this.F)], tu(this, e);
		}), this.g.attachEmptyPacketListener("pose_segmentation_mask", (t) => {
			this.h.poseSegmentationMasks = [], tu(this, t);
		})), this.g.attachProtoListener("face_landmarks", (t, e) => {
			Lc(t, this.h.faceLandmarks), tu(this, e);
		}), this.g.attachEmptyPacketListener("face_landmarks", (t) => {
			tu(this, t);
		}), this.outputFaceBlendshapes && (go(t, "extra_blendshapes"), ao(n, "FACE_BLENDSHAPES:extra_blendshapes"), this.g.attachProtoListener("extra_blendshapes", (t, e) => {
			var r = this.h.faceBlendshapes;
			this.outputFaceBlendshapes && (t = wo(t), r.push(qa(t.g() ?? []))), tu(this, e);
		}), this.g.attachEmptyPacketListener("extra_blendshapes", (t) => {
			tu(this, t);
		})), this.g.attachProtoListener("left_hand_landmarks", (t, e) => {
			Lc(t, this.h.leftHandLandmarks), tu(this, e);
		}), this.g.attachEmptyPacketListener("left_hand_landmarks", (t) => {
			tu(this, t);
		}), this.g.attachProtoListener("left_hand_world_landmarks", (t, e) => {
			var r = this.h.leftHandWorldLandmarks;
			t = xo(t), r.push(th(t)), tu(this, e);
		}), this.g.attachEmptyPacketListener("left_hand_world_landmarks", (t) => {
			tu(this, t);
		}), this.g.attachProtoListener("right_hand_landmarks", (t, e) => {
			Lc(t, this.h.rightHandLandmarks), tu(this, e);
		}), this.g.attachEmptyPacketListener("right_hand_landmarks", (t) => {
			tu(this, t);
		}), this.g.attachProtoListener("right_hand_world_landmarks", (t, e) => {
			var r = this.h.rightHandWorldLandmarks;
			t = xo(t), r.push(th(t)), tu(this, e);
		}), this.g.attachEmptyPacketListener("right_hand_world_landmarks", (t) => {
			tu(this, t);
		}), t = t.g(), this.setGraph(new Uint8Array(t), !0);
	}
};
xc.prototype.detectForVideo = xc.prototype.H, xc.prototype.detect = xc.prototype.G, xc.prototype.setOptions = xc.prototype.v, xc.createFromModelPath = function(t, e) {
	return Zu(xc, t, { baseOptions: { modelAssetPath: e } });
}, xc.createFromModelBuffer = function(t, e) {
	return Zu(xc, t, { baseOptions: { modelAssetBuffer: e } });
}, xc.createFromOptions = function(t, e) {
	return Zu(xc, t, e);
}, xc.HAND_CONNECTIONS = vc, r("module$exports$google3$third_party$mediapipe$tasks$web$vision$holistic_landmarker$holistic_landmarker.HolisticLandmarker.HAND_CONNECTIONS", xc.HAND_CONNECTIONS), xc.POSE_CONNECTIONS = Tc, r("module$exports$google3$third_party$mediapipe$tasks$web$vision$holistic_landmarker$holistic_landmarker.HolisticLandmarker.POSE_CONNECTIONS", xc.POSE_CONNECTIONS), xc.FACE_LANDMARKS_LIPS = sc, r("module$exports$google3$third_party$mediapipe$tasks$web$vision$holistic_landmarker$holistic_landmarker.HolisticLandmarker.FACE_LANDMARKS_LIPS", xc.FACE_LANDMARKS_LIPS), xc.FACE_LANDMARKS_LEFT_EYE = oc, r("module$exports$google3$third_party$mediapipe$tasks$web$vision$holistic_landmarker$holistic_landmarker.HolisticLandmarker.FACE_LANDMARKS_LEFT_EYE", xc.FACE_LANDMARKS_LEFT_EYE), xc.FACE_LANDMARKS_LEFT_EYEBROW = ac, r("module$exports$google3$third_party$mediapipe$tasks$web$vision$holistic_landmarker$holistic_landmarker.HolisticLandmarker.FACE_LANDMARKS_LEFT_EYEBROW", xc.FACE_LANDMARKS_LEFT_EYEBROW), xc.FACE_LANDMARKS_LEFT_IRIS = hc, r("module$exports$google3$third_party$mediapipe$tasks$web$vision$holistic_landmarker$holistic_landmarker.HolisticLandmarker.FACE_LANDMARKS_LEFT_IRIS", xc.FACE_LANDMARKS_LEFT_IRIS), xc.FACE_LANDMARKS_RIGHT_EYE = uc, r("module$exports$google3$third_party$mediapipe$tasks$web$vision$holistic_landmarker$holistic_landmarker.HolisticLandmarker.FACE_LANDMARKS_RIGHT_EYE", xc.FACE_LANDMARKS_RIGHT_EYE), xc.FACE_LANDMARKS_RIGHT_EYEBROW = cc, r("module$exports$google3$third_party$mediapipe$tasks$web$vision$holistic_landmarker$holistic_landmarker.HolisticLandmarker.FACE_LANDMARKS_RIGHT_EYEBROW", xc.FACE_LANDMARKS_RIGHT_EYEBROW), xc.FACE_LANDMARKS_RIGHT_IRIS = lc, r("module$exports$google3$third_party$mediapipe$tasks$web$vision$holistic_landmarker$holistic_landmarker.HolisticLandmarker.FACE_LANDMARKS_RIGHT_IRIS", xc.FACE_LANDMARKS_RIGHT_IRIS), xc.FACE_LANDMARKS_FACE_OVAL = dc, r("module$exports$google3$third_party$mediapipe$tasks$web$vision$holistic_landmarker$holistic_landmarker.HolisticLandmarker.FACE_LANDMARKS_FACE_OVAL", xc.FACE_LANDMARKS_FACE_OVAL), xc.FACE_LANDMARKS_CONTOURS = fc, r("module$exports$google3$third_party$mediapipe$tasks$web$vision$holistic_landmarker$holistic_landmarker.HolisticLandmarker.FACE_LANDMARKS_CONTOURS", xc.FACE_LANDMARKS_CONTOURS), xc.FACE_LANDMARKS_TESSELATION = pc, r("module$exports$google3$third_party$mediapipe$tasks$web$vision$holistic_landmarker$holistic_landmarker.HolisticLandmarker.FACE_LANDMARKS_TESSELATION", xc.FACE_LANDMARKS_TESSELATION);
var Rc = class extends nc {
	constructor(t, e) {
		super(new Ju(t, e), "input_image", "norm_rect", !0), this.l = { classifications: [] }, Ir(t = this.h = new ka(), 0, 1, e = new zo());
	}
	C() {
		return "ImageClassifier";
	}
	get baseOptions() {
		return Sr(this.h, zo, 1);
	}
	set baseOptions(t) {
		Ir(this.h, 0, 1, t);
	}
	v(t) {
		return Ir(this.h, 0, 2, za(t, Sr(this.h, Go, 2))), this.j(t);
	}
	Ga(t, e) {
		return this.l = { classifications: [] }, tc(this, t, e), this.l;
	}
	Ha(t, e, r) {
		return this.l = { classifications: [] }, ec(this, t, r, e), this.l;
	}
	o() {
		var t = new mo();
		po(t, "input_image"), po(t, "norm_rect"), go(t, "classifications");
		var e = new no();
		li(e, Sa, this.h);
		var r = new ho();
		Hr(r, 2, "mediapipe.tasks.vision.image_classifier.ImageClassifierGraph"), oo(r, "IMAGE:input_image"), oo(r, "NORM_RECT:norm_rect"), ao(r, "CLASSIFICATIONS:classifications"), r.v(e), fo(t, r), this.g.attachProtoListener("classifications", (t, e) => {
			this.l = Ja(Oo(t)), tu(this, e);
		}), this.g.attachEmptyPacketListener("classifications", (t) => {
			tu(this, t);
		}), t = t.g(), this.setGraph(new Uint8Array(t), !0);
	}
};
Rc.prototype.classifyForVideo = Rc.prototype.Ha, Rc.prototype.classify = Rc.prototype.Ga, Rc.prototype.setOptions = Rc.prototype.v, Rc.createFromModelPath = function(t, e) {
	return Zu(Rc, t, { baseOptions: { modelAssetPath: e } });
}, Rc.createFromModelBuffer = function(t, e) {
	return Zu(Rc, t, { baseOptions: { modelAssetBuffer: e } });
}, Rc.createFromOptions = function(t, e) {
	return Zu(Rc, t, e);
};
var Ic = class extends nc {
	constructor(t, e) {
		super(new Ju(t, e), "image_in", "norm_rect", !0), this.h = new La(), this.embeddings = { embeddings: [] }, Ir(t = this.h, 0, 1, e = new zo());
	}
	C() {
		return "ImageEmbedder";
	}
	get baseOptions() {
		return Sr(this.h, zo, 1);
	}
	set baseOptions(t) {
		Ir(this.h, 0, 1, t);
	}
	v(t) {
		var e = this.h, r = Sr(this.h, Vo, 2);
		if (r = r ? r.clone() : new Vo(), void 0 !== t.l2Normalize) {
			var n = t.l2Normalize;
			ar(r, 1, null == n ? n : Zt(n));
		} else "l2Normalize" in t && ar(r, 1);
		return void 0 !== t.quantize ? ar(r, 2, null == (n = t.quantize) ? n : Zt(n)) : "quantize" in t && ar(r, 2), Ir(e, 0, 2, r), this.j(t);
	}
	Na(t, e) {
		return tc(this, t, e), this.embeddings;
	}
	Oa(t, e, r) {
		return ec(this, t, r, e), this.embeddings;
	}
	o() {
		var t = new mo();
		po(t, "image_in"), po(t, "norm_rect"), go(t, "embeddings_out");
		var e = new no();
		li(e, xa, this.h);
		var r = new ho();
		Hr(r, 2, "mediapipe.tasks.vision.image_embedder.ImageEmbedderGraph"), oo(r, "IMAGE:image_in"), oo(r, "NORM_RECT:norm_rect"), ao(r, "EMBEDDINGS:embeddings_out"), r.v(e), fo(t, r), this.g.attachProtoListener("embeddings_out", (t, e) => {
			t = Bo(t), this.embeddings = function(t) {
				return {
					embeddings: xr(t, $o, 1).map((t) => {
						var e = {
							headIndex: Or(t, 3) ?? 0 ?? -1,
							headName: _e(sr(t, 4)) ?? "" ?? ""
						};
						if (ur(t, Do, 1, Uo)) t = lr(t = Pr(t, Do, 1), 1, Jt, cr()), e.floatEmbedding = t.slice();
						else {
							let r = /* @__PURE__ */ new Uint8Array(0);
							e.quantizedEmbedding = Pr(t, Po, 2)?.g()?.h() ?? r;
						}
						return e;
					}),
					timestampMs: Ya(sr(t, 2, void 0, fe) ?? nr)
				};
			}(t), tu(this, e);
		}), this.g.attachEmptyPacketListener("embeddings_out", (t) => {
			tu(this, t);
		}), t = t.g(), this.setGraph(new Uint8Array(t), !0);
	}
};
Ic.cosineSimilarity = function(t, e) {
	if (t.floatEmbedding && e.floatEmbedding) t = rh(t.floatEmbedding, e.floatEmbedding);
	else {
		if (!t.quantizedEmbedding || !e.quantizedEmbedding) throw Error("Cannot compute cosine similarity between quantized and float embeddings.");
		t = rh(eh(t.quantizedEmbedding), eh(e.quantizedEmbedding));
	}
	return t;
}, Ic.prototype.embedForVideo = Ic.prototype.Oa, Ic.prototype.embed = Ic.prototype.Na, Ic.prototype.setOptions = Ic.prototype.v, Ic.createFromModelPath = function(t, e) {
	return Zu(Ic, t, { baseOptions: { modelAssetPath: e } });
}, Ic.createFromModelBuffer = function(t, e) {
	return Zu(Ic, t, { baseOptions: { modelAssetBuffer: e } });
}, Ic.createFromOptions = function(t, e) {
	return Zu(Ic, t, e);
};
var Fc = class {
	constructor(t, e, r) {
		this.confidenceMasks = t, this.categoryMask = e, this.qualityScores = r;
	}
	close() {
		this.confidenceMasks?.forEach((t) => {
			t.close();
		}), this.categoryMask?.close();
	}
};
function Cc(t) {
	var e = function(t) {
		return xr(t, ho, 1);
	}(t.ja()).filter((t) => (_e(sr(t, 1)) ?? "").includes("mediapipe.tasks.TensorsToSegmentationCalculator"));
	if (t.u = [], e.length > 1) throw Error("The graph has more than one mediapipe.tasks.TensorsToSegmentationCalculator.");
	1 === e.length && (Sr(e[0], no, 7)?.o()?.g() ?? /* @__PURE__ */ new Map()).forEach((e, r) => {
		t.u[Number(r)] = _e(sr(e, 1)) ?? "";
	});
}
function Nc(t) {
	t.categoryMask = void 0, t.confidenceMasks = void 0, t.qualityScores = void 0;
}
function Mc(t) {
	try {
		let e = new Fc(t.confidenceMasks, t.categoryMask, t.qualityScores);
		if (!t.l) return e;
		t.l(e);
	} finally {
		nu(t);
	}
}
Fc.prototype.close = Fc.prototype.close;
var Oc = class extends nc {
	constructor(t, e) {
		super(new Ju(t, e), "image_in", "norm_rect", !1), this.u = [], this.outputCategoryMask = !1, this.outputConfidenceMasks = !0, this.h = new Na(), this.B = new Ra(), Ir(this.h, 0, 3, this.B), Ir(t = this.h, 0, 1, e = new zo());
	}
	C() {
		return "ImageSegmenter";
	}
	get baseOptions() {
		return Sr(this.h, zo, 1);
	}
	set baseOptions(t) {
		Ir(this.h, 0, 1, t);
	}
	v(t) {
		return void 0 !== t.displayNamesLocale ? ar(this.h, 2, ve(t.displayNamesLocale)) : "displayNamesLocale" in t && ar(this.h, 2), "outputCategoryMask" in t && (this.outputCategoryMask = t.outputCategoryMask ?? !1), "outputConfidenceMasks" in t && (this.outputConfidenceMasks = t.outputConfidenceMasks ?? !0), super.j(t);
	}
	L() {
		Cc(this);
	}
	segment(t, e, r) {
		var n = "function" != typeof e ? e : {};
		return this.l = "function" == typeof e ? e : r, Nc(this), tc(this, t, n), Mc(this);
	}
	eb(t, e, r, n) {
		var i = "function" != typeof r ? r : {};
		return this.l = "function" == typeof r ? r : n, Nc(this), ec(this, t, i, e), Mc(this);
	}
	Ra() {
		return this.u;
	}
	o() {
		var t = new mo();
		po(t, "image_in"), po(t, "norm_rect");
		var e = new no();
		li(e, Ma, this.h);
		var r = new ho();
		Hr(r, 2, "mediapipe.tasks.vision.image_segmenter.ImageSegmenterGraph"), oo(r, "IMAGE:image_in"), oo(r, "NORM_RECT:norm_rect"), r.v(e), fo(t, r), eu(this, t), this.outputConfidenceMasks && (go(t, "confidence_masks"), ao(r, "CONFIDENCE_MASKS:confidence_masks"), ru(this, "confidence_masks"), this.g.ha("confidence_masks", (t, e) => {
			this.confidenceMasks = t.map((t) => rc(this, t, !0, !this.l)), tu(this, e);
		}), this.g.attachEmptyPacketListener("confidence_masks", (t) => {
			this.confidenceMasks = [], tu(this, t);
		})), this.outputCategoryMask && (go(t, "category_mask"), ao(r, "CATEGORY_MASK:category_mask"), ru(this, "category_mask"), this.g.ga("category_mask", (t, e) => {
			this.categoryMask = rc(this, t, !1, !this.l), tu(this, e);
		}), this.g.attachEmptyPacketListener("category_mask", (t) => {
			this.categoryMask = void 0, tu(this, t);
		})), go(t, "quality_scores"), ao(r, "QUALITY_SCORES:quality_scores"), this.g.attachFloatVectorListener("quality_scores", (t, e) => {
			this.qualityScores = t, tu(this, e);
		}), this.g.attachEmptyPacketListener("quality_scores", (t) => {
			this.categoryMask = void 0, tu(this, t);
		}), t = t.g(), this.setGraph(new Uint8Array(t), !0);
	}
};
Oc.prototype.getLabels = Oc.prototype.Ra, Oc.prototype.segmentForVideo = Oc.prototype.eb, Oc.prototype.segment = Oc.prototype.segment, Oc.prototype.setOptions = Oc.prototype.v, Oc.createFromModelPath = function(t, e) {
	return Zu(Oc, t, { baseOptions: { modelAssetPath: e } });
}, Oc.createFromModelBuffer = function(t, e) {
	return Zu(Oc, t, { baseOptions: { modelAssetBuffer: e } });
}, Oc.createFromOptions = function(t, e) {
	return Zu(Oc, t, e);
};
var Dc = {
	0: 0,
	1: 1,
	2: 2,
	3: 3
};
function Pc() {
	return Ph() ? void 0 : document.createElement("canvas");
}
var $c = class extends iu {
	constructor(t, e) {
		super(new Yh(t, e)), this.u = new pu(), this.delegate = "CPU", this.h = 0, this.baseOptions = new zo(), this.B = this.l = 0;
	}
	C() {
		return "InteractiveSegmenter";
	}
	get i() {
		return this.g.i;
	}
	v(t) {
		return this.delegate = t.baseOptions?.delegate ?? "CPU", super.j(t);
	}
	fb(t) {
		if (0 === this.h) throw Error("Segmenter is not initialized.");
		var e;
		if (0 !== this.l && (this.i._free(this.l), this.l = 0), !(e = "undefined" != typeof ImageData && t instanceof ImageData)) if ("object" != typeof t || null === t) e = !1;
		else {
			e = t.data;
			var r = t.width, n = t.height;
			e = Number.isInteger(r) && r > 0 && Number.isInteger(n) && n > 0 && (e instanceof Uint8ClampedArray || e instanceof Uint8Array);
		}
		if (e) e = t.width, r = t.height, t = t.data;
		else {
			if ([e, r] = Uh(t), "undefined" != typeof OffscreenCanvas) n = new OffscreenCanvas(e, r);
			else {
				if ("undefined" == typeof document) throw Error("Canvas is not supported in this environment.");
				n = document.createElement("canvas");
			}
			if (n.width = e, n.height = r, !(n = n.getContext("2d"))) throw Error("Canvas 2D context is not supported in this environment.");
			n.drawImage(t, 0, 0), t = n.getImageData(0, 0, e, r).data;
		}
		if (!t) throw Error("Unsupported image source or failed to extract image pixels.");
		n = function({ Wa: t, width: e, height: r }) {
			if (e <= 0 || r <= 0) throw Error(`Invalid image dimensions: ${e}x${r}. Dimensions must be positive.`);
			if (t % (e * r) !== 0) throw Error(`Invalid image dimensions or pixel data length. Pixel data length ${t} is not a multiple of the number of pixels (${e * r}).`);
			if (4 !== (t /= e * r) && 3 !== t && 1 !== t) throw Error(`Invalid image dimensions or pixel data length. Calculated channels: ${t}. Expected 1, 3, or 4.`);
			return t;
		}({
			Wa: t.length,
			width: e,
			height: r
		});
		var i = this.i._malloc(t.length);
		if (this.i.HEAPU8.set(t, i), this.l = i, !this.i._interactive_segmenter_set_image(this.h, i, e, r, n)) throw Error("Failed to set image on native engine.");
	}
	segment(t) {
		if (0 === this.h) throw Error("Segmenter is not initialized.");
		var e = function(t) {
			t = t.map(({ isCompleted: t, brushMode: e, point: r }) => {
				e = Dc[e] ?? 0, r = r.map(({ x: t, y: e }) => {
					var r = new Oa();
					return Vr(r, 1, t), Vr(r, 2, e), r;
				});
				var n = new Da();
				return $r(n, t), _r(n, 1, ee(e), 0), Cr(n, 2, r), n;
			});
			var e = new Pa();
			return Cr(e, 1, t), $a(e);
		}(t);
		t = this.i._malloc(e.length), this.i.HEAPU8.set(e, t);
		var r = this.i._malloc(12), n = r + 4, i = r + 8, s = 0, o = this.B++;
		try {
			if (this.m) if ("GPU" === this.delegate) {
				var a = this.m;
				++a.g.T, a.h.set(o, performance.now());
			} else {
				var h = this.m;
				++h.g.P, h.h.set(o, performance.now());
			}
			if (0 === (s = this.i._interactive_segmenter_segment(this.h, t, e.length, r, n, i))) throw Error("Segmentation failed.");
			this.m?.za(o);
			let c = this.i.HEAPU32[r / 4], l = this.i.HEAPU32[n / 4], d = new Float32Array(this.i.HEAPU8.buffer, s, this.i.HEAPU32[i / 4] / 4);
			var u = new Float32Array(d);
			if (a = c * l, (u instanceof Uint8Array || u instanceof Float32Array) && u.length !== a) throw Error("Unsupported channel count: " + u.length / a);
			return new Su([u], !0, !1, this.g.i.canvas ?? void 0, this.u, c, l);
		} finally {
			0 !== t && this.i._free(t), 0 !== r && this.i._free(r), 0 !== s && this.i._free(s);
		}
	}
	o() {
		0 !== this.h && (this.m?.xa(), this.i._interactive_segmenter_close(this.h), this.h = 0), 0 !== this.l && (this.i._free(this.l), this.l = 0);
		var t = new Ko();
		if ("GPU" === this.delegate) {
			var e = new Ys();
			Fr(t, 2, Xo, e);
		} else Ur(e = new eo(), 1, 4), Fr(t, 1, Xo, e);
		if (Ir(this.baseOptions, 0, 3, t), t = Jo(this.baseOptions), e = this.i._malloc(t.length), this.i.HEAPU8.set(t, e), this.h = this.i._interactive_segmenter_create(e, t.length), this.i._free(e), 0 === this.h) throw Error("Failed to create native InteractiveSegmenter engine.");
		this.m?.ya();
	}
	close() {
		0 !== this.h && (this.i._interactive_segmenter_close(this.h), this.h = 0), 0 !== this.l && (this.i._free(this.l), this.l = 0), this.u.close(), super.close();
	}
};
$c.prototype.close = $c.prototype.close, $c.prototype.segment = $c.prototype.segment, $c.prototype.setImage = $c.prototype.fb, $c.prototype.setOptions = $c.prototype.v, $c.createFromModelPath = function(t, e) {
	return Jh($c, Pc(), t, { baseOptions: { modelAssetPath: e } });
}, $c.createFromModelBuffer = function(t, e) {
	return Jh($c, Pc(), t, { baseOptions: { modelAssetBuffer: e } });
}, $c.createFromOptions = function(t, e) {
	return Jh($c, e.canvas ?? Pc(), t, e);
};
var Uc = class {
	constructor(t, e, r) {
		this.confidenceMasks = t, this.categoryMask = e, this.qualityScores = r;
	}
	close() {
		this.confidenceMasks?.forEach((t) => {
			t.close();
		}), this.categoryMask?.close();
	}
};
Uc.prototype.close = Uc.prototype.close;
var Bc = class extends nc {
	constructor(t, e) {
		super(new Ju(t, e), "image_in", "norm_rect_in", !1), this.outputCategoryMask = !1, this.outputConfidenceMasks = !0, this.h = new Na(), this.u = new Ra(), Ir(this.h, 0, 3, this.u), Ir(t = this.h, 0, 1, e = new zo());
	}
	C() {
		return "InteractiveSegmenterLegacy";
	}
	get baseOptions() {
		return Sr(this.h, zo, 1);
	}
	set baseOptions(t) {
		Ir(this.h, 0, 1, t);
	}
	v(t) {
		return "outputCategoryMask" in t && (this.outputCategoryMask = t.outputCategoryMask ?? !1), "outputConfidenceMasks" in t && (this.outputConfidenceMasks = t.outputConfidenceMasks ?? !0), super.j(t);
	}
	segment(t, e, r, n) {
		var i = "function" != typeof r ? r : {};
		if (this.l = "function" == typeof r ? r : n, this.qualityScores = this.categoryMask = this.confidenceMasks = void 0, r = this.I + 1, n = new ja(), e.keypoint && e.scribble) throw Error("Cannot provide both keypoint and scribble.");
		if (e.keypoint) {
			var s = new Ua();
			$r(s, !0), Vr(s, 1, e.keypoint.x), Vr(s, 2, e.keypoint.y), Fr(n, 1, Va, s);
		} else {
			if (!e.scribble) throw Error("Must provide either a keypoint or a scribble.");
			{
				let t = new Ga();
				for (s of e.scribble) $r(e = new Ua(), !0), Vr(e, 1, s.x), Vr(e, 2, s.y), Mr(t, 1, Ua, e);
				Fr(n, 2, Va, t);
			}
		}
		this.g.addProtoToStream(n.g(), "mediapipe.tasks.vision.interactive_segmenter_legacy.proto.RegionOfInterest", "roi_in", r), tc(this, t, i);
		t: {
			try {
				let t = new Uc(this.confidenceMasks, this.categoryMask, this.qualityScores);
				if (!this.l) {
					var o = t;
					break t;
				}
				this.l(t);
			} finally {
				nu(this);
			}
			o = void 0;
		}
		return o;
	}
	o() {
		var t = new mo();
		po(t, "image_in"), po(t, "roi_in"), po(t, "norm_rect_in");
		var e = new no();
		li(e, Ma, this.h);
		var r = new ho();
		Hr(r, 2, "mediapipe.tasks.vision.interactive_segmenter_legacy.InteractiveSegmenterGraphV2"), oo(r, "IMAGE:image_in"), oo(r, "ROI:roi_in"), oo(r, "NORM_RECT:norm_rect_in"), r.v(e), fo(t, r), eu(this, t), this.outputConfidenceMasks && (go(t, "confidence_masks"), ao(r, "CONFIDENCE_MASKS:confidence_masks"), ru(this, "confidence_masks"), this.g.ha("confidence_masks", (t, e) => {
			this.confidenceMasks = t.map((t) => rc(this, t, !0, !this.l)), tu(this, e);
		}), this.g.attachEmptyPacketListener("confidence_masks", (t) => {
			this.confidenceMasks = [], tu(this, t);
		})), this.outputCategoryMask && (go(t, "category_mask"), ao(r, "CATEGORY_MASK:category_mask"), ru(this, "category_mask"), this.g.ga("category_mask", (t, e) => {
			this.categoryMask = rc(this, t, !1, !this.l), tu(this, e);
		}), this.g.attachEmptyPacketListener("category_mask", (t) => {
			this.categoryMask = void 0, tu(this, t);
		})), go(t, "quality_scores"), ao(r, "QUALITY_SCORES:quality_scores"), this.g.attachFloatVectorListener("quality_scores", (t, e) => {
			this.qualityScores = t, tu(this, e);
		}), this.g.attachEmptyPacketListener("quality_scores", (t) => {
			this.categoryMask = void 0, tu(this, t);
		}), t = t.g(), this.setGraph(new Uint8Array(t), !0);
	}
};
Bc.prototype.segment = Bc.prototype.segment, Bc.prototype.setOptions = Bc.prototype.v, Bc.createFromModelPath = function(t, e) {
	return Zu(Bc, t, { baseOptions: { modelAssetPath: e } });
}, Bc.createFromModelBuffer = function(t, e) {
	return Zu(Bc, t, { baseOptions: { modelAssetBuffer: e } });
}, Bc.createFromOptions = function(t, e) {
	return Zu(Bc, t, e);
};
var Gc = class extends nc {
	constructor(t, e) {
		super(new Ju(t, e), "input_frame_gpu", "norm_rect", !1), this.l = { detections: [] }, Ir(t = this.h = new Ha(), 0, 1, e = new zo());
	}
	C() {
		return "ObjectDetector";
	}
	get baseOptions() {
		return Sr(this.h, zo, 1);
	}
	set baseOptions(t) {
		Ir(this.h, 0, 1, t);
	}
	v(t) {
		return void 0 !== t.displayNamesLocale ? ar(this.h, 2, ve(t.displayNamesLocale)) : "displayNamesLocale" in t && ar(this.h, 2), void 0 !== t.maxResults ? Ur(this.h, 3, t.maxResults) : "maxResults" in t && ar(this.h, 3), void 0 !== t.scoreThreshold ? jr(this.h, 4, t.scoreThreshold) : "scoreThreshold" in t && ar(this.h, 4), void 0 !== t.categoryAllowlist ? Kr(this.h, 5, t.categoryAllowlist) : "categoryAllowlist" in t && ar(this.h, 5), void 0 !== t.categoryDenylist ? Kr(this.h, 6, t.categoryDenylist) : "categoryDenylist" in t && ar(this.h, 6), this.j(t);
	}
	G(t, e) {
		return this.l = { detections: [] }, tc(this, t, e), this.l;
	}
	H(t, e, r) {
		return this.l = { detections: [] }, ec(this, t, r, e), this.l;
	}
	o() {
		var t = new mo();
		po(t, "input_frame_gpu"), po(t, "norm_rect"), go(t, "detections");
		var e = new no();
		li(e, Ka, this.h);
		var r = new ho();
		Hr(r, 2, "mediapipe.tasks.vision.ObjectDetectorGraph"), oo(r, "IMAGE:input_frame_gpu"), oo(r, "NORM_RECT:norm_rect"), ao(r, "DETECTIONS:detections"), r.v(e), fo(t, r), this.g.attachProtoVectorListener("detections", (t, e) => {
			for (let e of t) t = So(e), this.l.detections.push(Za(t));
			tu(this, e);
		}), this.g.attachEmptyPacketListener("detections", (t) => {
			tu(this, t);
		}), t = t.g(), this.setGraph(new Uint8Array(t), !0);
	}
};
Gc.prototype.detectForVideo = Gc.prototype.H, Gc.prototype.detect = Gc.prototype.G, Gc.prototype.setOptions = Gc.prototype.v, Gc.createFromModelPath = async function(t, e) {
	return Zu(Gc, t, { baseOptions: { modelAssetPath: e } });
}, Gc.createFromModelBuffer = function(t, e) {
	return Zu(Gc, t, { baseOptions: { modelAssetBuffer: e } });
}, Gc.createFromOptions = function(t, e) {
	return Zu(Gc, t, e);
};
var jc = class {
	constructor(t, e, r) {
		this.landmarks = t, this.worldLandmarks = e, this.segmentationMasks = r;
	}
	close() {
		this.segmentationMasks?.forEach((t) => {
			t.close();
		});
	}
};
function Vc(t) {
	t.landmarks = [], t.worldLandmarks = [], t.segmentationMasks = void 0;
}
function Hc(t) {
	try {
		let e = new jc(t.landmarks, t.worldLandmarks, t.segmentationMasks);
		if (!t.u) return e;
		t.u(e);
	} finally {
		nu(t);
	}
}
jc.prototype.close = jc.prototype.close;
var Kc = class extends nc {
	constructor(t, e) {
		super(new Ju(t, e), "image_in", "norm_rect", !1), this.landmarks = [], this.worldLandmarks = [], this.outputSegmentationMasks = !1, Ir(t = this.h = new Xa(), 0, 1, e = new zo()), this.B = new Aa(), Ir(this.h, 0, 3, this.B), this.l = new Ea(), Ir(this.h, 0, 2, this.l), Ur(this.l, 4, 1), jr(this.l, 2, .5), jr(this.B, 2, .5), jr(this.h, 4, .5);
	}
	C() {
		return "PoseLandmarker";
	}
	get baseOptions() {
		return Sr(this.h, zo, 1);
	}
	set baseOptions(t) {
		Ir(this.h, 0, 1, t);
	}
	v(t) {
		return "numPoses" in t && Ur(this.l, 4, t.numPoses ?? 1), "minPoseDetectionConfidence" in t && jr(this.l, 2, t.minPoseDetectionConfidence ?? .5), "minTrackingConfidence" in t && jr(this.h, 4, t.minTrackingConfidence ?? .5), "minPosePresenceConfidence" in t && jr(this.B, 2, t.minPosePresenceConfidence ?? .5), "outputSegmentationMasks" in t && (this.outputSegmentationMasks = t.outputSegmentationMasks ?? !1), this.j(t);
	}
	G(t, e, r) {
		var n = "function" != typeof e ? e : {};
		return this.u = "function" == typeof e ? e : r, Vc(this), tc(this, t, n), Hc(this);
	}
	H(t, e, r, n) {
		var i = "function" != typeof r ? r : {};
		return this.u = "function" == typeof r ? r : n, Vc(this), ec(this, t, i, e), Hc(this);
	}
	o() {
		var t = new mo();
		po(t, "image_in"), po(t, "norm_rect"), go(t, "normalized_landmarks"), go(t, "world_landmarks"), go(t, "segmentation_masks");
		var e = new no();
		li(e, Wa, this.h);
		var r = new ho();
		Hr(r, 2, "mediapipe.tasks.vision.pose_landmarker.PoseLandmarkerGraph"), oo(r, "IMAGE:image_in"), oo(r, "NORM_RECT:norm_rect"), ao(r, "NORM_LANDMARKS:normalized_landmarks"), ao(r, "WORLD_LANDMARKS:world_landmarks"), r.v(e), fo(t, r), eu(this, t), this.g.attachProtoVectorListener("normalized_landmarks", (t, e) => {
			this.landmarks = [];
			for (let e of t) t = Io(e), this.landmarks.push(Qa(t));
			tu(this, e);
		}), this.g.attachEmptyPacketListener("normalized_landmarks", (t) => {
			this.landmarks = [], tu(this, t);
		}), this.g.attachProtoVectorListener("world_landmarks", (t, e) => {
			this.worldLandmarks = [];
			for (let e of t) t = xo(e), this.worldLandmarks.push(th(t));
			tu(this, e);
		}), this.g.attachEmptyPacketListener("world_landmarks", (t) => {
			this.worldLandmarks = [], tu(this, t);
		}), this.outputSegmentationMasks && (ao(r, "SEGMENTATION_MASK:segmentation_masks"), ru(this, "segmentation_masks"), this.g.ha("segmentation_masks", (t, e) => {
			this.segmentationMasks = t.map((t) => rc(this, t, !0, !this.u)), tu(this, e);
		}), this.g.attachEmptyPacketListener("segmentation_masks", (t) => {
			this.segmentationMasks = [], tu(this, t);
		})), t = t.g(), this.setGraph(new Uint8Array(t), !0);
	}
};
Kc.prototype.detectForVideo = Kc.prototype.H, Kc.prototype.detect = Kc.prototype.G, Kc.prototype.setOptions = Kc.prototype.v, Kc.createFromModelPath = function(t, e) {
	return Zu(Kc, t, { baseOptions: { modelAssetPath: e } });
}, Kc.createFromModelBuffer = function(t, e) {
	return Zu(Kc, t, { baseOptions: { modelAssetBuffer: e } });
}, Kc.createFromOptions = function(t, e) {
	return Zu(Kc, t, e);
}, Kc.POSE_CONNECTIONS = Tc, r("module$exports$google3$third_party$mediapipe$tasks$web$vision$pose_landmarker$pose_landmarker.PoseLandmarker.POSE_CONNECTIONS", Kc.POSE_CONNECTIONS);
//#endregion
//#region src/pose/landmarker.ts
async function createPoseLandmarker(model) {
	const vision = await ah.forVisionTasks(WASM_BASE_PATH);
	const create = (delegate) => Kc.createFromOptions(vision, {
		baseOptions: {
			modelAssetPath: POSE_MODELS[model].path,
			delegate
		},
		runningMode: "VIDEO",
		numPoses: 2
	});
	try {
		return {
			landmarker: await create("GPU"),
			delegate: "GPU",
			model
		};
	} catch {
		return {
			landmarker: await create("CPU"),
			delegate: "CPU",
			model
		};
	}
}
//#endregion
//#region src/avatar/observedHandRig.ts
var sides = ["left", "right"];
Object.freeze(sides.flatMap((side) => {
	const suffix = side === "left" ? "L" : "R";
	return Array.from({ length: 15 }, (_, i) => Object.freeze({
		side,
		bone: `finger${Math.floor(i / 3) + 1}-${i % 3 + 1}${suffix}`,
		parent: i % 3 ? `finger${Math.floor(i / 3) + 1}-${i % 3}${suffix}` : i < 3 ? `wrist${suffix}` : `metacarpal${Math.floor(i / 3)}${suffix}`,
		from: Math.floor(i / 3) * 4 + 1 + i % 3,
		to: Math.floor(i / 3) * 4 + 2 + i % 3
	}));
}));
function copyHandObservations(value) {
	if (!Array.isArray(value) || value.length > 2) return Object.freeze([]);
	const copied = [];
	const seen = /* @__PURE__ */ new Set();
	for (const hand of value) {
		const side = hand?.side;
		if (!sides.includes(side) || seen.has(side)) return Object.freeze([]);
		seen.add(side);
		const image = hand.landmarks, world = hand.worldLandmarks;
		if (!Array.isArray(image) || !Array.isArray(world) || image.length !== 21 || world.length !== 21) continue;
		const points = (array) => Object.freeze(Array.from(array, (p) => Object.freeze(p ? {
			x: p.x,
			y: p.y,
			z: p.z
		} : {
			x: NaN,
			y: NaN,
			z: NaN
		})));
		copied.push(Object.freeze({
			side,
			landmarks: points(image),
			worldLandmarks: points(world)
		}));
	}
	return Object.freeze(copied);
}
//#endregion
//#region src/coaching/resources.ts
var ResourceCleanupError = class extends Error {
	constructor() {
		super("Resource cleanup failed");
	}
};
//#endregion
//#region src/posture/capturedImage.ts
function copyCapturedImage(image) {
	if (image === void 0) return void 0;
	const { width, height, imageIsMirrored } = image;
	if (!Number.isSafeInteger(width) || width <= 0 || !Number.isSafeInteger(height) || height <= 0 || typeof imageIsMirrored !== "boolean") throw new Error("Invalid captured image");
	return Object.freeze({
		width,
		height,
		imageIsMirrored
	});
}
//#endregion
//#region src/posture/landmarks.ts
/** 화면 좌표(0~1)가 카메라 화면 안에 있는가 */
var isInFrame = (p) => Number.isFinite(p.x) && Number.isFinite(p.y) && Number.isFinite(p.z) && p.x >= 0 && p.x <= 1 && p.y >= 0 && p.y <= 1;
//#endregion
//#region src/pose/ownedPoseFrame.ts
function copyPosePoints(poses) {
	if (!Array.isArray(poses) || poses.length > 2) throw new Error();
	return Object.freeze(poses.map((points) => {
		if (!Array.isArray(points) || points.length > 33) throw new Error();
		return Object.freeze(points.map((point) => {
			const { x, y, z, visibility, presence } = point;
			if (typeof x !== "number" || typeof y !== "number" || typeof z !== "number") throw new Error();
			if (presence !== void 0 && typeof presence !== "number") throw new Error();
			return Object.freeze({
				x,
				y,
				z,
				...typeof visibility === "number" ? { visibility } : {},
				...presence === void 0 ? {} : { presence }
			});
		}));
	}));
}
function copyHead(value) {
	if (value === void 0) return {};
	if (value === null) return { headOrientation: null };
	if (!Array.isArray(value)) throw new Error();
	const copied = Array.from(value);
	if (copied.length !== 4 || !copied.every(Number.isFinite) || Math.abs(Math.hypot(...copied) - 1) > 1e-5) throw new Error();
	return { headOrientation: Object.freeze(copied) };
}
/** Private frame boundary. Capture supplies borrowed input with original stamps.
* Detect must return a fresh exclusively owned result; partial failure cleanup stays
* provider-owned. Caller owns the detector/camera and must retire its session on a
* read failure. This source neither authenticates nor starts a coaching session.
*/
function createOwnedPoseFrame(context, ports) {
	const { generation, signal } = context;
	if (!Number.isSafeInteger(generation) || generation <= 0 || typeof ports.capture !== "function" || typeof ports.detect !== "function") throw new Error("Invalid pose frame source");
	let closed = signal.aborted;
	let cleanupFailed = false;
	let lastSequence = 0, lastAt = -Infinity;
	let pending;
	const alive = () => !closed && !signal.aborted;
	function close() {
		closed = true;
		signal.removeEventListener("abort", close);
	}
	if (!closed) signal.addEventListener("abort", close, { once: true });
	async function acquire() {
		let result;
		let release;
		let frame = null;
		let failed = false;
		try {
			const captured = await ports.capture();
			if (!captured || !alive()) return null;
			const suppliedGeneration = captured.generation, sequence = captured.sequence, at = captured.at;
			if (suppliedGeneration !== generation || !Number.isSafeInteger(sequence) || sequence <= lastSequence || !Number.isFinite(at) || at < 0 || at <= lastAt) return null;
			const input = captured.input;
			const image = copyCapturedImage(captured.image);
			if (!alive()) return null;
			lastSequence = sequence;
			lastAt = at;
			result = await ports.detect(input, at);
			try {
				release = result.close;
				if (typeof release !== "function") throw new Error();
			} catch {
				cleanupFailed = true;
			}
			if (!cleanupFailed && alive()) {
				const suppliedHands = result.hands;
				frame = Object.freeze({
					generation: suppliedGeneration,
					sequence,
					at,
					...image === void 0 ? {} : { image },
					result: Object.freeze({
						landmarks: copyPosePoints(result.landmarks),
						worldLandmarks: copyPosePoints(result.worldLandmarks),
						...copyHead(result.headOrientation),
						...suppliedHands === void 0 ? {} : { hands: copyHandObservations(suppliedHands) }
					})
				});
			}
		} catch (error) {
			if (error instanceof ResourceCleanupError) cleanupFailed = true;
			else failed = true;
		} finally {
			if (result && release) try {
				release.call(result);
			} catch {
				cleanupFailed = true;
			}
		}
		if (cleanupFailed) {
			close();
			throw new ResourceCleanupError();
		}
		if (failed && alive()) {
			close();
			throw new Error("Pose frame unavailable");
		}
		return alive() ? frame : null;
	}
	function read() {
		if (!alive() || pending) return Promise.resolve(null);
		let resolve;
		let reject;
		pending = new Promise((yes, no) => {
			resolve = yes;
			reject = no;
		});
		const reading = pending;
		acquire().then(resolve, reject);
		pending.then(() => {
			pending = void 0;
		}, () => {
			pending = void 0;
		});
		return reading;
	}
	async function dispose() {
		close();
		await pending;
		if (cleanupFailed) throw new ResourceCleanupError();
	}
	return Object.freeze({
		read,
		dispose
	});
}
//#endregion
//#region src/pose/videoPoseSource.ts
function createVideoPoseSource(context, ports) {
	const { video, stream, detect } = ports;
	const { generation, signal } = context;
	if (typeof VideoFrame !== "function" || typeof video.requestVideoFrameCallback !== "function" || typeof video.cancelVideoFrameCallback !== "function" || typeof stream.getVideoTracks !== "function" || typeof detect !== "function") throw new Error("Invalid video pose source");
	const tracks = stream.getVideoTracks();
	if (tracks.length !== 1 || tracks[0].kind !== "video") throw new Error("Invalid video pose source");
	let closed = signal.aborted, invalid = false, cleanupFailed = false;
	let lastSequence = 0, lastAt = -Infinity, lastMedia = -Infinity;
	let disposal;
	const inputs = /* @__PURE__ */ new Set();
	let pending = null;
	function owns() {
		const current = stream.getVideoTracks();
		return !closed && !invalid && !signal.aborted && video.srcObject === stream && stream.active && current.length === 1 && current[0] === tracks[0] && tracks[0].readyState === "live" && tracks[0].enabled && !tracks[0].muted;
	}
	function release(frame) {
		if (!inputs.delete(frame)) return;
		try {
			frame.close();
		} catch {
			cleanupFailed = true;
		}
	}
	function cancel(reject = false) {
		const reservation = pending;
		pending = null;
		if (!reservation) return;
		reservation.live = false;
		try {
			if (reservation.id !== null) video.cancelVideoFrameCallback(reservation.id);
		} catch {
			cleanupFailed = true;
		}
		if (reject) reservation.reject(/* @__PURE__ */ new Error("Video capture unavailable"));
		else reservation.resolve(null);
	}
	function lost() {
		invalid = true;
		cancel(true);
	}
	const events = [
		"emptied",
		"error",
		"abort"
	];
	const core = createOwnedPoseFrame(Object.freeze({
		generation,
		signal
	}), {
		capture: () => {
			if (!owns()) throw new Error("Video capture unavailable");
			return new Promise((resolve, reject) => {
				const reservation = {
					id: null,
					live: true,
					resolve,
					reject
				};
				pending = reservation;
				try {
					const id = video.requestVideoFrameCallback((now, metadata) => {
						if (!reservation.live || pending !== reservation) return;
						reservation.live = false;
						pending = null;
						try {
							if (reservation.id === null || !owns() || video.readyState < 2) throw new Error("Video capture unavailable");
							const sequence = metadata.presentedFrames, mediaTime = metadata.mediaTime;
							if (!Number.isSafeInteger(sequence) || sequence <= lastSequence || !Number.isFinite(now) || now < 0 || now <= lastAt || !Number.isFinite(mediaTime) || mediaTime < 0 || mediaTime <= lastMedia || !Number.isSafeInteger(Math.round(mediaTime * 1e6))) {
								resolve(null);
								return;
							}
							const input = new VideoFrame(video, { timestamp: Math.round(mediaTime * 1e6) });
							inputs.add(input);
							const width = input.displayWidth, height = input.displayHeight;
							if (!Number.isSafeInteger(width) || width <= 0 || !Number.isSafeInteger(height) || height <= 0) {
								release(input);
								if (cleanupFailed) throw new ResourceCleanupError();
								throw new Error("Video capture unavailable");
							}
							lastSequence = sequence;
							lastAt = now;
							lastMedia = mediaTime;
							resolve({
								generation,
								sequence,
								at: now,
								input,
								image: Object.freeze({
									width,
									height,
									imageIsMirrored: false
								})
							});
						} catch (error) {
							reject(error instanceof ResourceCleanupError ? error : /* @__PURE__ */ new Error("Video capture unavailable"));
						}
					});
					if (!Number.isSafeInteger(id) || id < 0) throw new ResourceCleanupError();
					reservation.id = id;
					if (!reservation.live || pending !== reservation) try {
						video.cancelVideoFrameCallback(id);
					} catch {
						cleanupFailed = true;
					}
				} catch (error) {
					if (pending === reservation) pending = null;
					reservation.live = false;
					if (error instanceof ResourceCleanupError) cleanupFailed = true;
					reject(cleanupFailed ? new ResourceCleanupError() : /* @__PURE__ */ new Error("Video capture unavailable"));
				}
			});
		},
		detect: async (frame, at) => {
			let result, resultClose;
			let finished = false;
			function finish() {
				if (finished) return;
				finished = true;
				if (result) try {
					if (typeof resultClose !== "function") throw new Error();
					resultClose.call(result);
				} catch {
					cleanupFailed = true;
				}
				release(frame);
				if (cleanupFailed) throw new ResourceCleanupError();
			}
			try {
				if (!owns()) throw new Error("Video capture unavailable");
				result = await detect(frame, at);
				resultClose = result.close;
				if (!owns()) throw new Error("Video capture unavailable");
				const headOrientation = result.headOrientation;
				const hands = result.hands;
				return {
					landmarks: result.landmarks,
					worldLandmarks: result.worldLandmarks,
					...headOrientation === void 0 ? {} : { headOrientation },
					...hands === void 0 ? {} : { hands },
					close: finish
				};
			} catch (error) {
				finish();
				throw error instanceof ResourceCleanupError ? error : /* @__PURE__ */ new Error("Video capture unavailable");
			}
		}
	});
	function dispose() {
		if (disposal) return disposal;
		closed = true;
		let resolve, reject;
		disposal = new Promise((yes, no) => {
			resolve = yes;
			reject = no;
		});
		const finish = async () => {
			const unbind = [
				() => signal.removeEventListener("abort", aborted),
				...tracks.map((track) => () => track.removeEventListener("ended", lost)),
				...events.map((event) => () => video.removeEventListener(event, lost))
			];
			for (const action of unbind) try {
				action();
			} catch {
				cleanupFailed = true;
			}
			cancel();
			try {
				await core.dispose();
			} catch (error) {
				if (error instanceof ResourceCleanupError) cleanupFailed = true;
			} finally {
				for (const input of inputs) release(input);
			}
			if (cleanupFailed) throw new ResourceCleanupError();
		};
		finish().then(resolve, reject);
		return disposal;
	}
	function aborted() {
		dispose().catch(() => {});
	}
	if (!closed) {
		signal.addEventListener("abort", aborted, { once: true });
		for (const track of tracks) track.addEventListener("ended", lost);
		for (const event of events) video.addEventListener(event, lost);
	}
	async function read() {
		if (closed) return null;
		try {
			const frame = await core.read();
			if (closed) return null;
			if (!owns()) throw new Error("Video capture unavailable");
			return frame;
		} catch (error) {
			try {
				await dispose();
			} catch {
				cleanupFailed = true;
			}
			if (cleanupFailed || error instanceof ResourceCleanupError) throw new ResourceCleanupError();
			throw new Error("Video capture unavailable");
		}
	}
	return Object.freeze({
		read,
		dispose
	});
}
//#endregion
//#region src/pose/workerInference.ts
var unavailable$1 = () => /* @__PURE__ */ new Error("Worker inference unavailable");
var CLEANUP_LIMIT_MS = 5e3;
var RESPONSE_LIMIT_MS = 5e3;
async function createWorkerPoseInference(context, options) {
	const { generation, signal } = context;
	let config;
	try {
		config = Object.freeze({
			model: options.model,
			face: options.face,
			hands: options.hands,
			matrixLayout: options.matrixLayout
		});
		if (!Number.isSafeInteger(generation) || generation <= 0 || signal.aborted || typeof Worker !== "function" || typeof config.model !== "string" || !Object.hasOwn(POSE_MODELS, config.model) || typeof config.face !== "boolean" || typeof config.hands !== "boolean" || !["column-major", "row-major"].includes(config.matrixLayout)) throw unavailable$1();
	} catch {
		throw unavailable$1();
	}
	let worker;
	try {
		worker = new Worker(new URL(
			/* @vite-ignore */
			"/assets/nativeInference.worker-0PTDJHAy.js",
			"" + import.meta.url
		));
	} catch {
		throw unavailable$1();
	}
	let retiring = false, terminated = false, ready = false, cleanupFailed = false;
	let nextId = 0, lastAt = -Infinity;
	let pending;
	let resolveReady, rejectReady;
	const prepared = new Promise((resolve, reject) => {
		resolveReady = resolve;
		rejectReady = reject;
	});
	prepared.catch(() => {});
	let disposal;
	let finishDisposal;
	let cleanupTimer;
	let responseTimer;
	let responseDeadline;
	function clearResponseTimer() {
		if (responseTimer !== void 0) clearTimeout(responseTimer);
		responseTimer = void 0;
		responseDeadline = void 0;
	}
	function awaitResponse() {
		clearResponseTimer();
		responseDeadline = performance.now() + RESPONSE_LIMIT_MS;
		responseTimer = setTimeout(() => {
			responseTimer = void 0;
			failed();
		}, RESPONSE_LIMIT_MS);
	}
	function terminate() {
		if (terminated) return;
		terminated = true;
		signal.removeEventListener("abort", aborted);
		worker.removeEventListener("message", message);
		worker.removeEventListener("error", failed);
		worker.removeEventListener("messageerror", failed);
		if (cleanupTimer !== void 0) clearTimeout(cleanupTimer);
		clearResponseTimer();
		worker.terminate();
	}
	function rejectWork() {
		clearResponseTimer();
		const current = pending;
		pending = void 0;
		current?.reject(unavailable$1());
		if (!ready) rejectReady(unavailable$1());
	}
	function failed() {
		if (terminated) return;
		rejectWork();
		dispose().catch(() => {});
	}
	function message(event) {
		if (terminated) return;
		try {
			const data = event.data;
			if (!data || typeof data !== "object" || data.generation !== generation) throw unavailable$1();
			if (retiring) {
				if (data.type === "closed") finishDisposal?.(data.clean === true);
				return;
			}
			if (responseDeadline !== void 0 && performance.now() >= responseDeadline) throw unavailable$1();
			if (data.type === "ready" && data.id === 0 && !ready && !pending) {
				clearResponseTimer();
				ready = true;
				resolveReady();
				return;
			}
			if (data.type !== "result" || !ready || !pending || data.id !== pending.id || data.at !== pending.at || !data.result || typeof data.result !== "object") throw unavailable$1();
			const current = pending;
			clearResponseTimer();
			pending = void 0;
			const result = data.result;
			current.resolve({
				...result,
				close() {}
			});
		} catch {
			failed();
		}
	}
	function dispose() {
		if (disposal) return disposal;
		retiring = true;
		rejectWork();
		if (terminated) return Promise.reject(new ResourceCleanupError());
		disposal = new Promise((resolve, reject) => {
			finishDisposal = (clean) => {
				finishDisposal = void 0;
				clean = clean && !cleanupFailed;
				try {
					terminate();
				} catch {
					clean = false;
				}
				if (clean) resolve();
				else reject(new ResourceCleanupError());
			};
			cleanupTimer = setTimeout(() => finishDisposal?.(false), CLEANUP_LIMIT_MS);
			try {
				worker.postMessage({
					type: "close",
					generation
				});
			} catch {
				finishDisposal(false);
			}
		});
		return disposal;
	}
	function aborted() {
		dispose().catch(() => {});
	}
	worker.addEventListener("message", message);
	worker.addEventListener("error", failed);
	worker.addEventListener("messageerror", failed);
	signal.addEventListener("abort", aborted, { once: true });
	try {
		if (signal.aborted) {
			aborted();
			throw unavailable$1();
		}
		awaitResponse();
		worker.postMessage({
			type: "init",
			generation,
			id: 0,
			config
		});
		await prepared;
		if (retiring || signal.aborted) throw unavailable$1();
	} catch {
		if (!retiring) failed();
		if (disposal) await disposal;
		throw unavailable$1();
	}
	return Object.freeze({
		thread: "worker",
		async detect(frame, at) {
			if (retiring || terminated || signal.aborted || pending || !Number.isFinite(at) || at < 0 || at <= lastAt || nextId >= Number.MAX_SAFE_INTEGER) throw unavailable$1();
			let input;
			try {
				input = frame.clone();
				if (input.displayWidth <= 0 || input.displayHeight <= 0) throw unavailable$1();
				const id = ++nextId;
				lastAt = at;
				const task = new Promise((resolve, reject) => {
					pending = {
						id,
						at,
						resolve,
						reject
					};
				});
				try {
					awaitResponse();
					worker.postMessage({
						type: "frame",
						generation,
						id,
						at,
						frame: input
					}, [input]);
				} catch {
					failed();
				} finally {
					try {
						input.close();
					} catch {
						cleanupFailed = true;
						failed();
					}
					input = void 0;
				}
				return await task;
			} catch {
				throw unavailable$1();
			} finally {
				try {
					input?.close();
				} catch {
					cleanupFailed = true;
					failed();
				}
			}
		},
		dispose
	});
}
//#endregion
//#region src/posture/neckSideObservation.ts
var unavailable = Object.freeze({ status: "unavailable" });
var clock = (value) => Number.isFinite(value) && value >= 0 && value <= Number.MAX_SAFE_INTEGER;
var dimension = (value) => Number.isSafeInteger(value) && value > 0;
function observeCapturedNeckSide(input) {
	try {
		const { frame, now, minimumConfidence, maxAgeMs } = input;
		const image = frame.image;
		if (image === void 0) return unavailable;
		const { width, height, imageIsMirrored } = image;
		return observeNeckSide({
			frame,
			now,
			minimumConfidence,
			maxAgeMs,
			width,
			height,
			imageIsMirrored
		});
	} catch {
		return unavailable;
	}
}
function observeNeckSide(input) {
	try {
		const { frame, now, width, height, imageIsMirrored, minimumConfidence, maxAgeMs } = input;
		const { generation, sequence, at, result } = frame;
		if (!Number.isSafeInteger(generation) || generation <= 0 || !Number.isSafeInteger(sequence) || sequence < 0 || !clock(now) || !clock(at) || at > now || !clock(maxAgeMs) || maxAgeMs <= 0 || now - at > maxAgeMs || !dimension(width) || !dimension(height) || typeof imageIsMirrored !== "boolean" || !Number.isFinite(minimumConfidence) || minimumConfidence <= 0 || minimumConfidence > 1) return unavailable;
		const people = result.landmarks;
		if (!Array.isArray(people) || people.length !== 1) return unavailable;
		const image = people[0];
		if (!Array.isArray(image) || image.length !== 33) return unavailable;
		const points = [];
		for (const index of [
			0,
			7,
			8,
			11,
			12
		]) {
			const source = image[index];
			if (!source || typeof source !== "object") return unavailable;
			const { x, y, z, visibility, presence } = source;
			const point = {
				x,
				y,
				z,
				visibility
			};
			if (!isInFrame(point) || visibility === void 0 || !Number.isFinite(visibility) || visibility < minimumConfidence || visibility > 1 || presence !== void 0 && (!Number.isFinite(presence) || presence < minimumConfidence || presence > 1)) return unavailable;
			points.push(point);
		}
		const [, leftEar, rightEar, leftShoulder, rightShoulder] = points;
		const sign = imageIsMirrored ? -1 : 1;
		const delta = (a, b) => ({
			x: sign * (b.x - a.x) * width,
			y: (a.y - b.y) * height
		});
		const shoulder = delta(leftShoulder, rightShoulder), ears = delta(leftEar, rightEar);
		const shoulderLength = Math.hypot(shoulder.x, shoulder.y), earLength = Math.hypot(ears.x, ears.y);
		if (!(shoulderLength > 0) || !(earLength > 0)) return unavailable;
		const sx = shoulder.x / shoulderLength, sy = shoulder.y / shoulderLength;
		const ex = ears.x / earLength, ey = ears.y / earLength;
		const left = delta(leftShoulder, leftEar), right = delta(rightShoulder, rightEar);
		const offsetX = (left.x + right.x) / 2, offsetY = (left.y + right.y) / 2;
		const values = {
			headShoulderLineAngleRad: Math.atan2(sx * ey - sy * ex, sx * ex + sy * ey),
			shoulderImageAngleRad: Math.atan2(sy, sx),
			leftEarShoulderDistanceInShoulderWidths: Math.hypot(left.x, left.y) / shoulderLength,
			rightEarShoulderDistanceInShoulderWidths: Math.hypot(right.x, right.y) / shoulderLength,
			headOffsetAlongShoulder: (offsetX * sx + offsetY * sy) / shoulderLength,
			headOffsetNormalToShoulder: (sx * offsetY - sy * offsetX) / shoulderLength
		};
		if (!Object.values(values).every(Number.isFinite)) return unavailable;
		return Object.freeze({
			status: "available",
			space: "image-plane-only",
			generation,
			sequence,
			at,
			...values
		});
	} catch {
		return unavailable;
	}
}
//#endregion
//#region e2e/fixtures/capturedNeckProbe.ts
async function mountCapturedNeckProbe(mode) {
	const video = document.createElement("video"), abort = new AbortController();
	video.muted = video.playsInline = video.hidden = true;
	video.style.transform = "scaleX(-1)";
	document.body.append(video);
	let stream, source;
	let disposeInference;
	let frames = 0, closes = 0, nativeResults = 0, unavailable = 0, syntheticChecks = 0;
	let sourceGeometryMatches = true, syntheticChecksPassed = true, closed = false;
	let captured;
	const NativeFrame = globalThis.VideoFrame;
	class TrackedFrame extends NativeFrame {
		constructor(input, options) {
			if (options && "codedWidth" in options) super(input, options);
			else super(input, options);
			frames++;
		}
		close() {
			closes++;
			super.close();
		}
	}
	globalThis.VideoFrame = TrackedFrame;
	async function close() {
		if (closed) return snapshot();
		closed = true;
		abort.abort();
		try {
			await source?.dispose();
		} finally {
			try {
				await disposeInference?.();
			} finally {
				if (stream) closeCamera(video, stream);
				video.remove();
				globalThis.VideoFrame = NativeFrame;
			}
		}
		return snapshot();
	}
	function snapshot() {
		return {
			frames,
			closes,
			nativeResults,
			unavailable,
			syntheticChecks,
			sourceGeometryMatches,
			syntheticChecksPassed,
			closed,
			tracksEnded: stream?.getTracks().every((t) => t.readyState === "ended") ?? true,
			detached: video.srcObject === null,
			rawVideoHidden: video.hidden,
			actualHuman: false,
			actualCamera: false
		};
	}
	try {
		stream = await openCamera(video, abort.signal);
		const native = mode === "main" ? await createPoseLandmarker("lite") : void 0;
		const worker = mode === "worker" ? await createWorkerPoseInference({
			generation: 1,
			signal: abort.signal
		}, {
			model: "lite",
			face: false,
			hands: false,
			matrixLayout: "column-major"
		}) : void 0;
		disposeInference = () => native ? native.landmarker.close() : worker?.dispose();
		source = createVideoPoseSource({
			generation: 1,
			signal: abort.signal
		}, {
			video,
			stream,
			async detect(input, at) {
				captured = {
					width: input.displayWidth,
					height: input.displayHeight
				};
				if (worker) return worker.detect(input, at);
				if (!native) throw new Error("Private detector unavailable");
				return native.landmarker.detectForVideo(input, at);
			}
		});
		return {
			close,
			snapshot,
			async read() {
				const frame = await source?.read();
				if (!frame) throw new Error("Private captured input unavailable");
				nativeResults++;
				const image = frame.image;
				sourceGeometryMatches &&= Boolean(image && captured && image.width === captured.width && image.height === captured.height && image.imageIsMirrored === false && Object.isFrozen(image));
				const options = {
					now: performance.now(),
					minimumConfidence: .8,
					maxAgeMs: 250
				};
				if (observeCapturedNeckSide({
					frame,
					...options
				}).status === "unavailable") unavailable++;
				const points = Array.from({ length: 33 }, () => ({
					x: .5,
					y: .5,
					z: 0,
					visibility: 1,
					presence: 1
				}));
				points[7] = {
					x: .4,
					y: .2,
					z: 0,
					visibility: 1,
					presence: 1
				};
				points[8] = {
					x: .6,
					y: .1,
					z: 0,
					visibility: 1,
					presence: 1
				};
				points[11] = {
					x: .3,
					y: .4,
					z: 0,
					visibility: 1,
					presence: 1
				};
				points[12] = {
					x: .7,
					y: .4,
					z: 0,
					visibility: 1,
					presence: 1
				};
				const synthetic = {
					...frame,
					result: { landmarks: copyPosePoints(copyPosePoints([points])) }
				};
				const projected = observeCapturedNeckSide({
					frame: synthetic,
					...options,
					now: frame.at
				});
				syntheticChecks++;
				syntheticChecksPassed &&= Boolean(image && projected.status === "available" && Math.abs(projected.headShoulderLineAngleRad - Math.atan2(.1 * image.height, .2 * image.width)) < 1e-12 && projected.generation === frame.generation && projected.sequence === frame.sequence && projected.at === frame.at && !("classification" in projected));
				points[7].presence = 0;
				const hidden = {
					...frame,
					result: { landmarks: copyPosePoints(copyPosePoints([points])) }
				};
				syntheticChecksPassed &&= observeCapturedNeckSide({
					frame: hidden,
					...options,
					now: frame.at
				}).status === "unavailable";
				syntheticChecksPassed &&= observeCapturedNeckSide({
					frame: synthetic,
					...options,
					now: frame.at + 251
				}).status === "unavailable";
				return snapshot();
			}
		};
	} catch {
		await close();
		throw new Error("Private captured neck probe unavailable");
	}
}
//#endregion
export { mountCapturedNeckProbe };
