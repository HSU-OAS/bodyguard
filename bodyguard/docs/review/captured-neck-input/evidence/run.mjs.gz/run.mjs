// Fixed local receipts. No camera pixels/coordinates/observation values are captured.
import { spawnSync } from 'node:child_process'
import { createHash } from 'node:crypto'
import { readFileSync, writeFileSync, readdirSync } from 'node:fs'
import assert from 'node:assert/strict'
const work="/Applications/학교 내부/2026-2학기/오픈소스 AI SW 융합 프로젝트/BODYGUARD-captured-neck-input", proof="/private/tmp/bodyguard-neck-input.0FrXPy", fe=work+'/bodyguard/frontend'
const [action,label]=process.argv.slice(2); assert(/^[a-z-]+$/.test(label))
const paths=['src/posture/capturedImage.ts','src/posture/neckSideObservation.ts','src/posture/landmarks.ts','src/avatar/observedPoseRig.ts','src/pose/ownedPoseFrame.ts','src/pose/videoPoseSource.ts','src/coaching/nativePlaybackResources.ts']
const sha=b=>createHash('sha256').update(b).digest('hex')
const sources=()=>Object.fromEntries(paths.map(f=>[f,sha(readFileSync(fe+'/'+f))]))
const commands={
 focused:['pnpm',['exec','vitest','run','src/posture/capturedNeckObservation.test.ts','src/pose/ownedPoseFrame.test.ts','src/pose/videoPoseSource.test.ts','src/coaching/nativePlaybackResources.test.ts','--maxWorkers','1','--reporter=json','--outputFile='+proof+'/focused-'+label+'.json']],
 units:['pnpm',['exec','vitest','run','--maxWorkers','1','--reporter=json','--outputFile='+proof+'/units-'+label+'.json']],
 types:['pnpm',['typecheck']], lint:['pnpm',['check']], build:['pnpm',['build']],
 guard:['node',['scripts/check-selection-production.mjs']],
 privatebuild:['pnpm',['exec','vite','build','--config',proof+'/vite.config.mjs']],
 browser:['node',[proof+'/browser.mjs',label]],
}
const [command,args]=commands[action],before=sources(),startedAt=new Date().toISOString()
const r=spawnSync(command,args,{cwd:fe,encoding:'utf8',maxBuffer:20*1024*1024})
for(const [k,bytes]of [['stdout',r.stdout],['stderr',r.stderr]])writeFileSync(proof+'/'+action+'-'+label+'.'+k+'.txt',bytes??'',{flag:'wx'})
const result={command,args,startedAt,finishedAt:new Date().toISOString(),exit:r.status,sourcesBefore:before,sourcesAfter:sources()}
if(action==='build'&&r.status===0)result.assets=Object.fromEntries(readdirSync(fe+'/dist/assets').map(n=>[n,{bytes:readFileSync(fe+'/dist/assets/'+n).length,sha:sha(readFileSync(fe+'/dist/assets/'+n))}]))
writeFileSync(proof+'/'+action+'-'+label+'.receipt.json',JSON.stringify(result,null,2),{flag:'wx'})
console.log(JSON.stringify({action,label,exit:r.status,stdout:r.stdout?.slice(-1000),stderr:r.stderr?.slice(-1500)}))
process.exitCode=r.status??1
