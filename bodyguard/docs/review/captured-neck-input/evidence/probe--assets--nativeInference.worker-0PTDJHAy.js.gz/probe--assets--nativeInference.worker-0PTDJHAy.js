(function() {
	//#region src/coaching/resources.ts
	var ResourceCleanupError = class extends Error {
		constructor() {
			super("Resource cleanup failed");
		}
	};
	//#endregion
	//#region src/pose/constants.ts
	const WASM_BASE_PATH = "/mediapipe/wasm";
	const POSE_MODELS = {
		lite: {
			label: "lite (5.5MB)",
			path: "/models/pose_landmarker_lite.task"
		},
		full: {
			label: "full (9.0MB)",
			path: "/models/pose_landmarker_full.task"
		},
		heavy: {
			label: "heavy (29.2MB)",
			path: "/models/pose_landmarker_heavy.task"
		}
	};
	const GESTURE_MODEL_PATH = "/models/gesture_recognizer.task";
	const FACE_MODEL_PATH = "/models/face_landmarker.task";
	//#endregion
	//#region src/pose/workerInferenceRuntime.ts
	function createWorkerInferenceRuntime(ports) {
		let generation = 0, state = "idle";
		let engine;
		let preparing, inFlight;
		let lastId = 0, lastAt = -Infinity, cleanupFailed = false;
		const abort = new AbortController();
		function send(message) {
			ports.send({
				...message,
				generation
			});
		}
		function fail(id) {
			if (state === "closing" || state === "closed") return;
			state = "failed";
			send({
				type: "error",
				id
			});
		}
		async function close() {
			if (state === "closing" || state === "closed") return;
			state = "closing";
			abort.abort();
			await preparing;
			await inFlight;
			try {
				await engine?.dispose();
			} catch {
				cleanupFailed = true;
			}
			engine = void 0;
			state = "closed";
			send({
				type: "closed",
				clean: !cleanupFailed
			});
		}
		function receive(value) {
			let frame, id = 0;
			try {
				const message = value;
				if (!message || typeof message !== "object") throw new Error();
				if (message.type === "init") {
					if (state !== "idle" || message.id !== 0 || !Number.isSafeInteger(message.generation) || message.generation <= 0) throw new Error();
					const config = message.config;
					if (!config || typeof config !== "object" || typeof config.model !== "string" || !Object.hasOwn(POSE_MODELS, config.model) || typeof config.face !== "boolean" || typeof config.hands !== "boolean" || !["column-major", "row-major"].includes(config.matrixLayout)) throw new Error();
					generation = message.generation;
					state = "preparing";
					preparing = Promise.resolve().then(() => ports.prepare(Object.freeze({
						model: config.model,
						face: config.face,
						hands: config.hands,
						matrixLayout: config.matrixLayout
					}), abort.signal)).then((loaded) => {
						engine = loaded;
						if (state === "preparing") {
							state = "ready";
							send({
								type: "ready",
								id: 0
							});
						}
					}).catch((error) => {
						if (error instanceof ResourceCleanupError) cleanupFailed = true;
						fail(0);
					});
					return;
				}
				if (message.type === "frame") frame = message.frame;
				if (message.generation !== generation) throw new Error();
				if (message.type === "close") {
					close();
					return;
				}
				frame = message.frame;
				id = message.id;
				const at = message.at;
				if (message.type !== "frame" || state !== "ready" || inFlight || !engine || !Number.isSafeInteger(id) || id <= lastId || !Number.isFinite(at) || at < 0 || at <= lastAt || !frame || typeof frame.close !== "function" || frame.displayWidth <= 0 || frame.displayHeight <= 0) throw new Error();
				lastId = id;
				lastAt = at;
				const input = frame;
				frame = void 0;
				const current = engine;
				inFlight = Promise.resolve().then(async () => {
					let result;
					try {
						result = await current.detect(input, at);
					} catch (error) {
						if (error instanceof ResourceCleanupError) cleanupFailed = true;
						fail(id);
					} finally {
						try {
							input.close();
						} catch {
							cleanupFailed = true;
							fail(id);
						}
					}
					if (result && state === "ready" && !abort.signal.aborted) send({
						type: "result",
						id,
						at,
						result
					});
				}).catch(() => {
					fail(id);
				}).finally(() => {
					inFlight = void 0;
				});
			} catch {
				try {
					frame?.close();
				} catch {
					cleanupFailed = true;
				}
				fail(id);
			}
		}
		return Object.freeze({ receive });
	}
	//#endregion
	//#region node_modules/.pnpm/@mediapipe+tasks-vision@1.0.1/node_modules/@mediapipe/tasks-vision/vision_bundle.mjs
	var t = "undefined" != typeof self ? self : {};
	function e(e, r) {
		t: {
			for (var n = ["CLOSURE_FLAGS"], i = t, s = 0; s < n.length; s++) if (null == (i = i[n[s]])) {
				n = null;
				break t;
			}
			n = i;
		}
		return null != (e = n && n[e]) ? e : r;
	}
	function r(e, r) {
		e = e.split(".");
		for (var n, i = t; e.length && (n = e.shift());) e.length || void 0 === r ? i = i[n] && i[n] !== Object.prototype[n] ? i[n] : i[n] = {} : i[n] = r;
	}
	function n() {
		throw Error("Invalid UTF8");
	}
	function i(t, e) {
		return e = String.fromCharCode.apply(null, e), null == t ? e : t + e;
	}
	var s;
	var o;
	var a = void 0;
	var h = "undefined" != typeof TextDecoder;
	var u = "undefined" != typeof TextEncoder;
	function c(t) {
		if (u) t = (o ||= new TextEncoder()).encode(t);
		else {
			let r = 0, n = new Uint8Array(3 * t.length);
			for (let i = 0; i < t.length; i++) {
				var e = t.charCodeAt(i);
				if (e < 128) n[r++] = e;
				else {
					if (e < 2048) n[r++] = e >> 6 | 192;
					else {
						if (e >= 55296 && e <= 57343) {
							if (e <= 56319 && i < t.length) {
								let s = t.charCodeAt(++i);
								if (s >= 56320 && s <= 57343) {
									e = 1024 * (e - 55296) + s - 56320 + 65536, n[r++] = e >> 18 | 240, n[r++] = e >> 12 & 63 | 128, n[r++] = e >> 6 & 63 | 128, n[r++] = 63 & e | 128;
									continue;
								}
								i--;
							}
							e = 65533;
						}
						n[r++] = e >> 12 | 224, n[r++] = e >> 6 & 63 | 128;
					}
					n[r++] = 63 & e | 128;
				}
			}
			t = r === n.length ? n : n.subarray(0, r);
		}
		return t;
	}
	function l(e) {
		t.setTimeout(() => {
			throw e;
		}, 0);
	}
	var d = e(610401301, !1);
	var f = e(748402147, !0);
	function p() {
		var e = t.navigator;
		return e && (e = e.userAgent) ? e : "";
	}
	var g;
	var m = t.navigator;
	function v(t) {
		return v[" "](t), t;
	}
	g = m && m.userAgentData || null, v[" "] = function() {};
	var _ = {};
	var y = null;
	function E(t) {
		var e = t.length, r = 3 * e / 4;
		r % 3 ? r = Math.floor(r) : -1 != "=.".indexOf(t[e - 1]) && (r = -1 != "=.".indexOf(t[e - 2]) ? r - 2 : r - 1);
		var n = new Uint8Array(r), i = 0;
		return function(t, e) {
			function r(e) {
				for (; n < t.length;) {
					let e = t.charAt(n++), r = y[e];
					if (null != r) return r;
					if (!/^[\s\xa0]*$/.test(e)) throw Error("Unknown base64 encoding at char: " + e);
				}
				return e;
			}
			A();
			for (var n = 0;;) {
				let t = r(-1), n = r(0), i = r(64), s = r(64);
				if (64 === s && -1 === t) break;
				e(t << 2 | n >> 4), 64 != i && (e(n << 4 & 240 | i >> 2), 64 != s && e(i << 6 & 192 | s));
			}
		}(t, function(t) {
			n[i++] = t;
		}), i !== r ? n.subarray(0, i) : n;
	}
	function A() {
		if (!y) {
			y = {};
			var t = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789".split(""), e = [
				"+/=",
				"+/",
				"-_=",
				"-_.",
				"-_"
			];
			for (let r = 0; r < 5; r++) {
				let n = t.concat(e[r].split(""));
				_[r] = n;
				for (let t = 0; t < n.length; t++) {
					let e = n[t];
					void 0 === y[e] && (y[e] = t);
				}
			}
		}
	}
	var w = "undefined" != typeof Uint8Array;
	var b = !(!(d && g && g.brands.length > 0) && (-1 != p().indexOf("Trident") || -1 != p().indexOf("MSIE"))) && "function" == typeof btoa;
	var T = /[-_.]/g;
	var k = {
		"-": "+",
		_: "/",
		".": "="
	};
	function S(t) {
		return k[t] || "";
	}
	function L(t) {
		if (!b) return E(t);
		t = T.test(t) ? t.replace(T, S) : t, t = atob(t);
		var e = new Uint8Array(t.length);
		for (let r = 0; r < t.length; r++) e[r] = t.charCodeAt(r);
		return e;
	}
	function x(t) {
		return w && null != t && t instanceof Uint8Array;
	}
	var R = {};
	function I() {
		return C ||= new N(null, R);
	}
	function F(t) {
		M(R);
		var e = t.g;
		return null == (e = null == e || x(e) ? e : "string" == typeof e ? L(e) : null) ? e : t.g = e;
	}
	var C;
	var N = class {
		h() {
			return new Uint8Array(F(this) || 0);
		}
		constructor(t, e) {
			if (M(e), this.g = t, null != t && 0 === t.length) throw Error("ByteString should be constructed with non-empty values");
		}
	};
	function M(t) {
		if (t !== R) throw Error("illegal external caller");
	}
	function O(t, e) {
		t.__closure__error__context__984382 || (t.__closure__error__context__984382 = {}), t.__closure__error__context__984382.severity = e;
	}
	var D = void 0;
	function P(t) {
		return O(t = Error(t), "warning"), t;
	}
	function $(t, e) {
		if (null != t) {
			var r = D ??= {}, n = r[t] || 0;
			n >= e || (r[t] = n + 1, O(t = Error(), "incident"), l(t));
		}
	}
	function U() {
		return "function" == typeof BigInt;
	}
	var B = "function" == typeof Symbol && "symbol" == typeof Symbol();
	function G(t, e, r = !1) {
		return "function" == typeof Symbol && "symbol" == typeof Symbol() ? r && Symbol.for && t ? Symbol.for(t) : null != t ? Symbol(t) : Symbol() : e;
	}
	var j;
	var V = G("jas", void 0, !0);
	var H = G(void 0, "0di");
	var K = G(void 0, "1oa");
	var X = G(void 0, Symbol());
	var W = G(void 0, "0ub");
	var z = G(void 0, "0ubs");
	var Y = G(void 0, "0ubsb");
	var q = G(void 0, "0actk");
	var J = G("m_m", "kb", !0);
	var Z = G();
	var Q = { Va: {
		value: 0,
		configurable: !0,
		writable: !0,
		enumerable: !1
	} };
	var tt = Object.defineProperties;
	var et = B ? V : "Va";
	var rt = [];
	function nt(t, e) {
		B || et in t || tt(t, Q), t[et] |= e;
	}
	function it(t, e) {
		B || et in t || tt(t, Q), t[et] = e;
	}
	function st(t) {
		return nt(t, 34), t;
	}
	function ot(t) {
		return nt(t, 8192), t;
	}
	it(rt, 7), j = Object.freeze(rt);
	var at = {};
	function ht(t, e) {
		return void 0 === e ? t.h !== ut && !!(2 & t.A[et]) : !!(2 & e) && t.h !== ut;
	}
	var ut = {};
	function ct(t, e) {
		if (null != t) {
			if ("string" == typeof t) t = t ? new N(t, R) : I();
			else if (t.constructor !== N) if (x(t)) t = t.length ? new N(new Uint8Array(t), R) : I();
			else {
				if (!e) throw Error();
				t = void 0;
			}
		}
		return t;
	}
	var lt = class {
		constructor(t, e, r) {
			this.g = t, this.h = e, this.j = r;
		}
		next() {
			var t = this.g.next();
			return t.done || (t.value = this.h.call(this.j, t.value)), t;
		}
		[Symbol.iterator]() {
			return this;
		}
	};
	var dt = Object.freeze({});
	function ft(t, e, r) {
		var n, i = 128 & e ? 0 : -1, s = t.length;
		(n = !!s) && (n = null != (n = t[s - 1]) && "object" == typeof n && n.constructor === Object);
		var o = s + (n ? -1 : 0);
		for (e = 128 & e ? 1 : 0; e < o; e++) r(e - i, t[e]);
		if (n) {
			t = t[s - 1];
			for (let e in t) !isNaN(e) && r(+e, t[e]);
		}
	}
	var pt = {};
	function gt(t) {
		return 128 & t ? pt : void 0;
	}
	function mt(t) {
		return t.ib = !0, t;
	}
	var vt = mt((t) => "number" == typeof t);
	var _t = mt((t) => "string" == typeof t);
	var yt = mt((t) => "boolean" == typeof t);
	var Et = "function" == typeof t.BigInt && "bigint" == typeof t.BigInt(0);
	function At(t) {
		var e = t;
		if (_t(e)) {
			if (!/^\s*(?:-?[1-9]\d*|0)?\s*$/.test(e)) throw Error(String(e));
		} else if (vt(e) && !Number.isSafeInteger(e)) throw Error(String(e));
		return Et ? BigInt(t) : t = yt(t) ? t ? "1" : "0" : _t(t) ? t.trim() || "0" : String(t);
	}
	var wt = mt((t) => Et ? t >= Tt && t <= St : "-" === t[0] ? Lt(t, bt) : Lt(t, kt));
	var bt = Number.MIN_SAFE_INTEGER.toString();
	var Tt = Et ? BigInt(Number.MIN_SAFE_INTEGER) : void 0;
	var kt = Number.MAX_SAFE_INTEGER.toString();
	var St = Et ? BigInt(Number.MAX_SAFE_INTEGER) : void 0;
	function Lt(t, e) {
		if (t.length > e.length) return !1;
		if (t.length < e.length || t === e) return !0;
		for (let r = 0; r < t.length; r++) {
			let n = t[r], i = e[r];
			if (n > i) return !1;
			if (n < i) return !0;
		}
	}
	var xt;
	var Rt = "function" == typeof Uint8Array.prototype.slice;
	var It = 0;
	var Ft = 0;
	function Ct(t) {
		var e = t >>> 0;
		It = e, Ft = (t - e) / 4294967296 >>> 0;
	}
	function Nt(t) {
		if (t < 0) {
			Ct(-t);
			let [e, r] = jt(It, Ft);
			It = e >>> 0, Ft = r >>> 0;
		} else Ct(t);
	}
	function Mt(t) {
		var e = xt ||= /* @__PURE__ */ new DataView(/* @__PURE__ */ new ArrayBuffer(8));
		e.setFloat32(0, +t, !0), Ft = 0, It = e.getUint32(0, !0);
	}
	function Ot(t, e) {
		var r = 4294967296 * e + (t >>> 0);
		return Number.isSafeInteger(r) ? r : $t(t, e);
	}
	function Dt(t, e) {
		return At(U() ? BigInt.asUintN(64, (BigInt(e >>> 0) << BigInt(32)) + BigInt(t >>> 0)) : $t(t, e));
	}
	function Pt(t, e) {
		return U() ? At(BigInt.asIntN(64, (BigInt.asUintN(32, BigInt(e)) << BigInt(32)) + BigInt.asUintN(32, BigInt(t)))) : At(Bt(t, e));
	}
	function $t(t, e) {
		if (t >>>= 0, (e >>>= 0) <= 2097151) var r = "" + (4294967296 * e + t);
		else U() ? r = "" + (BigInt(e) << BigInt(32) | BigInt(t)) : (t = (16777215 & t) + 6777216 * (r = 16777215 & (t >>> 24 | e << 8)) + 6710656 * (e = e >> 16 & 65535), r += 8147497 * e, e *= 2, t >= 1e7 && (r += t / 1e7 >>> 0, t %= 1e7), r >= 1e7 && (e += r / 1e7 >>> 0, r %= 1e7), r = e + Ut(r) + Ut(t));
		return r;
	}
	function Ut(t) {
		return t = String(t), "0000000".slice(t.length) + t;
	}
	function Bt(t, e) {
		if (2147483648 & e) if (U()) t = "" + (BigInt(0 | e) << BigInt(32) | BigInt(t >>> 0));
		else {
			let [r, n] = jt(t, e);
			t = "-" + $t(r, n);
		}
		else t = $t(t, e);
		return t;
	}
	function Gt(t) {
		if (t.length < 16) Nt(Number(t));
		else if (U()) t = BigInt(t), It = Number(t & BigInt(4294967295)) >>> 0, Ft = Number(t >> BigInt(32) & BigInt(4294967295));
		else {
			let e = +("-" === t[0]);
			Ft = It = 0;
			let r = t.length;
			for (let n = e, i = (r - e) % 6 + e; i <= r; n = i, i += 6) {
				let e = Number(t.slice(n, i));
				Ft *= 1e6, (It = 1e6 * It + e) >= 4294967296 && (Ft += Math.trunc(It / 4294967296), Ft >>>= 0, It >>>= 0);
			}
			if (e) {
				let [t, e] = jt(It, Ft);
				It = t, Ft = e;
			}
		}
	}
	function jt(t, e) {
		return e = ~e, t ? t = 1 + ~t : e += 1, [t, e];
	}
	function Vt(t) {
		return Array.prototype.slice.call(t);
	}
	var Ht = "function" == typeof BigInt ? BigInt.asIntN : void 0;
	var Kt = "function" == typeof BigInt ? BigInt.asUintN : void 0;
	var Xt = Number.isSafeInteger;
	var Wt = Number.isFinite;
	var zt = Math.trunc;
	var Yt = At(0);
	function qt(t) {
		if ("number" != typeof t) throw Error(`Value of float/double field must be a number, found ${typeof t}: ${t}`);
		return t;
	}
	function Jt(t) {
		return null == t || "number" == typeof t ? t : "NaN" === t || "Infinity" === t || "-Infinity" === t ? Number(t) : void 0;
	}
	function Zt(t) {
		if ("boolean" != typeof t) {
			var e = typeof t;
			throw Error(`Expected boolean but got ${"object" != e ? e : t ? Array.isArray(t) ? "array" : e : "null"}: ${t}`);
		}
		return t;
	}
	var Qt = /^-?([1-9][0-9]*|0)(\.[0-9]+)?$/;
	function te(t) {
		switch (typeof t) {
			case "bigint": return !0;
			case "number": return Wt(t);
			case "string": return Qt.test(t);
			default: return !1;
		}
	}
	function ee(t) {
		if (null != t) {
			if (!Wt(t)) throw P("enum");
			t |= 0;
		}
		return t;
	}
	function re(t) {
		if (null == t) return t;
		if ("string" == typeof t && t) t = +t;
		else if ("number" != typeof t) return;
		return Wt(t) ? 0 | t : void 0;
	}
	function ne(t) {
		if (null == t) return t;
		if ("string" == typeof t && t) t = +t;
		else if ("number" != typeof t) return;
		return Wt(t) ? t >>> 0 : void 0;
	}
	function ie(t, e) {
		if (e ??= 1024, !te(t)) throw P("int64");
		var r = typeof t;
		switch (e) {
			case 512: switch (r) {
				case "string": return ce(t);
				case "bigint": return String(Ht(64, t));
				default: return ue(t);
			}
			case 1024: switch (r) {
				case "string": return le(t);
				case "bigint": return At(Ht(64, t));
				default: return de(t);
			}
			case 0: switch (r) {
				case "string": return ce(t);
				case "bigint": return At(Ht(64, t));
				default: return ae(t);
			}
			default: return function(t, e = `unexpected value ${t}!`) {
				throw Error(e);
			}(e, "Unknown format requested type for int64");
		}
	}
	function se(t) {
		var e = t.length;
		return ("-" === t[0] ? e < 20 || 20 === e && t <= "-9223372036854775808" : e < 19 || 19 === e && t <= "9223372036854775807") ? t : (Gt(t), Bt(It, Ft));
	}
	function oe(t) {
		if ("-" === t[0]) var e = !1;
		else e = (e = t.length) < 20 || 20 === e && t <= "18446744073709551615";
		return e ? t : (Gt(t), $t(It, Ft));
	}
	function ae(t) {
		if (t = zt(t), !Xt(t)) {
			Nt(t);
			var e = It, r = Ft;
			(t = 2147483648 & r) && (r = ~r >>> 0, 0 == (e = 1 + ~e >>> 0) && (r = r + 1 >>> 0)), t = "number" == typeof (e = Ot(e, r)) ? t ? -e : e : t ? "-" + e : e;
		}
		return t;
	}
	function he(t) {
		return (t = zt(t)) >= 0 && Xt(t) || (Nt(t), t = Ot(It, Ft)), t;
	}
	function ue(t) {
		return t = zt(t), Xt(t) ? t = String(t) : (Nt(t), t = Bt(It, Ft)), t;
	}
	function ce(t) {
		var e = zt(Number(t));
		return Xt(e) ? String(e) : (-1 !== (e = t.indexOf(".")) && (t = t.substring(0, e)), se(t));
	}
	function le(t) {
		var e = zt(Number(t));
		return Xt(e) ? At(e) : (-1 !== (e = t.indexOf(".")) && (t = t.substring(0, e)), U() ? At(Ht(64, BigInt(t))) : At(se(t)));
	}
	function de(t) {
		return Xt(t) ? At(ae(t)) : At(ue(t));
	}
	function fe(t) {
		var e = typeof t;
		return null == t ? t : "bigint" === e ? At(Ht(64, t)) : te(t) ? "string" === e ? le(t) : de(t) : void 0;
	}
	function pe(t) {
		if (null == t) return t;
		var e = typeof t;
		if ("bigint" === e) return String(Ht(64, t));
		if (te(t)) {
			if ("string" === e) return ce(t);
			if ("number" === e) return ae(t);
		}
	}
	function ge(t) {
		if (null == t || "string" == typeof t || t instanceof N) return t;
	}
	function me(t) {
		if ("string" != typeof t) throw Error();
		return t;
	}
	function ve(t) {
		if (null != t && "string" != typeof t) throw Error();
		return t;
	}
	function _e(t) {
		return null == t || "string" == typeof t ? t : void 0;
	}
	function ye(t, e, r, n) {
		return null != t && t[J] === at ? t : Array.isArray(t) ? ((n = (r = 0 | t[et]) | 32 & n | 2 & n) !== r && it(t, n), new e(t)) : (r ? 2 & n ? ((t = e[H]) || (st((t = new e()).A), t = e[H] = t), e = t) : e = new e() : e = void 0, e);
	}
	function Ee(t, e, r) {
		return null == (t = e ? ie(t, 1024) : fe(t)) ? r ? Yt : void 0 : t;
	}
	function Ae(t) {
		return t;
	}
	var we = {};
	var be = function() {
		try {
			return v(new class extends Map {
				constructor() {
					super();
				}
			}()), !1;
		} catch {
			return !0;
		}
	}();
	var Te = class {
		constructor() {
			this.g = /* @__PURE__ */ new Map();
		}
		get(t) {
			return this.g.get(t);
		}
		set(t, e) {
			return this.g.set(t, e), this.size = this.g.size, this;
		}
		delete(t) {
			return t = this.g.delete(t), this.size = this.g.size, t;
		}
		clear() {
			this.g.clear(), this.size = this.g.size;
		}
		has(t) {
			return this.g.has(t);
		}
		entries() {
			return this.g.entries();
		}
		keys() {
			return this.g.keys();
		}
		values() {
			return this.g.values();
		}
		forEach(t, e) {
			return this.g.forEach(t, e);
		}
		[Symbol.iterator]() {
			return this.entries();
		}
	};
	var ke = be ? (Object.setPrototypeOf(Te.prototype, Map.prototype), Object.defineProperties(Te.prototype, { size: {
		value: 0,
		configurable: !0,
		enumerable: !0,
		writable: !0
	} }), Te) : class extends Map {
		constructor() {
			super();
		}
	};
	function Se(t) {
		return t;
	}
	function Le(t) {
		if (2 & t.M) throw Error("Cannot mutate an immutable Map");
	}
	var xe;
	var Re = class extends ke {
		constructor(t, e, r = Se, n = Se) {
			super(), this.M = 0 | t[et], this.N = e, this.ba = r, this.na = this.N ? Ie : n;
			for (let i = 0; i < t.length; i++) {
				let s = t[i], o = r(s[0], !1, !0), a = s[1];
				e ? void 0 === a && (a = null) : a = n(s[1], !1, !0, void 0, void 0, this.M), super.set(o, a);
			}
		}
		ea(t) {
			return ot(Array.from(super.entries(), t));
		}
		clear() {
			Le(this), super.clear();
		}
		delete(t) {
			return Le(this), super.delete(this.ba(t, !0, !1));
		}
		entries() {
			if (this.N) {
				var t = super.keys();
				t = new lt(t, Fe, this);
			} else t = super.entries();
			return t;
		}
		values() {
			if (this.N) {
				var t = super.keys();
				t = new lt(t, Re.prototype.get, this);
			} else t = super.values();
			return t;
		}
		forEach(t, e) {
			this.N ? super.forEach((r, n, i) => {
				t.call(e, i.get(n), n, i);
			}) : super.forEach(t, e);
		}
		set(t, e) {
			return Le(this), null == (t = this.ba(t, !0, !1)) ? this : null == e ? (super.delete(t), this) : super.set(t, this.na(e, !0, !0, this.N, !1, this.M));
		}
		gb(t) {
			var e = this.ba(t[0], !1, !0);
			t = t[1], t = this.N ? void 0 === t ? null : t : this.na(t, !1, !0, void 0, !1, this.M), super.set(e, t);
		}
		has(t) {
			return super.has(this.ba(t, !1, !1));
		}
		get(t) {
			t = this.ba(t, !1, !1);
			var e = super.get(t);
			if (void 0 !== e) {
				var r = this.N;
				return r ? ((r = this.na(e, !1, !0, r, this.Fa, this.M)) !== e && super.set(t, r), r) : e;
			}
		}
		[Symbol.iterator]() {
			return this.entries();
		}
	};
	function Ie(t, e, r, n, i, s) {
		return t = ye(t, n, r, s), i && (t = Ze(t)), t;
	}
	function Fe(t) {
		return [t, this.get(t)];
	}
	function Ce() {
		return xe ||= new Re(st([]), void 0, void 0, void 0, we);
	}
	function Ne(t) {
		return X ? t[X] : void 0;
	}
	function Me(t, e) {
		for (let r in t) !isNaN(r) && e(t, +r, t[r]);
	}
	Re.prototype.toJSON = void 0;
	var De;
	var Pe;
	var $e = class {};
	var Ue = { cb: !0 };
	function Be(t, e) {
		e < 100 || $(z, 1);
	}
	function Ge(t, e, r, n) {
		var i = void 0 !== n;
		n = !!n;
		var s, o = X;
		!i && B && o && (s = t[o]) && Me(s, Be), o = [];
		var a = t.length;
		s = 4294967295;
		var h = !1, u = !!(64 & e), c = u ? 128 & e ? 0 : -1 : void 0;
		if (!(1 & e)) {
			var l = a && t[a - 1];
			null != l && "object" == typeof l && l.constructor === Object ? s = --a : l = void 0, !u || 128 & e || i || (h = !0, s = Ae(s - c, c, t, l, void 0) + c);
		}
		e = void 0;
		for (var d = 0; d < a; d++) {
			let i = t[d];
			if (null != i && null != (i = r(i, n))) if (u && d >= s) {
				let t = d - c;
				(e ??= {})[t] = i;
			} else o[d] = i;
		}
		if (l) for (let t in l) {
			if (null == (a = l[t]) || null == (a = r(a, n))) continue;
			let i;
			d = +t, u && !Number.isNaN(d) && (i = d + c) < s ? o[i] = a : (e ??= {})[t] = a;
		}
		return e && (h ? o.push(e) : o[s] = e), i && X && (t = Ne(t)) && t instanceof $e && (o[X] = function(t) {
			var e = new $e();
			return Me(t, (t, r, n) => {
				e[r] = Vt(n);
			}), e.ka = t.ka, e;
		}(t)), o;
	}
	function je(t) {
		return t[0] = Ve(t[0]), t[1] = Ve(t[1]), t;
	}
	function Ve(t) {
		switch (typeof t) {
			case "number": return Number.isFinite(t) ? t : "" + t;
			case "bigint": return wt(t) ? Number(t) : "" + t;
			case "boolean": return t ? 1 : 0;
			case "object":
				if (Array.isArray(t)) {
					var e = 0 | t[et];
					return 0 === t.length && 1 & e ? void 0 : Ge(t, e, Ve);
				}
				if (null != t && t[J] === at) return He(t);
				if (t instanceof N) {
					if (null == (e = t.g)) t = "";
					else if ("string" == typeof e) t = e;
					else {
						if (b) {
							for (var r = "", n = 0, i = e.length - 10240; n < i;) r += String.fromCharCode.apply(null, e.subarray(n, n += 10240));
							r += String.fromCharCode.apply(null, n ? e.subarray(n) : e), e = btoa(r);
						} else {
							void 0 === r && (r = 0), A(), r = _[r], n = Array(Math.floor(e.length / 3)), i = r[64] || "";
							let t = 0, u = 0;
							for (; t < e.length - 2; t += 3) {
								var s = e[t], o = e[t + 1], a = e[t + 2], h = r[s >> 2];
								s = r[(3 & s) << 4 | o >> 4], o = r[(15 & o) << 2 | a >> 6], a = r[63 & a], n[u++] = h + s + o + a;
							}
							switch (h = 0, a = i, e.length - t) {
								case 2: a = r[(15 & (h = e[t + 1])) << 2] || i;
								case 1: e = e[t], n[u] = r[e >> 2] + r[(3 & e) << 4 | h >> 4] + a + i;
							}
							e = n.join("");
						}
						t = t.g = e;
					}
					return t;
				}
				return t instanceof Re ? t = 0 !== t.size ? t.ea(je) : void 0 : void 0;
		}
		return t;
	}
	function He(t) {
		return Ge(t = t.A, 0 | t[et], Ve);
	}
	function Ke(t, e) {
		return Xe(t, e[0], e[1]);
	}
	function Xe(t, e, r, n = 0) {
		if (null == t) {
			var i = 32;
			r ? (t = [r], i |= 128) : t = [], e && (i = -16760833 & i | (1023 & e) << 14);
		} else {
			if (!Array.isArray(t)) throw Error("narr");
			if (i = 0 | t[et], f && 1 & i) throw Error("rfarr");
			if (2048 & i && !(2 & i) && function() {
				if (f) throw Error("carr");
				$(q, 5);
			}(), 256 & i) throw Error("farr");
			if (64 & i) return (i | n) !== i && it(t, i | n), t;
			if (r && (i |= 128, r !== t[0])) throw Error("mid");
			t: {
				i |= 64;
				var s = (r = t).length;
				if (s) {
					var o = s - 1;
					let t = r[o];
					if (null != t && "object" == typeof t && t.constructor === Object) {
						if ((o -= e = 128 & i ? 0 : -1) >= 1024) throw Error("pvtlmt");
						for (var a in t) (s = +a) < o && (r[s + e] = t[a], delete t[a]);
						i = -16760833 & i | (1023 & o) << 14;
						break t;
					}
				}
				if (e) {
					if ((a = Math.max(e, s - (128 & i ? 0 : -1))) > 1024) throw Error("spvt");
					i = -16760833 & i | (1023 & a) << 14;
				}
			}
		}
		return it(t, 64 | i | n), t;
	}
	function We(t, e) {
		if ("object" != typeof t) return t;
		if (Array.isArray(t)) {
			var r = 0 | t[et];
			return 0 === t.length && 1 & r ? void 0 : ze(t, r, e);
		}
		if (null != t && t[J] === at) return qe(t);
		if (t instanceof Re) {
			if (2 & (e = t.M)) return t;
			if (!t.size) return;
			if (r = st(t.ea()), t.N) for (t = 0; t < r.length; t++) {
				let n = r[t], i = n[1];
				i = null == i || "object" != typeof i ? void 0 : null != i && i[J] === at ? qe(i) : Array.isArray(i) ? ze(i, 0 | i[et], !!(32 & e)) : void 0, n[1] = i;
			}
			return r;
		}
		return t instanceof N ? t : void 0;
	}
	function ze(t, e, r) {
		return 2 & e || (!r || 4096 & e || 16 & e ? t = Je(t, e, !1, r && !(16 & e)) : (nt(t, 34), 4 & e && Object.freeze(t))), t;
	}
	function Ye(t, e, r) {
		return t = new t.constructor(e), r && (t.h = ut), t.m = ut, t;
	}
	function qe(t) {
		var e = t.A, r = 0 | e[et];
		return ht(t, r) ? t : rr(t, e, r) ? Ye(t, e) : Je(e, r);
	}
	function Je(t, e, r, n) {
		return n ??= !!(34 & e), t = Ge(t, e, We, n), n = 32, r && (n |= 2), it(t, e = 16769217 & e | n), t;
	}
	function Ze(t) {
		var e = t.A, r = 0 | e[et];
		return ht(t, r) ? rr(t, e, r) ? Ye(t, e, !0) : new t.constructor(Je(e, r, !1)) : t;
	}
	function Qe(t) {
		if (t.h !== ut) return !1;
		var e = t.A;
		return nt(e = Je(e, 0 | e[et]), 2048), t.A = e, t.h = void 0, t.m = void 0, !0;
	}
	function tr(t) {
		if (!Qe(t) && ht(t, 0 | t.A[et])) throw Error();
	}
	function er(t, e) {
		void 0 === e && (e = 0 | t[et]), 32 & e && !(4096 & e) && it(t, 4096 | e);
	}
	function rr(t, e, r) {
		return !!(2 & r) || !(!(32 & r) || 4096 & r) && (it(e, 2 | r), t.h = ut, !0);
	}
	var nr = At(0);
	var ir = {};
	function sr(t, e, r, n) {
		if (null !== (e = or(t.A, e, void 0, n)) || r && t.m !== ut) return e;
	}
	function or(t, e, r, n) {
		if (-1 === e) return null;
		var i = e + (r ? 0 : -1), s = t.length - 1;
		if (!(s < 1 + (r ? 0 : -1))) {
			if (i >= s) {
				var o = t[s];
				if (null != o && "object" == typeof o && o.constructor === Object) {
					r = o[e];
					var a = !0;
				} else {
					if (i !== s) return;
					r = o;
				}
			} else r = t[i];
			if (n && null != r) {
				if (null == (n = n(r))) return n;
				if (!Object.is(n, r)) return a ? o[e] = n : t[i] = n, n;
			}
			return r;
		}
	}
	function ar(t, e, r, n) {
		tr(t);
		var i = t.A;
		return hr(i, 0 | i[et], e, r, n), t;
	}
	function hr(t, e, r, n, i) {
		var s = r + (i ? 0 : -1), o = t.length - 1;
		if (o >= 1 + (i ? 0 : -1) && s >= o) {
			let i = t[o];
			if (null != i && "object" == typeof i && i.constructor === Object) return i[r] = n, e;
		}
		return s <= o ? (t[s] = n, e) : (void 0 !== n && (r >= (o = (e ??= 0 | t[et]) >> 14 & 1023 || 536870912) ? null != n && (t[o + (i ? 0 : -1)] = { [r]: n }) : t[s] = n), e);
	}
	function ur(t, e, r, n) {
		var i = t.A;
		return void 0 !== kr(i, 0 | i[et], e, t = Er(t, n) === r ? r : -1);
	}
	function cr() {
		return void 0 === dt ? 2 : 4;
	}
	function lr(t, e, r, n, i) {
		var s = t.A, o = 0 | s[et];
		n = ht(t, o) ? 1 : n, i = !!i || 3 === n, 2 === n && Qe(t) && (o = 0 | (s = t.A)[et]);
		var a = (t = fr(s, e)) === j ? 7 : 0 | t[et], h = pr(a, o), u = !(4 & h);
		if (u) {
			4 & h && (t = Vt(t), a = 0, h = Nr(h, o), o = hr(s, o, e, t));
			let n = 0, i = 0;
			for (; n < t.length; n++) {
				let e = r(t[n]);
				null != e && (t[i++] = e);
			}
			i < n && (t.length = i), r = -513 & h | 4, h = r &= -1025, h &= -4097;
		}
		return h !== a && (it(t, h), 2 & h && Object.freeze(t)), dr(t, h, s, o, e, n, u, i);
	}
	function dr(t, e, r, n, i, s, o, a) {
		var h = e;
		return 1 === s || 4 === s && (2 & e || !(16 & e) && 32 & n) ? gr(e) || ((e |= !t.length || o && !(4096 & e) || 32 & n && !(4096 & e || 16 & e) ? 2 : 256) !== h && it(t, e), Object.freeze(t)) : (2 === s && gr(e) && (t = Vt(t), h = 0, e = Nr(e, n), n = hr(r, n, i, t)), gr(e) || (a || (e |= 16), e !== h && it(t, e))), 2 & e || !(4096 & e || 16 & e) || er(r, n), t;
	}
	function fr(t, e, r) {
		return t = or(t, e, r), Array.isArray(t) ? t : j;
	}
	function pr(t, e) {
		return 2 & e && (t |= 2), 1 | t;
	}
	function gr(t) {
		return !!(2 & t) && !!(4 & t) || !!(256 & t);
	}
	function mr(t) {
		return ct(t, !0);
	}
	function vr(t) {
		t = Vt(t);
		for (let e = 0; e < t.length; e++) {
			let r = t[e] = Vt(t[e]);
			Array.isArray(r[1]) && (r[1] = st(r[1]));
		}
		return ot(t);
	}
	function _r(t, e, r, n) {
		tr(t), hr(t = t.A, 0 | t[et], e, ("0" === n ? 0 === Number(r) : r === n) ? void 0 : r);
	}
	function yr(t, e, r) {
		if (2 & e) throw Error();
		var n = gt(e), i = fr(t, r, n), s = i === j ? 7 : 0 | i[et], o = pr(s, e);
		return (2 & o || gr(o) || 16 & o) && (o === s || gr(o) || it(i, o), i = Vt(i), s = 0, o = Nr(o, e), hr(t, e, r, i, n)), (o &= -13) !== s && it(i, o), i;
	}
	function Er(t, e) {
		return br(Ar(t = t.A), t, void 0, e);
	}
	function Ar(t) {
		if (B) return t[K] ?? (t[K] = /* @__PURE__ */ new Map());
		if (K in t) return t[K];
		var e = /* @__PURE__ */ new Map();
		return Object.defineProperty(t, K, { value: e }), e;
	}
	function wr(t, e, r, n, i) {
		var s = Ar(t), o = br(s, t, e, r, i);
		return o !== n && (o && (e = hr(t, e, o, void 0, i)), s.set(r, n)), e;
	}
	function br(t, e, r, n, i) {
		var s = t.get(n);
		if (null != s) return s;
		s = 0;
		for (let t = 0; t < n.length; t++) {
			let o = n[t];
			null != or(e, o, i) && (0 !== s && (r = hr(e, r, s, void 0, i)), s = o);
		}
		return t.set(n, s), s;
	}
	function Tr(t, e, r) {
		var n = 0 | t[et], i = gt(n), s = or(t, r, i);
		if (null != s && s[J] === at) {
			if (!ht(s)) return Qe(s), s.A;
			var o = s.A;
		} else Array.isArray(s) && (o = s);
		if (o) {
			let t = 0 | o[et];
			2 & t && (o = Je(o, t));
		}
		return (o = Ke(o, e)) !== s && hr(t, n, r, o, i), o;
	}
	function kr(t, e, r, n, i) {
		var s = !1;
		if (null != (n = or(t, n, i, (t) => {
			var n = ye(t, r, !1, e);
			return s = n !== t && null != n, n;
		}))) return s && !ht(n) && er(t, e), n;
	}
	function Sr(t, e, r, n) {
		var i = t.A, s = 0 | i[et];
		if (null == (e = kr(i, s, e, r, n))) return e;
		if (!ht(t, s = 0 | i[et])) {
			let o = Ze(e);
			o !== e && (Qe(t) && (s = 0 | (i = t.A)[et]), er(i, s = hr(i, s, r, e = o, n)));
		}
		return e;
	}
	function Lr(t, e, r, n, i, s, o, a) {
		var h = ht(t, r);
		s = h ? 1 : s, o = !!o || 3 === s, h = a && !h, (2 === s || h) && Qe(t) && (r = 0 | (e = t.A)[et]);
		var u = (t = fr(e, i)) === j ? 7 : 0 | t[et], c = pr(u, r);
		if (a = !(4 & c)) {
			var l = t, d = r;
			let e = !!(2 & c);
			e && (d |= 2);
			let i = !e, s = !0, o = 0, a = 0;
			for (; o < l.length; o++) {
				let t = ye(l[o], n, !1, d);
				if (t instanceof n) {
					if (!e) {
						let e = ht(t);
						i &&= !e, s &&= e;
					}
					l[a++] = t;
				}
			}
			a < o && (l.length = a), c |= 4, c = s ? -4097 & c : 4096 | c, c = i ? 8 | c : -9 & c;
		}
		if (c !== u && (it(t, c), 2 & c && Object.freeze(t)), h && !(8 & c || !t.length && (1 === s || 4 === s && (2 & c || !(16 & c) && 32 & r)))) {
			for (gr(c) && (t = Vt(t), c = Nr(c, r), r = hr(e, r, i, t)), n = t, h = c, u = 0; u < n.length; u++) (l = n[u]) !== (c = Ze(l)) && (n[u] = c);
			h |= 8, it(t, c = h = n.length ? 4096 | h : -4097 & h);
		}
		return dr(t, c, e, r, i, s, a, o);
	}
	function xr(t, e, r) {
		var n = t.A;
		return Lr(t, n, 0 | n[et], e, r, cr(), !1, !0);
	}
	function Rr(t) {
		return t ??= void 0, t;
	}
	function Ir(t, e, r, n, i) {
		return ar(t, r, n = Rr(n), i), n && !ht(n) && er(t.A), t;
	}
	function Fr(t, e, r, n) {
		t: {
			var i = n = Rr(n);
			tr(t);
			let s = t.A, o = 0 | s[et];
			if (null == i) {
				let t = Ar(s);
				if (br(t, s, o, r) !== e) break t;
				t.set(r, 0);
			} else o = wr(s, o, r, e);
			hr(s, o, e, i);
		}
		return n && !ht(n) && er(t.A), t;
	}
	function Cr(t, e, r) {
		tr(t);
		var n = t.A, i = 0 | n[et];
		if (null == r) return hr(n, i, e), t;
		var s = r === j ? 7 : 0 | r[et], o = s, a = gr(s), h = a || Object.isFrozen(r), u = !0, c = !0;
		for (let t = 0; t < r.length; t++) {
			var l = r[t];
			a || (l = ht(l), u &&= !l, c &&= l);
		}
		return a || (s = u ? 13 : 5, s = c ? -4097 & s : 4096 | s), h && s === o || (r = Vt(r), o = 0, s = Nr(s, i)), s !== o && it(r, s), i = hr(n, i, e, r), 2 & s || !(4096 & s || 16 & s) || er(n, i), t;
	}
	function Nr(t, e) {
		return -273 & (2 & e ? 2 | t : -3 & t);
	}
	function Mr(t, e, r, n) {
		var i = n;
		tr(t), t = Lr(t, n = t.A, 0 | n[et], r, e, 2, !0), i = null != i ? i : new r(), t.push(i), e = r = t === j ? 7 : 0 | t[et], (i = ht(i)) ? (r &= -9, 1 === t.length && (r &= -4097)) : r |= 4096, r !== e && it(t, r), i || er(n);
	}
	function Or(t, e, r) {
		return re(sr(t, e, r));
	}
	function Dr(t, e) {
		return sr(t, e, void 0, Jt) ?? 0;
	}
	function Pr(t, e, r) {
		return Sr(t, e, r = Er(t, Uo) === r ? r : -1, void 0);
	}
	function $r(t, e) {
		_r(t, 3, null == e ? e : Zt(e), !1);
	}
	function Ur(t, e, r) {
		if (null != r) {
			if ("number" != typeof r) throw P("int32");
			if (!Wt(r)) throw P("int32");
			r |= 0;
		}
		ar(t, e, r);
	}
	function Br(t, e, r) {
		return ar(t, e, null == r ? r : ie(r));
	}
	function Gr(t, e, r) {
		return ar(t, e, null == r ? r : function(t) {
			if (!te(t)) throw P("uint64");
			switch (typeof t) {
				case "string":
					var e = zt(Number(t));
					return Xt(e) && e >= 0 ? t = At(e) : (-1 !== (e = t.indexOf(".")) && (t = t.substring(0, e)), t = U() ? At(Kt(64, BigInt(t))) : At(oe(t))), t;
				case "bigint": return At(Kt(64, t));
				default: return Xt(t) ? t = At(he(t)) : ((t = zt(t)) >= 0 && Xt(t) ? t = String(t) : (Nt(t), t = $t(It, Ft)), t = At(t)), t;
			}
		}(r));
	}
	function jr(t, e, r) {
		ar(t, e, null == r ? r : qt(r));
	}
	function Vr(t, e, r) {
		_r(t, e, null == r ? r : qt(r), 0);
	}
	function Hr(t, e, r) {
		_r(t, e, ve(r), "");
	}
	function Kr(t, e, r) {
		{
			tr(t);
			let o = t.A, a = 0 | o[et];
			if (null == r) hr(o, a, e);
			else {
				var n = t = r === j ? 7 : 0 | r[et], i = gr(t), s = i || Object.isFrozen(r);
				for (i || (t = 0), s || (r = Vt(r), n = 0, t = Nr(t, a), s = !1), t |= 5, t |= (4 & t ? 512 & t ? 512 : 1024 & t ? 1024 : 0 : void 0) ?? 1024, i = 0; i < r.length; i++) {
					let e = r[i], o = me(e);
					Object.is(e, o) || (s && (r = Vt(r), n = 0, t = Nr(t, a), s = !1), r[i] = o);
				}
				t !== n && (s && (r = Vt(r), t = Nr(t, a)), it(r, t)), hr(o, a, e, r);
			}
		}
	}
	function Xr(t, e, r) {
		tr(t), lr(t, e, _e, 2, !0).push(me(r));
	}
	var Wr = class {
		constructor(t, e, r) {
			if (this.buffer = t, r && !e) throw Error();
			this.g = e;
		}
	};
	function zr(t, e) {
		if ("string" == typeof t) return new Wr(L(t), e);
		if (Array.isArray(t)) return new Wr(new Uint8Array(t), e);
		if (t.constructor === Uint8Array) return new Wr(t, !1);
		if (t.constructor === ArrayBuffer) return t = new Uint8Array(t), new Wr(t, !1);
		if (t.constructor === N) return e = F(t) || /* @__PURE__ */ new Uint8Array(0), new Wr(e, !0, t);
		if (t instanceof Uint8Array) return t = t.constructor === Uint8Array ? t : new Uint8Array(t.buffer, t.byteOffset, t.byteLength), new Wr(t, !1);
		throw Error();
	}
	function Yr(t, e) {
		var r = 0, n = 0, i = 0, s = t.h, o = t.g;
		do {
			var a = s[o++];
			r |= (127 & a) << i, i += 7;
		} while (i < 32 && 128 & a);
		if (i > 32) for (n |= (127 & a) >> 4, i = 3; i < 32 && 128 & a; i += 7) n |= (127 & (a = s[o++])) << i;
		if (nn(t, o), !(128 & a)) return e(r >>> 0, n >>> 0);
		throw Error();
	}
	function qr(t) {
		for (var e = 0, r = t.g, n = r + 10, i = t.h; r < n;) {
			let n = i[r++];
			if (e |= n, !(128 & n)) return nn(t, r), !!(127 & e);
		}
		throw Error();
	}
	function Jr(t) {
		var e = t.h, r = t.g, n = e[r++], i = 127 & n;
		if (128 & n && (i |= (127 & (n = e[r++])) << 7, 128 & n && (i |= (127 & (n = e[r++])) << 14, 128 & n && (i |= (127 & (n = e[r++])) << 21, 128 & n && (i |= (n = e[r++]) << 28, 128 & n && 128 & e[r++] && 128 & e[r++] && 128 & e[r++] && 128 & e[r++] && 128 & e[r++]))))) throw Error();
		return nn(t, r), i;
	}
	function Zr(t) {
		return Jr(t) >>> 0;
	}
	function Qr(t) {
		return Yr(t, Pt);
	}
	function tn(t) {
		var e = t.h, r = t.g, n = e[r], i = e[r + 1], s = e[r + 2];
		return e = e[r + 3], nn(t, t.g + 4), (n | i << 8 | s << 16 | e << 24) >>> 0;
	}
	function en(t) {
		var e = tn(t);
		t = 2 * (e >> 31) + 1;
		var r = e >>> 23 & 255;
		return e &= 8388607, 255 == r ? e ? NaN : t * (1 / 0) : 0 == r ? 1401298464324817e-60 * t * e : t * Math.pow(2, r - 150) * (e + 8388608);
	}
	function rn(t) {
		return Jr(t);
	}
	function nn(t, e) {
		if (t.g = e, e > t.j) throw Error();
	}
	function sn(t, e) {
		if (e < 0) throw Error();
		var r = t.g;
		if ((e = r + e) > t.j) throw Error();
		return t.g = e, r;
	}
	function on(t, e) {
		if (0 == e) return I();
		var r = sn(t, e);
		return t.fa && t.o ? r = t.h.subarray(r, r + e) : (t = t.h, r = r === (e = r + e) ? /* @__PURE__ */ new Uint8Array(0) : Rt ? t.slice(r, e) : new Uint8Array(t.subarray(r, e))), 0 == r.length ? I() : new N(r, R);
	}
	var an = class {
		constructor(t, e, r, n) {
			this.h = null, this.o = !1, this.g = this.j = this.m = 0, this.init(t, e, r, n);
		}
		init(t, e, r, { fa: n = !1, ma: i = !1 } = {}) {
			this.fa = n, this.ma = i, t && (t = zr(t, this.ma), this.h = t.buffer, this.o = t.g, this.m = e || 0, this.j = void 0 !== r ? this.m + r : this.h.length, this.g = this.m);
		}
		clear() {
			this.h = null, this.o = !1, this.g = this.j = this.m = 0, this.fa = !1;
		}
	};
	var hn = [];
	var un = 0;
	function cn(t, e, r, n) {
		if (En.length) {
			let i = En.pop();
			return i.v(n), i.g.init(t, e, r, n), i;
		}
		return new yn(t, e, r, n);
	}
	function ln(t) {
		t.g.clear(), t.j = -1, t.h = -1, En.length < 100 && En.push(t);
	}
	function dn(t) {
		var e = t.g;
		if (e.g == e.j) return !1;
		t.m = t.g.g;
		var r = Zr(t.g);
		if (e = r >>> 3, !((r &= 7) >= 0 && r <= 5)) throw Error();
		if (e < 1) throw Error();
		return t.j = e, t.h = r, !0;
	}
	function fn(t) {
		try {
			switch (t.h) {
				case 0:
					0 != t.h ? fn(t) : qr(t.g);
					break;
				case 1:
					var e = t.g;
					nn(e, e.g + 8);
					break;
				case 2:
					if (2 != t.h) fn(t);
					else {
						var r = Zr(t.g), n = t.g;
						nn(n, n.g + r);
					}
					break;
				case 5:
					var i = t.g;
					nn(i, i.g + 4);
					break;
				case 3:
					pn();
					let s = t.j;
					try {
						for (;;) {
							if (!dn(t)) throw Error();
							if (4 == t.h) {
								if (t.j != s) throw Error();
								break;
							}
							fn(t);
						}
					} catch (t) {
						if (t instanceof RangeError) throw new SyntaxError();
						throw t;
					} finally {
						un > 0 && un--;
					}
					break;
				default: throw Error();
			}
		} catch (t) {
			if (t instanceof RangeError) throw new SyntaxError();
			throw t;
		}
	}
	function pn() {
		if (un >= 100) throw new SyntaxError();
		un++;
	}
	function gn(t, e, r) {
		var n = t.g.j, i = Zr(t.g), s = (i = t.g.g + i) - n;
		if (s <= 0 && (t.g.j = i, r(e, t, void 0, void 0, void 0), s = i - t.g.g), s) throw Error();
		return t.g.g = i, t.g.j = n, e;
	}
	function mn(t) {
		var e = Zr(t.g), r = sn(t = t.g, e);
		if (t = t.h, h) {
			var o, u = t;
			(o = s) || (o = s = new TextDecoder("utf-8", { fatal: !0 })), e = r + e, u = 0 === r && e === u.length ? u : u.subarray(r, e);
			try {
				var c = o.decode(u);
			} catch (t) {
				if (void 0 === a) {
					try {
						o.decode(new Uint8Array([128]));
					} catch (t) {}
					try {
						o.decode(new Uint8Array([97])), a = !0;
					} catch (t) {
						a = !1;
					}
				}
				throw !a && (s = void 0), t;
			}
		} else {
			e = (c = r) + e, r = [];
			let s, a = null;
			for (; c < e;) {
				var l = t[c++];
				l < 128 ? r.push(l) : l < 224 ? c >= e ? n() : (s = t[c++], l < 194 || 128 != (192 & s) ? (c--, n()) : r.push((31 & l) << 6 | 63 & s)) : l < 240 ? c >= e - 1 ? n() : (s = t[c++], 128 != (192 & s) || 224 === l && s < 160 || 237 === l && s >= 160 || 128 != (192 & (o = t[c++])) ? (c--, n()) : r.push((15 & l) << 12 | (63 & s) << 6 | 63 & o)) : l <= 244 ? c >= e - 2 ? n() : (s = t[c++], 128 != (192 & s) || s - 144 + (l << 28) >> 30 || 128 != (192 & (o = t[c++])) || 128 != (192 & (u = t[c++])) ? (c--, n()) : (l = (7 & l) << 18 | (63 & s) << 12 | (63 & o) << 6 | 63 & u, l -= 65536, r.push(55296 + (l >> 10 & 1023), 56320 + (1023 & l)))) : n(), r.length >= 8192 && (a = i(a, r), r.length = 0);
			}
			c = i(a, r);
		}
		return c;
	}
	function vn(t) {
		var e = Zr(t.g);
		return on(t.g, e);
	}
	function _n(t, e, r) {
		var n = Zr(t.g);
		for (n = t.g.g + n; t.g.g < n;) r.push(e(t.g));
	}
	var yn = class {
		constructor(t, e, r, n) {
			if (hn.length) {
				let i = hn.pop();
				i.init(t, e, r, n), t = i;
			} else t = new an(t, e, r, n);
			this.g = t, this.m = this.g.g, this.h = this.j = -1, this.v(n);
		}
		v({ ra: t = !1 } = {}) {
			this.ra = t;
		}
	};
	var En = [];
	function An(t) {
		return new Tn(4294967295 & t, Math.floor(t / 4294967296));
	}
	function wn(t) {
		return t ? /^\d+$/.test(t) ? (Gt(t), new Tn(It, Ft)) : null : bn ||= new Tn(0, 0);
	}
	var bn;
	var Tn = class {
		constructor(t, e) {
			this.h = t >>> 0, this.g = e >>> 0;
		}
	};
	function kn(t) {
		return new On(4294967295 & t, Math.floor(t / 4294967296));
	}
	function Sn(t) {
		return t ? /^-?\d+$/.test(t) ? (Gt(t), new On(It, Ft)) : null : Ln ||= new On(0, 0);
	}
	var Ln;
	var xn;
	var Rn;
	var In;
	var Fn;
	var Cn;
	var Nn;
	var Mn;
	var On = class {
		constructor(t, e) {
			this.h = t >>> 0, this.g = e >>> 0;
		}
	};
	function Dn(t, e, r) {
		return "undefined" != typeof BigInt64Array ? (Nn || (Nn = /* @__PURE__ */ new BigInt64Array(1), Mn = new Uint32Array(Nn.buffer), Nn[0] = BigInt(1), Cn = 1 === Mn[0]), Nn[0] = t, new e(Mn[t = Cn ? 0 : 1], Mn[1 - t])) : (Fn || (xn = BigInt(Number.MIN_SAFE_INTEGER), Rn = BigInt(Number.MAX_SAFE_INTEGER), In = BigInt(4294967295), Fn = BigInt(32)), t >= xn && t <= Rn ? r(Number(t)) : (t = BigInt.asUintN(64, t), new e(Number(t & In), Number(t >> Fn))));
	}
	function Pn(t, e, r) {
		for (; r > 0 || e > 127;) t.g.push(127 & e | 128), e = (e >>> 7 | r << 25) >>> 0, r >>>= 7;
		t.g.push(e);
	}
	function $n(t, e) {
		for (; e > 127;) t.g.push(127 & e | 128), e >>>= 7;
		t.g.push(e);
	}
	function Un(t, e) {
		if (e >= 0) $n(t, e);
		else {
			for (let r = 0; r < 9; r++) t.g.push(127 & e | 128), e >>= 7;
			t.g.push(1);
		}
	}
	function Bn(t, e) {
		Gt(e), function(t) {
			var e = Ft >> 31;
			t(It << 1 ^ e, (Ft << 1 | It >>> 31) ^ e);
		}((e, r) => {
			Pn(t, e >>> 0, r >>> 0);
		});
	}
	function Gn(t, e) {
		t.g.push(e >>> 0 & 255), t.g.push(e >>> 8 & 255), t.g.push(e >>> 16 & 255), t.g.push(e >>> 24 & 255);
	}
	var jn = class {
		constructor() {
			this.g = [];
		}
		length() {
			return this.g.length;
		}
		end() {
			var t = this.g;
			return this.g = [], t;
		}
	};
	function Vn(t, e) {
		0 !== e.length && (t.j.push(e), t.h += e.length);
	}
	function Hn(t, e, r) {
		$n(t.g, 8 * e + r);
	}
	function Kn(t, e) {
		return Hn(t, e, 2), e = t.g.end(), Vn(t, e), e.push(t.h), e;
	}
	function Xn(t, e) {
		var r = e.pop();
		for (r = t.h + t.g.length() - r; r > 127;) e.push(127 & r | 128), r >>>= 7, t.h++;
		e.push(r), t.h++;
	}
	function Wn(t, e, r) {
		if (null != r) switch (Hn(t, e, 0), typeof r) {
			case "number":
				t = t.g, Nt(r), Pn(t, It, Ft);
				break;
			case "bigint":
				r = Dn(r, On, kn), Pn(t.g, r.h, r.g);
				break;
			default: r = Sn(r), Pn(t.g, r.h, r.g);
		}
	}
	function zn(t, e, r) {
		Hn(t, e, 2), $n(t.g, r.length), Vn(t, t.g.end()), Vn(t, r);
	}
	function Yn(t, e, r, n) {
		null != r && (e = Kn(t, e), n(r, t), Xn(t, e));
	}
	var qn = class {
		constructor() {
			this.j = [], this.h = 0, this.g = new jn();
		}
	};
	function Jn(t) {
		if ("string" == typeof t) Sn(t);
	}
	function Zn() {
		var t = class {
			constructor() {
				throw Error();
			}
		};
		return Object.setPrototypeOf(t, t.prototype), t;
	}
	var Qn = Zn();
	var ti = Zn();
	var ei = Zn();
	var ri = Zn();
	var ni = Zn();
	var ii = Zn();
	var si = Zn();
	var oi = Zn();
	var ai = Zn();
	var hi = Zn();
	var ui = Zn();
	var ci = Zn();
	function li(t, e, r) {
		var n = t.A;
		X && X in n && (n = n[X]) && delete n[e.g], e.h ? e.o(t, e.h, e.g, r, e.j) : e.o(t, e.g, r, e.j);
	}
	var di = class {
		constructor(t, e) {
			this.A = Xe(t, e, void 0, 2048);
		}
		toJSON() {
			return He(this);
		}
		o() {
			var t = Ca, e = this.A, r = t.g, n = X;
			if (B && n && null != e[n]?.[r] && $(W, 3), e = t.g, Z && X && void 0 === Z && (n = (r = this.A)[X]) && (n = n.ka)) try {
				n(r, e, Ue);
			} catch (t) {
				l(t);
			}
			return t.h ? t.m(this, t.h, t.g, t.j) : t.m(this, t.g, t.defaultValue, t.j);
		}
		clone() {
			var t = this.A, e = 0 | t[et];
			return rr(this, t, e) ? Ye(this, t, !0) : new this.constructor(Je(t, e, !1));
		}
	};
	di.prototype[J] = at, di.prototype.toString = function() {
		return this.A.toString();
	};
	var fi = class {
		constructor(t, e, r) {
			this.g = t, this.h = e, t = Qn, this.j = !!t && r === t || !1;
		}
	};
	function pi(t, e) {
		return new fi(t, e, Qn);
	}
	function gi(t, e, r, n, i) {
		Yn(t, r, Li(e, n), i);
	}
	var mi;
	var vi;
	var _i = pi(function(t, e, r, n, i) {
		return 2 === t.h && (gn(t, Tr(e, n, r), i), !0);
	}, gi);
	var yi = pi(function(t, e, r, n, i) {
		return 2 === t.h && (gn(t, Tr(e, n, r), i), !0);
	}, gi);
	var Ei = Symbol();
	var Ai = Symbol();
	var wi = Symbol();
	var bi = Symbol();
	var Ti = Symbol();
	function ki(t, e, r, n) {
		var i = n[t];
		if (i) return i;
		(i = {}).Ea = n, i.ca = function(t) {
			switch (typeof t) {
				case "boolean": return De ||= [
					0,
					void 0,
					!0
				];
				case "number": return t > 0 ? void 0 : 0 === t ? Pe ||= [0, void 0] : [-t, void 0];
				case "string": return [0, t];
				case "object": return t;
			}
		}(n[0]);
		var s = n[1], o = 1;
		s && s.constructor === Object && (i.ia = s, "function" == typeof (s = n[++o]) && (i.wa = !0, mi ??= s, vi ??= n[o + 1], s = n[o += 2]));
		for (var a = {}; s && Array.isArray(s) && s.length && "number" == typeof s[0] && s[0] > 0;) {
			for (var h = 0; h < s.length; h++) a[s[h]] = s;
			s = n[++o];
		}
		for (h = 1; void 0 !== s;) {
			let t;
			"number" == typeof s && (h += s, s = n[++o]);
			var u = void 0;
			if (s instanceof fi ? t = s : (t = _i, o--), t?.j) {
				s = n[++o], u = n;
				var c = o;
				"function" == typeof s && (s = s(), u[c] = s), u = s;
			}
			for (c = h + 1, "number" == typeof (s = n[++o]) && s < 0 && (c -= s, s = n[++o]); h < c; h++) {
				let n = a[h];
				u ? r(i, h, t, u, n) : e(i, h, t, n);
			}
		}
		return n[t] = i;
	}
	function Si(t) {
		return Array.isArray(t) ? t[0] instanceof fi ? t : [yi, t] : [t, void 0];
	}
	function Li(t, e) {
		return t instanceof di ? t.A : Array.isArray(t) ? Ke(t, e) : void 0;
	}
	function xi(t, e, r, n) {
		var i = r.g;
		t[e] = n ? (t, e, r) => i(t, e, r, n) : i;
	}
	function Ri(t, e, r, n, i) {
		var s, o, a = r.g;
		t[e] = (t, e, r) => a(t, e, r, o ||= ki(Ai, xi, Ri, n).ca, s ||= Ii(n), i);
	}
	function Ii(t) {
		var e = t[wi];
		if (null != e) return e;
		var r = ki(Ai, xi, Ri, t);
		return e = r.wa ? (t, e) => mi(t, e, r) : (t, e) => {
			t: {
				pn();
				try {
					for (; dn(e) && 4 != e.h;) {
						let h = e.j, u = r[h];
						if (null == u) {
							let t = r.ia;
							if (t) {
								let e = t[h];
								if (e) {
									let t = Ci(e);
									null != t && (u = r[h] = t);
								}
							}
						}
						if (null == u || !u(e, t, h)) {
							var n = e;
							let r = n.m;
							if (fn(n), n.ra) var i = void 0;
							else {
								let t = n.g.g - r;
								n.g.g = r, i = on(n.g, t);
							}
							n = void 0;
							var s = t, o = h, a = i;
							a && ((n = s[X] ?? (s[X] = new $e()))[o] ?? (n[o] = [])).push(a);
						}
					}
					let u = Ne(t);
					u && (u.ka = r.Ea[Ti]);
					var h = !0;
					break t;
				} catch (t) {
					if (t instanceof RangeError) throw new SyntaxError();
					throw t;
				} finally {
					un > 0 && un--;
				}
			}
			return h;
		}, t[wi] = e, t[Ti] = Fi.bind(t), e;
	}
	function Fi(t, e, r, n) {
		var i = this[Ai], s = this[wi], o = Ke(void 0, i.ca), a = Ne(t);
		if (a) {
			var h = !1, u = i.ia;
			if (u) {
				if (i = (e, r, i) => {
					if (0 !== i.length) if (u[r]) for (let t of i) {
						e = cn(t);
						try {
							h = !0, s(o, e);
						} finally {
							ln(e);
						}
					}
					else n?.(t, r, i);
				}, null == e) Me(a, i);
				else if (null != a) {
					let t = a[e];
					t && i(a, e, t);
				}
				if (h) {
					let n = 0 | t[et];
					if (2 & n && 2048 & n && !r?.cb) throw Error();
					let i = gt(n), s = (e, s) => {
						if (null != or(t, e, i)) {
							if (1 === r?.lb) return;
							throw Error();
						}
						null != s && (n = hr(t, n, e, s, i)), delete a[e];
					};
					null == e ? ft(o, 0 | o[et], (t, e) => {
						s(t, e);
					}) : s(e, or(o, e, i));
				}
			}
		}
	}
	function Ci(t) {
		var e = (t = Si(t))[0].g;
		if (t = t[1]) {
			let r = Ii(t), n = ki(Ai, xi, Ri, t).ca;
			return (t, i, s) => e(t, i, s, n, r);
		}
		return e;
	}
	function Ni(t, e, r) {
		t[e] = r.h;
	}
	function Mi(t, e, r, n) {
		var i, s, o = r.h;
		t[e] = (t, e, r) => o(t, e, r, s ||= ki(Ei, Ni, Mi, n).ca, i ||= Oi(n));
	}
	function Oi(t) {
		var e = t[bi];
		if (!e) {
			let r = ki(Ei, Ni, Mi, t);
			e = (t, e) => Di(t, e, r), t[bi] = e;
		}
		return e;
	}
	function Di(t, e, r) {
		ft(t, 0 | t[et], (t, n) => {
			if (null != n) {
				var i = function(t, e) {
					var r = t[e];
					if (r) return r;
					if ((r = t.ia) && (r = r[e])) {
						var n = (r = Si(r))[0].h;
						if (r = r[1]) {
							let e = Oi(r), i = ki(Ei, Ni, Mi, r).ca;
							r = t.wa ? vi(i, e) : (t, r, s) => n(t, r, s, i, e);
						} else r = n;
						return t[e] = r;
					}
				}(r, t);
				i ? i(e, n, t) : t < 500 || $(Y, 3);
			}
		}), (t = Ne(t)) && Me(t, (t, r, n) => {
			for (Vn(e, e.g.end()), t = 0; t < n.length; t++) Vn(e, F(n[t]) || /* @__PURE__ */ new Uint8Array(0));
		});
	}
	var Pi = At(0);
	function $i(t, e, r) {
		if (Array.isArray(e)) {
			var n = 0 | e[et];
			if (4 & n) return e;
			for (var i = 0, s = 0; i < e.length; i++) {
				let r = t(e[i]);
				null != r && (e[s++] = r);
			}
			return s < i && (e.length = s), t = 1 | n, r && (t = -1537 & t | 4), t !== n && it(e, t), r && 2 & t && Object.freeze(e), e;
		}
	}
	var Ui = (t, e) => {
		var r = new qn();
		Di(t.A, r, ki(Ei, Ni, Mi, e)), Vn(r, r.g.end()), t = new Uint8Array(r.h);
		var n = (e = r.j).length, i = 0;
		for (let r = 0; r < n; r++) {
			let n = e[r];
			t.set(n, i), i += n.length;
		}
		return r.j = [t], t;
	};
	function Bi(t, e, r) {
		return new fi(t, e, r);
	}
	function Gi(t, e, r) {
		return new fi(t, e, r);
	}
	function ji(t, e, r) {
		hr(t, 0 | t[et], e, r, gt(0 | t[et]));
	}
	var Vi = pi(function(t, e, r, n, i) {
		if (2 !== t.h) return !1;
		if (t = Vt(t = gn(t, Ke([void 0, void 0], n), i)), i = gt(n = 0 | e[et]), 2 & n) throw Error();
		var s = or(e, r, i);
		if (s instanceof Re) 2 & s.M ? ((s = s.ea()).push(t), hr(e, n, r, s, i)) : s.gb(t);
		else if (Array.isArray(s)) {
			var o = 0 | s[et];
			8192 & o || it(s, o |= 8192), 2 & o && hr(e, n, r, s = vr(s), i), s.push(t);
		} else hr(e, n, r, ot([t]), i);
		return !0;
	}, function(t, e, r, n, i) {
		if (e instanceof Re) e.forEach((e, s) => {
			Yn(t, r, Ke([s, e], n), i);
		});
		else if (Array.isArray(e)) {
			for (let s = 0; s < e.length; s++) {
				let o = e[s];
				Array.isArray(o) && Yn(t, r, Ke(o, n), i);
			}
			ot(e);
		}
	});
	function Hi(t, e, r) {
		null != (e = Jt(e)) && (Hn(t, r, 5), t = t.g, Mt(e), Gn(t, It));
	}
	function Ki(t, e, r) {
		null != (e = pe(e)) && (Jn(e), Wn(t, r, e));
	}
	function Xi(t, e, r) {
		null != (e = re(e)) && null != e && (Hn(t, r, 0), Un(t.g, e));
	}
	function Wi(t, e, r) {
		null != (e = null == e || "boolean" == typeof e ? e : "number" == typeof e ? !!e : void 0) && (Hn(t, r, 0), t.g.g.push(e ? 1 : 0));
	}
	function zi(t, e, r) {
		null != (e = _e(e)) && zn(t, r, c(e));
	}
	function Yi(t, e, r, n, i) {
		Yn(t, r, Li(e, n), i);
	}
	function qi(t, e, r) {
		null != (e = ge(e)) && zn(t, r, zr(e, !0).buffer);
	}
	function Ji(t, e, r) {
		null != (e = ne(e)) && null != e && (Hn(t, r, 0), $n(t.g, e));
	}
	function Zi(t, e, r) {
		null != (e = re(e)) && (e = parseInt(e, 10), Hn(t, r, 0), Un(t.g, e));
	}
	function Qi(t, e, r) {
		return (5 === t.h || 2 === t.h) && (e = yr(e, 0 | e[et], r), 2 == t.h ? _n(t, en, e) : e.push(en(t.g)), !0);
	}
	function ts(t, e, r) {
		return 0 === t.h && (ji(e, r, Qr(t.g)), !0);
	}
	function es(t, e, r) {
		return (0 === t.h || 2 === t.h) && (e = yr(e, 0 | e[et], r), 2 == t.h ? _n(t, Jr, e) : e.push(Jr(t.g)), !0);
	}
	function rs(t, e, r) {
		return 2 === t.h && (ji(e, r, (t = vn(t)) === I() ? void 0 : t), !0);
	}
	var ns = Bi(function(t, e, r) {
		if (1 !== t.h) return !1;
		var n = t.g;
		t = tn(n);
		var i = tn(n);
		n = 2 * (i >> 31) + 1;
		var s = i >>> 20 & 2047;
		return t = 4294967296 * (1048575 & i) + t, ji(e, r, 2047 == s ? t ? NaN : n * (1 / 0) : 0 == s ? 5e-324 * n * t : n * Math.pow(2, s - 1075) * (t + 4503599627370496)), !0;
	}, function(t, e, r) {
		null != (e = Jt(e)) && (Hn(t, r, 1), t = t.g, (r = xt ||= /* @__PURE__ */ new DataView(/* @__PURE__ */ new ArrayBuffer(8))).setFloat64(0, +e, !0), It = r.getUint32(0, !0), Ft = r.getUint32(4, !0), Gn(t, It), Gn(t, Ft));
	}, hi);
	var is = Bi(function(t, e, r) {
		return 5 === t.h && (ji(e, r, en(t.g)), !0);
	}, Hi, ai);
	var ss = Gi(Qi, function(t, e, r) {
		if (null != (e = $i(Jt, e, !0))) for (let o = 0; o < e.length; o++) {
			var n = t, i = r, s = e[o];
			null != s && (Hn(n, i, 5), n = n.g, Mt(s), Gn(n, It));
		}
	}, ai);
	var os = Gi(Qi, function(t, e, r) {
		if (null != (e = $i(Jt, e, !0)) && e.length) {
			Hn(t, r, 2), $n(t.g, 4 * e.length);
			for (let n = 0; n < e.length; n++) r = t.g, Mt(e[n]), Gn(r, It);
		}
	}, ai);
	var as = Bi(function(t, e, r) {
		return 5 === t.h && (ji(e, r, 0 === (t = en(t.g)) ? void 0 : t), !0);
	}, Hi, ai);
	var hs = Bi(function(t, e, r) {
		return ts(t, e, r);
	}, Ki, ii);
	var us = Bi(function(t, e, r) {
		return ts(t, e, r);
	}, Ki, ii);
	var cs = Gi(function(t, e, r) {
		return 0 !== t.h && 2 !== t.h ? t = !1 : (e = yr(e, 0 | e[et], r), 2 == t.h ? _n(t, Qr, e) : e.push(Qr(t.g)), t = !0), t;
	}, function(t, e, r) {
		if (null != (e = $i(pe, e, !1))) for (let n = 0; n < e.length; n++) Wn(t, r, e[n]);
	}, ii);
	var ls = Bi(function(t, e, r) {
		return 0 !== t.h ? e = !1 : (ji(e, r, (t = Qr(t.g)) === Pi ? void 0 : t), e = !0), e;
	}, Ki, ii);
	var ds = Bi(function(t, e, r) {
		return 0 !== t.h ? t = !1 : (ji(e, r, Yr(t.g, Dt)), t = !0), t;
	}, function(t, e, r) {
		if (e = function(t) {
			if (null == t) return t;
			var e = typeof t;
			if ("bigint" === e) return String(Kt(64, t));
			if (te(t)) {
				if ("string" === e) return e = zt(Number(t)), Xt(e) && e >= 0 ? t = String(e) : (-1 !== (e = t.indexOf(".")) && (t = t.substring(0, e)), t = oe(t)), t;
				if ("number" === e) return he(t);
			}
		}(e), null != e) {
			if ("string" == typeof e) wn(e);
			if (null != e) switch (Hn(t, r, 0), typeof e) {
				case "number":
					t = t.g, Nt(e), Pn(t, It, Ft);
					break;
				case "bigint":
					r = Dn(e, Tn, An), Pn(t.g, r.h, r.g);
					break;
				default: r = wn(e), Pn(t.g, r.h, r.g);
			}
		}
	}, si);
	var fs = Bi(function(t, e, r) {
		return 0 === t.h && (ji(e, r, Jr(t.g)), !0);
	}, Xi, ri);
	var ps = Gi(es, function(t, e, r) {
		if (null != (e = $i(re, e, !0))) for (let o = 0; o < e.length; o++) {
			var n = t, i = r, s = e[o];
			null != s && (Hn(n, i, 0), Un(n.g, s));
		}
	}, ri);
	var gs = Gi(es, function(t, e, r) {
		if (null != (e = $i(re, e, !0)) && e.length) {
			r = Kn(t, r);
			for (let r = 0; r < e.length; r++) Un(t.g, e[r]);
			Xn(t, r);
		}
	}, ri);
	var ms = Bi(function(t, e, r) {
		return 0 === t.h && (ji(e, r, 0 === (t = Jr(t.g)) ? void 0 : t), !0);
	}, Xi, ri);
	var vs = Bi(function(t, e, r) {
		return 0 === t.h && (ji(e, r, qr(t.g)), !0);
	}, Wi, ti);
	var _s = Bi(function(t, e, r) {
		return 0 === t.h && (ji(e, r, !1 === (t = qr(t.g)) ? void 0 : t), !0);
	}, Wi, ti);
	var ys = Gi(function(t, e, r) {
		return 2 === t.h && (t = mn(t), yr(e, 0 | e[et], r).push(t), !0);
	}, function(t, e, r) {
		if (null != (e = $i(_e, e, !0))) for (let o = 0; o < e.length; o++) {
			var n = t, i = r, s = e[o];
			null != s && zn(n, i, c(s));
		}
	}, ei);
	var Es = Bi(function(t, e, r) {
		return 2 === t.h && (ji(e, r, "" === (t = mn(t)) ? void 0 : t), !0);
	}, zi, ei);
	var As = Bi(function(t, e, r) {
		return 2 === t.h && (ji(e, r, mn(t)), !0);
	}, zi, ei);
	var ws = function(t, e, r = Qn) {
		return new fi(t, e, r);
	}(function(t, e, r, n, i) {
		return 2 === t.h && (n = Ke(void 0, n), yr(e, 0 | e[et], r).push(n), gn(t, n, i), !0);
	}, function(t, e, r, n, i) {
		if (Array.isArray(e)) {
			for (let s = 0; s < e.length; s++) Yi(t, e[s], r, n, i);
			1 & (t = 0 | e[et]) || it(e, 1 | t);
		}
	});
	var bs = pi(function(t, e, r, n, i, s) {
		if (2 !== t.h) return !1;
		var o = 0 | e[et];
		return wr(e, o, s, r, gt(o)), gn(t, e = Tr(e, n, r), i), !0;
	}, Yi);
	var Ts = Bi(function(t, e, r) {
		return 2 === t.h && (ji(e, r, vn(t)), !0);
	}, qi, ui);
	var ks = Gi(function(t, e, r) {
		return 2 === t.h && (t = vn(t), yr(e, 0 | e[et], r).push(t), !0);
	}, function(t, e, r) {
		if (null != (e = $i(ge, e, !1))) for (let o = 0; o < e.length; o++) {
			var n = t, i = r, s = e[o];
			null != s && zn(n, i, zr(s, !0).buffer);
		}
	}, ui);
	var Ss = Bi(function(t, e, r) {
		return 0 === t.h && (ji(e, r, Zr(t.g)), !0);
	}, Ji, ni);
	var Ls = Gi(function(t, e, r) {
		return (0 === t.h || 2 === t.h) && (e = yr(e, 0 | e[et], r), 2 == t.h ? _n(t, Zr, e) : e.push(Zr(t.g)), !0);
	}, function(t, e, r) {
		if (null != (e = $i(ne, e, !0))) for (let o = 0; o < e.length; o++) {
			var n = t, i = r, s = e[o];
			null != s && (Hn(n, i, 0), $n(n.g, s));
		}
	}, ni);
	var xs = Bi(function(t, e, r) {
		return 0 === t.h && (ji(e, r, 0 === (t = Zr(t.g)) ? void 0 : t), !0);
	}, Ji, ni);
	var Rs = Bi(function(t, e, r) {
		return 0 === t.h && (ji(e, r, Jr(t.g)), !0);
	}, Zi, ci);
	var Is = Bi(function(t, e, r) {
		return 0 === t.h && (ji(e, r, 0 === (t = Jr(t.g)) ? void 0 : t), !0);
	}, Zi, ci);
	var Fs = Bi(function(t, e, r) {
		return 0 !== t.h ? t = !1 : (ji(e, r, function(t) {
			return Yr(t, (t, e) => {
				var r = -(1 & t);
				return Pt(t = (t >>> 1 | e << 31) ^ r, e >>> 1 ^ r);
			});
		}(t.g)), t = !0), t;
	}, function(t, e, r) {
		if (null != (e = pe(e)) && (Jn(e), null != e)) switch (Hn(t, r, 0), typeof e) {
			case "number":
				t = t.g, e = (r = e) < 0, Ct(r = 2 * Math.abs(r)), r = It;
				let n = Ft;
				e && (0 == r ? 0 == n ? n = r = 4294967295 : (n--, r = 4294967295) : r--), Pn(t, It = r, Ft = n);
				break;
			case "bigint":
				t = t.g, e = e << BigInt(1) ^ e >> BigInt(63), It = Number(BigInt.asUintN(32, e)), Ft = Number(BigInt.asUintN(32, e >> BigInt(32))), Pn(t, It, Ft);
				break;
			default: Bn(t.g, e);
		}
	}, oi);
	var Cs = class {
		constructor(t, e) {
			var r = no;
			this.g = t, this.h = e, this.m = Sr, this.o = Ir, this.defaultValue = void 0, this.j = null != r.jb ? pt : void 0;
		}
		register() {
			v(this);
		}
	};
	function Ns(t, e) {
		return new Cs(t, e);
	}
	function Ms(t, e) {
		return (r, n) => {
			t: {
				let s = { ma: !0 };
				n && Object.assign(s, n), r = cn(r, void 0, void 0, s);
				try {
					let n = new t(), s = n.A;
					Ii(e)(s, r);
					var i = n;
					break t;
				} catch (t) {
					if (t instanceof RangeError) throw new SyntaxError();
					throw t;
				} finally {
					ln(r);
				}
			}
			return i;
		};
	}
	function Os(t) {
		return (e) => Ui(e, t);
	}
	function Ds(t) {
		return function() {
			return Ui(this, t);
		};
	}
	var Ps = [
		0,
		Ts,
		ks,
		vs,
		As
	];
	var $s = [
		0,
		Es,
		[
			0,
			Is,
			[
				0,
				ls,
				ms
			],
			Is,
			-1,
			[0, Rs],
			Is,
			-1
		],
		Bi(rs, qi, ui)
	];
	var Us;
	var Bs = class extends di {
		constructor(t) {
			super(t);
		}
	};
	var Gs = [
		0,
		Es,
		Bi(rs, function(t, e, r) {
			if (null != e) {
				if (e instanceof di) {
					let n = e.mb;
					n ? (e = n(e), null != e && zn(t, r, zr(e, !0).buffer)) : $(Y, 3);
					return;
				}
				if (Array.isArray(e)) return void $(Y, 3);
			}
			qi(t, e, r);
		}, ui)
	];
	var js = [
		0,
		1,
		[
			0,
			12,
			fs,
			10,
			vs
		],
		[
			0,
			7,
			[
				0,
				fs,
				-1
			]
		]
	];
	var Vs = globalThis.trustedTypes;
	var Hs = class {
		constructor(t) {
			this.g = t;
		}
		toString() {
			return this.g + "";
		}
	};
	function Ks(t) {
		var e;
		return void 0 === Us && (Us = function() {
			var t = null;
			if (!Vs) return t;
			try {
				let e = (t) => t;
				t = Vs.createPolicy("goog#html", {
					createHTML: e,
					createScript: e,
					createScriptURL: e
				});
			} catch (t) {}
			return t;
		}()), t = (e = Us) ? e.createScriptURL(t) : t, new Hs(t);
	}
	function Xs(t, ...e) {
		if (0 === e.length) return Ks(t[0]);
		var r = t[0];
		for (let n = 0; n < e.length; n++) r += encodeURIComponent(e[n]) + t[n + 1];
		return Ks(r);
	}
	var Ws = [
		0,
		fs,
		Rs,
		vs,
		-1,
		gs,
		Rs,
		-1,
		vs,
		-1
	];
	var zs = [
		0,
		Rs,
		-1,
		vs
	];
	var Ys = class extends di {
		constructor(t) {
			super(t);
		}
	};
	var qs = [
		0,
		vs,
		As,
		vs,
		Rs,
		-1,
		Gi(function(t, e, r) {
			return (0 === t.h || 2 === t.h) && (e = yr(e, 0 | e[et], r), 2 == t.h ? _n(t, rn, e) : e.push(Jr(t.g)), !0);
		}, function(t, e, r) {
			if (null != (e = $i(re, e, !0)) && e.length) {
				r = Kn(t, r);
				for (let r = 0; r < e.length; r++) Un(t.g, e[r]);
				Xn(t, r);
			}
		}, ci),
		As,
		-1,
		[
			0,
			vs,
			-1
		],
		Rs,
		vs,
		-1,
		zs
	];
	var Js = [
		0,
		3,
		vs,
		-1,
		2,
		[
			0,
			[2],
			fs,
			bs,
			[0, Ss]
		],
		[
			0,
			Rs,
			vs,
			Rs,
			vs,
			Rs,
			4,
			[
				0,
				vs,
				As,
				-1,
				vs
			]
		],
		[
			0,
			[3, 4],
			As,
			-1,
			bs,
			[0, fs],
			bs,
			[
				0,
				Rs,
				-1
			]
		],
		[0]
	];
	var Zs = [
		0,
		As,
		-2
	];
	var Qs = class extends di {
		constructor(t) {
			super(t);
		}
	};
	var to = [0];
	var eo = class extends di {
		constructor(t) {
			super(t);
		}
	};
	var ro = [
		0,
		fs,
		vs,
		1,
		vs,
		-4
	];
	var no = class extends di {
		constructor(t) {
			super(t, 2);
		}
	};
	var io = {};
	io[336783863] = [
		0,
		As,
		vs,
		-1,
		fs,
		[
			0,
			[
				1,
				2,
				3,
				4,
				5,
				6,
				7,
				8,
				9
			],
			bs,
			to,
			bs,
			qs,
			bs,
			Zs,
			bs,
			ro,
			bs,
			Ws,
			bs,
			[
				0,
				As,
				-2
			],
			bs,
			[
				0,
				As,
				Rs
			],
			bs,
			Js,
			bs,
			zs
		],
		[0, As],
		vs,
		[
			0,
			[1, 3],
			[2, 4],
			bs,
			[0, gs],
			-1,
			bs,
			[0, ys],
			-1,
			ws,
			[
				0,
				As,
				-1
			]
		],
		As
	];
	var so = [
		0,
		ls,
		-1,
		_s,
		-3,
		ls,
		gs,
		Es,
		ms,
		ls,
		-1,
		_s,
		ms,
		_s,
		-2,
		Es
	];
	function oo(t, e) {
		Xr(t, 3, e);
	}
	function ao(t, e) {
		Xr(t, 4, e);
	}
	var ho = class extends di {
		constructor(t) {
			super(t, 500);
		}
		v(t) {
			return Ir(this, 0, 7, t);
		}
	};
	var uo = [-1, {}];
	var co = [
		0,
		As,
		1,
		uo
	];
	var lo = [
		0,
		As,
		ys,
		uo
	];
	function fo(t, e) {
		Mr(t, 1, ho, e);
	}
	function po(t, e) {
		Xr(t, 10, e);
	}
	function go(t, e) {
		Xr(t, 15, e);
	}
	var mo = class extends di {
		constructor(t) {
			super(t, 500);
		}
		v(t) {
			return Ir(this, 0, 1001, t);
		}
	};
	var vo = [
		-500,
		ws,
		[
			-500,
			Es,
			-1,
			ys,
			-3,
			[
				-2,
				io,
				vs
			],
			ws,
			Gs,
			ms,
			-1,
			co,
			lo,
			ws,
			[
				0,
				Es,
				_s
			],
			Es,
			so,
			ms,
			ys,
			987,
			ys
		],
		4,
		ws,
		[
			-500,
			As,
			-1,
			[-1, {}],
			998,
			As
		],
		ws,
		[
			-500,
			As,
			ys,
			-1,
			[
				-2,
				{},
				vs
			],
			997,
			ys,
			-1
		],
		ms,
		ws,
		[
			-500,
			As,
			ys,
			uo,
			998,
			ys
		],
		ys,
		ms,
		co,
		lo,
		ws,
		[
			0,
			Es,
			-1,
			uo
		],
		ys,
		-2,
		so,
		Es,
		-1,
		_s,
		[
			0,
			_s,
			xs
		],
		978,
		uo,
		ws,
		Gs
	];
	mo.prototype.g = Ds(vo);
	var _o = Ms(mo, vo);
	var yo = class extends di {
		constructor(t) {
			super(t);
		}
	};
	var Eo = class extends di {
		constructor(t) {
			super(t);
		}
		g() {
			return xr(this, yo, 1);
		}
	};
	var Ao = [
		0,
		ws,
		[
			0,
			fs,
			is,
			As,
			-1
		]
	];
	var wo = Ms(Eo, Ao);
	var bo = class extends di {
		constructor(t) {
			super(t);
		}
	};
	var To = class extends di {
		constructor(t) {
			super(t);
		}
	};
	var ko = class extends di {
		constructor(t) {
			super(t);
		}
		j() {
			return Sr(this, bo, 2);
		}
		g() {
			return xr(this, To, 5);
		}
	};
	var So = Ms(class extends di {
		constructor(t) {
			super(t);
		}
	}, [
		0,
		ys,
		gs,
		os,
		[
			0,
			Rs,
			[
				0,
				fs,
				-3
			],
			[
				0,
				is,
				-3
			],
			[
				0,
				fs,
				-1,
				[
					0,
					ws,
					[
						0,
						fs,
						-2
					]
				]
			],
			ws,
			[
				0,
				is,
				-1,
				As,
				is
			]
		],
		As,
		-1,
		us,
		ws,
		[
			0,
			fs,
			is
		],
		ys,
		us
	]);
	var Lo = class extends di {
		constructor(t) {
			super(t);
		}
	};
	var xo = Ms(class extends di {
		constructor(t) {
			super(t);
		}
	}, [
		0,
		ws,
		[
			0,
			is,
			-4
		]
	]);
	var Ro = class extends di {
		constructor(t) {
			super(t);
		}
	};
	var Io = Ms(class extends di {
		constructor(t) {
			super(t);
		}
	}, [
		0,
		ws,
		[
			0,
			is,
			-4
		]
	]);
	var Fo = class extends di {
		constructor(t) {
			super(t);
		}
	};
	var Co = [
		0,
		fs,
		-1,
		os,
		Rs
	];
	var No = class extends di {
		constructor(t) {
			super(t);
		}
	};
	No.prototype.g = Ds([
		0,
		is,
		-4,
		us
	]);
	var Mo = class extends di {
		constructor(t) {
			super(t);
		}
	};
	var Oo = Ms(class extends di {
		constructor(t) {
			super(t);
		}
	}, [
		0,
		ws,
		[
			0,
			1,
			fs,
			As,
			Ao
		],
		us
	]);
	var Do = class extends di {
		constructor(t) {
			super(t);
		}
	};
	var Po = class extends di {
		constructor(t) {
			super(t);
		}
		g() {
			var t = sr(this, 1, void 0, mr);
			return null == t ? I() : t;
		}
	};
	var $o = class extends di {
		constructor(t) {
			super(t);
		}
	};
	var Uo = [1, 2];
	var Bo = Ms(class extends di {
		constructor(t) {
			super(t);
		}
	}, [
		0,
		ws,
		[
			0,
			Uo,
			bs,
			[0, os],
			bs,
			[0, Ts],
			fs,
			As
		],
		us
	]);
	var Go = class extends di {
		constructor(t) {
			super(t);
		}
	};
	var jo = [
		0,
		As,
		fs,
		is,
		ys,
		-1
	];
	var Vo = class extends di {
		constructor(t) {
			super(t);
		}
	};
	var Ho = [
		0,
		vs,
		-1
	];
	var Ko = class extends di {
		constructor(t) {
			super(t);
		}
		g() {
			return ur(this, Ys, 2, Xo);
		}
	};
	var Xo = [
		1,
		2,
		3,
		4,
		5,
		6
	];
	var Wo = class extends di {
		constructor(t) {
			super(t);
		}
		g() {
			return null != sr(this, 1, void 0, mr);
		}
		j() {
			return null != _e(sr(this, 2));
		}
	};
	var zo = class extends di {
		constructor(t) {
			super(t);
		}
	};
	var Yo = [
		0,
		Ts,
		As,
		[
			0,
			fs,
			us,
			-1
		],
		[
			0,
			ds,
			us
		]
	];
	var qo = [
		0,
		Yo,
		vs,
		[
			0,
			Xo,
			bs,
			ro,
			bs,
			qs,
			bs,
			Ws,
			bs,
			to,
			bs,
			Zs,
			bs,
			Js
		],
		Rs
	];
	var Jo = Os(qo);
	var Zo = class extends di {
		constructor(t) {
			super(t);
		}
	};
	var Qo = [
		0,
		qo,
		is,
		-1,
		fs
	];
	var ta = Ns(502141897, Zo);
	io[502141897] = Qo;
	var ea = Ms(class extends di {
		constructor(t) {
			super(t);
		}
	}, [
		0,
		[
			0,
			Rs,
			-1,
			ss,
			Ls
		],
		Co
	]);
	var ra = class extends di {
		constructor(t) {
			super(t);
		}
	};
	var na = class extends di {
		constructor(t) {
			super(t);
		}
	};
	var ia = [
		0,
		qo,
		is,
		[0, qo],
		vs
	];
	var sa = Ns(508968150, na);
	io[508968150] = [
		0,
		qo,
		Qo,
		ia,
		is,
		[0, [0, Yo]]
	], io[508968149] = ia;
	var oa = class extends di {
		constructor(t) {
			super(t);
		}
		j() {
			return Sr(this, Go, 2);
		}
		g() {
			ar(this, 2);
		}
	};
	var aa = [
		0,
		qo,
		jo
	];
	io[478825465] = aa;
	var ha = class extends di {
		constructor(t) {
			super(t);
		}
	};
	var ua = class extends di {
		constructor(t) {
			super(t);
		}
	};
	var ca = class extends di {
		constructor(t) {
			super(t);
		}
	};
	var la = class extends di {
		constructor(t) {
			super(t);
		}
	};
	var da = class extends di {
		constructor(t) {
			super(t);
		}
	};
	var fa = [
		0,
		qo,
		[0, qo],
		aa,
		-1
	];
	var pa = [
		0,
		qo,
		is,
		fs
	];
	var ga = [
		0,
		qo,
		is
	];
	var ma = [
		0,
		qo,
		pa,
		ga,
		is
	];
	var va = Ns(479097054, da);
	io[479097054] = [
		0,
		qo,
		ma,
		fa
	], io[463370452] = fa, io[464864288] = pa;
	var _a = Ns(462713202, la);
	io[462713202] = ma, io[474472470] = ga;
	var ya = class extends di {
		constructor(t) {
			super(t);
		}
	};
	var Ea = class extends di {
		constructor(t) {
			super(t);
		}
	};
	var Aa = class extends di {
		constructor(t) {
			super(t);
		}
	};
	var wa = class extends di {
		constructor(t) {
			super(t);
		}
	};
	var ba = [
		0,
		qo,
		is,
		-1,
		fs
	];
	var Ta = [
		0,
		qo,
		is,
		vs
	];
	wa.prototype.g = Ds([
		0,
		qo,
		ga,
		[0, qo],
		Qo,
		ia,
		ba,
		Ta
	]);
	var ka = class extends di {
		constructor(t) {
			super(t);
		}
	};
	var Sa = Ns(456383383, ka);
	io[456383383] = [
		0,
		qo,
		jo
	];
	var La = class extends di {
		constructor(t) {
			super(t);
		}
	};
	var xa = Ns(476348187, La);
	io[476348187] = [
		0,
		qo,
		Ho
	];
	var Ra = class extends di {
		constructor(t) {
			super(t);
		}
	};
	var Ia = class extends di {
		constructor(t) {
			super(t);
		}
	};
	var Fa = [
		0,
		Rs,
		-1
	];
	var Ca = Ns(458105876, class extends di {
		constructor(t) {
			super(t);
		}
		g() {
			var t = this.A, e = 0 | t[et], r = ht(this, e);
			return t = function(t, e, r, n) {
				var i = Ia;
				!n && Qe(t) && (r = 0 | (e = t.A)[et]);
				var s = or(e, 2);
				if (t = !1, null == s) {
					if (n) return Ce();
					s = [];
				} else if (s.constructor === Re) {
					if (!(2 & s.M) || n) return s;
					s = s.ea();
				} else Array.isArray(s) ? t = !!(2 & s[et]) : s = [];
				if (n) {
					if (!s.length) return Ce();
					t || (t = !0, st(s));
				} else t && (t = !1, ot(s), s = vr(s));
				return !t && 32 & r && nt(s, 32), r = hr(e, r, 2, n = new Re(s, i, Ee, void 0)), t || er(e, r), n;
			}(this, t, e, r), !r && Ia && (t.Fa = !0), t;
		}
	});
	io[458105876] = [
		0,
		Fa,
		Vi,
		[
			!0,
			us,
			[
				0,
				As,
				-1,
				ys
			]
		],
		[
			0,
			gs,
			vs,
			Rs
		],
		vs
	];
	var Na = class extends di {
		constructor(t) {
			super(t);
		}
	};
	var Ma = Ns(458105758, Na);
	io[458105758] = [
		0,
		qo,
		As,
		Fa
	];
	var Oa = class extends di {
		constructor(t) {
			super(t);
		}
	};
	var Da = class extends di {
		constructor(t) {
			super(t);
		}
	};
	var Pa = class extends di {
		constructor(t) {
			super(t);
		}
	};
	var $a = Os([
		0,
		ws,
		[
			0,
			Is,
			ws,
			[
				0,
				as,
				-1
			],
			_s
		]
	]);
	var Ua = class extends di {
		constructor(t) {
			super(t);
		}
	};
	var Ba = [
		0,
		as,
		-1,
		_s
	];
	var Ga = class extends di {
		constructor(t) {
			super(t);
		}
	};
	var ja = class extends di {
		constructor(t) {
			super(t);
		}
	};
	var Va = [1, 2];
	ja.prototype.g = Ds([
		0,
		Va,
		bs,
		Ba,
		bs,
		[
			0,
			ws,
			Ba
		]
	]);
	var Ha = class extends di {
		constructor(t) {
			super(t);
		}
	};
	var Ka = Ns(443442058, Ha);
	io[443442058] = [
		0,
		qo,
		As,
		fs,
		is,
		ys,
		-1,
		vs,
		is
	], io[514774813] = ba;
	var Xa = class extends di {
		constructor(t) {
			super(t);
		}
	};
	var Wa = Ns(516587230, Xa);
	function za(t, e) {
		return e = e ? e.clone() : new Go(), void 0 !== t.displayNamesLocale ? ar(e, 1, ve(t.displayNamesLocale)) : void 0 === t.displayNamesLocale && ar(e, 1), void 0 !== t.maxResults ? Ur(e, 2, t.maxResults) : "maxResults" in t && ar(e, 2), void 0 !== t.scoreThreshold ? jr(e, 3, t.scoreThreshold) : "scoreThreshold" in t && ar(e, 3), void 0 !== t.categoryAllowlist ? Kr(e, 4, t.categoryAllowlist) : "categoryAllowlist" in t && ar(e, 4), void 0 !== t.categoryDenylist ? Kr(e, 5, t.categoryDenylist) : "categoryDenylist" in t && ar(e, 5), e;
	}
	function Ya(t) {
		var e = Number(t);
		return Number.isSafeInteger(e) ? e : String(t);
	}
	function qa(t, e = -1, r = "") {
		return {
			categories: t.map((t) => ({
				index: Or(t, 1) ?? 0 ?? -1,
				score: Dr(t, 2) ?? 0,
				categoryName: _e(sr(t, 3)) ?? "" ?? "",
				displayName: _e(sr(t, 4)) ?? "" ?? ""
			})),
			headIndex: e,
			headName: r
		};
	}
	function Ja(t) {
		var e = { classifications: xr(t, Mo, 1).map((t) => qa(Sr(t, Eo, 4)?.g() ?? [], Or(t, 2) ?? 0, _e(sr(t, 3)) ?? "")) };
		return null != function(t) {
			return null == t ? t : "bigint" == typeof t ? (wt(t) ? t = Number(t) : (t = Ht(64, t), t = wt(t) ? Number(t) : String(t)), t) : te(t) ? "number" == typeof t ? ae(t) : ce(t) : void 0;
		}(sr(t, 2, void 0, fe)) && (e.timestampMs = Ya(sr(t, 2, void 0, fe) ?? nr)), e;
	}
	function Za(t) {
		var e = lr(t, 3, Jt, cr()), r = lr(t, 2, re, cr()), n = lr(t, 1, _e, cr()), i = lr(t, 9, _e, cr()), s = {
			categories: [],
			keypoints: []
		};
		for (let t = 0; t < e.length; t++) s.categories.push({
			score: e[t],
			index: r[t] ?? -1,
			categoryName: n[t] ?? "",
			displayName: i[t] ?? ""
		});
		if ((e = Sr(t, ko, 4)?.j()) && (s.boundingBox = {
			originX: Or(e, 1, ir) ?? 0,
			originY: Or(e, 2, ir) ?? 0,
			width: Or(e, 3, ir) ?? 0,
			height: Or(e, 4, ir) ?? 0,
			angle: 0
		}), Sr(t, ko, 4)?.g().length) for (let e of Sr(t, ko, 4).g()) s.keypoints.push({
			x: sr(e, 1, ir, Jt) ?? 0,
			y: sr(e, 2, ir, Jt) ?? 0,
			score: sr(e, 4, ir, Jt) ?? 0,
			label: _e(sr(e, 3, ir)) ?? ""
		});
		return s;
	}
	function Qa(t) {
		var e = [];
		for (let r of xr(t, Ro, 1)) e.push({
			x: Dr(r, 1) ?? 0,
			y: Dr(r, 2) ?? 0,
			z: Dr(r, 3) ?? 0,
			visibility: Dr(r, 4) ?? 0
		});
		return e;
	}
	function th(t) {
		var e = [];
		for (let r of xr(t, Lo, 1)) e.push({
			x: Dr(r, 1) ?? 0,
			y: Dr(r, 2) ?? 0,
			z: Dr(r, 3) ?? 0,
			visibility: Dr(r, 4) ?? 0
		});
		return e;
	}
	function eh(t) {
		return Array.from(t, (t) => t > 127 ? t - 256 : t);
	}
	function rh(t, e) {
		if (t.length !== e.length) throw Error(`Cannot compute cosine similarity between embeddings of different sizes (${t.length} vs. ${e.length}).`);
		var r = 0, n = 0, i = 0;
		for (let s = 0; s < t.length; s++) r += t[s] * e[s], n += t[s] * t[s], i += e[s] * e[s];
		if (n <= 0 || i <= 0) throw Error("Cannot compute cosine similarity on embedding with 0 norm.");
		return r / Math.sqrt(n * i);
	}
	io[516587230] = [
		0,
		qo,
		ba,
		Ta,
		is
	], io[518928384] = Ta;
	var nh;
	var ih = new Uint8Array([
		0,
		97,
		115,
		109,
		1,
		0,
		0,
		0,
		1,
		5,
		1,
		96,
		0,
		1,
		123,
		3,
		2,
		1,
		0,
		10,
		10,
		1,
		8,
		0,
		65,
		0,
		253,
		15,
		253,
		98,
		11
	]);
	async function sh(t) {
		if (t) return !0;
		if (void 0 === nh) try {
			await WebAssembly.instantiate(ih), nh = !0;
		} catch {
			nh = !1;
		}
		return nh;
	}
	async function oh(t, e, r) {
		return {
			wasmLoaderPath: `${e}/${t}_${r = `wasm${r ? "_module" : ""}${await sh(r) ? "" : "_nosimd"}_internal`}.js`,
			wasmBinaryPath: `${e}/${t}_${r}.wasm`
		};
	}
	var ah = class {};
	function hh(t) {
		return ar(new uh(), 1, ee(t));
	}
	ah.forVisionTasks = function(t, e = !1) {
		return oh("vision", t ?? Xs``, e);
	}, ah.forTextTasks = function(t, e = !1) {
		return oh("text", t ?? Xs``, e);
	}, ah.forGenAiTasks = function(t, e = !1) {
		return oh("genai", t ?? Xs``, e);
	}, ah.forAudioTasks = function(t, e = !1) {
		return oh("audio", t ?? Xs``, e);
	}, ah.isSimdSupported = function(t = !1) {
		return sh(t);
	};
	var uh = class extends di {
		constructor(t) {
			super(t);
		}
	};
	var ch = class extends di {
		constructor(t) {
			super(t);
		}
	};
	var lh = [
		0,
		Rs,
		2,
		ds,
		-2,
		us,
		ws,
		[
			0,
			Rs,
			us
		]
	];
	var dh = class extends di {
		constructor(t) {
			super(t);
		}
	};
	var fh = class extends di {
		constructor(t) {
			super(t);
		}
	};
	function ph(t, e) {
		return ar(t, 1, ee(e));
	}
	function gh(t, e) {
		return ar(t, 2, ee(e));
	}
	var mh = class extends di {
		constructor(t) {
			super(t);
		}
	};
	var vh = [
		3,
		4,
		5,
		6,
		7
	];
	var _h = class extends di {
		constructor(t) {
			super(t);
		}
	};
	var yh = class extends di {
		constructor(t) {
			super(t);
		}
	};
	yh.prototype.g = Ds([
		0,
		[
			0,
			Rs,
			As,
			-3,
			Rs
		],
		[
			0,
			vh,
			Rs,
			-1,
			bs,
			[
				0,
				Rs,
				As,
				ds
			],
			bs,
			lh,
			bs,
			[
				0,
				1,
				lh
			],
			bs,
			[0, Rs],
			bs,
			[
				0,
				Rs,
				As,
				ds
			]
		]
	]);
	var Eh = class {
		constructor() {
			this.g = "undefined" != typeof AbortController;
		}
		async send(t, e, r) {
			var n = this.g ? new AbortController() : void 0, i = n && t.la > 0 ? setTimeout(() => {
				n.abort();
			}, t.la) : void 0;
			try {
				let i = await fetch(t.url, {
					method: t.bb,
					headers: { ...t.ab },
					...t.body && { body: t.body },
					...t.withCredentials && { credentials: "include" },
					signal: t.la && n ? n.signal : null
				});
				200 === i.status ? e?.(await i.text()) : r?.(i.status);
			} catch (t) {
				if ("AbortError" === t?.name) r?.(408);
				else r?.(400);
			} finally {
				clearTimeout(i);
			}
		}
	};
	var Ah = class extends di {
		constructor(t) {
			super(t, 37);
		}
	};
	var wh = [
		-4,
		{},
		js,
		Rs,
		$s
	];
	var bh = [
		0,
		As,
		Rs,
		1,
		As,
		-1,
		Rs,
		1,
		Rs,
		1,
		us
	];
	var Th = [
		0,
		Rs,
		As,
		-2
	];
	var kh = [
		0,
		As,
		Rs
	];
	var Sh = [
		0,
		As,
		Rs
	];
	var Lh = [
		0,
		vs,
		-3
	];
	var xh = [
		0,
		Rs,
		As,
		-1,
		us,
		fs,
		-1,
		As,
		-5,
		ws,
		[
			0,
			As,
			-4
		],
		-1,
		vs,
		[
			0,
			vs,
			-3
		],
		Rs
	];
	var Rh = class extends di {
		constructor(t) {
			super(t, 19);
		}
	};
	var Ih = Os([
		-19,
		{},
		[
			0,
			Rs,
			1,
			[
				0,
				As,
				-6,
				us,
				fs,
				As,
				-1,
				us
			],
			1,
			[
				0,
				As,
				1,
				As,
				-5
			],
			As,
			-1,
			[
				0,
				Rs,
				As,
				-8
			],
			[
				0,
				As,
				-3
			],
			[
				0,
				As,
				Rs,
				As,
				-2
			],
			[
				0,
				As,
				-1,
				Rs,
				As,
				-1,
				Rs,
				As,
				-1,
				[
					0,
					ws,
					[
						0,
						As,
						-1
					],
					vs,
					As,
					-5
				],
				[
					0,
					Rs,
					vs,
					fs,
					-2
				]
			],
			us,
			[
				0,
				As,
				-3,
				us,
				fs,
				As,
				-1
			],
			[
				0,
				Rs,
				As,
				-1
			],
			[
				0,
				As,
				-9
			],
			[
				0,
				As,
				-6,
				Rs,
				As,
				1,
				As,
				vs,
				Rs,
				-1,
				vs,
				As,
				-2,
				Rs,
				As,
				Rs,
				As,
				fs,
				-1
			],
			1,
			[0, Rs],
			1,
			[
				0,
				As,
				-4
			],
			1,
			bh,
			[
				0,
				[
					1,
					2,
					3,
					4,
					5,
					6
				],
				bs,
				bh,
				bs,
				kh,
				bs,
				Sh,
				bs,
				[0, Rs],
				bs,
				xh,
				bs,
				Th
			],
			kh,
			Sh,
			xh,
			[
				0,
				[
					0,
					Rs,
					As,
					-1,
					us,
					fs,
					-1,
					As,
					-4,
					ws,
					[
						0,
						As,
						-4
					],
					-1,
					1,
					Lh
				],
				[
					0,
					Rs,
					As,
					-1,
					us,
					fs,
					-1,
					As,
					-4,
					Lh
				]
			],
			Th,
			[
				0,
				As,
				[
					0,
					fs,
					-3,
					Rs
				],
				Rs,
				-2,
				[
					0,
					fs,
					-1
				],
				vs
			],
			4,
			[
				0,
				As,
				Rs,
				As,
				-1,
				us,
				Rs,
				As,
				-1,
				Rs,
				fs,
				-1
			]
		],
		Rs,
		ws,
		[
			-37,
			{},
			hs,
			As,
			ws,
			[
				0,
				As,
				-1
			],
			Ts,
			1,
			Ts,
			[
				0,
				ys,
				-1,
				ps,
				cs,
				-1
			],
			As,
			[
				0,
				fs,
				As,
				-1
			],
			vs,
			fs,
			us,
			As,
			-1,
			Fs,
			Ps,
			hs,
			Ts,
			Rs,
			ps,
			us,
			-1,
			[
				0,
				Rs,
				-1
			],
			As,
			vs,
			As,
			gs,
			As,
			-1,
			ns,
			1,
			ns,
			wh,
			vs,
			[
				0,
				Rs,
				[
					0,
					is,
					fs,
					-2
				],
				[0, is]
			],
			[
				0,
				Rs,
				us
			]
		],
		hs,
		ks,
		As,
		-1,
		hs,
		Rs,
		-1,
		[
			0,
			vs,
			-1,
			Rs,
			vs
		],
		[
			0,
			us,
			-1,
			As
		],
		[
			0,
			hs,
			vs,
			us
		],
		us,
		1,
		Ss,
		1,
		wh
	]);
	var Fh = class {
		constructor(t) {
			this.h = [], this.m = new Eh(), this.j = t ?? "", this.g = setInterval(() => {
				this.flush();
			}, 6e4);
		}
		close() {
			void 0 !== this.g && (clearInterval(this.g), this.g = void 0), this.flush();
		}
		flush(t, e) {
			if (this.error) e?.("net-send-failed");
			else if (0 === this.h.length) t?.();
			else {
				var r = this.h;
				this.h = [], r = function(t) {
					var e = new Rh();
					return Cr(e = ar(e, 2, ee(1786)), 3, t);
				}(r), r = Ih(r), this.m.send({
					url: "https://odml.pa.googleapis.com/v1/log",
					bb: "POST",
					la: 1e4,
					body: r,
					hb: 2,
					ab: {
						"Content-Type": "application/x-protobuf",
						"x-goog-api-key": this.j
					},
					withCredentials: !1
				}, () => {
					t?.();
				}, (t) => {
					this.error = Error(`Logging failed with HTTP error: ${t}`), this.h = [], void 0 !== this.g && (clearInterval(this.g), this.g = void 0), e?.("net-send-failed", t);
				});
			}
		}
	};
	var Ch = class {
		constructor() {
			this.aa = this.U = this.X = this.R = this.V = this.T = this.P = 0;
		}
	};
	function Nh(t, e) {
		var r = new yh();
		r = Ir(r, 0, 1, t.B), r = Ir(r, 0, 2, e), e = ar(e = new Ah(), 6, ct(r = r.g(), !1)), (t = t.l).error || t.h.push(e);
	}
	function Mh(t, e) {
		var r = {
			P: e.P - t.j.P,
			T: e.T - t.j.T,
			V: e.V - t.j.V,
			R: e.R - t.j.R,
			X: e.X - t.j.X,
			U: e.U,
			aa: e.aa
		}, n = gh(ph(new mh(), t.C), 1);
		r = Oh(t, r), Nh(t, n = Fr(n, 4, vh, r)), t.j = e;
	}
	function Oh(t, e) {
		var r = new ch();
		return t = Gr(t = Br(t = ar(r, 1, ee(t.D)), 7, e.R), 5, e.U), t = Gr(t, 6, e.aa), e.V > 0 && Gr(t, 4, e.X / e.V), 0 !== e.P && (r = Br(r = hh(3), 2, e.P), Mr(t, 8, uh, r)), 0 !== e.T && (e = Br(r = hh(4), 2, e.T), Mr(t, 8, uh, e)), t;
	}
	var Dh = class {
		constructor(t, e, r) {
			this.u = performance.now(), this.m = performance.now(), this.h = /* @__PURE__ */ new Map(), this.o = 0, this.g = new Ch(), this.j = new Ch(), this.l = new Fh(r), this.C = function(t) {
				switch (t) {
					case "AudioClassifier": return 4;
					case "AudioEmbedder": return 5;
					case "TextClassifier": return 6;
					case "TextEmbedder": return 7;
					case "GestureRecognizer": return 8;
					case "HandDetector": return 9;
					case "HandLandmarker": return 10;
					case "ImageClassifier": return 11;
					case "ImageEmbedder": return 12;
					case "ImageSegmenter": return 13;
					case "ObjectDetector": return 14;
					case "FaceDetector": return 15;
					case "FaceLandmarker": return 16;
					case "InteractiveSegmenter":
					case "InteractiveSegmenterLegacy": return 18;
					case "HolisticLandmarker": return 20;
					case "LlmInference": return 21;
					case "LanguageDetector": return 22;
					case "PoseLandmarker": return 23;
					default: return 0;
				}
			}(t), this.D = function(t) {
				switch (t) {
					case "IMAGE": return 11;
					case "VIDEO": return 12;
					case "LIVE_STREAM": return 13;
					case "AUDIO_CLIPS": return 14;
					case "AUDIO_STREAM": return 15;
					default: return 10;
				}
			}(e), t = new _h(), "undefined" == typeof window ? e = 0 : (e = navigator.userAgent, e = /Android/i.test(e) ? 1 : /iPhone|iPad|iPod/i.test(e) ? 2 : /Windows/i.test(e) ? 5 : /Macintosh/i.test(e) ? 4 : /Linux/i.test(e) ? 3 : 0), t = ar(t, 1, ee(e)), t = ar(t, 2, ve("")), t = ar(t, 3, ve("")), t = ar(t, 4, ve("1.0.1")), t = ar(t, 5, ve("")), this.B = ar(t, 6, ee(4));
		}
		ya() {
			var t = new fh();
			t = Gr(t = ar(t, 1, ee(this.D)), 3, performance.now() - this.u), Nh(this, t = Fr(gh(ph(new mh(), this.C), 0), 3, vh, t)), this.m = performance.now();
		}
		za(t) {
			var e = this.h.get(t);
			if (void 0 !== e && (this.h.delete(t), t = performance.now() - e, ++this.g.V, this.g.X += t, this.g.U = Math.max(this.g.U, t), this.o = Math.max(this.o, t), performance.now() > this.m + 3e4)) {
				for (let [r, n] of this.h.entries()) t = r, n < e && (this.g.R++, this.h.delete(t));
				e = {
					...this.g,
					aa: performance.now() - this.m
				}, this.g.U = 0, this.m = performance.now(), Mh(this, e);
			}
		}
		xa() {
			var t = {
				...this.g,
				R: this.g.R + this.h.size,
				U: this.o,
				aa: performance.now() - this.u
			};
			Mh(this, t);
			var e = new dh();
			e = Ir(e, 0, 2, t = Oh(this, t)), Nh(this, e = Fr(t = gh(ph(new mh(), this.C), 2), 5, vh, e));
		}
		close() {
			var t = this.l;
			"function" == typeof t.close ? t.close() : t.flush();
		}
	};
	function Ph() {
		var t = navigator;
		return "undefined" != typeof OffscreenCanvas && (!function(t = navigator) {
			return (t = t.userAgent).includes("Safari") && !t.includes("Chrome");
		}(t) || !!((t = t.userAgent.match(/Version\/([\d]+).*Safari/)) && t.length >= 1 && Number(t[1]) >= 17));
	}
	async function $h(t) {
		if ("function" != typeof importScripts) {
			let e = document.createElement("script");
			return e.src = t.toString(), e.crossOrigin = "anonymous", new Promise((t, r) => {
				e.addEventListener("load", () => {
					t();
				}, !1), e.addEventListener("error", (t) => {
					r(t);
				}, !1), document.body.appendChild(e);
			});
		}
		try {
			importScripts(t.toString());
		} catch (e) {
			if (!(e instanceof TypeError)) throw e;
			{
				let e = self.import;
				e ? await e(t.toString()) : await import(t.toString());
			}
		}
	}
	function Uh(t) {
		return void 0 !== t.videoWidth ? [t.videoWidth, t.videoHeight] : void 0 !== t.naturalWidth ? [t.naturalWidth, t.naturalHeight] : void 0 !== t.displayWidth ? [t.displayWidth, t.displayHeight] : [t.width, t.height];
	}
	function Bh(t, e, r) {
		t.m || console.error("No wasm multistream support detected: ensure dependency inclusion of :gl_graph_runner_internal_multi_input target"), r(e = t.i.stringToNewUTF8(e)), t.i._free(e);
	}
	function Gh(t, e, r) {
		if (!t.i.canvas) throw Error("No OpenGL canvas configured.");
		if (r ? t.i._bindTextureToStream(r) : t.i._bindTextureToCanvas(), !(r = t.i.canvas.getContext("webgl2") || t.i.canvas.getContext("webgl"))) throw Error("Failed to obtain WebGL context from the provided canvas. `getContext()` should only be invoked with `webgl` or `webgl2`.");
		t.i.gpuOriginForWebTexturesIsBottomLeft && r.pixelStorei(r.UNPACK_FLIP_Y_WEBGL, !0), r.texImage2D(r.TEXTURE_2D, 0, r.RGBA, r.RGBA, r.UNSIGNED_BYTE, e), t.i.gpuOriginForWebTexturesIsBottomLeft && r.pixelStorei(r.UNPACK_FLIP_Y_WEBGL, !1);
		var [n, i] = Uh(e);
		return !t.j || n === t.i.canvas.width && i === t.i.canvas.height || (t.i.canvas.width = n, t.i.canvas.height = i), [n, i];
	}
	function jh(t, e, r) {
		t.m || console.error("No wasm multistream support detected: ensure dependency inclusion of :gl_graph_runner_internal_multi_input target");
		var n = new Uint32Array(e.length);
		for (let r = 0; r < e.length; r++) n[r] = t.i.stringToNewUTF8(e[r]);
		e = t.i._malloc(4 * n.length), t.i.HEAPU32.set(n, e >> 2), r(e);
		for (let e of n) t.i._free(e);
		t.i._free(e);
	}
	function Vh(t, e, r) {
		t.i.simpleListeners = t.i.simpleListeners || {}, t.i.simpleListeners[e] = r;
	}
	function Hh(t, e, r) {
		var n = [];
		t.i.simpleListeners = t.i.simpleListeners || {}, t.i.simpleListeners[e] = (t, e, i) => {
			e ? (r(n, i), n = []) : n.push(t);
		};
	}
	var Kh = class {
		constructor(t, e) {
			this.j = !0, this.i = t, this.g = null, this.h = 0, this.m = "function" == typeof this.i._addIntToInputStream, void 0 !== e ? this.i.canvas = e : Ph() ? this.i.canvas = new OffscreenCanvas(1, 1) : (console.warn("OffscreenCanvas not supported and GraphRunner constructor glCanvas parameter is undefined. Creating backup canvas."), this.i.canvas = document.createElement("canvas"));
		}
		async initializeGraph(t) {
			var e = await (await fetch(t)).arrayBuffer();
			t = !(t.endsWith(".pbtxt") || t.endsWith(".textproto")), this.setGraph(new Uint8Array(e), t);
		}
		setGraphFromString(t) {
			this.setGraph(new TextEncoder().encode(t), !1);
		}
		setGraph(t, e) {
			var r = t.length, n = this.i._malloc(r);
			this.i.HEAPU8.set(t, n), e ? this.i._changeBinaryGraph(r, n) : this.i._changeTextGraph(r, n), this.i._free(n);
		}
		configureAudio(t, e, r, n, i) {
			this.i._configureAudio || console.warn("Attempting to use configureAudio without support for input audio. Is build dep \":gl_graph_runner_audio\" missing?"), Bh(this, n || "input_audio", (n) => {
				Bh(this, i = i || "audio_header", (i) => {
					this.i._configureAudio(n, i, t, e ?? 0, r);
				});
			});
		}
		setAutoResizeCanvas(t) {
			this.j = t;
		}
		setAutoRenderToScreen(t) {
			this.i._setAutoRenderToScreen(t);
		}
		setGpuBufferVerticalFlip(t) {
			this.i.gpuOriginForWebTexturesIsBottomLeft = t;
		}
		ja(t) {
			Vh(this, "__graph_config__", (e) => {
				t(e);
			}), Bh(this, "__graph_config__", (t) => {
				this.i._getGraphConfig(t, void 0);
			}), delete this.i.simpleListeners.__graph_config__;
		}
		attachErrorListener(t) {
			this.i.errorListener = t;
		}
		attachEmptyPacketListener(t, e) {
			this.i.emptyPacketListeners = this.i.emptyPacketListeners || {}, this.i.emptyPacketListeners[t] = e;
		}
		addAudioToStream(t, e, r) {
			this.addAudioToStreamWithShape(t, 0, 0, e, r);
		}
		addAudioToStreamWithShape(t, e, r, n, i) {
			var s = 4 * t.length;
			this.h !== s && (this.g && this.i._free(this.g), this.g = this.i._malloc(s), this.h = s), this.i.HEAPF32.set(t, this.g / 4), Bh(this, n, (t) => {
				this.i._addAudioToInputStream(this.g, e, r, t, i);
			});
		}
		addGpuBufferToStream(t, e, r) {
			Bh(this, e, (e) => {
				var [n, i] = Gh(this, t, e);
				this.i._addBoundTextureToStream(e, n, i, r);
			});
		}
		addBoolToStream(t, e, r) {
			Bh(this, e, (e) => {
				this.i._addBoolToInputStream(t, e, r);
			});
		}
		addDoubleToStream(t, e, r) {
			Bh(this, e, (e) => {
				this.i._addDoubleToInputStream(t, e, r);
			});
		}
		addFloatToStream(t, e, r) {
			Bh(this, e, (e) => {
				this.i._addFloatToInputStream(t, e, r);
			});
		}
		addIntToStream(t, e, r) {
			Bh(this, e, (e) => {
				this.i._addIntToInputStream(t, e, r);
			});
		}
		addUintToStream(t, e, r) {
			Bh(this, e, (e) => {
				this.i._addUintToInputStream(t, e, r);
			});
		}
		addStringToStream(t, e, r) {
			Bh(this, e, (e) => {
				Bh(this, t, (t) => {
					this.i._addStringToInputStream(t, e, r);
				});
			});
		}
		addStringRecordToStream(t, e, r) {
			Bh(this, e, (e) => {
				jh(this, Object.keys(t), (n) => {
					jh(this, Object.values(t), (i) => {
						this.i._addFlatHashMapToInputStream(n, i, Object.keys(t).length, e, r);
					});
				});
			});
		}
		addProtoToStream(t, e, r, n) {
			Bh(this, r, (r) => {
				Bh(this, e, (e) => {
					var i = this.i._malloc(t.length);
					this.i.HEAPU8.set(t, i), this.i._addProtoToInputStream(i, t.length, e, r, n), this.i._free(i);
				});
			});
		}
		addEmptyPacketToStream(t, e) {
			Bh(this, t, (t) => {
				this.i._addEmptyPacketToInputStream(t, e);
			});
		}
		addBoolVectorToStream(t, e, r) {
			Bh(this, e, (e) => {
				var n = this.i._allocateBoolVector(t.length);
				if (!n) throw Error("Unable to allocate new bool vector on heap.");
				for (let e of t) this.i._addBoolVectorEntry(n, e);
				this.i._addBoolVectorToInputStream(n, e, r);
			});
		}
		addDoubleVectorToStream(t, e, r) {
			Bh(this, e, (e) => {
				var n = this.i._allocateDoubleVector(t.length);
				if (!n) throw Error("Unable to allocate new double vector on heap.");
				for (let e of t) this.i._addDoubleVectorEntry(n, e);
				this.i._addDoubleVectorToInputStream(n, e, r);
			});
		}
		addFloatVectorToStream(t, e, r) {
			Bh(this, e, (e) => {
				var n = this.i._allocateFloatVector(t.length);
				if (!n) throw Error("Unable to allocate new float vector on heap.");
				for (let e of t) this.i._addFloatVectorEntry(n, e);
				this.i._addFloatVectorToInputStream(n, e, r);
			});
		}
		addIntVectorToStream(t, e, r) {
			Bh(this, e, (e) => {
				var n = this.i._allocateIntVector(t.length);
				if (!n) throw Error("Unable to allocate new int vector on heap.");
				for (let e of t) this.i._addIntVectorEntry(n, e);
				this.i._addIntVectorToInputStream(n, e, r);
			});
		}
		addUintVectorToStream(t, e, r) {
			Bh(this, e, (e) => {
				var n = this.i._allocateUintVector(t.length);
				if (!n) throw Error("Unable to allocate new unsigned int vector on heap.");
				for (let e of t) this.i._addUintVectorEntry(n, e);
				this.i._addUintVectorToInputStream(n, e, r);
			});
		}
		addStringVectorToStream(t, e, r) {
			Bh(this, e, (e) => {
				var n = this.i._allocateStringVector(t.length);
				if (!n) throw Error("Unable to allocate new string vector on heap.");
				for (let e of t) Bh(this, e, (t) => {
					this.i._addStringVectorEntry(n, t);
				});
				this.i._addStringVectorToInputStream(n, e, r);
			});
		}
		addBoolToInputSidePacket(t, e) {
			Bh(this, e, (e) => {
				this.i._addBoolToInputSidePacket(t, e);
			});
		}
		addDoubleToInputSidePacket(t, e) {
			Bh(this, e, (e) => {
				this.i._addDoubleToInputSidePacket(t, e);
			});
		}
		addFloatToInputSidePacket(t, e) {
			Bh(this, e, (e) => {
				this.i._addFloatToInputSidePacket(t, e);
			});
		}
		addIntToInputSidePacket(t, e) {
			Bh(this, e, (e) => {
				this.i._addIntToInputSidePacket(t, e);
			});
		}
		addUintToInputSidePacket(t, e) {
			Bh(this, e, (e) => {
				this.i._addUintToInputSidePacket(t, e);
			});
		}
		addStringToInputSidePacket(t, e) {
			Bh(this, e, (e) => {
				Bh(this, t, (t) => {
					this.i._addStringToInputSidePacket(t, e);
				});
			});
		}
		addProtoToInputSidePacket(t, e, r) {
			Bh(this, r, (r) => {
				Bh(this, e, (e) => {
					var n = this.i._malloc(t.length);
					this.i.HEAPU8.set(t, n), this.i._addProtoToInputSidePacket(n, t.length, e, r), this.i._free(n);
				});
			});
		}
		addBoolVectorToInputSidePacket(t, e) {
			Bh(this, e, (e) => {
				var r = this.i._allocateBoolVector(t.length);
				if (!r) throw Error("Unable to allocate new bool vector on heap.");
				for (let e of t) this.i._addBoolVectorEntry(r, e);
				this.i._addBoolVectorToInputSidePacket(r, e);
			});
		}
		addDoubleVectorToInputSidePacket(t, e) {
			Bh(this, e, (e) => {
				var r = this.i._allocateDoubleVector(t.length);
				if (!r) throw Error("Unable to allocate new double vector on heap.");
				for (let e of t) this.i._addDoubleVectorEntry(r, e);
				this.i._addDoubleVectorToInputSidePacket(r, e);
			});
		}
		addFloatVectorToInputSidePacket(t, e) {
			Bh(this, e, (e) => {
				var r = this.i._allocateFloatVector(t.length);
				if (!r) throw Error("Unable to allocate new float vector on heap.");
				for (let e of t) this.i._addFloatVectorEntry(r, e);
				this.i._addFloatVectorToInputSidePacket(r, e);
			});
		}
		addIntVectorToInputSidePacket(t, e) {
			Bh(this, e, (e) => {
				var r = this.i._allocateIntVector(t.length);
				if (!r) throw Error("Unable to allocate new int vector on heap.");
				for (let e of t) this.i._addIntVectorEntry(r, e);
				this.i._addIntVectorToInputSidePacket(r, e);
			});
		}
		addUintVectorToInputSidePacket(t, e) {
			Bh(this, e, (e) => {
				var r = this.i._allocateUintVector(t.length);
				if (!r) throw Error("Unable to allocate new unsigned int vector on heap.");
				for (let e of t) this.i._addUintVectorEntry(r, e);
				this.i._addUintVectorToInputSidePacket(r, e);
			});
		}
		addStringVectorToInputSidePacket(t, e) {
			Bh(this, e, (e) => {
				var r = this.i._allocateStringVector(t.length);
				if (!r) throw Error("Unable to allocate new string vector on heap.");
				for (let e of t) Bh(this, e, (t) => {
					this.i._addStringVectorEntry(r, t);
				});
				this.i._addStringVectorToInputSidePacket(r, e);
			});
		}
		attachBoolListener(t, e) {
			Vh(this, t, e), Bh(this, t, (t) => {
				this.i._attachBoolListener(t);
			});
		}
		attachBoolVectorListener(t, e) {
			Hh(this, t, e), Bh(this, t, (t) => {
				this.i._attachBoolVectorListener(t);
			});
		}
		attachIntListener(t, e) {
			Vh(this, t, e), Bh(this, t, (t) => {
				this.i._attachIntListener(t);
			});
		}
		attachIntVectorListener(t, e) {
			Hh(this, t, e), Bh(this, t, (t) => {
				this.i._attachIntVectorListener(t);
			});
		}
		attachUintListener(t, e) {
			Vh(this, t, e), Bh(this, t, (t) => {
				this.i._attachUintListener(t);
			});
		}
		attachUintVectorListener(t, e) {
			Hh(this, t, e), Bh(this, t, (t) => {
				this.i._attachUintVectorListener(t);
			});
		}
		attachDoubleListener(t, e) {
			Vh(this, t, e), Bh(this, t, (t) => {
				this.i._attachDoubleListener(t);
			});
		}
		attachDoubleVectorListener(t, e) {
			Hh(this, t, e), Bh(this, t, (t) => {
				this.i._attachDoubleVectorListener(t);
			});
		}
		attachFloatListener(t, e) {
			Vh(this, t, e), Bh(this, t, (t) => {
				this.i._attachFloatListener(t);
			});
		}
		attachFloatVectorListener(t, e) {
			Hh(this, t, e), Bh(this, t, (t) => {
				this.i._attachFloatVectorListener(t);
			});
		}
		attachStringListener(t, e) {
			Vh(this, t, e), Bh(this, t, (t) => {
				this.i._attachStringListener(t);
			});
		}
		attachStringVectorListener(t, e) {
			Hh(this, t, e), Bh(this, t, (t) => {
				this.i._attachStringVectorListener(t);
			});
		}
		attachProtoListener(t, e, r) {
			Vh(this, t, e), Bh(this, t, (t) => {
				this.i._attachProtoListener(t, r || !1);
			});
		}
		attachProtoVectorListener(t, e, r) {
			Hh(this, t, e), Bh(this, t, (t) => {
				this.i._attachProtoVectorListener(t, r || !1);
			});
		}
		attachAudioListener(t, e, r) {
			this.i._attachAudioListener || console.warn("Attempting to use attachAudioListener without support for output audio. Is build dep \":gl_graph_runner_audio_out\" missing?"), Vh(this, t, (t, r) => {
				t = new Float32Array(t.buffer, t.byteOffset, t.length / 4), e(t, r);
			}), Bh(this, t, (t) => {
				this.i._attachAudioListener(t, r || !1);
			});
		}
		finishProcessing() {
			this.i._waitUntilIdle();
		}
		closeGraph() {
			this.i._closeGraph(), this.i.simpleListeners = void 0, this.i.emptyPacketListeners = void 0;
		}
	};
	function Xh(t) {
		return class extends t {
			get pa() {
				return this.i;
			}
			Sa() {
				if ("function" == typeof this.pa._mediapipeLoggerGetEncodedApiKey) {
					let t = this.pa._mediapipeLoggerGetEncodedApiKey();
					return this.pa._decodeBase64(t);
				}
			}
		};
	}
	function Wh(t) {
		return class extends t {
			Za() {
				this.i._registerModelResourcesGraphService();
			}
		};
	}
	var zh = Xh(Wh(Kh));
	var Yh = class extends zh {};
	async function qh(t, e, r, n) {
		return t = await (async (t, e, r, n, i) => {
			if (e && await $h(e), !self.ModuleFactory) throw Error("ModuleFactory not set.");
			if (r && (await $h(r), !self.ModuleFactory)) throw Error("ModuleFactory not set.");
			return self.Module && i && ((e = self.Module).locateFile = i.locateFile, i.mainScriptUrlOrBlob && (e.mainScriptUrlOrBlob = i.mainScriptUrlOrBlob)), i = await self.ModuleFactory(self.Module || i), self.ModuleFactory = self.Module = void 0, new t(i, n);
		})(t, r.wasmLoaderPath, r.assetLoaderPath, e, { locateFile: (t) => t.endsWith(".wasm") ? r.wasmBinaryPath.toString() : r.assetBinaryPath && t.endsWith(".data") ? r.assetBinaryPath.toString() : t }), function(t, e) {
			e = e.runningMode ?? "";
			var r = t.g.Sa();
			t.m = new Dh(t.C(), e, r);
		}(t, n), await t.v(n), t;
	}
	async function Jh(t, e, r, n) {
		return qh(t, e, r, n);
	}
	function Zh(t, e) {
		var r = Sr(t.baseOptions, Wo, 1) || new Wo();
		"string" == typeof e ? (ar(r, 2, ve(e)), ar(r, 1)) : e instanceof Uint8Array && (ar(r, 1, ct(e, !1)), ar(r, 2)), Ir(t.baseOptions, 0, 1, r);
	}
	function Qh(t) {
		try {
			let e = t.K.length;
			if (1 === e) throw Error(t.K[0].message);
			if (e > 1) throw Error("Encountered multiple errors: " + t.K.map((t) => t.message).join(", "));
		} finally {
			t.K = [];
		}
	}
	function tu(t, e) {
		t.I = Math.max(t.I, e);
	}
	function eu(t, e) {
		t.D = new ho(), Hr(t.D, 2, "PassThroughCalculator"), oo(t.D, "free_memory"), ao(t.D, "free_memory_unused_out"), po(e, "free_memory"), fo(e, t.D);
	}
	function ru(t, e) {
		oo(t.D, e), ao(t.D, e + "_unused_out");
	}
	function nu(t) {
		t.g.addBoolToStream(!0, "free_memory", t.I);
	}
	var iu = class {
		constructor(t) {
			this.g = t, this.K = [], this.I = 0, this.g.setAutoRenderToScreen(!1);
		}
		j(t, e = !0) {
			if (e) {
				let e = t.baseOptions || {};
				if (t.baseOptions?.modelAssetBuffer && t.baseOptions?.modelAssetPath) throw Error("Cannot set both baseOptions.modelAssetPath and baseOptions.modelAssetBuffer");
				if (!(Sr(this.baseOptions, Wo, 1)?.g() || Sr(this.baseOptions, Wo, 1)?.j() || t.baseOptions?.modelAssetBuffer || t.baseOptions?.modelAssetPath)) throw Error("Either baseOptions.modelAssetPath or baseOptions.modelAssetBuffer must be set");
				if (function(t, e) {
					var r = Sr(t.baseOptions, Ko, 3);
					if (!r) {
						var n = r = new Ko(), i = new Qs();
						Fr(n, 4, Xo, i);
					}
					"delegate" in e && ("GPU" === e.delegate ? (e = r, n = new Ys(), Fr(e, 2, Xo, n)) : (e = r, n = new Qs(), Fr(e, 4, Xo, n))), Ir(t.baseOptions, 0, 3, r);
				}(this, e), e.modelAssetPath) return fetch(e.modelAssetPath.toString()).then((t) => {
					if (t.ok) return t.arrayBuffer();
					throw Error(`Failed to fetch model: ${e.modelAssetPath} (${t.status})`);
				}).then((t) => {
					try {
						this.g.i.FS_unlink("/model.dat");
					} catch {}
					this.g.i.FS_createDataFile("/", "model.dat", new Uint8Array(t), !0, !1, !1), Zh(this, "/model.dat"), this.o(), this.L();
				});
				if (e.modelAssetBuffer instanceof Uint8Array) Zh(this, e.modelAssetBuffer);
				else if (e.modelAssetBuffer) return async function(t) {
					for (var e = [], r = 0;;) {
						let { done: n, value: i } = await t.read();
						if (n) break;
						e.push(i), r += i.length;
					}
					if (0 === e.length) return /* @__PURE__ */ new Uint8Array(0);
					if (1 === e.length) return e[0];
					t = new Uint8Array(r), r = 0;
					for (let n of e) t.set(n, r), r += n.length;
					return t;
				}(e.modelAssetBuffer).then((t) => {
					Zh(this, t), this.o(), this.L();
				});
			}
			return this.o(), this.L(), Promise.resolve();
		}
		L() {}
		ja() {
			var t;
			if (this.g.ja((e) => {
				t = _o(e);
			}), !t) throw Error("Failed to retrieve CalculatorGraphConfig");
			return t;
		}
		setGraph(t, e) {
			this.g.attachErrorListener((t, e) => {
				this.K.push(Error(e));
			}), this.g.Za(), this.g.setGraph(t, e), this.m?.ya(), this.D = void 0, Qh(this);
		}
		finishProcessing(t) {
			this.g.finishProcessing(), Qh(this), this.m && void 0 !== t && this.m.za(t);
		}
		close() {
			this.D = void 0, this.m?.xa(), this.m?.close(), this.g.closeGraph();
		}
	};
	function su(t, e) {
		if (!t) throw Error(`Unable to obtain required WebGL resource: ${e}`);
		return t;
	}
	iu.prototype.close = iu.prototype.close;
	var ou = class {
		constructor(t, e, r, n) {
			this.g = t, this.h = e, this.m = r, this.j = n;
		}
		bind() {
			this.g.bindVertexArray(this.h);
		}
		close() {
			this.g.deleteVertexArray(this.h), this.g.deleteBuffer(this.m), this.g.deleteBuffer(this.j);
		}
	};
	function au(t, e, r) {
		var n = t.g;
		if (r = su(n.createShader(r), "Failed to create WebGL shader"), n.shaderSource(r, e), n.compileShader(r), !n.getShaderParameter(r, n.COMPILE_STATUS)) throw Error(`Could not compile WebGL shader: ${n.getShaderInfoLog(r)}`);
		return n.attachShader(t.h, r), r;
	}
	function hu(t, e) {
		var r = t.g, n = su(r.createVertexArray(), "Failed to create vertex array");
		r.bindVertexArray(n);
		var i = su(r.createBuffer(), "Failed to create buffer");
		r.bindBuffer(r.ARRAY_BUFFER, i), r.enableVertexAttribArray(t.F), r.vertexAttribPointer(t.F, 2, r.FLOAT, !1, 0, 0), r.bufferData(r.ARRAY_BUFFER, new Float32Array([
			-1,
			-1,
			-1,
			1,
			1,
			1,
			1,
			-1
		]), r.STATIC_DRAW);
		var s = su(r.createBuffer(), "Failed to create buffer");
		return r.bindBuffer(r.ARRAY_BUFFER, s), r.enableVertexAttribArray(t.K), r.vertexAttribPointer(t.K, 2, r.FLOAT, !1, 0, 0), r.bufferData(r.ARRAY_BUFFER, new Float32Array(e ? [
			0,
			1,
			0,
			0,
			1,
			0,
			1,
			1
		] : [
			0,
			0,
			0,
			1,
			1,
			1,
			1,
			0
		]), r.STATIC_DRAW), r.bindBuffer(r.ARRAY_BUFFER, null), r.bindVertexArray(null), new ou(r, n, i, s);
	}
	function uu(t, e) {
		if (t.g) {
			if (e !== t.g) throw Error("Cannot change GL context once initialized");
		} else t.g = e;
	}
	function cu(t, e, r, n) {
		return uu(t, e), t.h || (t.m(), t.I()), r ? (t.l || (t.l = hu(t, !0)), r = t.l) : (t.D || (t.D = hu(t, !1)), r = t.D), e.useProgram(t.h), r.bind(), t.j(), t = n(), r.g.bindVertexArray(null), t;
	}
	function lu(t, e, r) {
		return uu(t, e), t = su(e.createTexture(), "Failed to create texture"), e.bindTexture(e.TEXTURE_2D, t), e.texParameteri(e.TEXTURE_2D, e.TEXTURE_WRAP_S, e.CLAMP_TO_EDGE), e.texParameteri(e.TEXTURE_2D, e.TEXTURE_WRAP_T, e.CLAMP_TO_EDGE), e.texParameteri(e.TEXTURE_2D, e.TEXTURE_MIN_FILTER, r ?? e.LINEAR), e.texParameteri(e.TEXTURE_2D, e.TEXTURE_MAG_FILTER, r ?? e.LINEAR), e.bindTexture(e.TEXTURE_2D, null), t;
	}
	function du(t, e, r) {
		uu(t, e), t.C || (t.C = su(e.createFramebuffer(), "Failed to create framebuffe.")), e.bindFramebuffer(e.FRAMEBUFFER, t.C), e.framebufferTexture2D(e.FRAMEBUFFER, e.COLOR_ATTACHMENT0, e.TEXTURE_2D, r, 0);
	}
	function fu(t) {
		t.g?.bindFramebuffer(t.g.FRAMEBUFFER, null);
	}
	var pu = class {
		B() {
			return "\n  precision mediump float;\n  varying vec2 vTex;\n  uniform sampler2D inputTexture;\n  void main() {\n    gl_FragColor = texture2D(inputTexture, vTex);\n  }\n ";
		}
		m() {
			var t = this.g;
			if (this.h = su(t.createProgram(), "Failed to create WebGL program"), this.da = au(this, "\n  attribute vec2 aVertex;\n  attribute vec2 aTex;\n  varying vec2 vTex;\n  void main(void) {\n    gl_Position = vec4(aVertex, 0.0, 1.0);\n    vTex = aTex;\n  }", t.VERTEX_SHADER), this.Z = au(this, this.B(), t.FRAGMENT_SHADER), t.linkProgram(this.h), !t.getProgramParameter(this.h, t.LINK_STATUS)) throw Error(`Error during program linking: ${t.getProgramInfoLog(this.h)}`);
			this.F = t.getAttribLocation(this.h, "aVertex"), this.K = t.getAttribLocation(this.h, "aTex");
		}
		I() {}
		j() {}
		close() {
			if (this.h) {
				let t = this.g;
				t.deleteProgram(this.h), t.deleteShader(this.da), t.deleteShader(this.Z);
			}
			this.C && this.g.deleteFramebuffer(this.C), this.D && this.D.close(), this.l && this.l.close();
		}
	};
	var gu = class extends pu {
		B() {
			return "\n  precision mediump float;\n  uniform sampler2D backgroundTexture;\n  uniform sampler2D maskTexture;\n  uniform sampler2D colorMappingTexture;\n  varying vec2 vTex;\n  void main() {\n    vec4 backgroundColor = texture2D(backgroundTexture, vTex);\n    float category = texture2D(maskTexture, vTex).r;\n    vec4 categoryColor = texture2D(colorMappingTexture, vec2(category, 0.0));\n    gl_FragColor = mix(backgroundColor, categoryColor, categoryColor.a);\n  }\n ";
		}
		I() {
			var t = this.g;
			t.activeTexture(t.TEXTURE1), this.u = lu(this, t, t.LINEAR), t.activeTexture(t.TEXTURE2), this.o = lu(this, t, t.NEAREST);
		}
		m() {
			super.m();
			var t = this.g;
			this.O = su(t.getUniformLocation(this.h, "backgroundTexture"), "Uniform location"), this.Y = su(t.getUniformLocation(this.h, "colorMappingTexture"), "Uniform location"), this.L = su(t.getUniformLocation(this.h, "maskTexture"), "Uniform location");
		}
		j() {
			super.j();
			var t = this.g;
			t.uniform1i(this.L, 0), t.uniform1i(this.O, 1), t.uniform1i(this.Y, 2);
		}
		close() {
			this.u && this.g.deleteTexture(this.u), this.o && this.g.deleteTexture(this.o), super.close();
		}
	};
	var mu = class extends pu {
		B() {
			return "\n  precision mediump float;\n  uniform sampler2D maskTexture;\n  uniform sampler2D defaultTexture;\n  uniform sampler2D overlayTexture;\n  varying vec2 vTex;\n  void main() {\n    float confidence = texture2D(maskTexture, vTex).r;\n    vec4 defaultColor = texture2D(defaultTexture, vTex);\n    vec4 overlayColor = texture2D(overlayTexture, vTex);\n    // Apply the alpha from the overlay and merge in the default color\n    overlayColor = mix(defaultColor, overlayColor, overlayColor.a);\n    gl_FragColor = mix(defaultColor, overlayColor, confidence);\n  }\n ";
		}
		I() {
			var t = this.g;
			t.activeTexture(t.TEXTURE1), this.o = lu(this, t), t.activeTexture(t.TEXTURE2), this.u = lu(this, t);
		}
		m() {
			super.m();
			var t = this.g;
			this.L = su(t.getUniformLocation(this.h, "defaultTexture"), "Uniform location"), this.O = su(t.getUniformLocation(this.h, "overlayTexture"), "Uniform location"), this.J = su(t.getUniformLocation(this.h, "maskTexture"), "Uniform location");
		}
		j() {
			super.j();
			var t = this.g;
			t.uniform1i(this.J, 0), t.uniform1i(this.L, 1), t.uniform1i(this.O, 2);
		}
		close() {
			this.o && this.g.deleteTexture(this.o), this.u && this.g.deleteTexture(this.u), super.close();
		}
	};
	function vu(t, e) {
		switch (e) {
			case 0: return t.g.find((t) => t instanceof Uint8Array);
			case 1: return t.g.find((t) => t instanceof Float32Array);
			case 2: return t.g.find((t) => "undefined" != typeof WebGLTexture && t instanceof WebGLTexture);
			default: throw Error(`Type is not supported: ${e}`);
		}
	}
	function _u(t) {
		var e = vu(t, 1);
		if (!e) {
			if (e = vu(t, 0)) e = new Float32Array(e).map((t) => t / 255);
			else {
				e = new Float32Array(t.width * t.height);
				let n = Eu(t);
				var r = wu(t);
				if (du(r, n, yu(t)), "iPad Simulator;iPhone Simulator;iPod Simulator;iPad;iPhone;iPod".split(";").includes(navigator.platform) || navigator.userAgent.includes("Mac") && "document" in self && "ontouchend" in self.document) {
					r = new Float32Array(t.width * t.height * 4), n.readPixels(0, 0, t.width, t.height, n.RGBA, n.FLOAT, r);
					for (let t = 0, n = 0; t < e.length; ++t, n += 4) e[t] = r[n];
				} else n.readPixels(0, 0, t.width, t.height, n.RED, n.FLOAT, e);
			}
			t.g.push(e);
		}
		return e;
	}
	function yu(t) {
		var e = vu(t, 2);
		if (!e) {
			let r = Eu(t);
			e = bu(t);
			let n = _u(t), i = Au(t);
			r.texImage2D(r.TEXTURE_2D, 0, i, t.width, t.height, 0, r.RED, r.FLOAT, n), Tu(t);
		}
		return e;
	}
	function Eu(t) {
		if (!t.canvas) throw Error("Conversion to different image formats require that a canvas is passed when initializing the image.");
		return t.h || (t.h = su(t.canvas.getContext("webgl2"), "You cannot use a canvas that is already bound to a different type of rendering context.")), t.h;
	}
	function Au(t) {
		if (t = Eu(t), !ku) if (t.getExtension("EXT_color_buffer_float") && t.getExtension("OES_texture_float_linear") && t.getExtension("EXT_float_blend")) ku = t.R32F;
		else {
			if (!t.getExtension("EXT_color_buffer_half_float")) throw Error("GPU does not fully support 4-channel float32 or float16 formats");
			ku = t.R16F;
		}
		return ku;
	}
	function wu(t) {
		return t.j || (t.j = new pu()), t.j;
	}
	function bu(t) {
		var e = Eu(t);
		e.viewport(0, 0, t.width, t.height), e.activeTexture(e.TEXTURE0);
		var r = vu(t, 2);
		return r || (r = lu(wu(t), e, t.m ? e.LINEAR : e.NEAREST), t.g.push(r), t.o = !0), e.bindTexture(e.TEXTURE_2D, r), r;
	}
	function Tu(t) {
		t.h.bindTexture(t.h.TEXTURE_2D, null);
	}
	var ku;
	var Su = class {
		constructor(t, e, r, n, i, s, o) {
			this.g = t, this.m = e, this.o = r, this.canvas = n, this.j = i, this.width = s, this.height = o, this.o && 0 === --Lu && console.error("You seem to be creating MPMask instances without invoking .close(). This leaks resources.");
		}
		Ua() {
			return !!vu(this, 0);
		}
		ua() {
			return !!vu(this, 1);
		}
		W() {
			return !!vu(this, 2);
		}
		ta() {
			return (e = vu(t = this, 0)) || (e = _u(t), e = new Uint8Array(e.map((t) => Math.round(255 * t))), t.g.push(e)), e;
			var t, e;
		}
		sa() {
			return _u(this);
		}
		S() {
			return yu(this);
		}
		clone() {
			var t = [];
			for (let e of this.g) {
				let r;
				if (e instanceof Uint8Array) r = new Uint8Array(e);
				else if (e instanceof Float32Array) r = new Float32Array(e);
				else {
					if (!(e instanceof WebGLTexture)) throw Error(`Type is not supported: ${e}`);
					{
						let t = Eu(this), e = wu(this);
						t.activeTexture(t.TEXTURE1), r = lu(e, t, this.m ? t.LINEAR : t.NEAREST), t.bindTexture(t.TEXTURE_2D, r);
						let n = Au(this);
						t.texImage2D(t.TEXTURE_2D, 0, n, this.width, this.height, 0, t.RED, t.FLOAT, null), t.bindTexture(t.TEXTURE_2D, null), du(e, t, r), cu(e, t, !1, () => {
							bu(this), t.clearColor(0, 0, 0, 0), t.clear(t.COLOR_BUFFER_BIT), t.drawArrays(t.TRIANGLE_FAN, 0, 4), Tu(this);
						}), fu(e), Tu(this);
					}
				}
				t.push(r);
			}
			return new Su(t, this.m, this.W(), this.canvas, this.j, this.width, this.height);
		}
		close() {
			this.o && Eu(this).deleteTexture(vu(this, 2)), Lu = -1;
		}
	};
	Su.prototype.close = Su.prototype.close, Su.prototype.clone = Su.prototype.clone, Su.prototype.getAsWebGLTexture = Su.prototype.S, Su.prototype.getAsFloat32Array = Su.prototype.sa, Su.prototype.getAsUint8Array = Su.prototype.ta, Su.prototype.hasWebGLTexture = Su.prototype.W, Su.prototype.hasFloat32Array = Su.prototype.ua, Su.prototype.hasUint8Array = Su.prototype.Ua;
	var Lu = 250;
	var xu = {
		color: "white",
		lineWidth: 4,
		radius: 6
	};
	function Ru(t) {
		return {
			...xu,
			fillColor: (t = t || {}).color,
			...t
		};
	}
	function Iu(t, e) {
		return t instanceof Function ? t(e) : t;
	}
	function Fu(t, e, r) {
		return Math.max(Math.min(e, r), Math.min(Math.max(e, r), t));
	}
	function Cu(t) {
		if (!t.j) throw Error("CPU rendering requested but CanvasRenderingContext2D not provided.");
		return t.j;
	}
	function Nu(t) {
		if (!t.o) throw Error("GPU rendering requested but WebGL2RenderingContext not provided.");
		return t.o;
	}
	function Mu(t, e, r) {
		if (e.W()) r(e.S());
		else {
			let n = e.ua() ? e.sa() : e.ta();
			t.m = t.m ?? new pu();
			let i = Nu(t);
			r((t = new Su([n], e.m, !1, i.canvas, t.m, e.width, e.height)).S()), t.close();
		}
	}
	function Ou(t, e, r, n) {
		var i = function(t) {
			return t.g || (t.g = new gu()), t.g;
		}(t), s = Nu(t), o = Array.isArray(r) ? new ImageData(new Uint8ClampedArray(r), 1, 1) : r;
		cu(i, s, !0, () => {
			(function(t, e, r, n) {
				var i = t.g;
				if (i.activeTexture(i.TEXTURE0), i.bindTexture(i.TEXTURE_2D, e), i.activeTexture(i.TEXTURE1), i.bindTexture(i.TEXTURE_2D, t.u), i.texImage2D(i.TEXTURE_2D, 0, i.RGBA, i.RGBA, i.UNSIGNED_BYTE, r), t.J && function(t, e) {
					if (t !== e) return !1;
					t = t.entries(), e = e.entries();
					for (let [r, n] of t) {
						t = r;
						let i = n, s = e.next();
						if (s.done) return !1;
						let [o, a] = s.value;
						if (t !== o || i[0] !== a[0] || i[1] !== a[1] || i[2] !== a[2] || i[3] !== a[3]) return !1;
					}
					return !!e.next().done;
				}(t.J, n)) i.activeTexture(i.TEXTURE2), i.bindTexture(i.TEXTURE_2D, t.o);
				else {
					t.J = n;
					let e = Array(1024).fill(0);
					n.forEach((t, r) => {
						if (4 !== t.length) throw Error(`Color at index ${r} is not a four-channel value.`);
						e[4 * r] = t[0], e[4 * r + 1] = t[1], e[4 * r + 2] = t[2], e[4 * r + 3] = t[3];
					}), i.activeTexture(i.TEXTURE2), i.bindTexture(i.TEXTURE_2D, t.o), i.texImage2D(i.TEXTURE_2D, 0, i.RGBA, 256, 1, 0, i.RGBA, i.UNSIGNED_BYTE, new Uint8Array(e));
				}
			})(i, e, o, n), s.clearColor(0, 0, 0, 0), s.clear(s.COLOR_BUFFER_BIT), s.drawArrays(s.TRIANGLE_FAN, 0, 4);
			var t = i.g;
			t.activeTexture(t.TEXTURE0), t.bindTexture(t.TEXTURE_2D, null), t.activeTexture(t.TEXTURE1), t.bindTexture(t.TEXTURE_2D, null), t.activeTexture(t.TEXTURE2), t.bindTexture(t.TEXTURE_2D, null);
		});
	}
	function Du(t, e, r, n) {
		var i = Nu(t), s = function(t) {
			return t.h || (t.h = new mu()), t.h;
		}(t), o = Array.isArray(r) ? new ImageData(new Uint8ClampedArray(r), 1, 1) : r, a = Array.isArray(n) ? new ImageData(new Uint8ClampedArray(n), 1, 1) : n;
		cu(s, i, !0, () => {
			var t = s.g;
			t.activeTexture(t.TEXTURE0), t.bindTexture(t.TEXTURE_2D, e), t.activeTexture(t.TEXTURE1), t.bindTexture(t.TEXTURE_2D, s.o), t.texImage2D(t.TEXTURE_2D, 0, t.RGBA, t.RGBA, t.UNSIGNED_BYTE, o), t.activeTexture(t.TEXTURE2), t.bindTexture(t.TEXTURE_2D, s.u), t.texImage2D(t.TEXTURE_2D, 0, t.RGBA, t.RGBA, t.UNSIGNED_BYTE, a), i.clearColor(0, 0, 0, 0), i.clear(i.COLOR_BUFFER_BIT), i.drawArrays(i.TRIANGLE_FAN, 0, 4), i.bindTexture(i.TEXTURE_2D, null), (t = s.g).activeTexture(t.TEXTURE0), t.bindTexture(t.TEXTURE_2D, null), t.activeTexture(t.TEXTURE1), t.bindTexture(t.TEXTURE_2D, null), t.activeTexture(t.TEXTURE2), t.bindTexture(t.TEXTURE_2D, null);
		});
	}
	var Pu = class {
		constructor(t, e) {
			"undefined" != typeof CanvasRenderingContext2D && t instanceof CanvasRenderingContext2D || t instanceof OffscreenCanvasRenderingContext2D ? (this.j = t, this.o = e) : this.o = t;
		}
		Ma(t, e) {
			if (t) {
				var r = Cu(this);
				e = Ru(e), r.save();
				var n = r.canvas, i = 0;
				for (let s of t) r.fillStyle = Iu(e.fillColor, {
					index: i,
					from: s
				}), r.strokeStyle = Iu(e.color, {
					index: i,
					from: s
				}), r.lineWidth = Iu(e.lineWidth, {
					index: i,
					from: s
				}), (t = new Path2D()).arc(s.x * n.width, s.y * n.height, Iu(e.radius, {
					index: i,
					from: s
				}), 0, 2 * Math.PI), r.fill(t), r.stroke(t), ++i;
				r.restore();
			}
		}
		La(t, e, r) {
			if (t && e) {
				var n = Cu(this);
				r = Ru(r), n.save();
				var i = n.canvas, s = 0;
				for (let o of e) {
					n.beginPath(), e = t[o.start];
					let a = t[o.end];
					e && a && (n.strokeStyle = Iu(r.color, {
						index: s,
						from: e,
						to: a
					}), n.lineWidth = Iu(r.lineWidth, {
						index: s,
						from: e,
						to: a
					}), n.moveTo(e.x * i.width, e.y * i.height), n.lineTo(a.x * i.width, a.y * i.height)), ++s, n.stroke();
				}
				n.restore();
			}
		}
		Ia(t, e) {
			var r = Cu(this);
			e = Ru(e), r.save(), r.beginPath(), r.lineWidth = Iu(e.lineWidth, {}), r.strokeStyle = Iu(e.color, {}), r.fillStyle = Iu(e.fillColor, {}), r.moveTo(t.originX, t.originY), r.lineTo(t.originX + t.width, t.originY), r.lineTo(t.originX + t.width, t.originY + t.height), r.lineTo(t.originX, t.originY + t.height), r.lineTo(t.originX, t.originY), r.stroke(), r.fill(), r.restore();
		}
		Ja(t, e, r = [
			0,
			0,
			0,
			255
		]) {
			this.j ? function(t, e, r, n) {
				var i = Nu(t);
				Mu(t, e, (e) => {
					Ou(t, e, r, n), (e = Cu(t)).drawImage(i.canvas, 0, 0, e.canvas.width, e.canvas.height);
				});
			}(this, t, r, e) : Ou(this, t.S(), r, e);
		}
		Ka(t, e, r) {
			this.j ? function(t, e, r, n) {
				var i = Nu(t);
				Mu(t, e, (e) => {
					Du(t, e, r, n), (e = Cu(t)).drawImage(i.canvas, 0, 0, e.canvas.width, e.canvas.height);
				});
			}(this, t, e, r) : Du(this, t.S(), e, r);
		}
		close() {
			this.g?.close(), this.g = void 0, this.h?.close(), this.h = void 0, this.m?.close(), this.m = void 0;
		}
	};
	function $u(t, e) {
		switch (e) {
			case 0: return t.g.find((t) => t instanceof ImageData);
			case 1: return t.g.find((t) => "undefined" != typeof ImageBitmap && t instanceof ImageBitmap);
			case 2: return t.g.find((t) => "undefined" != typeof WebGLTexture && t instanceof WebGLTexture);
			default: throw Error(`Type is not supported: ${e}`);
		}
	}
	function Uu(t) {
		var e = $u(t, 0);
		if (!e) {
			e = Gu(t);
			let r = ju(t), n = new Uint8Array(t.width * t.height * 4);
			du(r, e, Bu(t)), e.readPixels(0, 0, t.width, t.height, e.RGBA, e.UNSIGNED_BYTE, n), fu(r), e = new ImageData(new Uint8ClampedArray(n.buffer), t.width, t.height), t.g.push(e);
		}
		return e;
	}
	function Bu(t) {
		var e = $u(t, 2);
		if (!e) {
			let r = Gu(t);
			e = Vu(t);
			let n = $u(t, 1) || Uu(t);
			r.texImage2D(r.TEXTURE_2D, 0, r.RGBA, r.RGBA, r.UNSIGNED_BYTE, n), Hu(t);
		}
		return e;
	}
	function Gu(t) {
		if (!t.canvas) throw Error("Conversion to different image formats require that a canvas is passed when initializing the image.");
		return t.h || (t.h = su(t.canvas.getContext("webgl2"), "You cannot use a canvas that is already bound to a different type of rendering context.")), t.h;
	}
	function ju(t) {
		return t.j || (t.j = new pu()), t.j;
	}
	function Vu(t) {
		var e = Gu(t);
		e.viewport(0, 0, t.width, t.height), e.activeTexture(e.TEXTURE0);
		var r = $u(t, 2);
		return r || (r = lu(ju(t), e), t.g.push(r), t.m = !0), e.bindTexture(e.TEXTURE_2D, r), r;
	}
	function Hu(t) {
		t.h.bindTexture(t.h.TEXTURE_2D, null);
	}
	function Ku(t) {
		var e = Gu(t);
		return cu(ju(t), e, !0, () => function(t, e) {
			var r = t.canvas;
			if (r.width === t.width && r.height === t.height) return e();
			var n = r.width, i = r.height;
			return r.width = t.width, r.height = t.height, t = e(), r.width = n, r.height = i, t;
		}(t, () => {
			if (e.bindFramebuffer(e.FRAMEBUFFER, null), e.clearColor(0, 0, 0, 0), e.clear(e.COLOR_BUFFER_BIT), e.drawArrays(e.TRIANGLE_FAN, 0, 4), !(t.canvas instanceof OffscreenCanvas)) throw Error("Conversion to ImageBitmap requires that the MediaPipe Tasks is initialized with an OffscreenCanvas");
			return t.canvas.transferToImageBitmap();
		}));
	}
	Pu.prototype.close = Pu.prototype.close, Pu.prototype.drawConfidenceMask = Pu.prototype.Ka, Pu.prototype.drawCategoryMask = Pu.prototype.Ja, Pu.prototype.drawBoundingBox = Pu.prototype.Ia, Pu.prototype.drawConnectors = Pu.prototype.La, Pu.prototype.drawLandmarks = Pu.prototype.Ma, Pu.lerp = function(t, e, r, n, i) {
		return Fu(n * (1 - (t - e) / (r - e)) + i * (1 - (r - t) / (r - e)), n, i);
	}, Pu.clamp = Fu;
	var Xu = class {
		constructor(t, e, r, n, i, s, o) {
			this.g = t, this.o = e, this.m = r, this.canvas = n, this.j = i, this.width = s, this.height = o, (this.o || this.m) && 0 === --Wu && console.error("You seem to be creating MPImage instances without invoking .close(). This leaks resources.");
		}
		Ta() {
			return !!$u(this, 0);
		}
		va() {
			return !!$u(this, 1);
		}
		W() {
			return !!$u(this, 2);
		}
		Qa() {
			return Uu(this);
		}
		Pa() {
			var t = $u(this, 1);
			return t || (Bu(this), Vu(this), t = Ku(this), Hu(this), this.g.push(t), this.o = !0), t;
		}
		S() {
			return Bu(this);
		}
		clone() {
			var t = [];
			for (let e of this.g) {
				let r;
				if (e instanceof ImageData) r = new ImageData(e.data, this.width, this.height);
				else if (e instanceof WebGLTexture) {
					let t = Gu(this), e = ju(this);
					t.activeTexture(t.TEXTURE1), r = lu(e, t), t.bindTexture(t.TEXTURE_2D, r), t.texImage2D(t.TEXTURE_2D, 0, t.RGBA, this.width, this.height, 0, t.RGBA, t.UNSIGNED_BYTE, null), t.bindTexture(t.TEXTURE_2D, null), du(e, t, r), cu(e, t, !1, () => {
						Vu(this), t.clearColor(0, 0, 0, 0), t.clear(t.COLOR_BUFFER_BIT), t.drawArrays(t.TRIANGLE_FAN, 0, 4), Hu(this);
					}), fu(e), Hu(this);
				} else {
					if (!(e instanceof ImageBitmap)) throw Error(`Type is not supported: ${e}`);
					Bu(this), Vu(this), r = Ku(this), Hu(this);
				}
				t.push(r);
			}
			return new Xu(t, this.va(), this.W(), this.canvas, this.j, this.width, this.height);
		}
		close() {
			this.o && $u(this, 1).close(), this.m && Gu(this).deleteTexture($u(this, 2)), Wu = -1;
		}
	};
	Xu.prototype.close = Xu.prototype.close, Xu.prototype.clone = Xu.prototype.clone, Xu.prototype.getAsWebGLTexture = Xu.prototype.S, Xu.prototype.getAsImageBitmap = Xu.prototype.Pa, Xu.prototype.getAsImageData = Xu.prototype.Qa, Xu.prototype.hasWebGLTexture = Xu.prototype.W, Xu.prototype.hasImageBitmap = Xu.prototype.va, Xu.prototype.hasImageData = Xu.prototype.Ta;
	var Wu = 250;
	function zu(...t) {
		return t.map(([t, e]) => ({
			start: t,
			end: e
		}));
	}
	var Yu;
	var qu = Wh((Yu = Xh(Kh), class extends Yu {
		get oa() {
			return this.i;
		}
		Da(t, e, r) {
			Bh(this, e, (e) => {
				var [n, i] = Gh(this, t, e);
				this.oa._addBoundTextureAsImageToStream(e, n, i, r);
			});
		}
		ga(t, e) {
			Vh(this, t, e), Bh(this, t, (t) => {
				this.oa._attachImageListener(t);
			});
		}
		ha(t, e) {
			Hh(this, t, e), Bh(this, t, (t) => {
				this.oa._attachImageVectorListener(t);
			});
		}
	}));
	var Ju = class extends qu {};
	async function Zu(t, e, r) {
		return Jh(t, r.canvas ?? (Ph() ? void 0 : document.createElement("canvas")), e, r);
	}
	function Qu(t, e, r, n) {
		if (t.m && void 0 !== n) if (Sr(t.baseOptions, Ko, 3)?.g()) {
			var i = t.m;
			++i.g.T, i.h.set(n, performance.now());
		} else ++(i = t.m).g.P, i.h.set(n, performance.now());
		if (t.qa) {
			if (i = new No(), r?.regionOfInterest) {
				if (!t.Ca) throw Error("This task doesn't support region-of-interest.");
				var s = r.regionOfInterest;
				if (s.left >= s.right || s.top >= s.bottom) throw Error("Expected RectF with left < right and top < bottom.");
				if (s.left < 0 || s.top < 0 || s.right > 1 || s.bottom > 1) throw Error("Expected RectF values to be in [0,1].");
				jr(i, 1, (s.left + s.right) / 2), jr(i, 2, (s.top + s.bottom) / 2), jr(i, 4, s.right - s.left), jr(i, 3, s.bottom - s.top);
			} else jr(i, 1, .5), jr(i, 2, .5), jr(i, 4, 1), jr(i, 3, 1);
			if (r?.rotationDegrees) {
				if (r?.rotationDegrees % 90 != 0) throw Error("Expected rotation to be a multiple of 90°.");
				if (jr(i, 5, -Math.PI * r.rotationDegrees / 180), r?.rotationDegrees % 180 != 0) {
					let [t, n] = Uh(e);
					r = Dr(i, 3) * n / t, s = Dr(i, 4) * t / n, jr(i, 4, r), jr(i, 3, s);
				}
			}
			t.g.addProtoToStream(i.g(), "mediapipe.NormalizedRect", t.qa, n);
		}
		t.g.Da(e, t.Ba, n ?? performance.now()), t.finishProcessing(n);
	}
	function tc(t, e, r) {
		if (t.J) throw Error("Task is not initialized with image mode. 'runningMode' must be set to 'IMAGE'.");
		Qu(t, e, r, t.I + 1);
	}
	function ec(t, e, r, n) {
		if (!t.J) throw Error("Task is not initialized with video mode. 'runningMode' must be set to 'VIDEO'.");
		Qu(t, e, r, n);
	}
	function rc(t, e, r, n) {
		var i = e.data, s = e.width, o = s * (e = e.height);
		if ((i instanceof Uint8Array || i instanceof Float32Array) && i.length !== o) throw Error("Unsupported channel count: " + i.length / o);
		return t = new Su([i], r, !1, t.g.i.canvas, t.da, s, e), n ? t.clone() : t;
	}
	var nc = class extends iu {
		constructor(t, e, r, n) {
			super(t), this.g = t, this.Ba = e, this.qa = r, this.Ca = n, this.da = new pu(), this.J = !1;
		}
		j(t, e = !0) {
			if ("runningMode" in t) {
				var r = this.J = !!t.runningMode && "IMAGE" !== t.runningMode;
				ar(this.baseOptions, 2, null == r ? r : Zt(r));
			}
			if (void 0 !== t.canvas && this.g.i.canvas !== t.canvas) throw Error("You must create a new task to reset the canvas.");
			return super.j(t, e);
		}
		close() {
			this.da.close(), super.close();
		}
	};
	nc.prototype.close = nc.prototype.close;
	var ic = class extends nc {
		constructor(t, e) {
			super(new Ju(t, e), "image_in", "norm_rect_in", !1), this.l = { detections: [] }, Ir(t = this.h = new Zo(), 0, 1, e = new zo()), jr(this.h, 2, .5), jr(this.h, 3, .3);
		}
		C() {
			return "FaceDetector";
		}
		get baseOptions() {
			return Sr(this.h, zo, 1);
		}
		set baseOptions(t) {
			Ir(this.h, 0, 1, t);
		}
		v(t) {
			return "minDetectionConfidence" in t && jr(this.h, 2, t.minDetectionConfidence ?? .5), "minSuppressionThreshold" in t && jr(this.h, 3, t.minSuppressionThreshold ?? .3), this.j(t);
		}
		G(t, e) {
			return this.l = { detections: [] }, tc(this, t, e), this.l;
		}
		H(t, e, r) {
			return this.l = { detections: [] }, ec(this, t, r, e), this.l;
		}
		o() {
			var t = new mo();
			po(t, "image_in"), po(t, "norm_rect_in"), go(t, "detections");
			var e = new no();
			li(e, ta, this.h);
			var r = new ho();
			Hr(r, 2, "mediapipe.tasks.vision.face_detector.FaceDetectorGraph"), oo(r, "IMAGE:image_in"), oo(r, "NORM_RECT:norm_rect_in"), ao(r, "DETECTIONS:detections"), r.v(e), fo(t, r), this.g.attachProtoVectorListener("detections", (t, e) => {
				for (let e of t) t = So(e), this.l.detections.push(Za(t));
				tu(this, e);
			}), this.g.attachEmptyPacketListener("detections", (t) => {
				tu(this, t);
			}), t = t.g(), this.setGraph(new Uint8Array(t), !0);
		}
	};
	ic.prototype.detectForVideo = ic.prototype.H, ic.prototype.detect = ic.prototype.G, ic.prototype.setOptions = ic.prototype.v, ic.createFromModelPath = async function(t, e) {
		return Zu(ic, t, { baseOptions: { modelAssetPath: e } });
	}, ic.createFromModelBuffer = function(t, e) {
		return Zu(ic, t, { baseOptions: { modelAssetBuffer: e } });
	}, ic.createFromOptions = function(t, e) {
		return Zu(ic, t, e);
	};
	var sc = zu([61, 146], [146, 91], [91, 181], [181, 84], [84, 17], [17, 314], [314, 405], [405, 321], [321, 375], [375, 291], [61, 185], [185, 40], [40, 39], [39, 37], [37, 0], [0, 267], [267, 269], [269, 270], [270, 409], [409, 291], [78, 95], [95, 88], [88, 178], [178, 87], [87, 14], [14, 317], [317, 402], [402, 318], [318, 324], [324, 308], [78, 191], [191, 80], [80, 81], [81, 82], [82, 13], [13, 312], [312, 311], [311, 310], [310, 415], [415, 308]);
	var oc = zu([263, 249], [249, 390], [390, 373], [373, 374], [374, 380], [380, 381], [381, 382], [382, 362], [263, 466], [466, 388], [388, 387], [387, 386], [386, 385], [385, 384], [384, 398], [398, 362]);
	var ac = zu([276, 283], [283, 282], [282, 295], [295, 285], [300, 293], [293, 334], [334, 296], [296, 336]);
	var hc = zu([474, 475], [475, 476], [476, 477], [477, 474]);
	var uc = zu([33, 7], [7, 163], [163, 144], [144, 145], [145, 153], [153, 154], [154, 155], [155, 133], [33, 246], [246, 161], [161, 160], [160, 159], [159, 158], [158, 157], [157, 173], [173, 133]);
	var cc = zu([46, 53], [53, 52], [52, 65], [65, 55], [70, 63], [63, 105], [105, 66], [66, 107]);
	var lc = zu([469, 470], [470, 471], [471, 472], [472, 469]);
	var dc = zu([10, 338], [338, 297], [297, 332], [332, 284], [284, 251], [251, 389], [389, 356], [356, 454], [454, 323], [323, 361], [361, 288], [288, 397], [397, 365], [365, 379], [379, 378], [378, 400], [400, 377], [377, 152], [152, 148], [148, 176], [176, 149], [149, 150], [150, 136], [136, 172], [172, 58], [58, 132], [132, 93], [93, 234], [234, 127], [127, 162], [162, 21], [21, 54], [54, 103], [103, 67], [67, 109], [109, 10]);
	var fc = [
		...sc,
		...oc,
		...ac,
		...uc,
		...cc,
		...dc
	];
	var pc = zu([127, 34], [34, 139], [139, 127], [11, 0], [0, 37], [37, 11], [232, 231], [231, 120], [120, 232], [72, 37], [37, 39], [39, 72], [128, 121], [121, 47], [47, 128], [232, 121], [121, 128], [128, 232], [104, 69], [69, 67], [67, 104], [175, 171], [171, 148], [148, 175], [118, 50], [50, 101], [101, 118], [73, 39], [39, 40], [40, 73], [9, 151], [151, 108], [108, 9], [48, 115], [115, 131], [131, 48], [194, 204], [204, 211], [211, 194], [74, 40], [40, 185], [185, 74], [80, 42], [42, 183], [183, 80], [40, 92], [92, 186], [186, 40], [230, 229], [229, 118], [118, 230], [202, 212], [212, 214], [214, 202], [83, 18], [18, 17], [17, 83], [76, 61], [61, 146], [146, 76], [160, 29], [29, 30], [30, 160], [56, 157], [157, 173], [173, 56], [106, 204], [204, 194], [194, 106], [135, 214], [214, 192], [192, 135], [203, 165], [165, 98], [98, 203], [21, 71], [71, 68], [68, 21], [51, 45], [45, 4], [4, 51], [144, 24], [24, 23], [23, 144], [77, 146], [146, 91], [91, 77], [205, 50], [50, 187], [187, 205], [201, 200], [200, 18], [18, 201], [91, 106], [106, 182], [182, 91], [90, 91], [91, 181], [181, 90], [85, 84], [84, 17], [17, 85], [206, 203], [203, 36], [36, 206], [148, 171], [171, 140], [140, 148], [92, 40], [40, 39], [39, 92], [193, 189], [189, 244], [244, 193], [159, 158], [158, 28], [28, 159], [247, 246], [246, 161], [161, 247], [236, 3], [3, 196], [196, 236], [54, 68], [68, 104], [104, 54], [193, 168], [168, 8], [8, 193], [117, 228], [228, 31], [31, 117], [189, 193], [193, 55], [55, 189], [98, 97], [97, 99], [99, 98], [126, 47], [47, 100], [100, 126], [166, 79], [79, 218], [218, 166], [155, 154], [154, 26], [26, 155], [209, 49], [49, 131], [131, 209], [135, 136], [136, 150], [150, 135], [47, 126], [126, 217], [217, 47], [223, 52], [52, 53], [53, 223], [45, 51], [51, 134], [134, 45], [211, 170], [170, 140], [140, 211], [67, 69], [69, 108], [108, 67], [43, 106], [106, 91], [91, 43], [230, 119], [119, 120], [120, 230], [226, 130], [130, 247], [247, 226], [63, 53], [53, 52], [52, 63], [238, 20], [20, 242], [242, 238], [46, 70], [70, 156], [156, 46], [78, 62], [62, 96], [96, 78], [46, 53], [53, 63], [63, 46], [143, 34], [34, 227], [227, 143], [123, 117], [117, 111], [111, 123], [44, 125], [125, 19], [19, 44], [236, 134], [134, 51], [51, 236], [216, 206], [206, 205], [205, 216], [154, 153], [153, 22], [22, 154], [39, 37], [37, 167], [167, 39], [200, 201], [201, 208], [208, 200], [36, 142], [142, 100], [100, 36], [57, 212], [212, 202], [202, 57], [20, 60], [60, 99], [99, 20], [28, 158], [158, 157], [157, 28], [35, 226], [226, 113], [113, 35], [160, 159], [159, 27], [27, 160], [204, 202], [202, 210], [210, 204], [113, 225], [225, 46], [46, 113], [43, 202], [202, 204], [204, 43], [62, 76], [76, 77], [77, 62], [137, 123], [123, 116], [116, 137], [41, 38], [38, 72], [72, 41], [203, 129], [129, 142], [142, 203], [64, 98], [98, 240], [240, 64], [49, 102], [102, 64], [64, 49], [41, 73], [73, 74], [74, 41], [212, 216], [216, 207], [207, 212], [42, 74], [74, 184], [184, 42], [169, 170], [170, 211], [211, 169], [170, 149], [149, 176], [176, 170], [105, 66], [66, 69], [69, 105], [122, 6], [6, 168], [168, 122], [123, 147], [147, 187], [187, 123], [96, 77], [77, 90], [90, 96], [65, 55], [55, 107], [107, 65], [89, 90], [90, 180], [180, 89], [101, 100], [100, 120], [120, 101], [63, 105], [105, 104], [104, 63], [93, 137], [137, 227], [227, 93], [15, 86], [86, 85], [85, 15], [129, 102], [102, 49], [49, 129], [14, 87], [87, 86], [86, 14], [55, 8], [8, 9], [9, 55], [100, 47], [47, 121], [121, 100], [145, 23], [23, 22], [22, 145], [88, 89], [89, 179], [179, 88], [6, 122], [122, 196], [196, 6], [88, 95], [95, 96], [96, 88], [138, 172], [172, 136], [136, 138], [215, 58], [58, 172], [172, 215], [115, 48], [48, 219], [219, 115], [42, 80], [80, 81], [81, 42], [195, 3], [3, 51], [51, 195], [43, 146], [146, 61], [61, 43], [171, 175], [175, 199], [199, 171], [81, 82], [82, 38], [38, 81], [53, 46], [46, 225], [225, 53], [144, 163], [163, 110], [110, 144], [52, 65], [65, 66], [66, 52], [229, 228], [228, 117], [117, 229], [34, 127], [127, 234], [234, 34], [107, 108], [108, 69], [69, 107], [109, 108], [108, 151], [151, 109], [48, 64], [64, 235], [235, 48], [62, 78], [78, 191], [191, 62], [129, 209], [209, 126], [126, 129], [111, 35], [35, 143], [143, 111], [117, 123], [123, 50], [50, 117], [222, 65], [65, 52], [52, 222], [19, 125], [125, 141], [141, 19], [221, 55], [55, 65], [65, 221], [3, 195], [195, 197], [197, 3], [25, 7], [7, 33], [33, 25], [220, 237], [237, 44], [44, 220], [70, 71], [71, 139], [139, 70], [122, 193], [193, 245], [245, 122], [247, 130], [130, 33], [33, 247], [71, 21], [21, 162], [162, 71], [170, 169], [169, 150], [150, 170], [188, 174], [174, 196], [196, 188], [216, 186], [186, 92], [92, 216], [2, 97], [97, 167], [167, 2], [141, 125], [125, 241], [241, 141], [164, 167], [167, 37], [37, 164], [72, 38], [38, 12], [12, 72], [38, 82], [82, 13], [13, 38], [63, 68], [68, 71], [71, 63], [226, 35], [35, 111], [111, 226], [101, 50], [50, 205], [205, 101], [206, 92], [92, 165], [165, 206], [209, 198], [198, 217], [217, 209], [165, 167], [167, 97], [97, 165], [220, 115], [115, 218], [218, 220], [133, 112], [112, 243], [243, 133], [239, 238], [238, 241], [241, 239], [214, 135], [135, 169], [169, 214], [190, 173], [173, 133], [133, 190], [171, 208], [208, 32], [32, 171], [125, 44], [44, 237], [237, 125], [86, 87], [87, 178], [178, 86], [85, 86], [86, 179], [179, 85], [84, 85], [85, 180], [180, 84], [83, 84], [84, 181], [181, 83], [201, 83], [83, 182], [182, 201], [137, 93], [93, 132], [132, 137], [76, 62], [62, 183], [183, 76], [61, 76], [76, 184], [184, 61], [57, 61], [61, 185], [185, 57], [212, 57], [57, 186], [186, 212], [214, 207], [207, 187], [187, 214], [34, 143], [143, 156], [156, 34], [79, 239], [239, 237], [237, 79], [123, 137], [137, 177], [177, 123], [44, 1], [1, 4], [4, 44], [201, 194], [194, 32], [32, 201], [64, 102], [102, 129], [129, 64], [213, 215], [215, 138], [138, 213], [59, 166], [166, 219], [219, 59], [242, 99], [99, 97], [97, 242], [2, 94], [94, 141], [141, 2], [75, 59], [59, 235], [235, 75], [24, 110], [110, 228], [228, 24], [25, 130], [130, 226], [226, 25], [23, 24], [24, 229], [229, 23], [22, 23], [23, 230], [230, 22], [26, 22], [22, 231], [231, 26], [112, 26], [26, 232], [232, 112], [189, 190], [190, 243], [243, 189], [221, 56], [56, 190], [190, 221], [28, 56], [56, 221], [221, 28], [27, 28], [28, 222], [222, 27], [29, 27], [27, 223], [223, 29], [30, 29], [29, 224], [224, 30], [247, 30], [30, 225], [225, 247], [238, 79], [79, 20], [20, 238], [166, 59], [59, 75], [75, 166], [60, 75], [75, 240], [240, 60], [147, 177], [177, 215], [215, 147], [20, 79], [79, 166], [166, 20], [187, 147], [147, 213], [213, 187], [112, 233], [233, 244], [244, 112], [233, 128], [128, 245], [245, 233], [128, 114], [114, 188], [188, 128], [114, 217], [217, 174], [174, 114], [131, 115], [115, 220], [220, 131], [217, 198], [198, 236], [236, 217], [198, 131], [131, 134], [134, 198], [177, 132], [132, 58], [58, 177], [143, 35], [35, 124], [124, 143], [110, 163], [163, 7], [7, 110], [228, 110], [110, 25], [25, 228], [356, 389], [389, 368], [368, 356], [11, 302], [302, 267], [267, 11], [452, 350], [350, 349], [349, 452], [302, 303], [303, 269], [269, 302], [357, 343], [343, 277], [277, 357], [452, 453], [453, 357], [357, 452], [333, 332], [332, 297], [297, 333], [175, 152], [152, 377], [377, 175], [347, 348], [348, 330], [330, 347], [303, 304], [304, 270], [270, 303], [9, 336], [336, 337], [337, 9], [278, 279], [279, 360], [360, 278], [418, 262], [262, 431], [431, 418], [304, 408], [408, 409], [409, 304], [310, 415], [415, 407], [407, 310], [270, 409], [409, 410], [410, 270], [450, 348], [348, 347], [347, 450], [422, 430], [430, 434], [434, 422], [313, 314], [314, 17], [17, 313], [306, 307], [307, 375], [375, 306], [387, 388], [388, 260], [260, 387], [286, 414], [414, 398], [398, 286], [335, 406], [406, 418], [418, 335], [364, 367], [367, 416], [416, 364], [423, 358], [358, 327], [327, 423], [251, 284], [284, 298], [298, 251], [281, 5], [5, 4], [4, 281], [373, 374], [374, 253], [253, 373], [307, 320], [320, 321], [321, 307], [425, 427], [427, 411], [411, 425], [421, 313], [313, 18], [18, 421], [321, 405], [405, 406], [406, 321], [320, 404], [404, 405], [405, 320], [315, 16], [16, 17], [17, 315], [426, 425], [425, 266], [266, 426], [377, 400], [400, 369], [369, 377], [322, 391], [391, 269], [269, 322], [417, 465], [465, 464], [464, 417], [386, 257], [257, 258], [258, 386], [466, 260], [260, 388], [388, 466], [456, 399], [399, 419], [419, 456], [284, 332], [332, 333], [333, 284], [417, 285], [285, 8], [8, 417], [346, 340], [340, 261], [261, 346], [413, 441], [441, 285], [285, 413], [327, 460], [460, 328], [328, 327], [355, 371], [371, 329], [329, 355], [392, 439], [439, 438], [438, 392], [382, 341], [341, 256], [256, 382], [429, 420], [420, 360], [360, 429], [364, 394], [394, 379], [379, 364], [277, 343], [343, 437], [437, 277], [443, 444], [444, 283], [283, 443], [275, 440], [440, 363], [363, 275], [431, 262], [262, 369], [369, 431], [297, 338], [338, 337], [337, 297], [273, 375], [375, 321], [321, 273], [450, 451], [451, 349], [349, 450], [446, 342], [342, 467], [467, 446], [293, 334], [334, 282], [282, 293], [458, 461], [461, 462], [462, 458], [276, 353], [353, 383], [383, 276], [308, 324], [324, 325], [325, 308], [276, 300], [300, 293], [293, 276], [372, 345], [345, 447], [447, 372], [352, 345], [345, 340], [340, 352], [274, 1], [1, 19], [19, 274], [456, 248], [248, 281], [281, 456], [436, 427], [427, 425], [425, 436], [381, 256], [256, 252], [252, 381], [269, 391], [391, 393], [393, 269], [200, 199], [199, 428], [428, 200], [266, 330], [330, 329], [329, 266], [287, 273], [273, 422], [422, 287], [250, 462], [462, 328], [328, 250], [258, 286], [286, 384], [384, 258], [265, 353], [353, 342], [342, 265], [387, 259], [259, 257], [257, 387], [424, 431], [431, 430], [430, 424], [342, 353], [353, 276], [276, 342], [273, 335], [335, 424], [424, 273], [292, 325], [325, 307], [307, 292], [366, 447], [447, 345], [345, 366], [271, 303], [303, 302], [302, 271], [423, 266], [266, 371], [371, 423], [294, 455], [455, 460], [460, 294], [279, 278], [278, 294], [294, 279], [271, 272], [272, 304], [304, 271], [432, 434], [434, 427], [427, 432], [272, 407], [407, 408], [408, 272], [394, 430], [430, 431], [431, 394], [395, 369], [369, 400], [400, 395], [334, 333], [333, 299], [299, 334], [351, 417], [417, 168], [168, 351], [352, 280], [280, 411], [411, 352], [325, 319], [319, 320], [320, 325], [295, 296], [296, 336], [336, 295], [319, 403], [403, 404], [404, 319], [330, 348], [348, 349], [349, 330], [293, 298], [298, 333], [333, 293], [323, 454], [454, 447], [447, 323], [15, 16], [16, 315], [315, 15], [358, 429], [429, 279], [279, 358], [14, 15], [15, 316], [316, 14], [285, 336], [336, 9], [9, 285], [329, 349], [349, 350], [350, 329], [374, 380], [380, 252], [252, 374], [318, 402], [402, 403], [403, 318], [6, 197], [197, 419], [419, 6], [318, 319], [319, 325], [325, 318], [367, 364], [364, 365], [365, 367], [435, 367], [367, 397], [397, 435], [344, 438], [438, 439], [439, 344], [272, 271], [271, 311], [311, 272], [195, 5], [5, 281], [281, 195], [273, 287], [287, 291], [291, 273], [396, 428], [428, 199], [199, 396], [311, 271], [271, 268], [268, 311], [283, 444], [444, 445], [445, 283], [373, 254], [254, 339], [339, 373], [282, 334], [334, 296], [296, 282], [449, 347], [347, 346], [346, 449], [264, 447], [447, 454], [454, 264], [336, 296], [296, 299], [299, 336], [338, 10], [10, 151], [151, 338], [278, 439], [439, 455], [455, 278], [292, 407], [407, 415], [415, 292], [358, 371], [371, 355], [355, 358], [340, 345], [345, 372], [372, 340], [346, 347], [347, 280], [280, 346], [442, 443], [443, 282], [282, 442], [19, 94], [94, 370], [370, 19], [441, 442], [442, 295], [295, 441], [248, 419], [419, 197], [197, 248], [263, 255], [255, 359], [359, 263], [440, 275], [275, 274], [274, 440], [300, 383], [383, 368], [368, 300], [351, 412], [412, 465], [465, 351], [263, 467], [467, 466], [466, 263], [301, 368], [368, 389], [389, 301], [395, 378], [378, 379], [379, 395], [412, 351], [351, 419], [419, 412], [436, 426], [426, 322], [322, 436], [2, 164], [164, 393], [393, 2], [370, 462], [462, 461], [461, 370], [164, 0], [0, 267], [267, 164], [302, 11], [11, 12], [12, 302], [268, 12], [12, 13], [13, 268], [293, 300], [300, 301], [301, 293], [446, 261], [261, 340], [340, 446], [330, 266], [266, 425], [425, 330], [426, 423], [423, 391], [391, 426], [429, 355], [355, 437], [437, 429], [391, 327], [327, 326], [326, 391], [440, 457], [457, 438], [438, 440], [341, 382], [382, 362], [362, 341], [459, 457], [457, 461], [461, 459], [434, 430], [430, 394], [394, 434], [414, 463], [463, 362], [362, 414], [396, 369], [369, 262], [262, 396], [354, 461], [461, 457], [457, 354], [316, 403], [403, 402], [402, 316], [315, 404], [404, 403], [403, 315], [314, 405], [405, 404], [404, 314], [313, 406], [406, 405], [405, 313], [421, 418], [418, 406], [406, 421], [366, 401], [401, 361], [361, 366], [306, 408], [408, 407], [407, 306], [291, 409], [409, 408], [408, 291], [287, 410], [410, 409], [409, 287], [432, 436], [436, 410], [410, 432], [434, 416], [416, 411], [411, 434], [264, 368], [368, 383], [383, 264], [309, 438], [438, 457], [457, 309], [352, 376], [376, 401], [401, 352], [274, 275], [275, 4], [4, 274], [421, 428], [428, 262], [262, 421], [294, 327], [327, 358], [358, 294], [433, 416], [416, 367], [367, 433], [289, 455], [455, 439], [439, 289], [462, 370], [370, 326], [326, 462], [2, 326], [326, 370], [370, 2], [305, 460], [460, 455], [455, 305], [254, 449], [449, 448], [448, 254], [255, 261], [261, 446], [446, 255], [253, 450], [450, 449], [449, 253], [252, 451], [451, 450], [450, 252], [256, 452], [452, 451], [451, 256], [341, 453], [453, 452], [452, 341], [413, 464], [464, 463], [463, 413], [441, 413], [413, 414], [414, 441], [258, 442], [442, 441], [441, 258], [257, 443], [443, 442], [442, 257], [259, 444], [444, 443], [443, 259], [260, 445], [445, 444], [444, 260], [467, 342], [342, 445], [445, 467], [459, 458], [458, 250], [250, 459], [289, 392], [392, 290], [290, 289], [290, 328], [328, 460], [460, 290], [376, 433], [433, 435], [435, 376], [250, 290], [290, 392], [392, 250], [411, 416], [416, 433], [433, 411], [341, 463], [463, 464], [464, 341], [453, 464], [464, 465], [465, 453], [357, 465], [465, 412], [412, 357], [343, 412], [412, 399], [399, 343], [360, 363], [363, 440], [440, 360], [437, 399], [399, 456], [456, 437], [420, 456], [456, 363], [363, 420], [401, 435], [435, 288], [288, 401], [372, 383], [383, 353], [353, 372], [339, 255], [255, 249], [249, 339], [448, 261], [261, 255], [255, 448], [133, 243], [243, 190], [190, 133], [133, 155], [155, 112], [112, 133], [33, 246], [246, 247], [247, 33], [33, 130], [130, 25], [25, 33], [398, 384], [384, 286], [286, 398], [362, 398], [398, 414], [414, 362], [362, 463], [463, 341], [341, 362], [263, 359], [359, 467], [467, 263], [263, 249], [249, 255], [255, 263], [466, 467], [467, 260], [260, 466], [75, 60], [60, 166], [166, 75], [238, 239], [239, 79], [79, 238], [162, 127], [127, 139], [139, 162], [72, 11], [11, 37], [37, 72], [121, 232], [232, 120], [120, 121], [73, 72], [72, 39], [39, 73], [114, 128], [128, 47], [47, 114], [233, 232], [232, 128], [128, 233], [103, 104], [104, 67], [67, 103], [152, 175], [175, 148], [148, 152], [119, 118], [118, 101], [101, 119], [74, 73], [73, 40], [40, 74], [107, 9], [9, 108], [108, 107], [49, 48], [48, 131], [131, 49], [32, 194], [194, 211], [211, 32], [184, 74], [74, 185], [185, 184], [191, 80], [80, 183], [183, 191], [185, 40], [40, 186], [186, 185], [119, 230], [230, 118], [118, 119], [210, 202], [202, 214], [214, 210], [84, 83], [83, 17], [17, 84], [77, 76], [76, 146], [146, 77], [161, 160], [160, 30], [30, 161], [190, 56], [56, 173], [173, 190], [182, 106], [106, 194], [194, 182], [138, 135], [135, 192], [192, 138], [129, 203], [203, 98], [98, 129], [54, 21], [21, 68], [68, 54], [5, 51], [51, 4], [4, 5], [145, 144], [144, 23], [23, 145], [90, 77], [77, 91], [91, 90], [207, 205], [205, 187], [187, 207], [83, 201], [201, 18], [18, 83], [181, 91], [91, 182], [182, 181], [180, 90], [90, 181], [181, 180], [16, 85], [85, 17], [17, 16], [205, 206], [206, 36], [36, 205], [176, 148], [148, 140], [140, 176], [165, 92], [92, 39], [39, 165], [245, 193], [193, 244], [244, 245], [27, 159], [159, 28], [28, 27], [30, 247], [247, 161], [161, 30], [174, 236], [236, 196], [196, 174], [103, 54], [54, 104], [104, 103], [55, 193], [193, 8], [8, 55], [111, 117], [117, 31], [31, 111], [221, 189], [189, 55], [55, 221], [240, 98], [98, 99], [99, 240], [142, 126], [126, 100], [100, 142], [219, 166], [166, 218], [218, 219], [112, 155], [155, 26], [26, 112], [198, 209], [209, 131], [131, 198], [169, 135], [135, 150], [150, 169], [114, 47], [47, 217], [217, 114], [224, 223], [223, 53], [53, 224], [220, 45], [45, 134], [134, 220], [32, 211], [211, 140], [140, 32], [109, 67], [67, 108], [108, 109], [146, 43], [43, 91], [91, 146], [231, 230], [230, 120], [120, 231], [113, 226], [226, 247], [247, 113], [105, 63], [63, 52], [52, 105], [241, 238], [238, 242], [242, 241], [124, 46], [46, 156], [156, 124], [95, 78], [78, 96], [96, 95], [70, 46], [46, 63], [63, 70], [116, 143], [143, 227], [227, 116], [116, 123], [123, 111], [111, 116], [1, 44], [44, 19], [19, 1], [3, 236], [236, 51], [51, 3], [207, 216], [216, 205], [205, 207], [26, 154], [154, 22], [22, 26], [165, 39], [39, 167], [167, 165], [199, 200], [200, 208], [208, 199], [101, 36], [36, 100], [100, 101], [43, 57], [57, 202], [202, 43], [242, 20], [20, 99], [99, 242], [56, 28], [28, 157], [157, 56], [124, 35], [35, 113], [113, 124], [29, 160], [160, 27], [27, 29], [211, 204], [204, 210], [210, 211], [124, 113], [113, 46], [46, 124], [106, 43], [43, 204], [204, 106], [96, 62], [62, 77], [77, 96], [227, 137], [137, 116], [116, 227], [73, 41], [41, 72], [72, 73], [36, 203], [203, 142], [142, 36], [235, 64], [64, 240], [240, 235], [48, 49], [49, 64], [64, 48], [42, 41], [41, 74], [74, 42], [214, 212], [212, 207], [207, 214], [183, 42], [42, 184], [184, 183], [210, 169], [169, 211], [211, 210], [140, 170], [170, 176], [176, 140], [104, 105], [105, 69], [69, 104], [193, 122], [122, 168], [168, 193], [50, 123], [123, 187], [187, 50], [89, 96], [96, 90], [90, 89], [66, 65], [65, 107], [107, 66], [179, 89], [89, 180], [180, 179], [119, 101], [101, 120], [120, 119], [68, 63], [63, 104], [104, 68], [234, 93], [93, 227], [227, 234], [16, 15], [15, 85], [85, 16], [209, 129], [129, 49], [49, 209], [15, 14], [14, 86], [86, 15], [107, 55], [55, 9], [9, 107], [120, 100], [100, 121], [121, 120], [153, 145], [145, 22], [22, 153], [178, 88], [88, 179], [179, 178], [197, 6], [6, 196], [196, 197], [89, 88], [88, 96], [96, 89], [135, 138], [138, 136], [136, 135], [138, 215], [215, 172], [172, 138], [218, 115], [115, 219], [219, 218], [41, 42], [42, 81], [81, 41], [5, 195], [195, 51], [51, 5], [57, 43], [43, 61], [61, 57], [208, 171], [171, 199], [199, 208], [41, 81], [81, 38], [38, 41], [224, 53], [53, 225], [225, 224], [24, 144], [144, 110], [110, 24], [105, 52], [52, 66], [66, 105], [118, 229], [229, 117], [117, 118], [227, 34], [34, 234], [234, 227], [66, 107], [107, 69], [69, 66], [10, 109], [109, 151], [151, 10], [219, 48], [48, 235], [235, 219], [183, 62], [62, 191], [191, 183], [142, 129], [129, 126], [126, 142], [116, 111], [111, 143], [143, 116], [118, 117], [117, 50], [50, 118], [223, 222], [222, 52], [52, 223], [94, 19], [19, 141], [141, 94], [222, 221], [221, 65], [65, 222], [196, 3], [3, 197], [197, 196], [45, 220], [220, 44], [44, 45], [156, 70], [70, 139], [139, 156], [188, 122], [122, 245], [245, 188], [139, 71], [71, 162], [162, 139], [149, 170], [170, 150], [150, 149], [122, 188], [188, 196], [196, 122], [206, 216], [216, 92], [92, 206], [164, 2], [2, 167], [167, 164], [242, 141], [141, 241], [241, 242], [0, 164], [164, 37], [37, 0], [11, 72], [72, 12], [12, 11], [12, 38], [38, 13], [13, 12], [70, 63], [63, 71], [71, 70], [31, 226], [226, 111], [111, 31], [36, 101], [101, 205], [205, 36], [203, 206], [206, 165], [165, 203], [126, 209], [209, 217], [217, 126], [98, 165], [165, 97], [97, 98], [237, 220], [220, 218], [218, 237], [237, 239], [239, 241], [241, 237], [210, 214], [214, 169], [169, 210], [140, 171], [171, 32], [32, 140], [241, 125], [125, 237], [237, 241], [179, 86], [86, 178], [178, 179], [180, 85], [85, 179], [179, 180], [181, 84], [84, 180], [180, 181], [182, 83], [83, 181], [181, 182], [194, 201], [201, 182], [182, 194], [177, 137], [137, 132], [132, 177], [184, 76], [76, 183], [183, 184], [185, 61], [61, 184], [184, 185], [186, 57], [57, 185], [185, 186], [216, 212], [212, 186], [186, 216], [192, 214], [214, 187], [187, 192], [139, 34], [34, 156], [156, 139], [218, 79], [79, 237], [237, 218], [147, 123], [123, 177], [177, 147], [45, 44], [44, 4], [4, 45], [208, 201], [201, 32], [32, 208], [98, 64], [64, 129], [129, 98], [192, 213], [213, 138], [138, 192], [235, 59], [59, 219], [219, 235], [141, 242], [242, 97], [97, 141], [97, 2], [2, 141], [141, 97], [240, 75], [75, 235], [235, 240], [229, 24], [24, 228], [228, 229], [31, 25], [25, 226], [226, 31], [230, 23], [23, 229], [229, 230], [231, 22], [22, 230], [230, 231], [232, 26], [26, 231], [231, 232], [233, 112], [112, 232], [232, 233], [244, 189], [189, 243], [243, 244], [189, 221], [221, 190], [190, 189], [222, 28], [28, 221], [221, 222], [223, 27], [27, 222], [222, 223], [224, 29], [29, 223], [223, 224], [225, 30], [30, 224], [224, 225], [113, 247], [247, 225], [225, 113], [99, 60], [60, 240], [240, 99], [213, 147], [147, 215], [215, 213], [60, 20], [20, 166], [166, 60], [192, 187], [187, 213], [213, 192], [243, 112], [112, 244], [244, 243], [244, 233], [233, 245], [245, 244], [245, 128], [128, 188], [188, 245], [188, 114], [114, 174], [174, 188], [134, 131], [131, 220], [220, 134], [174, 217], [217, 236], [236, 174], [236, 198], [198, 134], [134, 236], [215, 177], [177, 58], [58, 215], [156, 143], [143, 124], [124, 156], [25, 110], [110, 7], [7, 25], [31, 228], [228, 25], [25, 31], [264, 356], [356, 368], [368, 264], [0, 11], [11, 267], [267, 0], [451, 452], [452, 349], [349, 451], [267, 302], [302, 269], [269, 267], [350, 357], [357, 277], [277, 350], [350, 452], [452, 357], [357, 350], [299, 333], [333, 297], [297, 299], [396, 175], [175, 377], [377, 396], [280, 347], [347, 330], [330, 280], [269, 303], [303, 270], [270, 269], [151, 9], [9, 337], [337, 151], [344, 278], [278, 360], [360, 344], [424, 418], [418, 431], [431, 424], [270, 304], [304, 409], [409, 270], [272, 310], [310, 407], [407, 272], [322, 270], [270, 410], [410, 322], [449, 450], [450, 347], [347, 449], [432, 422], [422, 434], [434, 432], [18, 313], [313, 17], [17, 18], [291, 306], [306, 375], [375, 291], [259, 387], [387, 260], [260, 259], [424, 335], [335, 418], [418, 424], [434, 364], [364, 416], [416, 434], [391, 423], [423, 327], [327, 391], [301, 251], [251, 298], [298, 301], [275, 281], [281, 4], [4, 275], [254, 373], [373, 253], [253, 254], [375, 307], [307, 321], [321, 375], [280, 425], [425, 411], [411, 280], [200, 421], [421, 18], [18, 200], [335, 321], [321, 406], [406, 335], [321, 320], [320, 405], [405, 321], [314, 315], [315, 17], [17, 314], [423, 426], [426, 266], [266, 423], [396, 377], [377, 369], [369, 396], [270, 322], [322, 269], [269, 270], [413, 417], [417, 464], [464, 413], [385, 386], [386, 258], [258, 385], [248, 456], [456, 419], [419, 248], [298, 284], [284, 333], [333, 298], [168, 417], [417, 8], [8, 168], [448, 346], [346, 261], [261, 448], [417, 413], [413, 285], [285, 417], [326, 327], [327, 328], [328, 326], [277, 355], [355, 329], [329, 277], [309, 392], [392, 438], [438, 309], [381, 382], [382, 256], [256, 381], [279, 429], [429, 360], [360, 279], [365, 364], [364, 379], [379, 365], [355, 277], [277, 437], [437, 355], [282, 443], [443, 283], [283, 282], [281, 275], [275, 363], [363, 281], [395, 431], [431, 369], [369, 395], [299, 297], [297, 337], [337, 299], [335, 273], [273, 321], [321, 335], [348, 450], [450, 349], [349, 348], [359, 446], [446, 467], [467, 359], [283, 293], [293, 282], [282, 283], [250, 458], [458, 462], [462, 250], [300, 276], [276, 383], [383, 300], [292, 308], [308, 325], [325, 292], [283, 276], [276, 293], [293, 283], [264, 372], [372, 447], [447, 264], [346, 352], [352, 340], [340, 346], [354, 274], [274, 19], [19, 354], [363, 456], [456, 281], [281, 363], [426, 436], [436, 425], [425, 426], [380, 381], [381, 252], [252, 380], [267, 269], [269, 393], [393, 267], [421, 200], [200, 428], [428, 421], [371, 266], [266, 329], [329, 371], [432, 287], [287, 422], [422, 432], [290, 250], [250, 328], [328, 290], [385, 258], [258, 384], [384, 385], [446, 265], [265, 342], [342, 446], [386, 387], [387, 257], [257, 386], [422, 424], [424, 430], [430, 422], [445, 342], [342, 276], [276, 445], [422, 273], [273, 424], [424, 422], [306, 292], [292, 307], [307, 306], [352, 366], [366, 345], [345, 352], [268, 271], [271, 302], [302, 268], [358, 423], [423, 371], [371, 358], [327, 294], [294, 460], [460, 327], [331, 279], [279, 294], [294, 331], [303, 271], [271, 304], [304, 303], [436, 432], [432, 427], [427, 436], [304, 272], [272, 408], [408, 304], [395, 394], [394, 431], [431, 395], [378, 395], [395, 400], [400, 378], [296, 334], [334, 299], [299, 296], [6, 351], [351, 168], [168, 6], [376, 352], [352, 411], [411, 376], [307, 325], [325, 320], [320, 307], [285, 295], [295, 336], [336, 285], [320, 319], [319, 404], [404, 320], [329, 330], [330, 349], [349, 329], [334, 293], [293, 333], [333, 334], [366, 323], [323, 447], [447, 366], [316, 15], [15, 315], [315, 316], [331, 358], [358, 279], [279, 331], [317, 14], [14, 316], [316, 317], [8, 285], [285, 9], [9, 8], [277, 329], [329, 350], [350, 277], [253, 374], [374, 252], [252, 253], [319, 318], [318, 403], [403, 319], [351, 6], [6, 419], [419, 351], [324, 318], [318, 325], [325, 324], [397, 367], [367, 365], [365, 397], [288, 435], [435, 397], [397, 288], [278, 344], [344, 439], [439, 278], [310, 272], [272, 311], [311, 310], [248, 195], [195, 281], [281, 248], [375, 273], [273, 291], [291, 375], [175, 396], [396, 199], [199, 175], [312, 311], [311, 268], [268, 312], [276, 283], [283, 445], [445, 276], [390, 373], [373, 339], [339, 390], [295, 282], [282, 296], [296, 295], [448, 449], [449, 346], [346, 448], [356, 264], [264, 454], [454, 356], [337, 336], [336, 299], [299, 337], [337, 338], [338, 151], [151, 337], [294, 278], [278, 455], [455, 294], [308, 292], [292, 415], [415, 308], [429, 358], [358, 355], [355, 429], [265, 340], [340, 372], [372, 265], [352, 346], [346, 280], [280, 352], [295, 442], [442, 282], [282, 295], [354, 19], [19, 370], [370, 354], [285, 441], [441, 295], [295, 285], [195, 248], [248, 197], [197, 195], [457, 440], [440, 274], [274, 457], [301, 300], [300, 368], [368, 301], [417, 351], [351, 465], [465, 417], [251, 301], [301, 389], [389, 251], [394, 395], [395, 379], [379, 394], [399, 412], [412, 419], [419, 399], [410, 436], [436, 322], [322, 410], [326, 2], [2, 393], [393, 326], [354, 370], [370, 461], [461, 354], [393, 164], [164, 267], [267, 393], [268, 302], [302, 12], [12, 268], [312, 268], [268, 13], [13, 312], [298, 293], [293, 301], [301, 298], [265, 446], [446, 340], [340, 265], [280, 330], [330, 425], [425, 280], [322, 426], [426, 391], [391, 322], [420, 429], [429, 437], [437, 420], [393, 391], [391, 326], [326, 393], [344, 440], [440, 438], [438, 344], [458, 459], [459, 461], [461, 458], [364, 434], [434, 394], [394, 364], [428, 396], [396, 262], [262, 428], [274, 354], [354, 457], [457, 274], [317, 316], [316, 402], [402, 317], [316, 315], [315, 403], [403, 316], [315, 314], [314, 404], [404, 315], [314, 313], [313, 405], [405, 314], [313, 421], [421, 406], [406, 313], [323, 366], [366, 361], [361, 323], [292, 306], [306, 407], [407, 292], [306, 291], [291, 408], [408, 306], [291, 287], [287, 409], [409, 291], [287, 432], [432, 410], [410, 287], [427, 434], [434, 411], [411, 427], [372, 264], [264, 383], [383, 372], [459, 309], [309, 457], [457, 459], [366, 352], [352, 401], [401, 366], [1, 274], [274, 4], [4, 1], [418, 421], [421, 262], [262, 418], [331, 294], [294, 358], [358, 331], [435, 433], [433, 367], [367, 435], [392, 289], [289, 439], [439, 392], [328, 462], [462, 326], [326, 328], [94, 2], [2, 370], [370, 94], [289, 305], [305, 455], [455, 289], [339, 254], [254, 448], [448, 339], [359, 255], [255, 446], [446, 359], [254, 253], [253, 449], [449, 254], [253, 252], [252, 450], [450, 253], [252, 256], [256, 451], [451, 252], [256, 341], [341, 452], [452, 256], [414, 413], [413, 463], [463, 414], [286, 441], [441, 414], [414, 286], [286, 258], [258, 441], [441, 286], [258, 257], [257, 442], [442, 258], [257, 259], [259, 443], [443, 257], [259, 260], [260, 444], [444, 259], [260, 467], [467, 445], [445, 260], [309, 459], [459, 250], [250, 309], [305, 289], [289, 290], [290, 305], [305, 290], [290, 460], [460, 305], [401, 376], [376, 435], [435, 401], [309, 250], [250, 392], [392, 309], [376, 411], [411, 433], [433, 376], [453, 341], [341, 464], [464, 453], [357, 453], [453, 465], [465, 357], [343, 357], [357, 412], [412, 343], [437, 343], [343, 399], [399, 437], [344, 360], [360, 440], [440, 344], [420, 437], [437, 456], [456, 420], [360, 420], [420, 363], [363, 360], [361, 401], [401, 288], [288, 361], [265, 372], [372, 353], [353, 265], [390, 339], [339, 249], [249, 390], [339, 448], [448, 255], [255, 339]);
	function gc(t) {
		t.l = {
			faceLandmarks: [],
			faceBlendshapes: [],
			facialTransformationMatrixes: []
		};
	}
	var mc = class extends nc {
		constructor(t, e) {
			super(new Ju(t, e), "image_in", "norm_rect", !1), this.l = {
				faceLandmarks: [],
				faceBlendshapes: [],
				facialTransformationMatrixes: []
			}, this.outputFacialTransformationMatrixes = this.outputFaceBlendshapes = !1, Ir(t = this.h = new na(), 0, 1, e = new zo()), this.B = new ra(), Ir(this.h, 0, 3, this.B), this.u = new Zo(), Ir(this.h, 0, 2, this.u), Ur(this.u, 4, 1), jr(this.u, 2, .5), jr(this.B, 2, .5), jr(this.h, 4, .5);
		}
		C() {
			return "FaceLandmarker";
		}
		get baseOptions() {
			return Sr(this.h, zo, 1);
		}
		set baseOptions(t) {
			Ir(this.h, 0, 1, t);
		}
		v(t) {
			return "numFaces" in t && Ur(this.u, 4, t.numFaces ?? 1), "minFaceDetectionConfidence" in t && jr(this.u, 2, t.minFaceDetectionConfidence ?? .5), "minTrackingConfidence" in t && jr(this.h, 4, t.minTrackingConfidence ?? .5), "minFacePresenceConfidence" in t && jr(this.B, 2, t.minFacePresenceConfidence ?? .5), "outputFaceBlendshapes" in t && (this.outputFaceBlendshapes = !!t.outputFaceBlendshapes), "outputFacialTransformationMatrixes" in t && (this.outputFacialTransformationMatrixes = !!t.outputFacialTransformationMatrixes), this.j(t);
		}
		G(t, e) {
			return gc(this), tc(this, t, e), this.l;
		}
		H(t, e, r) {
			return gc(this), ec(this, t, r, e), this.l;
		}
		o() {
			var t = new mo();
			po(t, "image_in"), po(t, "norm_rect"), go(t, "face_landmarks");
			var e = new no();
			li(e, sa, this.h);
			var r = new ho();
			Hr(r, 2, "mediapipe.tasks.vision.face_landmarker.FaceLandmarkerGraph"), oo(r, "IMAGE:image_in"), oo(r, "NORM_RECT:norm_rect"), ao(r, "NORM_LANDMARKS:face_landmarks"), r.v(e), fo(t, r), this.g.attachProtoVectorListener("face_landmarks", (t, e) => {
				for (let e of t) t = Io(e), this.l.faceLandmarks.push(Qa(t));
				tu(this, e);
			}), this.g.attachEmptyPacketListener("face_landmarks", (t) => {
				tu(this, t);
			}), this.outputFaceBlendshapes && (go(t, "blendshapes"), ao(r, "BLENDSHAPES:blendshapes"), this.g.attachProtoVectorListener("blendshapes", (t, e) => {
				if (this.outputFaceBlendshapes) for (let e of t) t = wo(e), this.l.faceBlendshapes.push(qa(t.g() ?? []));
				tu(this, e);
			}), this.g.attachEmptyPacketListener("blendshapes", (t) => {
				tu(this, t);
			})), this.outputFacialTransformationMatrixes && (go(t, "face_geometry"), ao(r, "FACE_GEOMETRY:face_geometry"), this.g.attachProtoVectorListener("face_geometry", (t, e) => {
				if (this.outputFacialTransformationMatrixes) for (let e of t) (t = Sr(t = ea(e), Fo, 2)) && this.l.facialTransformationMatrixes.push({
					rows: Or(t, 1) ?? 0 ?? 0,
					columns: Or(t, 2) ?? 0 ?? 0,
					data: lr(t, 3, Jt, cr()).slice() ?? []
				});
				tu(this, e);
			}), this.g.attachEmptyPacketListener("face_geometry", (t) => {
				tu(this, t);
			})), t = t.g(), this.setGraph(new Uint8Array(t), !0);
		}
	};
	mc.prototype.detectForVideo = mc.prototype.H, mc.prototype.detect = mc.prototype.G, mc.prototype.setOptions = mc.prototype.v, mc.createFromModelPath = function(t, e) {
		return Zu(mc, t, { baseOptions: { modelAssetPath: e } });
	}, mc.createFromModelBuffer = function(t, e) {
		return Zu(mc, t, { baseOptions: { modelAssetBuffer: e } });
	}, mc.createFromOptions = function(t, e) {
		return Zu(mc, t, e);
	}, mc.FACE_LANDMARKS_LIPS = sc, r("module$exports$google3$third_party$mediapipe$tasks$web$vision$face_landmarker$face_landmarker.FaceLandmarker.FACE_LANDMARKS_LIPS", mc.FACE_LANDMARKS_LIPS), mc.FACE_LANDMARKS_LEFT_EYE = oc, r("module$exports$google3$third_party$mediapipe$tasks$web$vision$face_landmarker$face_landmarker.FaceLandmarker.FACE_LANDMARKS_LEFT_EYE", mc.FACE_LANDMARKS_LEFT_EYE), mc.FACE_LANDMARKS_LEFT_EYEBROW = ac, r("module$exports$google3$third_party$mediapipe$tasks$web$vision$face_landmarker$face_landmarker.FaceLandmarker.FACE_LANDMARKS_LEFT_EYEBROW", mc.FACE_LANDMARKS_LEFT_EYEBROW), mc.FACE_LANDMARKS_LEFT_IRIS = hc, r("module$exports$google3$third_party$mediapipe$tasks$web$vision$face_landmarker$face_landmarker.FaceLandmarker.FACE_LANDMARKS_LEFT_IRIS", mc.FACE_LANDMARKS_LEFT_IRIS), mc.FACE_LANDMARKS_RIGHT_EYE = uc, r("module$exports$google3$third_party$mediapipe$tasks$web$vision$face_landmarker$face_landmarker.FaceLandmarker.FACE_LANDMARKS_RIGHT_EYE", mc.FACE_LANDMARKS_RIGHT_EYE), mc.FACE_LANDMARKS_RIGHT_EYEBROW = cc, r("module$exports$google3$third_party$mediapipe$tasks$web$vision$face_landmarker$face_landmarker.FaceLandmarker.FACE_LANDMARKS_RIGHT_EYEBROW", mc.FACE_LANDMARKS_RIGHT_EYEBROW), mc.FACE_LANDMARKS_RIGHT_IRIS = lc, r("module$exports$google3$third_party$mediapipe$tasks$web$vision$face_landmarker$face_landmarker.FaceLandmarker.FACE_LANDMARKS_RIGHT_IRIS", mc.FACE_LANDMARKS_RIGHT_IRIS), mc.FACE_LANDMARKS_FACE_OVAL = dc, r("module$exports$google3$third_party$mediapipe$tasks$web$vision$face_landmarker$face_landmarker.FaceLandmarker.FACE_LANDMARKS_FACE_OVAL", mc.FACE_LANDMARKS_FACE_OVAL), mc.FACE_LANDMARKS_CONTOURS = fc, r("module$exports$google3$third_party$mediapipe$tasks$web$vision$face_landmarker$face_landmarker.FaceLandmarker.FACE_LANDMARKS_CONTOURS", mc.FACE_LANDMARKS_CONTOURS), mc.FACE_LANDMARKS_TESSELATION = pc, r("module$exports$google3$third_party$mediapipe$tasks$web$vision$face_landmarker$face_landmarker.FaceLandmarker.FACE_LANDMARKS_TESSELATION", mc.FACE_LANDMARKS_TESSELATION);
	var vc = zu([0, 1], [1, 2], [2, 3], [3, 4], [0, 5], [5, 6], [6, 7], [7, 8], [5, 9], [9, 10], [10, 11], [11, 12], [9, 13], [13, 14], [14, 15], [15, 16], [13, 17], [0, 17], [17, 18], [18, 19], [19, 20]);
	function _c(t) {
		t.gestures = [], t.landmarks = [], t.worldLandmarks = [], t.handedness = [];
	}
	function yc(t) {
		return 0 === t.gestures.length ? {
			gestures: [],
			landmarks: [],
			worldLandmarks: [],
			handedness: [],
			handednesses: []
		} : {
			gestures: t.gestures,
			landmarks: t.landmarks,
			worldLandmarks: t.worldLandmarks,
			handedness: t.handedness,
			handednesses: t.handedness
		};
	}
	function Ec(t, e = !0) {
		var r = [];
		for (let i of t) {
			var n = wo(i);
			t = [];
			for (let r of n.g()) n = e && null != Or(r, 1) ? Or(r, 1) ?? 0 : -1, t.push({
				score: Dr(r, 2) ?? 0,
				index: n,
				categoryName: _e(sr(r, 3)) ?? "" ?? "",
				displayName: _e(sr(r, 4)) ?? "" ?? ""
			});
			r.push(t);
		}
		return r;
	}
	var Ac = class extends nc {
		constructor(t, e) {
			super(new Ju(t, e), "image_in", "norm_rect", !1), this.gestures = [], this.landmarks = [], this.worldLandmarks = [], this.handedness = [], Ir(t = this.l = new da(), 0, 1, e = new zo()), this.u = new la(), Ir(this.l, 0, 2, this.u), this.F = new ca(), Ir(this.u, 0, 3, this.F), this.B = new ua(), Ir(this.u, 0, 2, this.B), this.h = new ha(), Ir(this.l, 0, 3, this.h), jr(this.B, 2, .5), jr(this.u, 4, .5), jr(this.F, 2, .5);
		}
		C() {
			return "GestureRecognizer";
		}
		get baseOptions() {
			return Sr(this.l, zo, 1);
		}
		set baseOptions(t) {
			Ir(this.l, 0, 1, t);
		}
		v(t) {
			if (Ur(this.B, 3, t.numHands ?? 1), "minHandDetectionConfidence" in t && jr(this.B, 2, t.minHandDetectionConfidence ?? .5), "minTrackingConfidence" in t && jr(this.u, 4, t.minTrackingConfidence ?? .5), "minHandPresenceConfidence" in t && jr(this.F, 2, t.minHandPresenceConfidence ?? .5), t.cannedGesturesClassifierOptions) {
				var e = new oa(), r = e, n = za(t.cannedGesturesClassifierOptions, Sr(this.h, oa, 3)?.j());
				Ir(r, 0, 2, n), Ir(this.h, 0, 3, e);
			} else void 0 === t.cannedGesturesClassifierOptions && Sr(this.h, oa, 3)?.g();
			return t.customGesturesClassifierOptions ? (Ir(r = e = new oa(), 0, 2, n = za(t.customGesturesClassifierOptions, Sr(this.h, oa, 4)?.j())), Ir(this.h, 0, 4, e)) : void 0 === t.customGesturesClassifierOptions && Sr(this.h, oa, 4)?.g(), this.j(t);
		}
		Xa(t, e) {
			return _c(this), tc(this, t, e), yc(this);
		}
		Ya(t, e, r) {
			return _c(this), ec(this, t, r, e), yc(this);
		}
		o() {
			var t = new mo();
			po(t, "image_in"), po(t, "norm_rect"), go(t, "hand_gestures"), go(t, "hand_landmarks"), go(t, "world_hand_landmarks"), go(t, "handedness");
			var e = new no();
			li(e, va, this.l);
			var r = new ho();
			Hr(r, 2, "mediapipe.tasks.vision.gesture_recognizer.GestureRecognizerGraph"), oo(r, "IMAGE:image_in"), oo(r, "NORM_RECT:norm_rect"), ao(r, "HAND_GESTURES:hand_gestures"), ao(r, "LANDMARKS:hand_landmarks"), ao(r, "WORLD_LANDMARKS:world_hand_landmarks"), ao(r, "HANDEDNESS:handedness"), r.v(e), fo(t, r), this.g.attachProtoVectorListener("hand_landmarks", (t, e) => {
				for (let e of t) {
					t = Io(e);
					let r = [];
					for (let e of xr(t, Ro, 1)) r.push({
						x: Dr(e, 1) ?? 0,
						y: Dr(e, 2) ?? 0,
						z: Dr(e, 3) ?? 0,
						visibility: Dr(e, 4) ?? 0
					});
					this.landmarks.push(r);
				}
				tu(this, e);
			}), this.g.attachEmptyPacketListener("hand_landmarks", (t) => {
				tu(this, t);
			}), this.g.attachProtoVectorListener("world_hand_landmarks", (t, e) => {
				for (let e of t) {
					t = xo(e);
					let r = [];
					for (let e of xr(t, Lo, 1)) r.push({
						x: Dr(e, 1) ?? 0,
						y: Dr(e, 2) ?? 0,
						z: Dr(e, 3) ?? 0,
						visibility: Dr(e, 4) ?? 0
					});
					this.worldLandmarks.push(r);
				}
				tu(this, e);
			}), this.g.attachEmptyPacketListener("world_hand_landmarks", (t) => {
				tu(this, t);
			}), this.g.attachProtoVectorListener("hand_gestures", (t, e) => {
				this.gestures.push(...Ec(t, !1)), tu(this, e);
			}), this.g.attachEmptyPacketListener("hand_gestures", (t) => {
				tu(this, t);
			}), this.g.attachProtoVectorListener("handedness", (t, e) => {
				this.handedness.push(...Ec(t)), tu(this, e);
			}), this.g.attachEmptyPacketListener("handedness", (t) => {
				tu(this, t);
			}), t = t.g(), this.setGraph(new Uint8Array(t), !0);
		}
	};
	function wc(t) {
		return {
			landmarks: t.landmarks,
			worldLandmarks: t.worldLandmarks,
			handednesses: t.handedness,
			handedness: t.handedness
		};
	}
	Ac.prototype.recognizeForVideo = Ac.prototype.Ya, Ac.prototype.recognize = Ac.prototype.Xa, Ac.prototype.setOptions = Ac.prototype.v, Ac.createFromModelPath = function(t, e) {
		return Zu(Ac, t, { baseOptions: { modelAssetPath: e } });
	}, Ac.createFromModelBuffer = function(t, e) {
		return Zu(Ac, t, { baseOptions: { modelAssetBuffer: e } });
	}, Ac.createFromOptions = function(t, e) {
		return Zu(Ac, t, e);
	}, Ac.HAND_CONNECTIONS = vc, r("module$exports$google3$third_party$mediapipe$tasks$web$vision$gesture_recognizer$gesture_recognizer.GestureRecognizer.HAND_CONNECTIONS", Ac.HAND_CONNECTIONS);
	var bc = class extends nc {
		constructor(t, e) {
			super(new Ju(t, e), "image_in", "norm_rect", !1), this.landmarks = [], this.worldLandmarks = [], this.handedness = [], Ir(t = this.h = new la(), 0, 1, e = new zo()), this.u = new ca(), Ir(this.h, 0, 3, this.u), this.l = new ua(), Ir(this.h, 0, 2, this.l), Ur(this.l, 3, 1), jr(this.l, 2, .5), jr(this.u, 2, .5), jr(this.h, 4, .5);
		}
		C() {
			return "HandLandmarker";
		}
		get baseOptions() {
			return Sr(this.h, zo, 1);
		}
		set baseOptions(t) {
			Ir(this.h, 0, 1, t);
		}
		v(t) {
			return "numHands" in t && Ur(this.l, 3, t.numHands ?? 1), "minHandDetectionConfidence" in t && jr(this.l, 2, t.minHandDetectionConfidence ?? .5), "minTrackingConfidence" in t && jr(this.h, 4, t.minTrackingConfidence ?? .5), "minHandPresenceConfidence" in t && jr(this.u, 2, t.minHandPresenceConfidence ?? .5), this.j(t);
		}
		G(t, e) {
			return this.landmarks = [], this.worldLandmarks = [], this.handedness = [], tc(this, t, e), wc(this);
		}
		H(t, e, r) {
			return this.landmarks = [], this.worldLandmarks = [], this.handedness = [], ec(this, t, r, e), wc(this);
		}
		o() {
			var t = new mo();
			po(t, "image_in"), po(t, "norm_rect"), go(t, "hand_landmarks"), go(t, "world_hand_landmarks"), go(t, "handedness");
			var e = new no();
			li(e, _a, this.h);
			var r = new ho();
			Hr(r, 2, "mediapipe.tasks.vision.hand_landmarker.HandLandmarkerGraph"), oo(r, "IMAGE:image_in"), oo(r, "NORM_RECT:norm_rect"), ao(r, "LANDMARKS:hand_landmarks"), ao(r, "WORLD_LANDMARKS:world_hand_landmarks"), ao(r, "HANDEDNESS:handedness"), r.v(e), fo(t, r), this.g.attachProtoVectorListener("hand_landmarks", (t, e) => {
				for (let e of t) t = Io(e), this.landmarks.push(Qa(t));
				tu(this, e);
			}), this.g.attachEmptyPacketListener("hand_landmarks", (t) => {
				tu(this, t);
			}), this.g.attachProtoVectorListener("world_hand_landmarks", (t, e) => {
				for (let e of t) t = xo(e), this.worldLandmarks.push(th(t));
				tu(this, e);
			}), this.g.attachEmptyPacketListener("world_hand_landmarks", (t) => {
				tu(this, t);
			}), this.g.attachProtoVectorListener("handedness", (t, e) => {
				var r = this.handedness, n = r.push, i = [];
				for (let e of t) {
					t = wo(e);
					let r = [];
					for (let e of t.g()) r.push({
						score: Dr(e, 2) ?? 0,
						index: Or(e, 1) ?? 0 ?? -1,
						categoryName: _e(sr(e, 3)) ?? "" ?? "",
						displayName: _e(sr(e, 4)) ?? "" ?? ""
					});
					i.push(r);
				}
				n.call(r, ...i), tu(this, e);
			}), this.g.attachEmptyPacketListener("handedness", (t) => {
				tu(this, t);
			}), t = t.g(), this.setGraph(new Uint8Array(t), !0);
		}
	};
	bc.prototype.detectForVideo = bc.prototype.H, bc.prototype.detect = bc.prototype.G, bc.prototype.setOptions = bc.prototype.v, bc.createFromModelPath = function(t, e) {
		return Zu(bc, t, { baseOptions: { modelAssetPath: e } });
	}, bc.createFromModelBuffer = function(t, e) {
		return Zu(bc, t, { baseOptions: { modelAssetBuffer: e } });
	}, bc.createFromOptions = function(t, e) {
		return Zu(bc, t, e);
	}, bc.HAND_CONNECTIONS = vc, r("module$exports$google3$third_party$mediapipe$tasks$web$vision$hand_landmarker$hand_landmarker.HandLandmarker.HAND_CONNECTIONS", bc.HAND_CONNECTIONS);
	var Tc = zu([0, 1], [1, 2], [2, 3], [3, 7], [0, 4], [4, 5], [5, 6], [6, 8], [9, 10], [11, 12], [11, 13], [13, 15], [15, 17], [15, 19], [15, 21], [17, 19], [12, 14], [14, 16], [16, 18], [16, 20], [16, 22], [18, 20], [11, 23], [12, 24], [23, 24], [23, 25], [24, 26], [25, 27], [26, 28], [27, 29], [28, 30], [29, 31], [30, 32], [27, 31], [28, 32]);
	function kc(t) {
		t.h = {
			faceLandmarks: [],
			faceBlendshapes: [],
			poseLandmarks: [],
			poseWorldLandmarks: [],
			poseSegmentationMasks: [],
			leftHandLandmarks: [],
			leftHandWorldLandmarks: [],
			rightHandLandmarks: [],
			rightHandWorldLandmarks: []
		};
	}
	function Sc(t) {
		try {
			if (!t.F) return t.h;
			t.F(t.h);
		} finally {
			nu(t);
		}
	}
	function Lc(t, e) {
		t = Io(t), e.push(Qa(t));
	}
	var xc = class extends nc {
		constructor(t, e) {
			super(new Ju(t, e), "input_frames_image", null, !1), this.h = {
				faceLandmarks: [],
				faceBlendshapes: [],
				poseLandmarks: [],
				poseWorldLandmarks: [],
				poseSegmentationMasks: [],
				leftHandLandmarks: [],
				leftHandWorldLandmarks: [],
				rightHandLandmarks: [],
				rightHandWorldLandmarks: []
			}, this.outputPoseSegmentationMasks = this.outputFaceBlendshapes = !1, Ir(t = this.l = new wa(), 0, 1, e = new zo()), this.Y = new ca(), Ir(this.l, 0, 2, this.Y), this.Aa = new ya(), Ir(this.l, 0, 3, this.Aa), this.u = new Zo(), Ir(this.l, 0, 4, this.u), this.O = new ra(), Ir(this.l, 0, 5, this.O), this.B = new Ea(), Ir(this.l, 0, 6, this.B), this.Z = new Aa(), Ir(this.l, 0, 7, this.Z), jr(this.u, 2, .5), jr(this.u, 3, .3), jr(this.O, 2, .5), jr(this.B, 2, .5), jr(this.B, 3, .3), jr(this.Z, 2, .5), jr(this.Y, 2, .5);
		}
		C() {
			return "HolisticLandmarker";
		}
		get baseOptions() {
			return Sr(this.l, zo, 1);
		}
		set baseOptions(t) {
			Ir(this.l, 0, 1, t);
		}
		v(t) {
			return "minFaceDetectionConfidence" in t && jr(this.u, 2, t.minFaceDetectionConfidence ?? .5), "minFaceSuppressionThreshold" in t && jr(this.u, 3, t.minFaceSuppressionThreshold ?? .3), "minFacePresenceConfidence" in t && jr(this.O, 2, t.minFacePresenceConfidence ?? .5), "outputFaceBlendshapes" in t && (this.outputFaceBlendshapes = !!t.outputFaceBlendshapes), "minPoseDetectionConfidence" in t && jr(this.B, 2, t.minPoseDetectionConfidence ?? .5), "minPoseSuppressionThreshold" in t && jr(this.B, 3, t.minPoseSuppressionThreshold ?? .3), "minPosePresenceConfidence" in t && jr(this.Z, 2, t.minPosePresenceConfidence ?? .5), "outputPoseSegmentationMasks" in t && (this.outputPoseSegmentationMasks = !!t.outputPoseSegmentationMasks), "minHandLandmarksConfidence" in t && jr(this.Y, 2, t.minHandLandmarksConfidence ?? .5), this.j(t);
		}
		G(t, e, r) {
			var n = "function" != typeof e ? e : {};
			return this.F = "function" == typeof e ? e : r, kc(this), tc(this, t, n), Sc(this);
		}
		H(t, e, r, n) {
			var i = "function" != typeof r ? r : {};
			return this.F = "function" == typeof r ? r : n, kc(this), ec(this, t, i, e), Sc(this);
		}
		o() {
			var t = new mo();
			po(t, "input_frames_image"), go(t, "pose_landmarks"), go(t, "pose_world_landmarks"), go(t, "face_landmarks"), go(t, "left_hand_landmarks"), go(t, "left_hand_world_landmarks"), go(t, "right_hand_landmarks"), go(t, "right_hand_world_landmarks");
			var e = new no(), r = new Bs();
			Hr(r, 1, "type.googleapis.com/mediapipe.tasks.vision.holistic_landmarker.proto.HolisticLandmarkerGraphOptions"), function(t, e) {
				if (null != e) if (Array.isArray(e)) ar(t, 2, Ge(e, 0, Ve));
				else {
					if (!("string" == typeof e || e instanceof N || x(e))) throw Error("invalid value in Any.value field: " + e + " expected a ByteString, a base64 encoded string, a Uint8Array or a jspb array");
					_r(t, 2, ct(e, !1), I());
				}
			}(r, this.l.g());
			var n = new ho();
			Hr(n, 2, "mediapipe.tasks.vision.holistic_landmarker.HolisticLandmarkerGraph"), Mr(n, 8, Bs, r), oo(n, "IMAGE:input_frames_image"), ao(n, "POSE_LANDMARKS:pose_landmarks"), ao(n, "POSE_WORLD_LANDMARKS:pose_world_landmarks"), ao(n, "FACE_LANDMARKS:face_landmarks"), ao(n, "LEFT_HAND_LANDMARKS:left_hand_landmarks"), ao(n, "LEFT_HAND_WORLD_LANDMARKS:left_hand_world_landmarks"), ao(n, "RIGHT_HAND_LANDMARKS:right_hand_landmarks"), ao(n, "RIGHT_HAND_WORLD_LANDMARKS:right_hand_world_landmarks"), n.v(e), fo(t, n), eu(this, t), this.g.attachProtoListener("pose_landmarks", (t, e) => {
				Lc(t, this.h.poseLandmarks), tu(this, e);
			}), this.g.attachEmptyPacketListener("pose_landmarks", (t) => {
				tu(this, t);
			}), this.g.attachProtoListener("pose_world_landmarks", (t, e) => {
				var r = this.h.poseWorldLandmarks;
				t = xo(t), r.push(th(t)), tu(this, e);
			}), this.g.attachEmptyPacketListener("pose_world_landmarks", (t) => {
				tu(this, t);
			}), this.outputPoseSegmentationMasks && (ao(n, "POSE_SEGMENTATION_MASK:pose_segmentation_mask"), ru(this, "pose_segmentation_mask"), this.g.ga("pose_segmentation_mask", (t, e) => {
				this.h.poseSegmentationMasks = [rc(this, t, !0, !this.F)], tu(this, e);
			}), this.g.attachEmptyPacketListener("pose_segmentation_mask", (t) => {
				this.h.poseSegmentationMasks = [], tu(this, t);
			})), this.g.attachProtoListener("face_landmarks", (t, e) => {
				Lc(t, this.h.faceLandmarks), tu(this, e);
			}), this.g.attachEmptyPacketListener("face_landmarks", (t) => {
				tu(this, t);
			}), this.outputFaceBlendshapes && (go(t, "extra_blendshapes"), ao(n, "FACE_BLENDSHAPES:extra_blendshapes"), this.g.attachProtoListener("extra_blendshapes", (t, e) => {
				var r = this.h.faceBlendshapes;
				this.outputFaceBlendshapes && (t = wo(t), r.push(qa(t.g() ?? []))), tu(this, e);
			}), this.g.attachEmptyPacketListener("extra_blendshapes", (t) => {
				tu(this, t);
			})), this.g.attachProtoListener("left_hand_landmarks", (t, e) => {
				Lc(t, this.h.leftHandLandmarks), tu(this, e);
			}), this.g.attachEmptyPacketListener("left_hand_landmarks", (t) => {
				tu(this, t);
			}), this.g.attachProtoListener("left_hand_world_landmarks", (t, e) => {
				var r = this.h.leftHandWorldLandmarks;
				t = xo(t), r.push(th(t)), tu(this, e);
			}), this.g.attachEmptyPacketListener("left_hand_world_landmarks", (t) => {
				tu(this, t);
			}), this.g.attachProtoListener("right_hand_landmarks", (t, e) => {
				Lc(t, this.h.rightHandLandmarks), tu(this, e);
			}), this.g.attachEmptyPacketListener("right_hand_landmarks", (t) => {
				tu(this, t);
			}), this.g.attachProtoListener("right_hand_world_landmarks", (t, e) => {
				var r = this.h.rightHandWorldLandmarks;
				t = xo(t), r.push(th(t)), tu(this, e);
			}), this.g.attachEmptyPacketListener("right_hand_world_landmarks", (t) => {
				tu(this, t);
			}), t = t.g(), this.setGraph(new Uint8Array(t), !0);
		}
	};
	xc.prototype.detectForVideo = xc.prototype.H, xc.prototype.detect = xc.prototype.G, xc.prototype.setOptions = xc.prototype.v, xc.createFromModelPath = function(t, e) {
		return Zu(xc, t, { baseOptions: { modelAssetPath: e } });
	}, xc.createFromModelBuffer = function(t, e) {
		return Zu(xc, t, { baseOptions: { modelAssetBuffer: e } });
	}, xc.createFromOptions = function(t, e) {
		return Zu(xc, t, e);
	}, xc.HAND_CONNECTIONS = vc, r("module$exports$google3$third_party$mediapipe$tasks$web$vision$holistic_landmarker$holistic_landmarker.HolisticLandmarker.HAND_CONNECTIONS", xc.HAND_CONNECTIONS), xc.POSE_CONNECTIONS = Tc, r("module$exports$google3$third_party$mediapipe$tasks$web$vision$holistic_landmarker$holistic_landmarker.HolisticLandmarker.POSE_CONNECTIONS", xc.POSE_CONNECTIONS), xc.FACE_LANDMARKS_LIPS = sc, r("module$exports$google3$third_party$mediapipe$tasks$web$vision$holistic_landmarker$holistic_landmarker.HolisticLandmarker.FACE_LANDMARKS_LIPS", xc.FACE_LANDMARKS_LIPS), xc.FACE_LANDMARKS_LEFT_EYE = oc, r("module$exports$google3$third_party$mediapipe$tasks$web$vision$holistic_landmarker$holistic_landmarker.HolisticLandmarker.FACE_LANDMARKS_LEFT_EYE", xc.FACE_LANDMARKS_LEFT_EYE), xc.FACE_LANDMARKS_LEFT_EYEBROW = ac, r("module$exports$google3$third_party$mediapipe$tasks$web$vision$holistic_landmarker$holistic_landmarker.HolisticLandmarker.FACE_LANDMARKS_LEFT_EYEBROW", xc.FACE_LANDMARKS_LEFT_EYEBROW), xc.FACE_LANDMARKS_LEFT_IRIS = hc, r("module$exports$google3$third_party$mediapipe$tasks$web$vision$holistic_landmarker$holistic_landmarker.HolisticLandmarker.FACE_LANDMARKS_LEFT_IRIS", xc.FACE_LANDMARKS_LEFT_IRIS), xc.FACE_LANDMARKS_RIGHT_EYE = uc, r("module$exports$google3$third_party$mediapipe$tasks$web$vision$holistic_landmarker$holistic_landmarker.HolisticLandmarker.FACE_LANDMARKS_RIGHT_EYE", xc.FACE_LANDMARKS_RIGHT_EYE), xc.FACE_LANDMARKS_RIGHT_EYEBROW = cc, r("module$exports$google3$third_party$mediapipe$tasks$web$vision$holistic_landmarker$holistic_landmarker.HolisticLandmarker.FACE_LANDMARKS_RIGHT_EYEBROW", xc.FACE_LANDMARKS_RIGHT_EYEBROW), xc.FACE_LANDMARKS_RIGHT_IRIS = lc, r("module$exports$google3$third_party$mediapipe$tasks$web$vision$holistic_landmarker$holistic_landmarker.HolisticLandmarker.FACE_LANDMARKS_RIGHT_IRIS", xc.FACE_LANDMARKS_RIGHT_IRIS), xc.FACE_LANDMARKS_FACE_OVAL = dc, r("module$exports$google3$third_party$mediapipe$tasks$web$vision$holistic_landmarker$holistic_landmarker.HolisticLandmarker.FACE_LANDMARKS_FACE_OVAL", xc.FACE_LANDMARKS_FACE_OVAL), xc.FACE_LANDMARKS_CONTOURS = fc, r("module$exports$google3$third_party$mediapipe$tasks$web$vision$holistic_landmarker$holistic_landmarker.HolisticLandmarker.FACE_LANDMARKS_CONTOURS", xc.FACE_LANDMARKS_CONTOURS), xc.FACE_LANDMARKS_TESSELATION = pc, r("module$exports$google3$third_party$mediapipe$tasks$web$vision$holistic_landmarker$holistic_landmarker.HolisticLandmarker.FACE_LANDMARKS_TESSELATION", xc.FACE_LANDMARKS_TESSELATION);
	var Rc = class extends nc {
		constructor(t, e) {
			super(new Ju(t, e), "input_image", "norm_rect", !0), this.l = { classifications: [] }, Ir(t = this.h = new ka(), 0, 1, e = new zo());
		}
		C() {
			return "ImageClassifier";
		}
		get baseOptions() {
			return Sr(this.h, zo, 1);
		}
		set baseOptions(t) {
			Ir(this.h, 0, 1, t);
		}
		v(t) {
			return Ir(this.h, 0, 2, za(t, Sr(this.h, Go, 2))), this.j(t);
		}
		Ga(t, e) {
			return this.l = { classifications: [] }, tc(this, t, e), this.l;
		}
		Ha(t, e, r) {
			return this.l = { classifications: [] }, ec(this, t, r, e), this.l;
		}
		o() {
			var t = new mo();
			po(t, "input_image"), po(t, "norm_rect"), go(t, "classifications");
			var e = new no();
			li(e, Sa, this.h);
			var r = new ho();
			Hr(r, 2, "mediapipe.tasks.vision.image_classifier.ImageClassifierGraph"), oo(r, "IMAGE:input_image"), oo(r, "NORM_RECT:norm_rect"), ao(r, "CLASSIFICATIONS:classifications"), r.v(e), fo(t, r), this.g.attachProtoListener("classifications", (t, e) => {
				this.l = Ja(Oo(t)), tu(this, e);
			}), this.g.attachEmptyPacketListener("classifications", (t) => {
				tu(this, t);
			}), t = t.g(), this.setGraph(new Uint8Array(t), !0);
		}
	};
	Rc.prototype.classifyForVideo = Rc.prototype.Ha, Rc.prototype.classify = Rc.prototype.Ga, Rc.prototype.setOptions = Rc.prototype.v, Rc.createFromModelPath = function(t, e) {
		return Zu(Rc, t, { baseOptions: { modelAssetPath: e } });
	}, Rc.createFromModelBuffer = function(t, e) {
		return Zu(Rc, t, { baseOptions: { modelAssetBuffer: e } });
	}, Rc.createFromOptions = function(t, e) {
		return Zu(Rc, t, e);
	};
	var Ic = class extends nc {
		constructor(t, e) {
			super(new Ju(t, e), "image_in", "norm_rect", !0), this.h = new La(), this.embeddings = { embeddings: [] }, Ir(t = this.h, 0, 1, e = new zo());
		}
		C() {
			return "ImageEmbedder";
		}
		get baseOptions() {
			return Sr(this.h, zo, 1);
		}
		set baseOptions(t) {
			Ir(this.h, 0, 1, t);
		}
		v(t) {
			var e = this.h, r = Sr(this.h, Vo, 2);
			if (r = r ? r.clone() : new Vo(), void 0 !== t.l2Normalize) {
				var n = t.l2Normalize;
				ar(r, 1, null == n ? n : Zt(n));
			} else "l2Normalize" in t && ar(r, 1);
			return void 0 !== t.quantize ? ar(r, 2, null == (n = t.quantize) ? n : Zt(n)) : "quantize" in t && ar(r, 2), Ir(e, 0, 2, r), this.j(t);
		}
		Na(t, e) {
			return tc(this, t, e), this.embeddings;
		}
		Oa(t, e, r) {
			return ec(this, t, r, e), this.embeddings;
		}
		o() {
			var t = new mo();
			po(t, "image_in"), po(t, "norm_rect"), go(t, "embeddings_out");
			var e = new no();
			li(e, xa, this.h);
			var r = new ho();
			Hr(r, 2, "mediapipe.tasks.vision.image_embedder.ImageEmbedderGraph"), oo(r, "IMAGE:image_in"), oo(r, "NORM_RECT:norm_rect"), ao(r, "EMBEDDINGS:embeddings_out"), r.v(e), fo(t, r), this.g.attachProtoListener("embeddings_out", (t, e) => {
				t = Bo(t), this.embeddings = function(t) {
					return {
						embeddings: xr(t, $o, 1).map((t) => {
							var e = {
								headIndex: Or(t, 3) ?? 0 ?? -1,
								headName: _e(sr(t, 4)) ?? "" ?? ""
							};
							if (ur(t, Do, 1, Uo)) t = lr(t = Pr(t, Do, 1), 1, Jt, cr()), e.floatEmbedding = t.slice();
							else {
								let r = /* @__PURE__ */ new Uint8Array(0);
								e.quantizedEmbedding = Pr(t, Po, 2)?.g()?.h() ?? r;
							}
							return e;
						}),
						timestampMs: Ya(sr(t, 2, void 0, fe) ?? nr)
					};
				}(t), tu(this, e);
			}), this.g.attachEmptyPacketListener("embeddings_out", (t) => {
				tu(this, t);
			}), t = t.g(), this.setGraph(new Uint8Array(t), !0);
		}
	};
	Ic.cosineSimilarity = function(t, e) {
		if (t.floatEmbedding && e.floatEmbedding) t = rh(t.floatEmbedding, e.floatEmbedding);
		else {
			if (!t.quantizedEmbedding || !e.quantizedEmbedding) throw Error("Cannot compute cosine similarity between quantized and float embeddings.");
			t = rh(eh(t.quantizedEmbedding), eh(e.quantizedEmbedding));
		}
		return t;
	}, Ic.prototype.embedForVideo = Ic.prototype.Oa, Ic.prototype.embed = Ic.prototype.Na, Ic.prototype.setOptions = Ic.prototype.v, Ic.createFromModelPath = function(t, e) {
		return Zu(Ic, t, { baseOptions: { modelAssetPath: e } });
	}, Ic.createFromModelBuffer = function(t, e) {
		return Zu(Ic, t, { baseOptions: { modelAssetBuffer: e } });
	}, Ic.createFromOptions = function(t, e) {
		return Zu(Ic, t, e);
	};
	var Fc = class {
		constructor(t, e, r) {
			this.confidenceMasks = t, this.categoryMask = e, this.qualityScores = r;
		}
		close() {
			this.confidenceMasks?.forEach((t) => {
				t.close();
			}), this.categoryMask?.close();
		}
	};
	function Cc(t) {
		var e = function(t) {
			return xr(t, ho, 1);
		}(t.ja()).filter((t) => (_e(sr(t, 1)) ?? "").includes("mediapipe.tasks.TensorsToSegmentationCalculator"));
		if (t.u = [], e.length > 1) throw Error("The graph has more than one mediapipe.tasks.TensorsToSegmentationCalculator.");
		1 === e.length && (Sr(e[0], no, 7)?.o()?.g() ?? /* @__PURE__ */ new Map()).forEach((e, r) => {
			t.u[Number(r)] = _e(sr(e, 1)) ?? "";
		});
	}
	function Nc(t) {
		t.categoryMask = void 0, t.confidenceMasks = void 0, t.qualityScores = void 0;
	}
	function Mc(t) {
		try {
			let e = new Fc(t.confidenceMasks, t.categoryMask, t.qualityScores);
			if (!t.l) return e;
			t.l(e);
		} finally {
			nu(t);
		}
	}
	Fc.prototype.close = Fc.prototype.close;
	var Oc = class extends nc {
		constructor(t, e) {
			super(new Ju(t, e), "image_in", "norm_rect", !1), this.u = [], this.outputCategoryMask = !1, this.outputConfidenceMasks = !0, this.h = new Na(), this.B = new Ra(), Ir(this.h, 0, 3, this.B), Ir(t = this.h, 0, 1, e = new zo());
		}
		C() {
			return "ImageSegmenter";
		}
		get baseOptions() {
			return Sr(this.h, zo, 1);
		}
		set baseOptions(t) {
			Ir(this.h, 0, 1, t);
		}
		v(t) {
			return void 0 !== t.displayNamesLocale ? ar(this.h, 2, ve(t.displayNamesLocale)) : "displayNamesLocale" in t && ar(this.h, 2), "outputCategoryMask" in t && (this.outputCategoryMask = t.outputCategoryMask ?? !1), "outputConfidenceMasks" in t && (this.outputConfidenceMasks = t.outputConfidenceMasks ?? !0), super.j(t);
		}
		L() {
			Cc(this);
		}
		segment(t, e, r) {
			var n = "function" != typeof e ? e : {};
			return this.l = "function" == typeof e ? e : r, Nc(this), tc(this, t, n), Mc(this);
		}
		eb(t, e, r, n) {
			var i = "function" != typeof r ? r : {};
			return this.l = "function" == typeof r ? r : n, Nc(this), ec(this, t, i, e), Mc(this);
		}
		Ra() {
			return this.u;
		}
		o() {
			var t = new mo();
			po(t, "image_in"), po(t, "norm_rect");
			var e = new no();
			li(e, Ma, this.h);
			var r = new ho();
			Hr(r, 2, "mediapipe.tasks.vision.image_segmenter.ImageSegmenterGraph"), oo(r, "IMAGE:image_in"), oo(r, "NORM_RECT:norm_rect"), r.v(e), fo(t, r), eu(this, t), this.outputConfidenceMasks && (go(t, "confidence_masks"), ao(r, "CONFIDENCE_MASKS:confidence_masks"), ru(this, "confidence_masks"), this.g.ha("confidence_masks", (t, e) => {
				this.confidenceMasks = t.map((t) => rc(this, t, !0, !this.l)), tu(this, e);
			}), this.g.attachEmptyPacketListener("confidence_masks", (t) => {
				this.confidenceMasks = [], tu(this, t);
			})), this.outputCategoryMask && (go(t, "category_mask"), ao(r, "CATEGORY_MASK:category_mask"), ru(this, "category_mask"), this.g.ga("category_mask", (t, e) => {
				this.categoryMask = rc(this, t, !1, !this.l), tu(this, e);
			}), this.g.attachEmptyPacketListener("category_mask", (t) => {
				this.categoryMask = void 0, tu(this, t);
			})), go(t, "quality_scores"), ao(r, "QUALITY_SCORES:quality_scores"), this.g.attachFloatVectorListener("quality_scores", (t, e) => {
				this.qualityScores = t, tu(this, e);
			}), this.g.attachEmptyPacketListener("quality_scores", (t) => {
				this.categoryMask = void 0, tu(this, t);
			}), t = t.g(), this.setGraph(new Uint8Array(t), !0);
		}
	};
	Oc.prototype.getLabels = Oc.prototype.Ra, Oc.prototype.segmentForVideo = Oc.prototype.eb, Oc.prototype.segment = Oc.prototype.segment, Oc.prototype.setOptions = Oc.prototype.v, Oc.createFromModelPath = function(t, e) {
		return Zu(Oc, t, { baseOptions: { modelAssetPath: e } });
	}, Oc.createFromModelBuffer = function(t, e) {
		return Zu(Oc, t, { baseOptions: { modelAssetBuffer: e } });
	}, Oc.createFromOptions = function(t, e) {
		return Zu(Oc, t, e);
	};
	var Dc = {
		0: 0,
		1: 1,
		2: 2,
		3: 3
	};
	function Pc() {
		return Ph() ? void 0 : document.createElement("canvas");
	}
	var $c = class extends iu {
		constructor(t, e) {
			super(new Yh(t, e)), this.u = new pu(), this.delegate = "CPU", this.h = 0, this.baseOptions = new zo(), this.B = this.l = 0;
		}
		C() {
			return "InteractiveSegmenter";
		}
		get i() {
			return this.g.i;
		}
		v(t) {
			return this.delegate = t.baseOptions?.delegate ?? "CPU", super.j(t);
		}
		fb(t) {
			if (0 === this.h) throw Error("Segmenter is not initialized.");
			var e;
			if (0 !== this.l && (this.i._free(this.l), this.l = 0), !(e = "undefined" != typeof ImageData && t instanceof ImageData)) if ("object" != typeof t || null === t) e = !1;
			else {
				e = t.data;
				var r = t.width, n = t.height;
				e = Number.isInteger(r) && r > 0 && Number.isInteger(n) && n > 0 && (e instanceof Uint8ClampedArray || e instanceof Uint8Array);
			}
			if (e) e = t.width, r = t.height, t = t.data;
			else {
				if ([e, r] = Uh(t), "undefined" != typeof OffscreenCanvas) n = new OffscreenCanvas(e, r);
				else {
					if ("undefined" == typeof document) throw Error("Canvas is not supported in this environment.");
					n = document.createElement("canvas");
				}
				if (n.width = e, n.height = r, !(n = n.getContext("2d"))) throw Error("Canvas 2D context is not supported in this environment.");
				n.drawImage(t, 0, 0), t = n.getImageData(0, 0, e, r).data;
			}
			if (!t) throw Error("Unsupported image source or failed to extract image pixels.");
			n = function({ Wa: t, width: e, height: r }) {
				if (e <= 0 || r <= 0) throw Error(`Invalid image dimensions: ${e}x${r}. Dimensions must be positive.`);
				if (t % (e * r) !== 0) throw Error(`Invalid image dimensions or pixel data length. Pixel data length ${t} is not a multiple of the number of pixels (${e * r}).`);
				if (4 !== (t /= e * r) && 3 !== t && 1 !== t) throw Error(`Invalid image dimensions or pixel data length. Calculated channels: ${t}. Expected 1, 3, or 4.`);
				return t;
			}({
				Wa: t.length,
				width: e,
				height: r
			});
			var i = this.i._malloc(t.length);
			if (this.i.HEAPU8.set(t, i), this.l = i, !this.i._interactive_segmenter_set_image(this.h, i, e, r, n)) throw Error("Failed to set image on native engine.");
		}
		segment(t) {
			if (0 === this.h) throw Error("Segmenter is not initialized.");
			var e = function(t) {
				t = t.map(({ isCompleted: t, brushMode: e, point: r }) => {
					e = Dc[e] ?? 0, r = r.map(({ x: t, y: e }) => {
						var r = new Oa();
						return Vr(r, 1, t), Vr(r, 2, e), r;
					});
					var n = new Da();
					return $r(n, t), _r(n, 1, ee(e), 0), Cr(n, 2, r), n;
				});
				var e = new Pa();
				return Cr(e, 1, t), $a(e);
			}(t);
			t = this.i._malloc(e.length), this.i.HEAPU8.set(e, t);
			var r = this.i._malloc(12), n = r + 4, i = r + 8, s = 0, o = this.B++;
			try {
				if (this.m) if ("GPU" === this.delegate) {
					var a = this.m;
					++a.g.T, a.h.set(o, performance.now());
				} else {
					var h = this.m;
					++h.g.P, h.h.set(o, performance.now());
				}
				if (0 === (s = this.i._interactive_segmenter_segment(this.h, t, e.length, r, n, i))) throw Error("Segmentation failed.");
				this.m?.za(o);
				let c = this.i.HEAPU32[r / 4], l = this.i.HEAPU32[n / 4], d = new Float32Array(this.i.HEAPU8.buffer, s, this.i.HEAPU32[i / 4] / 4);
				var u = new Float32Array(d);
				if (a = c * l, (u instanceof Uint8Array || u instanceof Float32Array) && u.length !== a) throw Error("Unsupported channel count: " + u.length / a);
				return new Su([u], !0, !1, this.g.i.canvas ?? void 0, this.u, c, l);
			} finally {
				0 !== t && this.i._free(t), 0 !== r && this.i._free(r), 0 !== s && this.i._free(s);
			}
		}
		o() {
			0 !== this.h && (this.m?.xa(), this.i._interactive_segmenter_close(this.h), this.h = 0), 0 !== this.l && (this.i._free(this.l), this.l = 0);
			var t = new Ko();
			if ("GPU" === this.delegate) {
				var e = new Ys();
				Fr(t, 2, Xo, e);
			} else Ur(e = new eo(), 1, 4), Fr(t, 1, Xo, e);
			if (Ir(this.baseOptions, 0, 3, t), t = Jo(this.baseOptions), e = this.i._malloc(t.length), this.i.HEAPU8.set(t, e), this.h = this.i._interactive_segmenter_create(e, t.length), this.i._free(e), 0 === this.h) throw Error("Failed to create native InteractiveSegmenter engine.");
			this.m?.ya();
		}
		close() {
			0 !== this.h && (this.i._interactive_segmenter_close(this.h), this.h = 0), 0 !== this.l && (this.i._free(this.l), this.l = 0), this.u.close(), super.close();
		}
	};
	$c.prototype.close = $c.prototype.close, $c.prototype.segment = $c.prototype.segment, $c.prototype.setImage = $c.prototype.fb, $c.prototype.setOptions = $c.prototype.v, $c.createFromModelPath = function(t, e) {
		return Jh($c, Pc(), t, { baseOptions: { modelAssetPath: e } });
	}, $c.createFromModelBuffer = function(t, e) {
		return Jh($c, Pc(), t, { baseOptions: { modelAssetBuffer: e } });
	}, $c.createFromOptions = function(t, e) {
		return Jh($c, e.canvas ?? Pc(), t, e);
	};
	var Uc = class {
		constructor(t, e, r) {
			this.confidenceMasks = t, this.categoryMask = e, this.qualityScores = r;
		}
		close() {
			this.confidenceMasks?.forEach((t) => {
				t.close();
			}), this.categoryMask?.close();
		}
	};
	Uc.prototype.close = Uc.prototype.close;
	var Bc = class extends nc {
		constructor(t, e) {
			super(new Ju(t, e), "image_in", "norm_rect_in", !1), this.outputCategoryMask = !1, this.outputConfidenceMasks = !0, this.h = new Na(), this.u = new Ra(), Ir(this.h, 0, 3, this.u), Ir(t = this.h, 0, 1, e = new zo());
		}
		C() {
			return "InteractiveSegmenterLegacy";
		}
		get baseOptions() {
			return Sr(this.h, zo, 1);
		}
		set baseOptions(t) {
			Ir(this.h, 0, 1, t);
		}
		v(t) {
			return "outputCategoryMask" in t && (this.outputCategoryMask = t.outputCategoryMask ?? !1), "outputConfidenceMasks" in t && (this.outputConfidenceMasks = t.outputConfidenceMasks ?? !0), super.j(t);
		}
		segment(t, e, r, n) {
			var i = "function" != typeof r ? r : {};
			if (this.l = "function" == typeof r ? r : n, this.qualityScores = this.categoryMask = this.confidenceMasks = void 0, r = this.I + 1, n = new ja(), e.keypoint && e.scribble) throw Error("Cannot provide both keypoint and scribble.");
			if (e.keypoint) {
				var s = new Ua();
				$r(s, !0), Vr(s, 1, e.keypoint.x), Vr(s, 2, e.keypoint.y), Fr(n, 1, Va, s);
			} else {
				if (!e.scribble) throw Error("Must provide either a keypoint or a scribble.");
				{
					let t = new Ga();
					for (s of e.scribble) $r(e = new Ua(), !0), Vr(e, 1, s.x), Vr(e, 2, s.y), Mr(t, 1, Ua, e);
					Fr(n, 2, Va, t);
				}
			}
			this.g.addProtoToStream(n.g(), "mediapipe.tasks.vision.interactive_segmenter_legacy.proto.RegionOfInterest", "roi_in", r), tc(this, t, i);
			t: {
				try {
					let t = new Uc(this.confidenceMasks, this.categoryMask, this.qualityScores);
					if (!this.l) {
						var o = t;
						break t;
					}
					this.l(t);
				} finally {
					nu(this);
				}
				o = void 0;
			}
			return o;
		}
		o() {
			var t = new mo();
			po(t, "image_in"), po(t, "roi_in"), po(t, "norm_rect_in");
			var e = new no();
			li(e, Ma, this.h);
			var r = new ho();
			Hr(r, 2, "mediapipe.tasks.vision.interactive_segmenter_legacy.InteractiveSegmenterGraphV2"), oo(r, "IMAGE:image_in"), oo(r, "ROI:roi_in"), oo(r, "NORM_RECT:norm_rect_in"), r.v(e), fo(t, r), eu(this, t), this.outputConfidenceMasks && (go(t, "confidence_masks"), ao(r, "CONFIDENCE_MASKS:confidence_masks"), ru(this, "confidence_masks"), this.g.ha("confidence_masks", (t, e) => {
				this.confidenceMasks = t.map((t) => rc(this, t, !0, !this.l)), tu(this, e);
			}), this.g.attachEmptyPacketListener("confidence_masks", (t) => {
				this.confidenceMasks = [], tu(this, t);
			})), this.outputCategoryMask && (go(t, "category_mask"), ao(r, "CATEGORY_MASK:category_mask"), ru(this, "category_mask"), this.g.ga("category_mask", (t, e) => {
				this.categoryMask = rc(this, t, !1, !this.l), tu(this, e);
			}), this.g.attachEmptyPacketListener("category_mask", (t) => {
				this.categoryMask = void 0, tu(this, t);
			})), go(t, "quality_scores"), ao(r, "QUALITY_SCORES:quality_scores"), this.g.attachFloatVectorListener("quality_scores", (t, e) => {
				this.qualityScores = t, tu(this, e);
			}), this.g.attachEmptyPacketListener("quality_scores", (t) => {
				this.categoryMask = void 0, tu(this, t);
			}), t = t.g(), this.setGraph(new Uint8Array(t), !0);
		}
	};
	Bc.prototype.segment = Bc.prototype.segment, Bc.prototype.setOptions = Bc.prototype.v, Bc.createFromModelPath = function(t, e) {
		return Zu(Bc, t, { baseOptions: { modelAssetPath: e } });
	}, Bc.createFromModelBuffer = function(t, e) {
		return Zu(Bc, t, { baseOptions: { modelAssetBuffer: e } });
	}, Bc.createFromOptions = function(t, e) {
		return Zu(Bc, t, e);
	};
	var Gc = class extends nc {
		constructor(t, e) {
			super(new Ju(t, e), "input_frame_gpu", "norm_rect", !1), this.l = { detections: [] }, Ir(t = this.h = new Ha(), 0, 1, e = new zo());
		}
		C() {
			return "ObjectDetector";
		}
		get baseOptions() {
			return Sr(this.h, zo, 1);
		}
		set baseOptions(t) {
			Ir(this.h, 0, 1, t);
		}
		v(t) {
			return void 0 !== t.displayNamesLocale ? ar(this.h, 2, ve(t.displayNamesLocale)) : "displayNamesLocale" in t && ar(this.h, 2), void 0 !== t.maxResults ? Ur(this.h, 3, t.maxResults) : "maxResults" in t && ar(this.h, 3), void 0 !== t.scoreThreshold ? jr(this.h, 4, t.scoreThreshold) : "scoreThreshold" in t && ar(this.h, 4), void 0 !== t.categoryAllowlist ? Kr(this.h, 5, t.categoryAllowlist) : "categoryAllowlist" in t && ar(this.h, 5), void 0 !== t.categoryDenylist ? Kr(this.h, 6, t.categoryDenylist) : "categoryDenylist" in t && ar(this.h, 6), this.j(t);
		}
		G(t, e) {
			return this.l = { detections: [] }, tc(this, t, e), this.l;
		}
		H(t, e, r) {
			return this.l = { detections: [] }, ec(this, t, r, e), this.l;
		}
		o() {
			var t = new mo();
			po(t, "input_frame_gpu"), po(t, "norm_rect"), go(t, "detections");
			var e = new no();
			li(e, Ka, this.h);
			var r = new ho();
			Hr(r, 2, "mediapipe.tasks.vision.ObjectDetectorGraph"), oo(r, "IMAGE:input_frame_gpu"), oo(r, "NORM_RECT:norm_rect"), ao(r, "DETECTIONS:detections"), r.v(e), fo(t, r), this.g.attachProtoVectorListener("detections", (t, e) => {
				for (let e of t) t = So(e), this.l.detections.push(Za(t));
				tu(this, e);
			}), this.g.attachEmptyPacketListener("detections", (t) => {
				tu(this, t);
			}), t = t.g(), this.setGraph(new Uint8Array(t), !0);
		}
	};
	Gc.prototype.detectForVideo = Gc.prototype.H, Gc.prototype.detect = Gc.prototype.G, Gc.prototype.setOptions = Gc.prototype.v, Gc.createFromModelPath = async function(t, e) {
		return Zu(Gc, t, { baseOptions: { modelAssetPath: e } });
	}, Gc.createFromModelBuffer = function(t, e) {
		return Zu(Gc, t, { baseOptions: { modelAssetBuffer: e } });
	}, Gc.createFromOptions = function(t, e) {
		return Zu(Gc, t, e);
	};
	var jc = class {
		constructor(t, e, r) {
			this.landmarks = t, this.worldLandmarks = e, this.segmentationMasks = r;
		}
		close() {
			this.segmentationMasks?.forEach((t) => {
				t.close();
			});
		}
	};
	function Vc(t) {
		t.landmarks = [], t.worldLandmarks = [], t.segmentationMasks = void 0;
	}
	function Hc(t) {
		try {
			let e = new jc(t.landmarks, t.worldLandmarks, t.segmentationMasks);
			if (!t.u) return e;
			t.u(e);
		} finally {
			nu(t);
		}
	}
	jc.prototype.close = jc.prototype.close;
	var Kc = class extends nc {
		constructor(t, e) {
			super(new Ju(t, e), "image_in", "norm_rect", !1), this.landmarks = [], this.worldLandmarks = [], this.outputSegmentationMasks = !1, Ir(t = this.h = new Xa(), 0, 1, e = new zo()), this.B = new Aa(), Ir(this.h, 0, 3, this.B), this.l = new Ea(), Ir(this.h, 0, 2, this.l), Ur(this.l, 4, 1), jr(this.l, 2, .5), jr(this.B, 2, .5), jr(this.h, 4, .5);
		}
		C() {
			return "PoseLandmarker";
		}
		get baseOptions() {
			return Sr(this.h, zo, 1);
		}
		set baseOptions(t) {
			Ir(this.h, 0, 1, t);
		}
		v(t) {
			return "numPoses" in t && Ur(this.l, 4, t.numPoses ?? 1), "minPoseDetectionConfidence" in t && jr(this.l, 2, t.minPoseDetectionConfidence ?? .5), "minTrackingConfidence" in t && jr(this.h, 4, t.minTrackingConfidence ?? .5), "minPosePresenceConfidence" in t && jr(this.B, 2, t.minPosePresenceConfidence ?? .5), "outputSegmentationMasks" in t && (this.outputSegmentationMasks = t.outputSegmentationMasks ?? !1), this.j(t);
		}
		G(t, e, r) {
			var n = "function" != typeof e ? e : {};
			return this.u = "function" == typeof e ? e : r, Vc(this), tc(this, t, n), Hc(this);
		}
		H(t, e, r, n) {
			var i = "function" != typeof r ? r : {};
			return this.u = "function" == typeof r ? r : n, Vc(this), ec(this, t, i, e), Hc(this);
		}
		o() {
			var t = new mo();
			po(t, "image_in"), po(t, "norm_rect"), go(t, "normalized_landmarks"), go(t, "world_landmarks"), go(t, "segmentation_masks");
			var e = new no();
			li(e, Wa, this.h);
			var r = new ho();
			Hr(r, 2, "mediapipe.tasks.vision.pose_landmarker.PoseLandmarkerGraph"), oo(r, "IMAGE:image_in"), oo(r, "NORM_RECT:norm_rect"), ao(r, "NORM_LANDMARKS:normalized_landmarks"), ao(r, "WORLD_LANDMARKS:world_landmarks"), r.v(e), fo(t, r), eu(this, t), this.g.attachProtoVectorListener("normalized_landmarks", (t, e) => {
				this.landmarks = [];
				for (let e of t) t = Io(e), this.landmarks.push(Qa(t));
				tu(this, e);
			}), this.g.attachEmptyPacketListener("normalized_landmarks", (t) => {
				this.landmarks = [], tu(this, t);
			}), this.g.attachProtoVectorListener("world_landmarks", (t, e) => {
				this.worldLandmarks = [];
				for (let e of t) t = xo(e), this.worldLandmarks.push(th(t));
				tu(this, e);
			}), this.g.attachEmptyPacketListener("world_landmarks", (t) => {
				this.worldLandmarks = [], tu(this, t);
			}), this.outputSegmentationMasks && (ao(r, "SEGMENTATION_MASK:segmentation_masks"), ru(this, "segmentation_masks"), this.g.ha("segmentation_masks", (t, e) => {
				this.segmentationMasks = t.map((t) => rc(this, t, !0, !this.u)), tu(this, e);
			}), this.g.attachEmptyPacketListener("segmentation_masks", (t) => {
				this.segmentationMasks = [], tu(this, t);
			})), t = t.g(), this.setGraph(new Uint8Array(t), !0);
		}
	};
	Kc.prototype.detectForVideo = Kc.prototype.H, Kc.prototype.detect = Kc.prototype.G, Kc.prototype.setOptions = Kc.prototype.v, Kc.createFromModelPath = function(t, e) {
		return Zu(Kc, t, { baseOptions: { modelAssetPath: e } });
	}, Kc.createFromModelBuffer = function(t, e) {
		return Zu(Kc, t, { baseOptions: { modelAssetBuffer: e } });
	}, Kc.createFromOptions = function(t, e) {
		return Zu(Kc, t, e);
	}, Kc.POSE_CONNECTIONS = Tc, r("module$exports$google3$third_party$mediapipe$tasks$web$vision$pose_landmarker$pose_landmarker.PoseLandmarker.POSE_CONNECTIONS", Kc.POSE_CONNECTIONS);
	/**
	* @license
	* Copyright 2010-2026 Three.js Authors
	* SPDX-License-Identifier: MIT
	*/
	/**
	* The texture will simply repeat to infinity.
	*
	* @type {number}
	* @constant
	*/
	const RepeatWrapping = 1e3;
	/**
	* The last pixel of the texture stretches to the edge of the mesh.
	*
	* @type {number}
	* @constant
	*/
	const ClampToEdgeWrapping = 1001;
	/**
	* The texture will repeats to infinity, mirroring on each repeat.
	*
	* @type {number}
	* @constant
	*/
	const MirroredRepeatWrapping = 1002;
	/**
	* Returns the weighted average of the four texture elements that are closest to the specified
	* texture coordinates, and can include items wrapped or repeated from other parts of a texture,
	* depending on the values of `wrapS` and `wrapT`, and on the exact mapping.
	*
	* @type {number}
	* @constant
	*/
	const LinearFilter = 1006;
	/**
	* Chooses the two mipmaps that most closely match the size of the pixel being textured and uses
	* the `LinearFilter` criterion to produce a texture value from each mipmap. The final texture value
	* is a weighted average of those two values.
	*
	* @type {number}
	* @constant
	*/
	const LinearMipmapLinearFilter = 1008;
	/**
	* An unsigned byte data type for textures.
	*
	* @type {number}
	* @constant
	*/
	const UnsignedByteType = 1009;
	/**
	* Reads the red, green, blue and alpha components.
	*
	* @type {number}
	* @constant
	*/
	const RGBAFormat = 1023;
	/**
	* Discrete interpolation mode for keyframe tracks.
	*
	* @type {number}
	* @constant
	*/
	const InterpolateDiscrete = 2300;
	/**
	* Linear interpolation mode for keyframe tracks.
	*
	* @type {number}
	* @constant
	*/
	const InterpolateLinear = 2301;
	/**
	* Smooth interpolation mode for keyframe tracks.
	*
	* @type {number}
	* @constant
	*/
	const InterpolateSmooth = 2302;
	/**
	* Bezier interpolation mode for keyframe tracks.
	*
	* Uses cubic Bezier curves with explicit 2D control points.
	* Requires tangent data to be set on the track.
	*
	* @type {number}
	* @constant
	*/
	const InterpolateBezier = 2303;
	/**
	* Zero curvature ending for animations.
	*
	* @type {number}
	* @constant
	*/
	const ZeroCurvatureEnding = 2400;
	/**
	* Zero slope ending for animations.
	*
	* @type {number}
	* @constant
	*/
	const ZeroSlopeEnding = 2401;
	/**
	* Wrap around ending for animations.
	*
	* @type {number}
	* @constant
	*/
	const WrapAroundEnding = 2402;
	/**
	* sRGB color space.
	*
	* @type {string}
	* @constant
	*/
	const SRGBColorSpace = "srgb";
	/**
	* sRGB-linear color space.
	*
	* @type {string}
	* @constant
	*/
	const LinearSRGBColorSpace = "srgb-linear";
	/**
	* Linear transfer function.
	*
	* @type {string}
	* @constant
	*/
	const LinearTransfer = "linear";
	/**
	* sRGB transfer function.
	*
	* @type {string}
	* @constant
	*/
	const SRGBTransfer = "srgb";
	/**
	* WebGL coordinate system.
	*
	* @type {number}
	* @constant
	*/
	const WebGLCoordinateSystem = 2e3;
	/**
	* Returns `true` if the given object is a typed array.
	*
	* @param {any} array - The object to check.
	* @return {boolean} Whether the given object is a typed array.
	*/
	function isTypedArray(array) {
		return ArrayBuffer.isView(array) && !(array instanceof DataView);
	}
	/**
	* Creates an XHTML element with the specified tag name.
	*
	* This function uses the XHTML namespace to create DOM elements,
	* ensuring proper element creation in XML-based contexts.
	*
	* @private
	* @param {string} name - The tag name of the element to create (e.g., 'canvas', 'div').
	* @return {HTMLElement} The created XHTML element.
	*/
	function createElementNS(name) {
		return document.createElementNS("http://www.w3.org/1999/xhtml", name);
	}
	/**
	* Internal cache for tracking warning messages to prevent duplicate warnings.
	*
	* @private
	* @type {Object<string, boolean>}
	*/
	const _cache = {};
	/**
	* Enhances log/warn/error messages related to TSL.
	*
	* @param {Array<any>} params - The original message parameters.
	* @returns {Array<any>} The filtered and enhanced message parameters.
	*/
	function enhanceLogMessage(params) {
		const message = params[0];
		if (typeof message === "string" && message.startsWith("TSL:")) {
			const stackTrace = params[1];
			if (stackTrace && stackTrace.isStackTrace) params[0] += " " + stackTrace.getLocation();
			else params[1] = "Stack trace not available. Enable \"THREE.Node.captureStackTrace\" to capture stack traces.";
		}
		return params;
	}
	/**
	* Logs a warning message with the 'THREE.' prefix.
	*
	* If a custom console function is set via setConsoleFunction(), it will be used
	* instead of the native console.warn. The first parameter is treated as the
	* method name and is automatically prefixed with 'THREE.'.
	*
	* @param {...any} params - The message components. The first param is used as
	*                          the method name and prefixed with 'THREE.'.
	*/
	function warn(...params) {
		params = enhanceLogMessage(params);
		const message = "THREE." + params.shift();
		{
			const stackTrace = params[0];
			if (stackTrace && stackTrace.isStackTrace) console.warn(stackTrace.getError(message));
			else console.warn(message, ...params);
		}
	}
	/**
	* Logs an error message with the 'THREE.' prefix.
	*
	* If a custom console function is set via setConsoleFunction(), it will be used
	* instead of the native console.error. The first parameter is treated as the
	* method name and is automatically prefixed with 'THREE.'.
	*
	* @param {...any} params - The message components. The first param is used as
	*                          the method name and prefixed with 'THREE.'.
	*/
	function error(...params) {
		params = enhanceLogMessage(params);
		const message = "THREE." + params.shift();
		{
			const stackTrace = params[0];
			if (stackTrace && stackTrace.isStackTrace) console.error(stackTrace.getError(message));
			else console.error(message, ...params);
		}
	}
	/**
	* Logs a warning message only once, preventing duplicate warnings.
	*
	* This function maintains an internal cache of warning messages and will only
	* output each unique warning message once. Useful for warnings that may be
	* triggered repeatedly but should only be shown to the user once.
	*
	* @param {...any} params - The warning message components.
	*/
	function warnOnce(...params) {
		const message = params.join(" ");
		if (message in _cache) return;
		_cache[message] = true;
		warn(...params);
	}
	/**
	* This modules allows to dispatch event objects on custom JavaScript objects.
	*
	* Main repository: [eventdispatcher.js](https://github.com/mrdoob/eventdispatcher.js/)
	*
	* Code Example:
	* ```js
	* class Car extends EventDispatcher {
	* 	start() {
	*		this.dispatchEvent( { type: 'start', message: 'vroom vroom!' } );
	*	}
	*};
	*
	* // Using events with the custom object
	* const car = new Car();
	* car.addEventListener( 'start', function ( event ) {
	* 	alert( event.message );
	* } );
	*
	* car.start();
	* ```
	*/
	var EventDispatcher = class {
		/**
		* Adds the given event listener to the given event type.
		*
		* @param {string} type - The type of event to listen to.
		* @param {Function} listener - The function that gets called when the event is fired.
		*/
		addEventListener(type, listener) {
			if (this._listeners === void 0) this._listeners = {};
			const listeners = this._listeners;
			if (listeners[type] === void 0) listeners[type] = [];
			if (listeners[type].indexOf(listener) === -1) listeners[type].push(listener);
		}
		/**
		* Returns `true` if the given event listener has been added to the given event type.
		*
		* @param {string} type - The type of event.
		* @param {Function} listener - The listener to check.
		* @return {boolean} Whether the given event listener has been added to the given event type.
		*/
		hasEventListener(type, listener) {
			const listeners = this._listeners;
			if (listeners === void 0) return false;
			return listeners[type] !== void 0 && listeners[type].indexOf(listener) !== -1;
		}
		/**
		* Removes the given event listener from the given event type.
		*
		* @param {string} type - The type of event.
		* @param {Function} listener - The listener to remove.
		*/
		removeEventListener(type, listener) {
			const listeners = this._listeners;
			if (listeners === void 0) return;
			const listenerArray = listeners[type];
			if (listenerArray !== void 0) {
				const index = listenerArray.indexOf(listener);
				if (index !== -1) listenerArray.splice(index, 1);
			}
		}
		/**
		* Dispatches an event object.
		*
		* @param {Object} event - The event that gets fired.
		*/
		dispatchEvent(event) {
			const listeners = this._listeners;
			if (listeners === void 0) return;
			const listenerArray = listeners[event.type];
			if (listenerArray !== void 0) {
				event.target = this;
				const array = listenerArray.slice(0);
				for (let i = 0, l = array.length; i < l; i++) array[i].call(this, event);
				event.target = null;
			}
		}
	};
	const _lut = [
		"00",
		"01",
		"02",
		"03",
		"04",
		"05",
		"06",
		"07",
		"08",
		"09",
		"0a",
		"0b",
		"0c",
		"0d",
		"0e",
		"0f",
		"10",
		"11",
		"12",
		"13",
		"14",
		"15",
		"16",
		"17",
		"18",
		"19",
		"1a",
		"1b",
		"1c",
		"1d",
		"1e",
		"1f",
		"20",
		"21",
		"22",
		"23",
		"24",
		"25",
		"26",
		"27",
		"28",
		"29",
		"2a",
		"2b",
		"2c",
		"2d",
		"2e",
		"2f",
		"30",
		"31",
		"32",
		"33",
		"34",
		"35",
		"36",
		"37",
		"38",
		"39",
		"3a",
		"3b",
		"3c",
		"3d",
		"3e",
		"3f",
		"40",
		"41",
		"42",
		"43",
		"44",
		"45",
		"46",
		"47",
		"48",
		"49",
		"4a",
		"4b",
		"4c",
		"4d",
		"4e",
		"4f",
		"50",
		"51",
		"52",
		"53",
		"54",
		"55",
		"56",
		"57",
		"58",
		"59",
		"5a",
		"5b",
		"5c",
		"5d",
		"5e",
		"5f",
		"60",
		"61",
		"62",
		"63",
		"64",
		"65",
		"66",
		"67",
		"68",
		"69",
		"6a",
		"6b",
		"6c",
		"6d",
		"6e",
		"6f",
		"70",
		"71",
		"72",
		"73",
		"74",
		"75",
		"76",
		"77",
		"78",
		"79",
		"7a",
		"7b",
		"7c",
		"7d",
		"7e",
		"7f",
		"80",
		"81",
		"82",
		"83",
		"84",
		"85",
		"86",
		"87",
		"88",
		"89",
		"8a",
		"8b",
		"8c",
		"8d",
		"8e",
		"8f",
		"90",
		"91",
		"92",
		"93",
		"94",
		"95",
		"96",
		"97",
		"98",
		"99",
		"9a",
		"9b",
		"9c",
		"9d",
		"9e",
		"9f",
		"a0",
		"a1",
		"a2",
		"a3",
		"a4",
		"a5",
		"a6",
		"a7",
		"a8",
		"a9",
		"aa",
		"ab",
		"ac",
		"ad",
		"ae",
		"af",
		"b0",
		"b1",
		"b2",
		"b3",
		"b4",
		"b5",
		"b6",
		"b7",
		"b8",
		"b9",
		"ba",
		"bb",
		"bc",
		"bd",
		"be",
		"bf",
		"c0",
		"c1",
		"c2",
		"c3",
		"c4",
		"c5",
		"c6",
		"c7",
		"c8",
		"c9",
		"ca",
		"cb",
		"cc",
		"cd",
		"ce",
		"cf",
		"d0",
		"d1",
		"d2",
		"d3",
		"d4",
		"d5",
		"d6",
		"d7",
		"d8",
		"d9",
		"da",
		"db",
		"dc",
		"dd",
		"de",
		"df",
		"e0",
		"e1",
		"e2",
		"e3",
		"e4",
		"e5",
		"e6",
		"e7",
		"e8",
		"e9",
		"ea",
		"eb",
		"ec",
		"ed",
		"ee",
		"ef",
		"f0",
		"f1",
		"f2",
		"f3",
		"f4",
		"f5",
		"f6",
		"f7",
		"f8",
		"f9",
		"fa",
		"fb",
		"fc",
		"fd",
		"fe",
		"ff"
	];
	/**
	* Generate a [UUID](https://en.wikipedia.org/wiki/Universally_unique_identifier)
	* (universally unique identifier).
	*
	* @return {string} The UUID.
	*/
	function generateUUID() {
		const d0 = Math.random() * 4294967295 | 0;
		const d1 = Math.random() * 4294967295 | 0;
		const d2 = Math.random() * 4294967295 | 0;
		const d3 = Math.random() * 4294967295 | 0;
		return (_lut[d0 & 255] + _lut[d0 >> 8 & 255] + _lut[d0 >> 16 & 255] + _lut[d0 >> 24 & 255] + "-" + _lut[d1 & 255] + _lut[d1 >> 8 & 255] + "-" + _lut[d1 >> 16 & 15 | 64] + _lut[d1 >> 24 & 255] + "-" + _lut[d2 & 63 | 128] + _lut[d2 >> 8 & 255] + "-" + _lut[d2 >> 16 & 255] + _lut[d2 >> 24 & 255] + _lut[d3 & 255] + _lut[d3 >> 8 & 255] + _lut[d3 >> 16 & 255] + _lut[d3 >> 24 & 255]).toLowerCase();
	}
	/**
	* Clamps the given value between min and max.
	*
	* @param {number} value - The value to clamp.
	* @param {number} min - The min value.
	* @param {number} max - The max value.
	* @return {number} The clamped value.
	*/
	function clamp(value, min, max) {
		return Math.max(min, Math.min(max, value));
	}
	/**
	* Computes the Euclidean modulo of the given parameters that
	* is `( ( n % m ) + m ) % m`.
	*
	* @param {number} n - The first parameter.
	* @param {number} m - The second parameter.
	* @return {number} The Euclidean modulo.
	*/
	function euclideanModulo(n, m) {
		return (n % m + m) % m;
	}
	/**
	* Returns a value linearly interpolated from two known points based on the given interval -
	* `t = 0` will return `x` and `t = 1` will return `y`.
	*
	* @param {number} x - The start point
	* @param {number} y - The end point.
	* @param {number} t - The interpolation factor in the closed interval `[0, 1]`.
	* @return {number} The interpolated value.
	*/
	function lerp(x, y, t) {
		return (1 - t) * x + t * y;
	}
	/**
	* Class representing a 2D vector. A 2D vector is an ordered pair of numbers
	* (labeled x and y), which can be used to represent a number of things, such as:
	*
	* - A point in 2D space (i.e. a position on a plane).
	* - A direction and length across a plane. In three.js the length will
	* always be the Euclidean distance(straight-line distance) from `(0, 0)` to `(x, y)`
	* and the direction is also measured from `(0, 0)` towards `(x, y)`.
	* - Any arbitrary ordered pair of numbers.
	*
	* There are other things a 2D vector can be used to represent, such as
	* momentum vectors, complex numbers and so on, however these are the most
	* common uses in three.js.
	*
	* Iterating through a vector instance will yield its components `(x, y)` in
	* the corresponding order.
	* ```js
	* const a = new THREE.Vector2( 0, 1 );
	*
	* //no arguments; will be initialised to (0, 0)
	* const b = new THREE.Vector2( );
	*
	* const d = a.distanceTo( b );
	* ```
	*/
	var Vector2 = class Vector2 {
		static {
			/**
			* This flag can be used for type testing.
			*
			* @type {boolean}
			* @readonly
			* @default true
			*/
			Vector2.prototype.isVector2 = true;
		}
		/**
		* Constructs a new 2D vector.
		*
		* @param {number} [x=0] - The x value of this vector.
		* @param {number} [y=0] - The y value of this vector.
		*/
		constructor(x = 0, y = 0) {
			/**
			* The x value of this vector.
			*
			* @type {number}
			*/
			this.x = x;
			/**
			* The y value of this vector.
			*
			* @type {number}
			*/
			this.y = y;
		}
		/**
		* Alias for {@link Vector2#x}.
		*
		* @type {number}
		*/
		get width() {
			return this.x;
		}
		set width(value) {
			this.x = value;
		}
		/**
		* Alias for {@link Vector2#y}.
		*
		* @type {number}
		*/
		get height() {
			return this.y;
		}
		set height(value) {
			this.y = value;
		}
		/**
		* Sets the vector components.
		*
		* @param {number} x - The value of the x component.
		* @param {number} y - The value of the y component.
		* @return {Vector2} A reference to this vector.
		*/
		set(x, y) {
			this.x = x;
			this.y = y;
			return this;
		}
		/**
		* Sets the vector components to the same value.
		*
		* @param {number} scalar - The value to set for all vector components.
		* @return {Vector2} A reference to this vector.
		*/
		setScalar(scalar) {
			this.x = scalar;
			this.y = scalar;
			return this;
		}
		/**
		* Sets the vector's x component to the given value
		*
		* @param {number} x - The value to set.
		* @return {Vector2} A reference to this vector.
		*/
		setX(x) {
			this.x = x;
			return this;
		}
		/**
		* Sets the vector's y component to the given value
		*
		* @param {number} y - The value to set.
		* @return {Vector2} A reference to this vector.
		*/
		setY(y) {
			this.y = y;
			return this;
		}
		/**
		* Allows to set a vector component with an index.
		*
		* @param {number} index - The component index. `0` equals to x, `1` equals to y.
		* @param {number} value - The value to set.
		* @return {Vector2} A reference to this vector.
		*/
		setComponent(index, value) {
			switch (index) {
				case 0:
					this.x = value;
					break;
				case 1:
					this.y = value;
					break;
				default: throw new Error("THREE.Vector2: index is out of range: " + index);
			}
			return this;
		}
		/**
		* Returns the value of the vector component which matches the given index.
		*
		* @param {number} index - The component index. `0` equals to x, `1` equals to y.
		* @return {number} A vector component value.
		*/
		getComponent(index) {
			switch (index) {
				case 0: return this.x;
				case 1: return this.y;
				default: throw new Error("THREE.Vector2: index is out of range: " + index);
			}
		}
		/**
		* Returns a new vector with copied values from this instance.
		*
		* @return {Vector2} A clone of this instance.
		*/
		clone() {
			return new this.constructor(this.x, this.y);
		}
		/**
		* Copies the values of the given vector to this instance.
		*
		* @param {Vector2} v - The vector to copy.
		* @return {Vector2} A reference to this vector.
		*/
		copy(v) {
			this.x = v.x;
			this.y = v.y;
			return this;
		}
		/**
		* Adds the given vector to this instance.
		*
		* @param {Vector2} v - The vector to add.
		* @return {Vector2} A reference to this vector.
		*/
		add(v) {
			this.x += v.x;
			this.y += v.y;
			return this;
		}
		/**
		* Adds the given scalar value to all components of this instance.
		*
		* @param {number} s - The scalar to add.
		* @return {Vector2} A reference to this vector.
		*/
		addScalar(s) {
			this.x += s;
			this.y += s;
			return this;
		}
		/**
		* Adds the given vectors and stores the result in this instance.
		*
		* @param {Vector2} a - The first vector.
		* @param {Vector2} b - The second vector.
		* @return {Vector2} A reference to this vector.
		*/
		addVectors(a, b) {
			this.x = a.x + b.x;
			this.y = a.y + b.y;
			return this;
		}
		/**
		* Adds the given vector scaled by the given factor to this instance.
		*
		* @param {Vector2} v - The vector.
		* @param {number} s - The factor that scales `v`.
		* @return {Vector2} A reference to this vector.
		*/
		addScaledVector(v, s) {
			this.x += v.x * s;
			this.y += v.y * s;
			return this;
		}
		/**
		* Subtracts the given vector from this instance.
		*
		* @param {Vector2} v - The vector to subtract.
		* @return {Vector2} A reference to this vector.
		*/
		sub(v) {
			this.x -= v.x;
			this.y -= v.y;
			return this;
		}
		/**
		* Subtracts the given scalar value from all components of this instance.
		*
		* @param {number} s - The scalar to subtract.
		* @return {Vector2} A reference to this vector.
		*/
		subScalar(s) {
			this.x -= s;
			this.y -= s;
			return this;
		}
		/**
		* Subtracts the given vectors and stores the result in this instance.
		*
		* @param {Vector2} a - The first vector.
		* @param {Vector2} b - The second vector.
		* @return {Vector2} A reference to this vector.
		*/
		subVectors(a, b) {
			this.x = a.x - b.x;
			this.y = a.y - b.y;
			return this;
		}
		/**
		* Multiplies the given vector with this instance.
		*
		* @param {Vector2} v - The vector to multiply.
		* @return {Vector2} A reference to this vector.
		*/
		multiply(v) {
			this.x *= v.x;
			this.y *= v.y;
			return this;
		}
		/**
		* Multiplies the given scalar value with all components of this instance.
		*
		* @param {number} scalar - The scalar to multiply.
		* @return {Vector2} A reference to this vector.
		*/
		multiplyScalar(scalar) {
			this.x *= scalar;
			this.y *= scalar;
			return this;
		}
		/**
		* Divides this instance by the given vector.
		*
		* @param {Vector2} v - The vector to divide.
		* @return {Vector2} A reference to this vector.
		*/
		divide(v) {
			this.x /= v.x;
			this.y /= v.y;
			return this;
		}
		/**
		* Divides this vector by the given scalar.
		*
		* @param {number} scalar - The scalar to divide.
		* @return {Vector2} A reference to this vector.
		*/
		divideScalar(scalar) {
			return this.multiplyScalar(1 / scalar);
		}
		/**
		* Multiplies this vector (with an implicit 1 as the 3rd component) by
		* the given 3x3 matrix.
		*
		* @param {Matrix3} m - The matrix to apply.
		* @return {Vector2} A reference to this vector.
		*/
		applyMatrix3(m) {
			const x = this.x, y = this.y;
			const e = m.elements;
			this.x = e[0] * x + e[3] * y + e[6];
			this.y = e[1] * x + e[4] * y + e[7];
			return this;
		}
		/**
		* If this vector's x or y value is greater than the given vector's x or y
		* value, replace that value with the corresponding min value.
		*
		* @param {Vector2} v - The vector.
		* @return {Vector2} A reference to this vector.
		*/
		min(v) {
			this.x = Math.min(this.x, v.x);
			this.y = Math.min(this.y, v.y);
			return this;
		}
		/**
		* If this vector's x or y value is less than the given vector's x or y
		* value, replace that value with the corresponding max value.
		*
		* @param {Vector2} v - The vector.
		* @return {Vector2} A reference to this vector.
		*/
		max(v) {
			this.x = Math.max(this.x, v.x);
			this.y = Math.max(this.y, v.y);
			return this;
		}
		/**
		* If this vector's x or y value is greater than the max vector's x or y
		* value, it is replaced by the corresponding value.
		* If this vector's x or y value is less than the min vector's x or y value,
		* it is replaced by the corresponding value.
		*
		* @param {Vector2} min - The minimum x and y values.
		* @param {Vector2} max - The maximum x and y values in the desired range.
		* @return {Vector2} A reference to this vector.
		*/
		clamp(min, max) {
			this.x = clamp(this.x, min.x, max.x);
			this.y = clamp(this.y, min.y, max.y);
			return this;
		}
		/**
		* If this vector's x or y values are greater than the max value, they are
		* replaced by the max value.
		* If this vector's x or y values are less than the min value, they are
		* replaced by the min value.
		*
		* @param {number} minVal - The minimum value the components will be clamped to.
		* @param {number} maxVal - The maximum value the components will be clamped to.
		* @return {Vector2} A reference to this vector.
		*/
		clampScalar(minVal, maxVal) {
			this.x = clamp(this.x, minVal, maxVal);
			this.y = clamp(this.y, minVal, maxVal);
			return this;
		}
		/**
		* If this vector's length is greater than the max value, it is replaced by
		* the max value.
		* If this vector's length is less than the min value, it is replaced by the
		* min value.
		*
		* @param {number} min - The minimum value the vector length will be clamped to.
		* @param {number} max - The maximum value the vector length will be clamped to.
		* @return {Vector2} A reference to this vector.
		*/
		clampLength(min, max) {
			const length = this.length();
			return this.divideScalar(length || 1).multiplyScalar(clamp(length, min, max));
		}
		/**
		* The components of this vector are rounded down to the nearest integer value.
		*
		* @return {Vector2} A reference to this vector.
		*/
		floor() {
			this.x = Math.floor(this.x);
			this.y = Math.floor(this.y);
			return this;
		}
		/**
		* The components of this vector are rounded up to the nearest integer value.
		*
		* @return {Vector2} A reference to this vector.
		*/
		ceil() {
			this.x = Math.ceil(this.x);
			this.y = Math.ceil(this.y);
			return this;
		}
		/**
		* The components of this vector are rounded to the nearest integer value
		*
		* @return {Vector2} A reference to this vector.
		*/
		round() {
			this.x = Math.round(this.x);
			this.y = Math.round(this.y);
			return this;
		}
		/**
		* The components of this vector are rounded towards zero (up if negative,
		* down if positive) to an integer value.
		*
		* @return {Vector2} A reference to this vector.
		*/
		roundToZero() {
			this.x = Math.trunc(this.x);
			this.y = Math.trunc(this.y);
			return this;
		}
		/**
		* Inverts this vector - i.e. sets x = -x and y = -y.
		*
		* @return {Vector2} A reference to this vector.
		*/
		negate() {
			this.x = -this.x;
			this.y = -this.y;
			return this;
		}
		/**
		* Calculates the dot product of the given vector with this instance.
		*
		* @param {Vector2} v - The vector to compute the dot product with.
		* @return {number} The result of the dot product.
		*/
		dot(v) {
			return this.x * v.x + this.y * v.y;
		}
		/**
		* Calculates the cross product of the given vector with this instance.
		*
		* @param {Vector2} v - The vector to compute the cross product with.
		* @return {number} The result of the cross product.
		*/
		cross(v) {
			return this.x * v.y - this.y * v.x;
		}
		/**
		* Computes the square of the Euclidean length (straight-line length) from
		* (0, 0) to (x, y). If you are comparing the lengths of vectors, you should
		* compare the length squared instead as it is slightly more efficient to calculate.
		*
		* @return {number} The square length of this vector.
		*/
		lengthSq() {
			return this.x * this.x + this.y * this.y;
		}
		/**
		* Computes the  Euclidean length (straight-line length) from (0, 0) to (x, y).
		*
		* @return {number} The length of this vector.
		*/
		length() {
			return Math.sqrt(this.x * this.x + this.y * this.y);
		}
		/**
		* Computes the Manhattan length of this vector.
		*
		* @return {number} The length of this vector.
		*/
		manhattanLength() {
			return Math.abs(this.x) + Math.abs(this.y);
		}
		/**
		* Converts this vector to a unit vector - that is, sets it equal to a vector
		* with the same direction as this one, but with a vector length of `1`.
		*
		* @return {Vector2} A reference to this vector.
		*/
		normalize() {
			return this.divideScalar(this.length() || 1);
		}
		/**
		* Computes the angle in radians of this vector with respect to the positive x-axis.
		*
		* @return {number} The angle in radians.
		*/
		angle() {
			return Math.atan2(-this.y, -this.x) + Math.PI;
		}
		/**
		* Returns the angle between the given vector and this instance in radians.
		*
		* @param {Vector2} v - The vector to compute the angle with.
		* @return {number} The angle in radians.
		*/
		angleTo(v) {
			const denominator = Math.sqrt(this.lengthSq() * v.lengthSq());
			if (denominator === 0) return Math.PI / 2;
			const theta = this.dot(v) / denominator;
			return Math.acos(clamp(theta, -1, 1));
		}
		/**
		* Computes the distance from the given vector to this instance.
		*
		* @param {Vector2} v - The vector to compute the distance to.
		* @return {number} The distance.
		*/
		distanceTo(v) {
			return Math.sqrt(this.distanceToSquared(v));
		}
		/**
		* Computes the squared distance from the given vector to this instance.
		* If you are just comparing the distance with another distance, you should compare
		* the distance squared instead as it is slightly more efficient to calculate.
		*
		* @param {Vector2} v - The vector to compute the squared distance to.
		* @return {number} The squared distance.
		*/
		distanceToSquared(v) {
			const dx = this.x - v.x, dy = this.y - v.y;
			return dx * dx + dy * dy;
		}
		/**
		* Computes the Manhattan distance from the given vector to this instance.
		*
		* @param {Vector2} v - The vector to compute the Manhattan distance to.
		* @return {number} The Manhattan distance.
		*/
		manhattanDistanceTo(v) {
			return Math.abs(this.x - v.x) + Math.abs(this.y - v.y);
		}
		/**
		* Sets this vector to a vector with the same direction as this one, but
		* with the specified length.
		*
		* @param {number} length - The new length of this vector.
		* @return {Vector2} A reference to this vector.
		*/
		setLength(length) {
			return this.normalize().multiplyScalar(length);
		}
		/**
		* Linearly interpolates between the given vector and this instance, where
		* alpha is the percent distance along the line - alpha = 0 will be this
		* vector, and alpha = 1 will be the given one.
		*
		* @param {Vector2} v - The vector to interpolate towards.
		* @param {number} alpha - The interpolation factor, typically in the closed interval `[0, 1]`.
		* @return {Vector2} A reference to this vector.
		*/
		lerp(v, alpha) {
			this.x += (v.x - this.x) * alpha;
			this.y += (v.y - this.y) * alpha;
			return this;
		}
		/**
		* Linearly interpolates between the given vectors, where alpha is the percent
		* distance along the line - alpha = 0 will be first vector, and alpha = 1 will
		* be the second one. The result is stored in this instance.
		*
		* @param {Vector2} v1 - The first vector.
		* @param {Vector2} v2 - The second vector.
		* @param {number} alpha - The interpolation factor, typically in the closed interval `[0, 1]`.
		* @return {Vector2} A reference to this vector.
		*/
		lerpVectors(v1, v2, alpha) {
			this.x = v1.x + (v2.x - v1.x) * alpha;
			this.y = v1.y + (v2.y - v1.y) * alpha;
			return this;
		}
		/**
		* Returns `true` if this vector is equal with the given one.
		*
		* @param {Vector2} v - The vector to test for equality.
		* @return {boolean} Whether this vector is equal with the given one.
		*/
		equals(v) {
			return v.x === this.x && v.y === this.y;
		}
		/**
		* Sets this vector's x value to be `array[ offset ]` and y
		* value to be `array[ offset + 1 ]`.
		*
		* @param {Array<number>} array - An array holding the vector component values.
		* @param {number} [offset=0] - The offset into the array.
		* @return {Vector2} A reference to this vector.
		*/
		fromArray(array, offset = 0) {
			this.x = array[offset];
			this.y = array[offset + 1];
			return this;
		}
		/**
		* Writes the components of this vector to the given array. If no array is provided,
		* the method returns a new instance.
		*
		* @param {Array<number>} [array=[]] - The target array holding the vector components.
		* @param {number} [offset=0] - Index of the first element in the array.
		* @return {Array<number>} The vector components.
		*/
		toArray(array = [], offset = 0) {
			array[offset] = this.x;
			array[offset + 1] = this.y;
			return array;
		}
		/**
		* Sets the components of this vector from the given buffer attribute.
		*
		* @param {BufferAttribute} attribute - The buffer attribute holding vector data.
		* @param {number} index - The index into the attribute.
		* @return {Vector2} A reference to this vector.
		*/
		fromBufferAttribute(attribute, index) {
			this.x = attribute.getX(index);
			this.y = attribute.getY(index);
			return this;
		}
		/**
		* Rotates this vector around the given center by the given angle.
		*
		* @param {Vector2} center - The point around which to rotate.
		* @param {number} angle - The angle to rotate, in radians.
		* @return {Vector2} A reference to this vector.
		*/
		rotateAround(center, angle) {
			const c = Math.cos(angle), s = Math.sin(angle);
			const x = this.x - center.x;
			const y = this.y - center.y;
			this.x = x * c - y * s + center.x;
			this.y = x * s + y * c + center.y;
			return this;
		}
		/**
		* Sets each component of this vector to a pseudo-random value between `0` and
		* `1`, excluding `1`.
		*
		* @return {Vector2} A reference to this vector.
		*/
		random() {
			this.x = Math.random();
			this.y = Math.random();
			return this;
		}
		*[Symbol.iterator]() {
			yield this.x;
			yield this.y;
		}
	};
	/**
	* Class for representing a Quaternion. Quaternions are used in three.js to represent rotations.
	*
	* Iterating through a vector instance will yield its components `(x, y, z, w)` in
	* the corresponding order.
	*
	* Note that three.js expects Quaternions to be normalized.
	* ```js
	* const quaternion = new THREE.Quaternion();
	* quaternion.setFromAxisAngle( new THREE.Vector3( 0, 1, 0 ), Math.PI / 2 );
	*
	* const vector = new THREE.Vector3( 1, 0, 0 );
	* vector.applyQuaternion( quaternion );
	* ```
	*/
	var Quaternion = class {
		/**
		* Constructs a new quaternion.
		*
		* @param {number} [x=0] - The x value of this quaternion.
		* @param {number} [y=0] - The y value of this quaternion.
		* @param {number} [z=0] - The z value of this quaternion.
		* @param {number} [w=1] - The w value of this quaternion.
		*/
		constructor(x = 0, y = 0, z = 0, w = 1) {
			/**
			* This flag can be used for type testing.
			*
			* @type {boolean}
			* @readonly
			* @default true
			*/
			this.isQuaternion = true;
			this._x = x;
			this._y = y;
			this._z = z;
			this._w = w;
		}
		/**
		* Interpolates between two quaternions via SLERP. This implementation assumes the
		* quaternion data are managed in flat arrays.
		*
		* @param {Array<number>} dst - The destination array.
		* @param {number} dstOffset - An offset into the destination array.
		* @param {Array<number>} src0 - The source array of the first quaternion.
		* @param {number} srcOffset0 - An offset into the first source array.
		* @param {Array<number>} src1 -  The source array of the second quaternion.
		* @param {number} srcOffset1 - An offset into the second source array.
		* @param {number} t - The interpolation factor. A value in the range `[0,1]` will interpolate. A value outside the range `[0,1]` will extrapolate.
		* @see {@link Quaternion#slerp}
		*/
		static slerpFlat(dst, dstOffset, src0, srcOffset0, src1, srcOffset1, t) {
			let x0 = src0[srcOffset0 + 0], y0 = src0[srcOffset0 + 1], z0 = src0[srcOffset0 + 2], w0 = src0[srcOffset0 + 3];
			let x1 = src1[srcOffset1 + 0], y1 = src1[srcOffset1 + 1], z1 = src1[srcOffset1 + 2], w1 = src1[srcOffset1 + 3];
			if (w0 !== w1 || x0 !== x1 || y0 !== y1 || z0 !== z1) {
				let dot = x0 * x1 + y0 * y1 + z0 * z1 + w0 * w1;
				if (dot < 0) {
					x1 = -x1;
					y1 = -y1;
					z1 = -z1;
					w1 = -w1;
					dot = -dot;
				}
				let s = 1 - t;
				if (dot < .9995) {
					const theta = Math.acos(dot);
					const sin = Math.sin(theta);
					s = Math.sin(s * theta) / sin;
					t = Math.sin(t * theta) / sin;
					x0 = x0 * s + x1 * t;
					y0 = y0 * s + y1 * t;
					z0 = z0 * s + z1 * t;
					w0 = w0 * s + w1 * t;
				} else {
					x0 = x0 * s + x1 * t;
					y0 = y0 * s + y1 * t;
					z0 = z0 * s + z1 * t;
					w0 = w0 * s + w1 * t;
					const f = 1 / Math.sqrt(x0 * x0 + y0 * y0 + z0 * z0 + w0 * w0);
					x0 *= f;
					y0 *= f;
					z0 *= f;
					w0 *= f;
				}
			}
			dst[dstOffset] = x0;
			dst[dstOffset + 1] = y0;
			dst[dstOffset + 2] = z0;
			dst[dstOffset + 3] = w0;
		}
		/**
		* Multiplies two quaternions. This implementation assumes the quaternion data are managed
		* in flat arrays.
		*
		* @param {Array<number>} dst - The destination array.
		* @param {number} dstOffset - An offset into the destination array.
		* @param {Array<number>} src0 - The source array of the first quaternion.
		* @param {number} srcOffset0 - An offset into the first source array.
		* @param {Array<number>} src1 -  The source array of the second quaternion.
		* @param {number} srcOffset1 - An offset into the second source array.
		* @return {Array<number>} The destination array.
		* @see {@link Quaternion#multiplyQuaternions}.
		*/
		static multiplyQuaternionsFlat(dst, dstOffset, src0, srcOffset0, src1, srcOffset1) {
			const x0 = src0[srcOffset0];
			const y0 = src0[srcOffset0 + 1];
			const z0 = src0[srcOffset0 + 2];
			const w0 = src0[srcOffset0 + 3];
			const x1 = src1[srcOffset1];
			const y1 = src1[srcOffset1 + 1];
			const z1 = src1[srcOffset1 + 2];
			const w1 = src1[srcOffset1 + 3];
			dst[dstOffset] = x0 * w1 + w0 * x1 + y0 * z1 - z0 * y1;
			dst[dstOffset + 1] = y0 * w1 + w0 * y1 + z0 * x1 - x0 * z1;
			dst[dstOffset + 2] = z0 * w1 + w0 * z1 + x0 * y1 - y0 * x1;
			dst[dstOffset + 3] = w0 * w1 - x0 * x1 - y0 * y1 - z0 * z1;
			return dst;
		}
		/**
		* The x value of this quaternion.
		*
		* @type {number}
		* @default 0
		*/
		get x() {
			return this._x;
		}
		set x(value) {
			this._x = value;
			this._onChangeCallback();
		}
		/**
		* The y value of this quaternion.
		*
		* @type {number}
		* @default 0
		*/
		get y() {
			return this._y;
		}
		set y(value) {
			this._y = value;
			this._onChangeCallback();
		}
		/**
		* The z value of this quaternion.
		*
		* @type {number}
		* @default 0
		*/
		get z() {
			return this._z;
		}
		set z(value) {
			this._z = value;
			this._onChangeCallback();
		}
		/**
		* The w value of this quaternion.
		*
		* @type {number}
		* @default 1
		*/
		get w() {
			return this._w;
		}
		set w(value) {
			this._w = value;
			this._onChangeCallback();
		}
		/**
		* Sets the quaternion components.
		*
		* @param {number} x - The x value of this quaternion.
		* @param {number} y - The y value of this quaternion.
		* @param {number} z - The z value of this quaternion.
		* @param {number} w - The w value of this quaternion.
		* @return {Quaternion} A reference to this quaternion.
		*/
		set(x, y, z, w) {
			this._x = x;
			this._y = y;
			this._z = z;
			this._w = w;
			this._onChangeCallback();
			return this;
		}
		/**
		* Returns a new quaternion with copied values from this instance.
		*
		* @return {Quaternion} A clone of this instance.
		*/
		clone() {
			return new this.constructor(this._x, this._y, this._z, this._w);
		}
		/**
		* Copies the values of the given quaternion to this instance.
		*
		* @param {Quaternion} quaternion - The quaternion to copy.
		* @return {Quaternion} A reference to this quaternion.
		*/
		copy(quaternion) {
			this._x = quaternion.x;
			this._y = quaternion.y;
			this._z = quaternion.z;
			this._w = quaternion.w;
			this._onChangeCallback();
			return this;
		}
		/**
		* Sets this quaternion from the rotation specified by the given
		* Euler angles.
		*
		* @param {Euler} euler - The Euler angles.
		* @param {boolean} [update=true] - Whether the internal `onChange` callback should be executed or not.
		* @return {Quaternion} A reference to this quaternion.
		*/
		setFromEuler(euler, update = true) {
			const x = euler._x, y = euler._y, z = euler._z, order = euler._order;
			const cos = Math.cos;
			const sin = Math.sin;
			const c1 = cos(x / 2);
			const c2 = cos(y / 2);
			const c3 = cos(z / 2);
			const s1 = sin(x / 2);
			const s2 = sin(y / 2);
			const s3 = sin(z / 2);
			switch (order) {
				case "XYZ":
					this._x = s1 * c2 * c3 + c1 * s2 * s3;
					this._y = c1 * s2 * c3 - s1 * c2 * s3;
					this._z = c1 * c2 * s3 + s1 * s2 * c3;
					this._w = c1 * c2 * c3 - s1 * s2 * s3;
					break;
				case "YXZ":
					this._x = s1 * c2 * c3 + c1 * s2 * s3;
					this._y = c1 * s2 * c3 - s1 * c2 * s3;
					this._z = c1 * c2 * s3 - s1 * s2 * c3;
					this._w = c1 * c2 * c3 + s1 * s2 * s3;
					break;
				case "ZXY":
					this._x = s1 * c2 * c3 - c1 * s2 * s3;
					this._y = c1 * s2 * c3 + s1 * c2 * s3;
					this._z = c1 * c2 * s3 + s1 * s2 * c3;
					this._w = c1 * c2 * c3 - s1 * s2 * s3;
					break;
				case "ZYX":
					this._x = s1 * c2 * c3 - c1 * s2 * s3;
					this._y = c1 * s2 * c3 + s1 * c2 * s3;
					this._z = c1 * c2 * s3 - s1 * s2 * c3;
					this._w = c1 * c2 * c3 + s1 * s2 * s3;
					break;
				case "YZX":
					this._x = s1 * c2 * c3 + c1 * s2 * s3;
					this._y = c1 * s2 * c3 + s1 * c2 * s3;
					this._z = c1 * c2 * s3 - s1 * s2 * c3;
					this._w = c1 * c2 * c3 - s1 * s2 * s3;
					break;
				case "XZY":
					this._x = s1 * c2 * c3 - c1 * s2 * s3;
					this._y = c1 * s2 * c3 - s1 * c2 * s3;
					this._z = c1 * c2 * s3 + s1 * s2 * c3;
					this._w = c1 * c2 * c3 + s1 * s2 * s3;
					break;
				default: warn("Quaternion: .setFromEuler() encountered an unknown order: " + order);
			}
			if (update === true) this._onChangeCallback();
			return this;
		}
		/**
		* Sets this quaternion from the given axis and angle.
		*
		* @param {Vector3} axis - The normalized axis.
		* @param {number} angle - The angle in radians.
		* @return {Quaternion} A reference to this quaternion.
		*/
		setFromAxisAngle(axis, angle) {
			const halfAngle = angle / 2, s = Math.sin(halfAngle);
			this._x = axis.x * s;
			this._y = axis.y * s;
			this._z = axis.z * s;
			this._w = Math.cos(halfAngle);
			this._onChangeCallback();
			return this;
		}
		/**
		* Sets this quaternion from the given rotation matrix.
		*
		* @param {Matrix4} m - A 4x4 matrix of which the upper 3x3 of matrix is a pure rotation matrix (i.e. unscaled).
		* @return {Quaternion} A reference to this quaternion.
		*/
		setFromRotationMatrix(m) {
			const te = m.elements, m11 = te[0], m12 = te[4], m13 = te[8], m21 = te[1], m22 = te[5], m23 = te[9], m31 = te[2], m32 = te[6], m33 = te[10], trace = m11 + m22 + m33;
			if (trace > 0) {
				const s = .5 / Math.sqrt(trace + 1);
				this._w = .25 / s;
				this._x = (m32 - m23) * s;
				this._y = (m13 - m31) * s;
				this._z = (m21 - m12) * s;
			} else if (m11 > m22 && m11 > m33) {
				const s = 2 * Math.sqrt(1 + m11 - m22 - m33);
				this._w = (m32 - m23) / s;
				this._x = .25 * s;
				this._y = (m12 + m21) / s;
				this._z = (m13 + m31) / s;
			} else if (m22 > m33) {
				const s = 2 * Math.sqrt(1 + m22 - m11 - m33);
				this._w = (m13 - m31) / s;
				this._x = (m12 + m21) / s;
				this._y = .25 * s;
				this._z = (m23 + m32) / s;
			} else {
				const s = 2 * Math.sqrt(1 + m33 - m11 - m22);
				this._w = (m21 - m12) / s;
				this._x = (m13 + m31) / s;
				this._y = (m23 + m32) / s;
				this._z = .25 * s;
			}
			this._onChangeCallback();
			return this;
		}
		/**
		* Sets this quaternion to the rotation required to rotate the direction vector
		* `vFrom` to the direction vector `vTo`.
		*
		* @param {Vector3} vFrom - The first (normalized) direction vector.
		* @param {Vector3} vTo - The second (normalized) direction vector.
		* @return {Quaternion} A reference to this quaternion.
		*/
		setFromUnitVectors(vFrom, vTo) {
			let r = vFrom.dot(vTo) + 1;
			if (r < 1e-8) {
				r = 0;
				if (Math.abs(vFrom.x) > Math.abs(vFrom.z)) {
					this._x = -vFrom.y;
					this._y = vFrom.x;
					this._z = 0;
					this._w = r;
				} else {
					this._x = 0;
					this._y = -vFrom.z;
					this._z = vFrom.y;
					this._w = r;
				}
			} else {
				this._x = vFrom.y * vTo.z - vFrom.z * vTo.y;
				this._y = vFrom.z * vTo.x - vFrom.x * vTo.z;
				this._z = vFrom.x * vTo.y - vFrom.y * vTo.x;
				this._w = r;
			}
			return this.normalize();
		}
		/**
		* Returns the angle between this quaternion and the given one in radians.
		*
		* @param {Quaternion} q - The quaternion to compute the angle with.
		* @return {number} The angle in radians.
		*/
		angleTo(q) {
			return 2 * Math.acos(Math.abs(clamp(this.dot(q), -1, 1)));
		}
		/**
		* Rotates this quaternion by a given angular step to the given quaternion.
		* The method ensures that the final quaternion will not overshoot `q`.
		*
		* @param {Quaternion} q - The target quaternion.
		* @param {number} step - The angular step in radians.
		* @return {Quaternion} A reference to this quaternion.
		*/
		rotateTowards(q, step) {
			const angle = this.angleTo(q);
			if (angle === 0) return this;
			const t = Math.min(1, step / angle);
			this.slerp(q, t);
			return this;
		}
		/**
		* Sets this quaternion to the identity quaternion; that is, to the
		* quaternion that represents "no rotation".
		*
		* @return {Quaternion} A reference to this quaternion.
		*/
		identity() {
			return this.set(0, 0, 0, 1);
		}
		/**
		* Inverts this quaternion via {@link Quaternion#conjugate}. The
		* quaternion is assumed to have unit length.
		*
		* @return {Quaternion} A reference to this quaternion.
		*/
		invert() {
			return this.conjugate();
		}
		/**
		* Returns the rotational conjugate of this quaternion. The conjugate of a
		* quaternion represents the same rotation in the opposite direction about
		* the rotational axis.
		*
		* @return {Quaternion} A reference to this quaternion.
		*/
		conjugate() {
			this._x *= -1;
			this._y *= -1;
			this._z *= -1;
			this._onChangeCallback();
			return this;
		}
		/**
		* Calculates the dot product of this quaternion and the given one.
		*
		* @param {Quaternion} v - The quaternion to compute the dot product with.
		* @return {number} The result of the dot product.
		*/
		dot(v) {
			return this._x * v._x + this._y * v._y + this._z * v._z + this._w * v._w;
		}
		/**
		* Computes the squared Euclidean length (straight-line length) of this quaternion,
		* considered as a 4 dimensional vector. This can be useful if you are comparing the
		* lengths of two quaternions, as this is a slightly more efficient calculation than
		* {@link Quaternion#length}.
		*
		* @return {number} The squared Euclidean length.
		*/
		lengthSq() {
			return this._x * this._x + this._y * this._y + this._z * this._z + this._w * this._w;
		}
		/**
		* Computes the Euclidean length (straight-line length) of this quaternion,
		* considered as a 4 dimensional vector.
		*
		* @return {number} The Euclidean length.
		*/
		length() {
			return Math.sqrt(this._x * this._x + this._y * this._y + this._z * this._z + this._w * this._w);
		}
		/**
		* Normalizes this quaternion - that is, calculated the quaternion that performs
		* the same rotation as this one, but has a length equal to `1`.
		*
		* @return {Quaternion} A reference to this quaternion.
		*/
		normalize() {
			let l = this.length();
			if (l === 0) {
				this._x = 0;
				this._y = 0;
				this._z = 0;
				this._w = 1;
			} else {
				l = 1 / l;
				this._x = this._x * l;
				this._y = this._y * l;
				this._z = this._z * l;
				this._w = this._w * l;
			}
			this._onChangeCallback();
			return this;
		}
		/**
		* Multiplies this quaternion by the given one.
		*
		* @param {Quaternion} q - The quaternion.
		* @return {Quaternion} A reference to this quaternion.
		*/
		multiply(q) {
			return this.multiplyQuaternions(this, q);
		}
		/**
		* Pre-multiplies this quaternion by the given one.
		*
		* @param {Quaternion} q - The quaternion.
		* @return {Quaternion} A reference to this quaternion.
		*/
		premultiply(q) {
			return this.multiplyQuaternions(q, this);
		}
		/**
		* Multiplies the given quaternions and stores the result in this instance.
		*
		* @param {Quaternion} a - The first quaternion.
		* @param {Quaternion} b - The second quaternion.
		* @return {Quaternion} A reference to this quaternion.
		*/
		multiplyQuaternions(a, b) {
			const qax = a._x, qay = a._y, qaz = a._z, qaw = a._w;
			const qbx = b._x, qby = b._y, qbz = b._z, qbw = b._w;
			this._x = qax * qbw + qaw * qbx + qay * qbz - qaz * qby;
			this._y = qay * qbw + qaw * qby + qaz * qbx - qax * qbz;
			this._z = qaz * qbw + qaw * qbz + qax * qby - qay * qbx;
			this._w = qaw * qbw - qax * qbx - qay * qby - qaz * qbz;
			this._onChangeCallback();
			return this;
		}
		/**
		* Performs a spherical linear interpolation between this quaternion and the target quaternion.
		*
		* @param {Quaternion} qb - The target quaternion.
		* @param {number} t - The interpolation factor. A value in the range `[0,1]` will interpolate. A value outside the range `[0,1]` will extrapolate.
		* @return {Quaternion} A reference to this quaternion.
		*/
		slerp(qb, t) {
			let x = qb._x, y = qb._y, z = qb._z, w = qb._w;
			let dot = this.dot(qb);
			if (dot < 0) {
				x = -x;
				y = -y;
				z = -z;
				w = -w;
				dot = -dot;
			}
			let s = 1 - t;
			if (dot < .9995) {
				const theta = Math.acos(dot);
				const sin = Math.sin(theta);
				s = Math.sin(s * theta) / sin;
				t = Math.sin(t * theta) / sin;
				this._x = this._x * s + x * t;
				this._y = this._y * s + y * t;
				this._z = this._z * s + z * t;
				this._w = this._w * s + w * t;
				this._onChangeCallback();
			} else {
				this._x = this._x * s + x * t;
				this._y = this._y * s + y * t;
				this._z = this._z * s + z * t;
				this._w = this._w * s + w * t;
				this.normalize();
			}
			return this;
		}
		/**
		* Performs a spherical linear interpolation between the given quaternions
		* and stores the result in this quaternion.
		*
		* @param {Quaternion} qa - The source quaternion.
		* @param {Quaternion} qb - The target quaternion.
		* @param {number} t - The interpolation factor in the closed interval `[0, 1]`.
		* @return {Quaternion} A reference to this quaternion.
		*/
		slerpQuaternions(qa, qb, t) {
			return this.copy(qa).slerp(qb, t);
		}
		/**
		* Sets this quaternion to a uniformly random, normalized quaternion.
		*
		* @return {Quaternion} A reference to this quaternion.
		*/
		random() {
			const theta1 = 2 * Math.PI * Math.random();
			const theta2 = 2 * Math.PI * Math.random();
			const x0 = Math.random();
			const r1 = Math.sqrt(1 - x0);
			const r2 = Math.sqrt(x0);
			return this.set(r1 * Math.sin(theta1), r1 * Math.cos(theta1), r2 * Math.sin(theta2), r2 * Math.cos(theta2));
		}
		/**
		* Returns `true` if this quaternion is equal with the given one.
		*
		* @param {Quaternion} quaternion - The quaternion to test for equality.
		* @return {boolean} Whether this quaternion is equal with the given one.
		*/
		equals(quaternion) {
			return quaternion._x === this._x && quaternion._y === this._y && quaternion._z === this._z && quaternion._w === this._w;
		}
		/**
		* Sets this quaternion's components from the given array.
		*
		* @param {Array<number>} array - An array holding the quaternion component values.
		* @param {number} [offset=0] - The offset into the array.
		* @return {Quaternion} A reference to this quaternion.
		*/
		fromArray(array, offset = 0) {
			this._x = array[offset];
			this._y = array[offset + 1];
			this._z = array[offset + 2];
			this._w = array[offset + 3];
			this._onChangeCallback();
			return this;
		}
		/**
		* Writes the components of this quaternion to the given array. If no array is provided,
		* the method returns a new instance.
		*
		* @param {Array<number>} [array=[]] - The target array holding the quaternion components.
		* @param {number} [offset=0] - Index of the first element in the array.
		* @return {Array<number>} The quaternion components.
		*/
		toArray(array = [], offset = 0) {
			array[offset] = this._x;
			array[offset + 1] = this._y;
			array[offset + 2] = this._z;
			array[offset + 3] = this._w;
			return array;
		}
		/**
		* Sets the components of this quaternion from the given buffer attribute.
		*
		* @param {BufferAttribute} attribute - The buffer attribute holding quaternion data.
		* @param {number} index - The index into the attribute.
		* @return {Quaternion} A reference to this quaternion.
		*/
		fromBufferAttribute(attribute, index) {
			this._x = attribute.getX(index);
			this._y = attribute.getY(index);
			this._z = attribute.getZ(index);
			this._w = attribute.getW(index);
			this._onChangeCallback();
			return this;
		}
		/**
		* This methods defines the serialization result of this class. Returns the
		* numerical elements of this quaternion in an array of format `[x, y, z, w]`.
		*
		* @return {Array<number>} The serialized quaternion.
		*/
		toJSON() {
			return this.toArray();
		}
		_onChange(callback) {
			this._onChangeCallback = callback;
			return this;
		}
		_onChangeCallback() {}
		*[Symbol.iterator]() {
			yield this._x;
			yield this._y;
			yield this._z;
			yield this._w;
		}
	};
	/**
	* Class representing a 3D vector. A 3D vector is an ordered triplet of numbers
	* (labeled x, y and z), which can be used to represent a number of things, such as:
	*
	* - A point in 3D space.
	* - A direction and length in 3D space. In three.js the length will
	* always be the Euclidean distance(straight-line distance) from `(0, 0, 0)` to `(x, y, z)`
	* and the direction is also measured from `(0, 0, 0)` towards `(x, y, z)`.
	* - Any arbitrary ordered triplet of numbers.
	*
	* There are other things a 3D vector can be used to represent, such as
	* momentum vectors and so on, however these are the most
	* common uses in three.js.
	*
	* Iterating through a vector instance will yield its components `(x, y, z)` in
	* the corresponding order.
	* ```js
	* const a = new THREE.Vector3( 0, 1, 0 );
	*
	* //no arguments; will be initialised to (0, 0, 0)
	* const b = new THREE.Vector3( );
	*
	* const d = a.distanceTo( b );
	* ```
	*/
	var Vector3 = class Vector3 {
		static {
			/**
			* This flag can be used for type testing.
			*
			* @type {boolean}
			* @readonly
			* @default true
			*/
			Vector3.prototype.isVector3 = true;
		}
		/**
		* Constructs a new 3D vector.
		*
		* @param {number} [x=0] - The x value of this vector.
		* @param {number} [y=0] - The y value of this vector.
		* @param {number} [z=0] - The z value of this vector.
		*/
		constructor(x = 0, y = 0, z = 0) {
			/**
			* The x value of this vector.
			*
			* @type {number}
			*/
			this.x = x;
			/**
			* The y value of this vector.
			*
			* @type {number}
			*/
			this.y = y;
			/**
			* The z value of this vector.
			*
			* @type {number}
			*/
			this.z = z;
		}
		/**
		* Sets the vector components.
		*
		* @param {number} x - The value of the x component.
		* @param {number} y - The value of the y component.
		* @param {number} z - The value of the z component.
		* @return {Vector3} A reference to this vector.
		*/
		set(x, y, z) {
			if (z === void 0) z = this.z;
			this.x = x;
			this.y = y;
			this.z = z;
			return this;
		}
		/**
		* Sets the vector components to the same value.
		*
		* @param {number} scalar - The value to set for all vector components.
		* @return {Vector3} A reference to this vector.
		*/
		setScalar(scalar) {
			this.x = scalar;
			this.y = scalar;
			this.z = scalar;
			return this;
		}
		/**
		* Sets the vector's x component to the given value.
		*
		* @param {number} x - The value to set.
		* @return {Vector3} A reference to this vector.
		*/
		setX(x) {
			this.x = x;
			return this;
		}
		/**
		* Sets the vector's y component to the given value.
		*
		* @param {number} y - The value to set.
		* @return {Vector3} A reference to this vector.
		*/
		setY(y) {
			this.y = y;
			return this;
		}
		/**
		* Sets the vector's z component to the given value.
		*
		* @param {number} z - The value to set.
		* @return {Vector3} A reference to this vector.
		*/
		setZ(z) {
			this.z = z;
			return this;
		}
		/**
		* Allows to set a vector component with an index.
		*
		* @param {number} index - The component index. `0` equals to x, `1` equals to y, `2` equals to z.
		* @param {number} value - The value to set.
		* @return {Vector3} A reference to this vector.
		*/
		setComponent(index, value) {
			switch (index) {
				case 0:
					this.x = value;
					break;
				case 1:
					this.y = value;
					break;
				case 2:
					this.z = value;
					break;
				default: throw new Error("THREE.Vector3: index is out of range: " + index);
			}
			return this;
		}
		/**
		* Returns the value of the vector component which matches the given index.
		*
		* @param {number} index - The component index. `0` equals to x, `1` equals to y, `2` equals to z.
		* @return {number} A vector component value.
		*/
		getComponent(index) {
			switch (index) {
				case 0: return this.x;
				case 1: return this.y;
				case 2: return this.z;
				default: throw new Error("THREE.Vector3: index is out of range: " + index);
			}
		}
		/**
		* Returns a new vector with copied values from this instance.
		*
		* @return {Vector3} A clone of this instance.
		*/
		clone() {
			return new this.constructor(this.x, this.y, this.z);
		}
		/**
		* Copies the values of the given vector to this instance.
		*
		* @param {Vector3} v - The vector to copy.
		* @return {Vector3} A reference to this vector.
		*/
		copy(v) {
			this.x = v.x;
			this.y = v.y;
			this.z = v.z;
			return this;
		}
		/**
		* Adds the given vector to this instance.
		*
		* @param {Vector3} v - The vector to add.
		* @return {Vector3} A reference to this vector.
		*/
		add(v) {
			this.x += v.x;
			this.y += v.y;
			this.z += v.z;
			return this;
		}
		/**
		* Adds the given scalar value to all components of this instance.
		*
		* @param {number} s - The scalar to add.
		* @return {Vector3} A reference to this vector.
		*/
		addScalar(s) {
			this.x += s;
			this.y += s;
			this.z += s;
			return this;
		}
		/**
		* Adds the given vectors and stores the result in this instance.
		*
		* @param {Vector3} a - The first vector.
		* @param {Vector3} b - The second vector.
		* @return {Vector3} A reference to this vector.
		*/
		addVectors(a, b) {
			this.x = a.x + b.x;
			this.y = a.y + b.y;
			this.z = a.z + b.z;
			return this;
		}
		/**
		* Adds the given vector scaled by the given factor to this instance.
		*
		* @param {Vector3|Vector4} v - The vector.
		* @param {number} s - The factor that scales `v`.
		* @return {Vector3} A reference to this vector.
		*/
		addScaledVector(v, s) {
			this.x += v.x * s;
			this.y += v.y * s;
			this.z += v.z * s;
			return this;
		}
		/**
		* Subtracts the given vector from this instance.
		*
		* @param {Vector3} v - The vector to subtract.
		* @return {Vector3} A reference to this vector.
		*/
		sub(v) {
			this.x -= v.x;
			this.y -= v.y;
			this.z -= v.z;
			return this;
		}
		/**
		* Subtracts the given scalar value from all components of this instance.
		*
		* @param {number} s - The scalar to subtract.
		* @return {Vector3} A reference to this vector.
		*/
		subScalar(s) {
			this.x -= s;
			this.y -= s;
			this.z -= s;
			return this;
		}
		/**
		* Subtracts the given vectors and stores the result in this instance.
		*
		* @param {Vector3} a - The first vector.
		* @param {Vector3} b - The second vector.
		* @return {Vector3} A reference to this vector.
		*/
		subVectors(a, b) {
			this.x = a.x - b.x;
			this.y = a.y - b.y;
			this.z = a.z - b.z;
			return this;
		}
		/**
		* Multiplies the given vector with this instance.
		*
		* @param {Vector3} v - The vector to multiply.
		* @return {Vector3} A reference to this vector.
		*/
		multiply(v) {
			this.x *= v.x;
			this.y *= v.y;
			this.z *= v.z;
			return this;
		}
		/**
		* Multiplies the given scalar value with all components of this instance.
		*
		* @param {number} scalar - The scalar to multiply.
		* @return {Vector3} A reference to this vector.
		*/
		multiplyScalar(scalar) {
			this.x *= scalar;
			this.y *= scalar;
			this.z *= scalar;
			return this;
		}
		/**
		* Multiplies the given vectors and stores the result in this instance.
		*
		* @param {Vector3} a - The first vector.
		* @param {Vector3} b - The second vector.
		* @return {Vector3} A reference to this vector.
		*/
		multiplyVectors(a, b) {
			this.x = a.x * b.x;
			this.y = a.y * b.y;
			this.z = a.z * b.z;
			return this;
		}
		/**
		* Applies the given Euler rotation to this vector.
		*
		* @param {Euler} euler - The Euler angles.
		* @return {Vector3} A reference to this vector.
		*/
		applyEuler(euler) {
			return this.applyQuaternion(_quaternion$5.setFromEuler(euler));
		}
		/**
		* Applies a rotation specified by an axis and an angle to this vector.
		*
		* @param {Vector3} axis - A normalized vector representing the rotation axis.
		* @param {number} angle - The angle in radians.
		* @return {Vector3} A reference to this vector.
		*/
		applyAxisAngle(axis, angle) {
			return this.applyQuaternion(_quaternion$5.setFromAxisAngle(axis, angle));
		}
		/**
		* Multiplies this vector with the given 3x3 matrix.
		*
		* @param {Matrix3} m - The 3x3 matrix.
		* @return {Vector3} A reference to this vector.
		*/
		applyMatrix3(m) {
			const x = this.x, y = this.y, z = this.z;
			const e = m.elements;
			this.x = e[0] * x + e[3] * y + e[6] * z;
			this.y = e[1] * x + e[4] * y + e[7] * z;
			this.z = e[2] * x + e[5] * y + e[8] * z;
			return this;
		}
		/**
		* Multiplies this vector by the given normal matrix and normalizes
		* the result.
		*
		* @param {Matrix3} m - The normal matrix.
		* @return {Vector3} A reference to this vector.
		*/
		applyNormalMatrix(m) {
			return this.applyMatrix3(m).normalize();
		}
		/**
		* Multiplies this vector (with an implicit 1 in the 4th dimension) by m, and
		* divides by perspective.
		*
		* @param {Matrix4} m - The matrix to apply.
		* @return {Vector3} A reference to this vector.
		*/
		applyMatrix4(m) {
			const x = this.x, y = this.y, z = this.z;
			const e = m.elements;
			const w = 1 / (e[3] * x + e[7] * y + e[11] * z + e[15]);
			this.x = (e[0] * x + e[4] * y + e[8] * z + e[12]) * w;
			this.y = (e[1] * x + e[5] * y + e[9] * z + e[13]) * w;
			this.z = (e[2] * x + e[6] * y + e[10] * z + e[14]) * w;
			return this;
		}
		/**
		* Applies the given Quaternion to this vector.
		*
		* @param {Quaternion} q - The Quaternion.
		* @return {Vector3} A reference to this vector.
		*/
		applyQuaternion(q) {
			const vx = this.x, vy = this.y, vz = this.z;
			const qx = q.x, qy = q.y, qz = q.z, qw = q.w;
			const tx = 2 * (qy * vz - qz * vy);
			const ty = 2 * (qz * vx - qx * vz);
			const tz = 2 * (qx * vy - qy * vx);
			this.x = vx + qw * tx + qy * tz - qz * ty;
			this.y = vy + qw * ty + qz * tx - qx * tz;
			this.z = vz + qw * tz + qx * ty - qy * tx;
			return this;
		}
		/**
		* Projects this vector from world space into the camera's normalized
		* device coordinate (NDC) space.
		*
		* @param {Camera} camera - The camera.
		* @return {Vector3} A reference to this vector.
		*/
		project(camera) {
			return this.applyMatrix4(camera.matrixWorldInverse).applyMatrix4(camera.projectionMatrix);
		}
		/**
		* Unprojects this vector from the camera's normalized device coordinate (NDC)
		* space into world space.
		*
		* @param {Camera} camera - The camera.
		* @return {Vector3} A reference to this vector.
		*/
		unproject(camera) {
			return this.applyMatrix4(camera.projectionMatrixInverse).applyMatrix4(camera.matrixWorld);
		}
		/**
		* Transforms this vector by the upper left 3x3 sub-matrix of the given 4x4 matrix,
		* and normalizes the result.
		*
		* @param {Matrix4} m - The matrix.
		* @return {Vector3} A reference to this vector.
		*/
		transformDirection(m) {
			const x = this.x, y = this.y, z = this.z;
			const e = m.elements;
			this.x = e[0] * x + e[4] * y + e[8] * z;
			this.y = e[1] * x + e[5] * y + e[9] * z;
			this.z = e[2] * x + e[6] * y + e[10] * z;
			return this.normalize();
		}
		/**
		* Divides this instance by the given vector.
		*
		* @param {Vector3} v - The vector to divide.
		* @return {Vector3} A reference to this vector.
		*/
		divide(v) {
			this.x /= v.x;
			this.y /= v.y;
			this.z /= v.z;
			return this;
		}
		/**
		* Divides this vector by the given scalar.
		*
		* @param {number} scalar - The scalar to divide.
		* @return {Vector3} A reference to this vector.
		*/
		divideScalar(scalar) {
			return this.multiplyScalar(1 / scalar);
		}
		/**
		* If this vector's x, y or z value is greater than the given vector's x, y or z
		* value, replace that value with the corresponding min value.
		*
		* @param {Vector3} v - The vector.
		* @return {Vector3} A reference to this vector.
		*/
		min(v) {
			this.x = Math.min(this.x, v.x);
			this.y = Math.min(this.y, v.y);
			this.z = Math.min(this.z, v.z);
			return this;
		}
		/**
		* If this vector's x, y or z value is less than the given vector's x, y or z
		* value, replace that value with the corresponding max value.
		*
		* @param {Vector3} v - The vector.
		* @return {Vector3} A reference to this vector.
		*/
		max(v) {
			this.x = Math.max(this.x, v.x);
			this.y = Math.max(this.y, v.y);
			this.z = Math.max(this.z, v.z);
			return this;
		}
		/**
		* If this vector's x, y or z value is greater than the max vector's x, y or z
		* value, it is replaced by the corresponding value.
		* If this vector's x, y or z value is less than the min vector's x, y or z value,
		* it is replaced by the corresponding value.
		*
		* @param {Vector3} min - The minimum x, y and z values.
		* @param {Vector3} max - The maximum x, y and z values in the desired range.
		* @return {Vector3} A reference to this vector.
		*/
		clamp(min, max) {
			this.x = clamp(this.x, min.x, max.x);
			this.y = clamp(this.y, min.y, max.y);
			this.z = clamp(this.z, min.z, max.z);
			return this;
		}
		/**
		* If this vector's x, y or z values are greater than the max value, they are
		* replaced by the max value.
		* If this vector's x, y or z values are less than the min value, they are
		* replaced by the min value.
		*
		* @param {number} minVal - The minimum value the components will be clamped to.
		* @param {number} maxVal - The maximum value the components will be clamped to.
		* @return {Vector3} A reference to this vector.
		*/
		clampScalar(minVal, maxVal) {
			this.x = clamp(this.x, minVal, maxVal);
			this.y = clamp(this.y, minVal, maxVal);
			this.z = clamp(this.z, minVal, maxVal);
			return this;
		}
		/**
		* If this vector's length is greater than the max value, it is replaced by
		* the max value.
		* If this vector's length is less than the min value, it is replaced by the
		* min value.
		*
		* @param {number} min - The minimum value the vector length will be clamped to.
		* @param {number} max - The maximum value the vector length will be clamped to.
		* @return {Vector3} A reference to this vector.
		*/
		clampLength(min, max) {
			const length = this.length();
			return this.divideScalar(length || 1).multiplyScalar(clamp(length, min, max));
		}
		/**
		* The components of this vector are rounded down to the nearest integer value.
		*
		* @return {Vector3} A reference to this vector.
		*/
		floor() {
			this.x = Math.floor(this.x);
			this.y = Math.floor(this.y);
			this.z = Math.floor(this.z);
			return this;
		}
		/**
		* The components of this vector are rounded up to the nearest integer value.
		*
		* @return {Vector3} A reference to this vector.
		*/
		ceil() {
			this.x = Math.ceil(this.x);
			this.y = Math.ceil(this.y);
			this.z = Math.ceil(this.z);
			return this;
		}
		/**
		* The components of this vector are rounded to the nearest integer value
		*
		* @return {Vector3} A reference to this vector.
		*/
		round() {
			this.x = Math.round(this.x);
			this.y = Math.round(this.y);
			this.z = Math.round(this.z);
			return this;
		}
		/**
		* The components of this vector are rounded towards zero (up if negative,
		* down if positive) to an integer value.
		*
		* @return {Vector3} A reference to this vector.
		*/
		roundToZero() {
			this.x = Math.trunc(this.x);
			this.y = Math.trunc(this.y);
			this.z = Math.trunc(this.z);
			return this;
		}
		/**
		* Inverts this vector - i.e. sets x = -x, y = -y and z = -z.
		*
		* @return {Vector3} A reference to this vector.
		*/
		negate() {
			this.x = -this.x;
			this.y = -this.y;
			this.z = -this.z;
			return this;
		}
		/**
		* Calculates the dot product of the given vector with this instance.
		*
		* @param {Vector3} v - The vector to compute the dot product with.
		* @return {number} The result of the dot product.
		*/
		dot(v) {
			return this.x * v.x + this.y * v.y + this.z * v.z;
		}
		/**
		* Computes the square of the Euclidean length (straight-line length) from
		* (0, 0, 0) to (x, y, z). If you are comparing the lengths of vectors, you should
		* compare the length squared instead as it is slightly more efficient to calculate.
		*
		* @return {number} The square length of this vector.
		*/
		lengthSq() {
			return this.x * this.x + this.y * this.y + this.z * this.z;
		}
		/**
		* Computes the  Euclidean length (straight-line length) from (0, 0, 0) to (x, y, z).
		*
		* @return {number} The length of this vector.
		*/
		length() {
			return Math.sqrt(this.x * this.x + this.y * this.y + this.z * this.z);
		}
		/**
		* Computes the Manhattan length of this vector.
		*
		* @return {number} The length of this vector.
		*/
		manhattanLength() {
			return Math.abs(this.x) + Math.abs(this.y) + Math.abs(this.z);
		}
		/**
		* Converts this vector to a unit vector - that is, sets it equal to a vector
		* with the same direction as this one, but with a vector length of `1`.
		*
		* @return {Vector3} A reference to this vector.
		*/
		normalize() {
			return this.divideScalar(this.length() || 1);
		}
		/**
		* Sets this vector to a vector with the same direction as this one, but
		* with the specified length.
		*
		* @param {number} length - The new length of this vector.
		* @return {Vector3} A reference to this vector.
		*/
		setLength(length) {
			return this.normalize().multiplyScalar(length);
		}
		/**
		* Linearly interpolates between the given vector and this instance, where
		* alpha is the percent distance along the line - alpha = 0 will be this
		* vector, and alpha = 1 will be the given one.
		*
		* @param {Vector3} v - The vector to interpolate towards.
		* @param {number} alpha - The interpolation factor, typically in the closed interval `[0, 1]`.
		* @return {Vector3} A reference to this vector.
		*/
		lerp(v, alpha) {
			this.x += (v.x - this.x) * alpha;
			this.y += (v.y - this.y) * alpha;
			this.z += (v.z - this.z) * alpha;
			return this;
		}
		/**
		* Linearly interpolates between the given vectors, where alpha is the percent
		* distance along the line - alpha = 0 will be first vector, and alpha = 1 will
		* be the second one. The result is stored in this instance.
		*
		* @param {Vector3} v1 - The first vector.
		* @param {Vector3} v2 - The second vector.
		* @param {number} alpha - The interpolation factor, typically in the closed interval `[0, 1]`.
		* @return {Vector3} A reference to this vector.
		*/
		lerpVectors(v1, v2, alpha) {
			this.x = v1.x + (v2.x - v1.x) * alpha;
			this.y = v1.y + (v2.y - v1.y) * alpha;
			this.z = v1.z + (v2.z - v1.z) * alpha;
			return this;
		}
		/**
		* Calculates the cross product of the given vector with this instance.
		*
		* @param {Vector3} v - The vector to compute the cross product with.
		* @return {Vector3} The result of the cross product.
		*/
		cross(v) {
			return this.crossVectors(this, v);
		}
		/**
		* Calculates the cross product of the given vectors and stores the result
		* in this instance.
		*
		* @param {Vector3} a - The first vector.
		* @param {Vector3} b - The second vector.
		* @return {Vector3} A reference to this vector.
		*/
		crossVectors(a, b) {
			const ax = a.x, ay = a.y, az = a.z;
			const bx = b.x, by = b.y, bz = b.z;
			this.x = ay * bz - az * by;
			this.y = az * bx - ax * bz;
			this.z = ax * by - ay * bx;
			return this;
		}
		/**
		* Projects this vector onto the given one.
		*
		* @param {Vector3} v - The vector to project to.
		* @return {Vector3} A reference to this vector.
		*/
		projectOnVector(v) {
			const denominator = v.lengthSq();
			if (denominator === 0) return this.set(0, 0, 0);
			const scalar = v.dot(this) / denominator;
			return this.copy(v).multiplyScalar(scalar);
		}
		/**
		* Projects this vector onto a plane by subtracting this
		* vector projected onto the plane's normal from this vector.
		*
		* @param {Vector3} planeNormal - The plane normal.
		* @return {Vector3} A reference to this vector.
		*/
		projectOnPlane(planeNormal) {
			_vector$c.copy(this).projectOnVector(planeNormal);
			return this.sub(_vector$c);
		}
		/**
		* Reflects this vector off a plane orthogonal to the given normal vector.
		*
		* @param {Vector3} normal - The (normalized) normal vector.
		* @return {Vector3} A reference to this vector.
		*/
		reflect(normal) {
			return this.sub(_vector$c.copy(normal).multiplyScalar(2 * this.dot(normal)));
		}
		/**
		* Returns the angle between the given vector and this instance in radians.
		*
		* @param {Vector3} v - The vector to compute the angle with.
		* @return {number} The angle in radians.
		*/
		angleTo(v) {
			const denominator = Math.sqrt(this.lengthSq() * v.lengthSq());
			if (denominator === 0) return Math.PI / 2;
			const theta = this.dot(v) / denominator;
			return Math.acos(clamp(theta, -1, 1));
		}
		/**
		* Computes the distance from the given vector to this instance.
		*
		* @param {Vector3} v - The vector to compute the distance to.
		* @return {number} The distance.
		*/
		distanceTo(v) {
			return Math.sqrt(this.distanceToSquared(v));
		}
		/**
		* Computes the squared distance from the given vector to this instance.
		* If you are just comparing the distance with another distance, you should compare
		* the distance squared instead as it is slightly more efficient to calculate.
		*
		* @param {Vector3} v - The vector to compute the squared distance to.
		* @return {number} The squared distance.
		*/
		distanceToSquared(v) {
			const dx = this.x - v.x, dy = this.y - v.y, dz = this.z - v.z;
			return dx * dx + dy * dy + dz * dz;
		}
		/**
		* Computes the Manhattan distance from the given vector to this instance.
		*
		* @param {Vector3} v - The vector to compute the Manhattan distance to.
		* @return {number} The Manhattan distance.
		*/
		manhattanDistanceTo(v) {
			return Math.abs(this.x - v.x) + Math.abs(this.y - v.y) + Math.abs(this.z - v.z);
		}
		/**
		* Sets the vector components from the given spherical coordinates.
		*
		* @param {Spherical} s - The spherical coordinates.
		* @return {Vector3} A reference to this vector.
		*/
		setFromSpherical(s) {
			return this.setFromSphericalCoords(s.radius, s.phi, s.theta);
		}
		/**
		* Sets the vector components from the given spherical coordinates.
		*
		* @param {number} radius - The radius.
		* @param {number} phi - The phi angle in radians.
		* @param {number} theta - The theta angle in radians.
		* @return {Vector3} A reference to this vector.
		*/
		setFromSphericalCoords(radius, phi, theta) {
			const sinPhiRadius = Math.sin(phi) * radius;
			this.x = sinPhiRadius * Math.sin(theta);
			this.y = Math.cos(phi) * radius;
			this.z = sinPhiRadius * Math.cos(theta);
			return this;
		}
		/**
		* Sets the vector components from the given cylindrical coordinates.
		*
		* @param {Cylindrical} c - The cylindrical coordinates.
		* @return {Vector3} A reference to this vector.
		*/
		setFromCylindrical(c) {
			return this.setFromCylindricalCoords(c.radius, c.theta, c.y);
		}
		/**
		* Sets the vector components from the given cylindrical coordinates.
		*
		* @param {number} radius - The radius.
		* @param {number} theta - The theta angle in radians.
		* @param {number} y - The y value.
		* @return {Vector3} A reference to this vector.
		*/
		setFromCylindricalCoords(radius, theta, y) {
			this.x = radius * Math.sin(theta);
			this.y = y;
			this.z = radius * Math.cos(theta);
			return this;
		}
		/**
		* Sets the vector components to the position elements of the
		* given transformation matrix.
		*
		* @param {Matrix4} m - The 4x4 matrix.
		* @return {Vector3} A reference to this vector.
		*/
		setFromMatrixPosition(m) {
			const e = m.elements;
			this.x = e[12];
			this.y = e[13];
			this.z = e[14];
			return this;
		}
		/**
		* Sets the vector components to the scale elements of the
		* given transformation matrix.
		*
		* @param {Matrix4} m - The 4x4 matrix.
		* @return {Vector3} A reference to this vector.
		*/
		setFromMatrixScale(m) {
			const sx = this.setFromMatrixColumn(m, 0).length();
			const sy = this.setFromMatrixColumn(m, 1).length();
			const sz = this.setFromMatrixColumn(m, 2).length();
			this.x = sx;
			this.y = sy;
			this.z = sz;
			return this;
		}
		/**
		* Sets the vector components from the specified matrix column.
		*
		* @param {Matrix4} m - The 4x4 matrix.
		* @param {number} index - The column index.
		* @return {Vector3} A reference to this vector.
		*/
		setFromMatrixColumn(m, index) {
			return this.fromArray(m.elements, index * 4);
		}
		/**
		* Sets the vector components from the specified matrix column.
		*
		* @param {Matrix3} m - The 3x3 matrix.
		* @param {number} index - The column index.
		* @return {Vector3} A reference to this vector.
		*/
		setFromMatrix3Column(m, index) {
			return this.fromArray(m.elements, index * 3);
		}
		/**
		* Sets the vector components from the given Euler angles.
		*
		* @param {Euler} e - The Euler angles to set.
		* @return {Vector3} A reference to this vector.
		*/
		setFromEuler(e) {
			this.x = e._x;
			this.y = e._y;
			this.z = e._z;
			return this;
		}
		/**
		* Sets the vector components from the RGB components of the
		* given color.
		*
		* @param {Color} c - The color to set.
		* @return {Vector3} A reference to this vector.
		*/
		setFromColor(c) {
			this.x = c.r;
			this.y = c.g;
			this.z = c.b;
			return this;
		}
		/**
		* Returns `true` if this vector is equal with the given one.
		*
		* @param {Vector3} v - The vector to test for equality.
		* @return {boolean} Whether this vector is equal with the given one.
		*/
		equals(v) {
			return v.x === this.x && v.y === this.y && v.z === this.z;
		}
		/**
		* Sets this vector's x value to be `array[ offset ]`, y value to be `array[ offset + 1 ]`
		* and z value to be `array[ offset + 2 ]`.
		*
		* @param {Array<number>} array - An array holding the vector component values.
		* @param {number} [offset=0] - The offset into the array.
		* @return {Vector3} A reference to this vector.
		*/
		fromArray(array, offset = 0) {
			this.x = array[offset];
			this.y = array[offset + 1];
			this.z = array[offset + 2];
			return this;
		}
		/**
		* Writes the components of this vector to the given array. If no array is provided,
		* the method returns a new instance.
		*
		* @param {Array<number>} [array=[]] - The target array holding the vector components.
		* @param {number} [offset=0] - Index of the first element in the array.
		* @return {Array<number>} The vector components.
		*/
		toArray(array = [], offset = 0) {
			array[offset] = this.x;
			array[offset + 1] = this.y;
			array[offset + 2] = this.z;
			return array;
		}
		/**
		* Sets the components of this vector from the given buffer attribute.
		*
		* @param {BufferAttribute} attribute - The buffer attribute holding vector data.
		* @param {number} index - The index into the attribute.
		* @return {Vector3} A reference to this vector.
		*/
		fromBufferAttribute(attribute, index) {
			this.x = attribute.getX(index);
			this.y = attribute.getY(index);
			this.z = attribute.getZ(index);
			return this;
		}
		/**
		* Sets each component of this vector to a pseudo-random value between `0` and
		* `1`, excluding `1`.
		*
		* @return {Vector3} A reference to this vector.
		*/
		random() {
			this.x = Math.random();
			this.y = Math.random();
			this.z = Math.random();
			return this;
		}
		/**
		* Sets this vector to a uniformly random point on a unit sphere.
		*
		* @return {Vector3} A reference to this vector.
		*/
		randomDirection() {
			const theta = Math.random() * Math.PI * 2;
			const u = Math.random() * 2 - 1;
			const c = Math.sqrt(1 - u * u);
			this.x = c * Math.cos(theta);
			this.y = u;
			this.z = c * Math.sin(theta);
			return this;
		}
		*[Symbol.iterator]() {
			yield this.x;
			yield this.y;
			yield this.z;
		}
	};
	const _vector$c = /*@__PURE__*/ new Vector3();
	const _quaternion$5 = /*@__PURE__*/ new Quaternion();
	/**
	* Represents a 3x3 matrix.
	*
	* A Note on Row-Major and Column-Major Ordering:
	*
	* The constructor and {@link Matrix3#set} method take arguments in
	* [row-major](https://en.wikipedia.org/wiki/Row-_and_column-major_order#Column-major_order)
	* order, while internally they are stored in the {@link Matrix3#elements} array in column-major order.
	* This means that calling:
	* ```js
	* const m = new THREE.Matrix();
	* m.set( 11, 12, 13,
	*        21, 22, 23,
	*        31, 32, 33 );
	* ```
	* will result in the elements array containing:
	* ```js
	* m.elements = [ 11, 21, 31,
	*                12, 22, 32,
	*                13, 23, 33 ];
	* ```
	* and internally all calculations are performed using column-major ordering.
	* However, as the actual ordering makes no difference mathematically and
	* most people are used to thinking about matrices in row-major order, the
	* three.js documentation shows matrices in row-major order. Just bear in
	* mind that if you are reading the source code, you'll have to take the
	* transpose of any matrices outlined here to make sense of the calculations.
	*/
	var Matrix3 = class Matrix3 {
		static {
			/**
			* This flag can be used for type testing.
			*
			* @type {boolean}
			* @readonly
			* @default true
			*/
			Matrix3.prototype.isMatrix3 = true;
		}
		/**
		* Constructs a new 3x3 matrix. The arguments are supposed to be
		* in row-major order. If no arguments are provided, the constructor
		* initializes the matrix as an identity matrix.
		*
		* @param {number} [n11] - 1-1 matrix element.
		* @param {number} [n12] - 1-2 matrix element.
		* @param {number} [n13] - 1-3 matrix element.
		* @param {number} [n21] - 2-1 matrix element.
		* @param {number} [n22] - 2-2 matrix element.
		* @param {number} [n23] - 2-3 matrix element.
		* @param {number} [n31] - 3-1 matrix element.
		* @param {number} [n32] - 3-2 matrix element.
		* @param {number} [n33] - 3-3 matrix element.
		*/
		constructor(n11, n12, n13, n21, n22, n23, n31, n32, n33) {
			/**
			* A column-major list of matrix values.
			*
			* @type {Array<number>}
			*/
			this.elements = [
				1,
				0,
				0,
				0,
				1,
				0,
				0,
				0,
				1
			];
			if (n11 !== void 0) this.set(n11, n12, n13, n21, n22, n23, n31, n32, n33);
		}
		/**
		* Sets the elements of the matrix.The arguments are supposed to be
		* in row-major order.
		*
		* @param {number} [n11] - 1-1 matrix element.
		* @param {number} [n12] - 1-2 matrix element.
		* @param {number} [n13] - 1-3 matrix element.
		* @param {number} [n21] - 2-1 matrix element.
		* @param {number} [n22] - 2-2 matrix element.
		* @param {number} [n23] - 2-3 matrix element.
		* @param {number} [n31] - 3-1 matrix element.
		* @param {number} [n32] - 3-2 matrix element.
		* @param {number} [n33] - 3-3 matrix element.
		* @return {Matrix3} A reference to this matrix.
		*/
		set(n11, n12, n13, n21, n22, n23, n31, n32, n33) {
			const te = this.elements;
			te[0] = n11;
			te[1] = n21;
			te[2] = n31;
			te[3] = n12;
			te[4] = n22;
			te[5] = n32;
			te[6] = n13;
			te[7] = n23;
			te[8] = n33;
			return this;
		}
		/**
		* Sets this matrix to the 3x3 identity matrix.
		*
		* @return {Matrix3} A reference to this matrix.
		*/
		identity() {
			this.set(1, 0, 0, 0, 1, 0, 0, 0, 1);
			return this;
		}
		/**
		* Copies the values of the given matrix to this instance.
		*
		* @param {Matrix3} m - The matrix to copy.
		* @return {Matrix3} A reference to this matrix.
		*/
		copy(m) {
			const te = this.elements;
			const me = m.elements;
			te[0] = me[0];
			te[1] = me[1];
			te[2] = me[2];
			te[3] = me[3];
			te[4] = me[4];
			te[5] = me[5];
			te[6] = me[6];
			te[7] = me[7];
			te[8] = me[8];
			return this;
		}
		/**
		* Extracts the basis of this matrix into the three axis vectors provided.
		*
		* @param {Vector3} xAxis - The basis's x axis.
		* @param {Vector3} yAxis - The basis's y axis.
		* @param {Vector3} zAxis - The basis's z axis.
		* @return {Matrix3} A reference to this matrix.
		*/
		extractBasis(xAxis, yAxis, zAxis) {
			xAxis.setFromMatrix3Column(this, 0);
			yAxis.setFromMatrix3Column(this, 1);
			zAxis.setFromMatrix3Column(this, 2);
			return this;
		}
		/**
		* Set this matrix to the upper 3x3 matrix of the given 4x4 matrix.
		*
		* @param {Matrix4} m - The 4x4 matrix.
		* @return {Matrix3} A reference to this matrix.
		*/
		setFromMatrix4(m) {
			const me = m.elements;
			this.set(me[0], me[4], me[8], me[1], me[5], me[9], me[2], me[6], me[10]);
			return this;
		}
		/**
		* Post-multiplies this matrix by the given 3x3 matrix.
		*
		* @param {Matrix3} m - The matrix to multiply with.
		* @return {Matrix3} A reference to this matrix.
		*/
		multiply(m) {
			return this.multiplyMatrices(this, m);
		}
		/**
		* Pre-multiplies this matrix by the given 3x3 matrix.
		*
		* @param {Matrix3} m - The matrix to multiply with.
		* @return {Matrix3} A reference to this matrix.
		*/
		premultiply(m) {
			return this.multiplyMatrices(m, this);
		}
		/**
		* Multiples the given 3x3 matrices and stores the result
		* in this matrix.
		*
		* @param {Matrix3} a - The first matrix.
		* @param {Matrix3} b - The second matrix.
		* @return {Matrix3} A reference to this matrix.
		*/
		multiplyMatrices(a, b) {
			const ae = a.elements;
			const be = b.elements;
			const te = this.elements;
			const a11 = ae[0], a12 = ae[3], a13 = ae[6];
			const a21 = ae[1], a22 = ae[4], a23 = ae[7];
			const a31 = ae[2], a32 = ae[5], a33 = ae[8];
			const b11 = be[0], b12 = be[3], b13 = be[6];
			const b21 = be[1], b22 = be[4], b23 = be[7];
			const b31 = be[2], b32 = be[5], b33 = be[8];
			te[0] = a11 * b11 + a12 * b21 + a13 * b31;
			te[3] = a11 * b12 + a12 * b22 + a13 * b32;
			te[6] = a11 * b13 + a12 * b23 + a13 * b33;
			te[1] = a21 * b11 + a22 * b21 + a23 * b31;
			te[4] = a21 * b12 + a22 * b22 + a23 * b32;
			te[7] = a21 * b13 + a22 * b23 + a23 * b33;
			te[2] = a31 * b11 + a32 * b21 + a33 * b31;
			te[5] = a31 * b12 + a32 * b22 + a33 * b32;
			te[8] = a31 * b13 + a32 * b23 + a33 * b33;
			return this;
		}
		/**
		* Multiplies every component of the matrix by the given scalar.
		*
		* @param {number} s - The scalar.
		* @return {Matrix3} A reference to this matrix.
		*/
		multiplyScalar(s) {
			const te = this.elements;
			te[0] *= s;
			te[3] *= s;
			te[6] *= s;
			te[1] *= s;
			te[4] *= s;
			te[7] *= s;
			te[2] *= s;
			te[5] *= s;
			te[8] *= s;
			return this;
		}
		/**
		* Computes and returns the determinant of this matrix.
		*
		* @return {number} The determinant.
		*/
		determinant() {
			const te = this.elements;
			const a = te[0], b = te[1], c = te[2], d = te[3], e = te[4], f = te[5], g = te[6], h = te[7], i = te[8];
			return a * e * i - a * f * h - b * d * i + b * f * g + c * d * h - c * e * g;
		}
		/**
		* Inverts this matrix, using the [analytic method](https://en.wikipedia.org/wiki/Invertible_matrix#Analytic_solution).
		* You can not invert with a determinant of zero. If you attempt this, the method produces
		* a zero matrix instead.
		*
		* @return {Matrix3} A reference to this matrix.
		*/
		invert() {
			const te = this.elements, n11 = te[0], n21 = te[1], n31 = te[2], n12 = te[3], n22 = te[4], n32 = te[5], n13 = te[6], n23 = te[7], n33 = te[8], t11 = n33 * n22 - n32 * n23, t12 = n32 * n13 - n33 * n12, t13 = n23 * n12 - n22 * n13, det = n11 * t11 + n21 * t12 + n31 * t13;
			if (det === 0) return this.set(0, 0, 0, 0, 0, 0, 0, 0, 0);
			const detInv = 1 / det;
			te[0] = t11 * detInv;
			te[1] = (n31 * n23 - n33 * n21) * detInv;
			te[2] = (n32 * n21 - n31 * n22) * detInv;
			te[3] = t12 * detInv;
			te[4] = (n33 * n11 - n31 * n13) * detInv;
			te[5] = (n31 * n12 - n32 * n11) * detInv;
			te[6] = t13 * detInv;
			te[7] = (n21 * n13 - n23 * n11) * detInv;
			te[8] = (n22 * n11 - n21 * n12) * detInv;
			return this;
		}
		/**
		* Transposes this matrix in place.
		*
		* @return {Matrix3} A reference to this matrix.
		*/
		transpose() {
			let tmp;
			const m = this.elements;
			tmp = m[1];
			m[1] = m[3];
			m[3] = tmp;
			tmp = m[2];
			m[2] = m[6];
			m[6] = tmp;
			tmp = m[5];
			m[5] = m[7];
			m[7] = tmp;
			return this;
		}
		/**
		* Computes the normal matrix which is the inverse transpose of the upper
		* left 3x3 portion of the given 4x4 matrix.
		*
		* @param {Matrix4} matrix4 - The 4x4 matrix.
		* @return {Matrix3} A reference to this matrix.
		*/
		getNormalMatrix(matrix4) {
			return this.setFromMatrix4(matrix4).invert().transpose();
		}
		/**
		* Transposes this matrix into the supplied array, and returns itself unchanged.
		*
		* @param {Array<number>} r - An array to store the transposed matrix elements.
		* @return {Matrix3} A reference to this matrix.
		*/
		transposeIntoArray(r) {
			const m = this.elements;
			r[0] = m[0];
			r[1] = m[3];
			r[2] = m[6];
			r[3] = m[1];
			r[4] = m[4];
			r[5] = m[7];
			r[6] = m[2];
			r[7] = m[5];
			r[8] = m[8];
			return this;
		}
		/**
		* Sets the UV transform matrix from offset, repeat, rotation, and center.
		*
		* @param {number} tx - Offset x.
		* @param {number} ty - Offset y.
		* @param {number} sx - Repeat x.
		* @param {number} sy - Repeat y.
		* @param {number} rotation - Rotation, in radians. Positive values rotate counterclockwise.
		* @param {number} cx - Center x of rotation.
		* @param {number} cy - Center y of rotation
		* @return {Matrix3} A reference to this matrix.
		*/
		setUvTransform(tx, ty, sx, sy, rotation, cx, cy) {
			const c = Math.cos(rotation);
			const s = Math.sin(rotation);
			this.set(sx * c, sx * s, -sx * (c * cx + s * cy) + cx + tx, -sy * s, sy * c, -sy * (-s * cx + c * cy) + cy + ty, 0, 0, 1);
			return this;
		}
		/**
		* Scales this matrix with the given scalar values.
		*
		* @deprecated
		* @param {number} sx - The amount to scale in the X axis.
		* @param {number} sy - The amount to scale in the Y axis.
		* @return {Matrix3} A reference to this matrix.
		*/
		scale(sx, sy) {
			warnOnce("Matrix3: .scale() is deprecated. Use .makeScale() instead.");
			this.premultiply(_m3.makeScale(sx, sy));
			return this;
		}
		/**
		* Rotates this matrix by the given angle.
		*
		* @deprecated
		* @param {number} theta - The rotation in radians.
		* @return {Matrix3} A reference to this matrix.
		*/
		rotate(theta) {
			warnOnce("Matrix3: .rotate() is deprecated. Use .makeRotation() instead.");
			this.premultiply(_m3.makeRotation(-theta));
			return this;
		}
		/**
		* Translates this matrix by the given scalar values.
		*
		* @deprecated
		* @param {number} tx - The amount to translate in the X axis.
		* @param {number} ty - The amount to translate in the Y axis.
		* @return {Matrix3} A reference to this matrix.
		*/
		translate(tx, ty) {
			warnOnce("Matrix3: .translate() is deprecated. Use .makeTranslation() instead.");
			this.premultiply(_m3.makeTranslation(tx, ty));
			return this;
		}
		/**
		* Sets this matrix as a 2D translation transform.
		*
		* @param {number|Vector2} x - The amount to translate in the X axis or alternatively a translation vector.
		* @param {number} y - The amount to translate in the Y axis.
		* @return {Matrix3} A reference to this matrix.
		*/
		makeTranslation(x, y) {
			if (x.isVector2) this.set(1, 0, x.x, 0, 1, x.y, 0, 0, 1);
			else this.set(1, 0, x, 0, 1, y, 0, 0, 1);
			return this;
		}
		/**
		* Sets this matrix as a 2D rotational transformation.
		*
		* @param {number} theta - The rotation in radians.
		* @return {Matrix3} A reference to this matrix.
		*/
		makeRotation(theta) {
			const c = Math.cos(theta);
			const s = Math.sin(theta);
			this.set(c, -s, 0, s, c, 0, 0, 0, 1);
			return this;
		}
		/**
		* Sets this matrix as a 2D scale transform.
		*
		* @param {number} x - The amount to scale in the X axis.
		* @param {number} y - The amount to scale in the Y axis.
		* @return {Matrix3} A reference to this matrix.
		*/
		makeScale(x, y) {
			this.set(x, 0, 0, 0, y, 0, 0, 0, 1);
			return this;
		}
		/**
		* Returns `true` if this matrix is equal with the given one.
		*
		* @param {Matrix3} matrix - The matrix to test for equality.
		* @return {boolean} Whether this matrix is equal with the given one.
		*/
		equals(matrix) {
			const te = this.elements;
			const me = matrix.elements;
			for (let i = 0; i < 9; i++) if (te[i] !== me[i]) return false;
			return true;
		}
		/**
		* Sets the elements of the matrix from the given array.
		*
		* @param {Array<number>} array - The matrix elements in column-major order.
		* @param {number} [offset=0] - Index of the first element in the array.
		* @return {Matrix3} A reference to this matrix.
		*/
		fromArray(array, offset = 0) {
			for (let i = 0; i < 9; i++) this.elements[i] = array[i + offset];
			return this;
		}
		/**
		* Writes the elements of this matrix to the given array. If no array is provided,
		* the method returns a new instance.
		*
		* @param {Array<number>} [array=[]] - The target array holding the matrix elements in column-major order.
		* @param {number} [offset=0] - Index of the first element in the array.
		* @return {Array<number>} The matrix elements in column-major order.
		*/
		toArray(array = [], offset = 0) {
			const te = this.elements;
			array[offset] = te[0];
			array[offset + 1] = te[1];
			array[offset + 2] = te[2];
			array[offset + 3] = te[3];
			array[offset + 4] = te[4];
			array[offset + 5] = te[5];
			array[offset + 6] = te[6];
			array[offset + 7] = te[7];
			array[offset + 8] = te[8];
			return array;
		}
		/**
		* Returns a matrix with copied values from this instance.
		*
		* @return {Matrix3} A clone of this instance.
		*/
		clone() {
			return new this.constructor().fromArray(this.elements);
		}
	};
	const _m3 = /*@__PURE__*/ new Matrix3();
	const LINEAR_REC709_TO_XYZ = /*@__PURE__*/ new Matrix3().set(.4123908, .3575843, .1804808, .212639, .7151687, .0721923, .0193308, .1191948, .9505322);
	const XYZ_TO_LINEAR_REC709 = /*@__PURE__*/ new Matrix3().set(3.2409699, -1.5373832, -.4986108, -.9692436, 1.8759675, .0415551, .0556301, -.203977, 1.0569715);
	function createColorManagement() {
		const ColorManagement = {
			enabled: true,
			workingColorSpace: LinearSRGBColorSpace,
			/**
			* Implementations of supported color spaces.
			*
			* Required:
			*	- primaries: chromaticity coordinates [ rx ry gx gy bx by ]
			*	- whitePoint: reference white [ x y ]
			*	- transfer: transfer function (pre-defined)
			*	- toXYZ: Matrix3 RGB to XYZ transform
			*	- fromXYZ: Matrix3 XYZ to RGB transform
			*	- luminanceCoefficients: RGB luminance coefficients
			*
			* Optional:
			*  - outputColorSpaceConfig: { drawingBufferColorSpace: ColorSpace, toneMappingMode: 'extended' | 'standard' }
			*  - workingColorSpaceConfig: { unpackColorSpace: ColorSpace }
			*
			* Reference:
			* - https://www.russellcottrell.com/photo/matrixCalculator.htm
			*/
			spaces: {},
			convert: function(color, sourceColorSpace, targetColorSpace) {
				if (this.enabled === false || sourceColorSpace === targetColorSpace || !sourceColorSpace || !targetColorSpace) return color;
				if (this.spaces[sourceColorSpace].transfer === "srgb") {
					color.r = SRGBToLinear(color.r);
					color.g = SRGBToLinear(color.g);
					color.b = SRGBToLinear(color.b);
				}
				if (this.spaces[sourceColorSpace].primaries !== this.spaces[targetColorSpace].primaries) {
					color.applyMatrix3(this.spaces[sourceColorSpace].toXYZ);
					color.applyMatrix3(this.spaces[targetColorSpace].fromXYZ);
				}
				if (this.spaces[targetColorSpace].transfer === "srgb") {
					color.r = LinearToSRGB(color.r);
					color.g = LinearToSRGB(color.g);
					color.b = LinearToSRGB(color.b);
				}
				return color;
			},
			workingToColorSpace: function(color, targetColorSpace) {
				return this.convert(color, this.workingColorSpace, targetColorSpace);
			},
			colorSpaceToWorking: function(color, sourceColorSpace) {
				return this.convert(color, sourceColorSpace, this.workingColorSpace);
			},
			getPrimaries: function(colorSpace) {
				return this.spaces[colorSpace].primaries;
			},
			getTransfer: function(colorSpace) {
				if (colorSpace === "") return LinearTransfer;
				return this.spaces[colorSpace].transfer;
			},
			getToneMappingMode: function(colorSpace) {
				return this.spaces[colorSpace].outputColorSpaceConfig.toneMappingMode || "standard";
			},
			getLuminanceCoefficients: function(target, colorSpace = this.workingColorSpace) {
				return target.fromArray(this.spaces[colorSpace].luminanceCoefficients);
			},
			define: function(colorSpaces) {
				Object.assign(this.spaces, colorSpaces);
			},
			_getMatrix: function(targetMatrix, sourceColorSpace, targetColorSpace) {
				return targetMatrix.copy(this.spaces[sourceColorSpace].toXYZ).multiply(this.spaces[targetColorSpace].fromXYZ);
			},
			_getDrawingBufferColorSpace: function(colorSpace) {
				return this.spaces[colorSpace].outputColorSpaceConfig.drawingBufferColorSpace;
			},
			_getUnpackColorSpace: function(colorSpace = this.workingColorSpace) {
				return this.spaces[colorSpace].workingColorSpaceConfig.unpackColorSpace;
			},
			fromWorkingColorSpace: function(color, targetColorSpace) {
				warnOnce("ColorManagement: .fromWorkingColorSpace() has been renamed to .workingToColorSpace().");
				return ColorManagement.workingToColorSpace(color, targetColorSpace);
			},
			toWorkingColorSpace: function(color, sourceColorSpace) {
				warnOnce("ColorManagement: .toWorkingColorSpace() has been renamed to .colorSpaceToWorking().");
				return ColorManagement.colorSpaceToWorking(color, sourceColorSpace);
			}
		};
		/******************************************************************************
		* sRGB definitions
		*/
		const REC709_PRIMARIES = [
			.64,
			.33,
			.3,
			.6,
			.15,
			.06
		];
		const REC709_LUMINANCE_COEFFICIENTS = [
			.2126,
			.7152,
			.0722
		];
		const D65 = [.3127, .329];
		ColorManagement.define({
			[LinearSRGBColorSpace]: {
				primaries: REC709_PRIMARIES,
				whitePoint: D65,
				transfer: LinearTransfer,
				toXYZ: LINEAR_REC709_TO_XYZ,
				fromXYZ: XYZ_TO_LINEAR_REC709,
				luminanceCoefficients: REC709_LUMINANCE_COEFFICIENTS,
				workingColorSpaceConfig: { unpackColorSpace: SRGBColorSpace },
				outputColorSpaceConfig: { drawingBufferColorSpace: SRGBColorSpace }
			},
			[SRGBColorSpace]: {
				primaries: REC709_PRIMARIES,
				whitePoint: D65,
				transfer: SRGBTransfer,
				toXYZ: LINEAR_REC709_TO_XYZ,
				fromXYZ: XYZ_TO_LINEAR_REC709,
				luminanceCoefficients: REC709_LUMINANCE_COEFFICIENTS,
				outputColorSpaceConfig: { drawingBufferColorSpace: SRGBColorSpace }
			}
		});
		return ColorManagement;
	}
	const ColorManagement = /*@__PURE__*/ createColorManagement();
	function SRGBToLinear(c) {
		return c < .04045 ? c * .0773993808 : Math.pow(c * .9478672986 + .0521327014, 2.4);
	}
	function LinearToSRGB(c) {
		return c < .0031308 ? c * 12.92 : 1.055 * Math.pow(c, .41666) - .055;
	}
	let _canvas;
	/**
	* A class containing utility functions for images.
	*
	* @hideconstructor
	*/
	var ImageUtils = class {
		/**
		* Returns a data URI containing a representation of the given image.
		*
		* @param {(HTMLImageElement|HTMLCanvasElement)} image - The image object.
		* @param {string} [type='image/png'] - Indicates the image format.
		* @return {string} The data URI.
		*/
		static getDataURL(image, type = "image/png") {
			if (/^data:/i.test(image.src)) return image.src;
			if (typeof HTMLCanvasElement === "undefined") return image.src;
			let canvas;
			if (image instanceof HTMLCanvasElement) canvas = image;
			else {
				if (_canvas === void 0) _canvas = createElementNS("canvas");
				_canvas.width = image.width;
				_canvas.height = image.height;
				const context = _canvas.getContext("2d");
				if (image instanceof ImageData) context.putImageData(image, 0, 0);
				else context.drawImage(image, 0, 0, image.width, image.height);
				canvas = _canvas;
			}
			return canvas.toDataURL(type);
		}
		/**
		* Converts the given sRGB image data to linear color space.
		*
		* @param {(HTMLImageElement|HTMLCanvasElement|ImageBitmap|Object)} image - The image object.
		* @return {HTMLCanvasElement|Object} The converted image.
		*/
		static sRGBToLinear(image) {
			if (typeof HTMLImageElement !== "undefined" && image instanceof HTMLImageElement || typeof HTMLCanvasElement !== "undefined" && image instanceof HTMLCanvasElement || typeof ImageBitmap !== "undefined" && image instanceof ImageBitmap) {
				const canvas = createElementNS("canvas");
				canvas.width = image.width;
				canvas.height = image.height;
				const context = canvas.getContext("2d");
				context.drawImage(image, 0, 0, image.width, image.height);
				const imageData = context.getImageData(0, 0, image.width, image.height);
				const data = imageData.data;
				for (let i = 0; i < data.length; i++) data[i] = SRGBToLinear(data[i] / 255) * 255;
				context.putImageData(imageData, 0, 0);
				return canvas;
			} else if (image.data) {
				const data = image.data.slice(0);
				for (let i = 0; i < data.length; i++) if (data instanceof Uint8Array || data instanceof Uint8ClampedArray) data[i] = Math.floor(SRGBToLinear(data[i] / 255) * 255);
				else data[i] = SRGBToLinear(data[i]);
				return {
					data,
					width: image.width,
					height: image.height
				};
			} else {
				warn("ImageUtils.sRGBToLinear(): Unsupported image type. No color space conversion applied.");
				return image;
			}
		}
	};
	let _sourceId = 0;
	/**
	* Represents the data source of a texture.
	*
	* The main purpose of this class is to decouple the data definition from the texture
	* definition so the same data can be used with multiple texture instances.
	*/
	var TextureSource = class {
		/**
		* Constructs a new texture source.
		*
		* @param {any} [data=null] - The data definition of a texture.
		*/
		constructor(data = null) {
			/**
			* This flag can be used for type testing.
			*
			* @type {boolean}
			* @readonly
			* @default true
			*/
			this.isTextureSource = true;
			/**
			* The ID of the source.
			*
			* @name TextureSource#id
			* @type {number}
			* @readonly
			*/
			Object.defineProperty(this, "id", { value: _sourceId++ });
			/**
			* The UUID of the source.
			*
			* @type {string}
			* @readonly
			*/
			this.uuid = generateUUID();
			/**
			* The data definition of a texture.
			*
			* @type {any}
			*/
			this.data = data;
			/**
			* This property is only relevant when {@link TextureSource#needsUpdate} is set to `true` and
			* provides more control on how texture data should be processed. When `dataReady` is set
			* to `false`, the engine performs the memory allocation (if necessary) but does not transfer
			* the data into the GPU memory.
			*
			* @type {boolean}
			* @default true
			*/
			this.dataReady = true;
			/**
			* This starts at `0` and counts how many times {@link TextureSource#needsUpdate} is set to `true`.
			*
			* @type {number}
			* @readonly
			* @default 0
			*/
			this.version = 0;
		}
		/**
		* Returns the dimensions of the source into the given target vector.
		*
		* @param {(Vector2|Vector3)} target - The target object the result is written into.
		* @return {(Vector2|Vector3)} The dimensions of the source.
		*/
		getSize(target) {
			const data = this.data;
			if (typeof HTMLVideoElement !== "undefined" && data instanceof HTMLVideoElement) target.set(data.videoWidth, data.videoHeight, 0);
			else if (typeof VideoFrame !== "undefined" && data instanceof VideoFrame) target.set(data.displayWidth, data.displayHeight, 0);
			else if (data !== null) target.set(data.width, data.height, data.depth || 0);
			else target.set(0, 0, 0);
			return target;
		}
		/**
		* When the property is set to `true`, the engine allocates the memory
		* for the texture (if necessary) and triggers the actual texture upload
		* to the GPU next time the source is used.
		*
		* @type {boolean}
		* @default false
		* @param {boolean} value
		*/
		set needsUpdate(value) {
			if (value === true) this.version++;
		}
		/**
		* Serializes the source into JSON.
		*
		* @param {?(Object|string)} meta - An optional value holding meta information about the serialization.
		* @return {Object} A JSON object representing the serialized source.
		* @see {@link ObjectLoader#parse}
		*/
		toJSON(meta) {
			const isRootObject = meta === void 0 || typeof meta === "string";
			if (!isRootObject && meta.images[this.uuid] !== void 0) return meta.images[this.uuid];
			const output = {
				uuid: this.uuid,
				url: ""
			};
			const data = this.data;
			if (data !== null) {
				let url;
				if (Array.isArray(data)) {
					url = [];
					for (let i = 0, l = data.length; i < l; i++) if (data[i].isDataTexture) url.push(serializeImage(data[i].image));
					else url.push(serializeImage(data[i]));
				} else url = serializeImage(data);
				output.url = url;
			}
			if (!isRootObject) meta.images[this.uuid] = output;
			return output;
		}
	};
	function serializeImage(image) {
		if (typeof HTMLImageElement !== "undefined" && image instanceof HTMLImageElement || typeof HTMLCanvasElement !== "undefined" && image instanceof HTMLCanvasElement || typeof ImageBitmap !== "undefined" && image instanceof ImageBitmap) return ImageUtils.getDataURL(image);
		else if (image.data) return {
			data: Array.from(image.data),
			width: image.width,
			height: image.height,
			type: image.data.constructor.name
		};
		else {
			warn("Texture: Unable to serialize Texture.");
			return {};
		}
	}
	let _textureId = 0;
	const _tempVec3 = /*@__PURE__*/ new Vector3();
	/**
	* Base class for all textures.
	*
	* Note: After the initial use of a texture, its dimensions, format, and type
	* cannot be changed. Instead, call {@link Texture#dispose} on the texture and instantiate a new one.
	*
	* @augments EventDispatcher
	*/
	var Texture = class Texture extends EventDispatcher {
		/**
		* Constructs a new texture.
		*
		* @param {?Object} [image=Texture.DEFAULT_IMAGE] - The image holding the texture data.
		* @param {number} [mapping=Texture.DEFAULT_MAPPING] - The texture mapping.
		* @param {number} [wrapS=ClampToEdgeWrapping] - The wrapS value.
		* @param {number} [wrapT=ClampToEdgeWrapping] - The wrapT value.
		* @param {number} [magFilter=LinearFilter] - The mag filter value.
		* @param {number} [minFilter=LinearMipmapLinearFilter] - The min filter value.
		* @param {number} [format=RGBAFormat] - The texture format.
		* @param {number} [type=UnsignedByteType] - The texture type.
		* @param {number} [anisotropy=Texture.DEFAULT_ANISOTROPY] - The anisotropy value.
		* @param {string} [colorSpace=NoColorSpace] - The color space.
		*/
		constructor(image = Texture.DEFAULT_IMAGE, mapping = Texture.DEFAULT_MAPPING, wrapS = ClampToEdgeWrapping, wrapT = ClampToEdgeWrapping, magFilter = LinearFilter, minFilter = LinearMipmapLinearFilter, format = RGBAFormat, type = UnsignedByteType, anisotropy = Texture.DEFAULT_ANISOTROPY, colorSpace = "") {
			super();
			/**
			* This flag can be used for type testing.
			*
			* @type {boolean}
			* @readonly
			* @default true
			*/
			this.isTexture = true;
			/**
			* The ID of the texture.
			*
			* @name Texture#id
			* @type {number}
			* @readonly
			*/
			Object.defineProperty(this, "id", { value: _textureId++ });
			/**
			* The UUID of the texture.
			*
			* @type {string}
			* @readonly
			*/
			this.uuid = generateUUID();
			/**
			* The name of the texture.
			*
			* @type {string}
			*/
			this.name = "";
			/**
			* The data definition of a texture. A reference to the data source can be
			* shared across textures. This is often useful in context of spritesheets
			* where multiple textures render the same data but with different texture
			* transformations.
			*
			* @type {TextureSource}
			*/
			this.source = new TextureSource(image);
			/**
			* An array holding user-defined mipmaps.
			*
			* @type {Array<Object>}
			*/
			this.mipmaps = [];
			/**
			* How the texture is applied to the object. The value `UVMapping`
			* is the default, where texture or uv coordinates are used to apply the map.
			*
			* @type {(UVMapping|CubeReflectionMapping|CubeRefractionMapping|EquirectangularReflectionMapping|EquirectangularRefractionMapping|CubeUVReflectionMapping)}
			* @default UVMapping
			*/
			this.mapping = mapping;
			/**
			* Lets you select the uv attribute to map the texture to. `0` for `uv`,
			* `1` for `uv1`, `2` for `uv2` and `3` for `uv3`.
			*
			* @type {number}
			* @default 0
			*/
			this.channel = 0;
			/**
			* This defines how the texture is wrapped horizontally and corresponds to
			* *U* in UV mapping.
			*
			* @type {(RepeatWrapping|ClampToEdgeWrapping|MirroredRepeatWrapping)}
			* @default ClampToEdgeWrapping
			*/
			this.wrapS = wrapS;
			/**
			* This defines how the texture is wrapped horizontally and corresponds to
			* *V* in UV mapping.
			*
			* @type {(RepeatWrapping|ClampToEdgeWrapping|MirroredRepeatWrapping)}
			* @default ClampToEdgeWrapping
			*/
			this.wrapT = wrapT;
			/**
			* How the texture is sampled when a texel covers more than one pixel.
			*
			* @type {(NearestFilter|NearestMipmapNearestFilter|NearestMipmapLinearFilter|LinearFilter|LinearMipmapNearestFilter|LinearMipmapLinearFilter)}
			* @default LinearFilter
			*/
			this.magFilter = magFilter;
			/**
			* How the texture is sampled when a texel covers less than one pixel.
			*
			* @type {(NearestFilter|NearestMipmapNearestFilter|NearestMipmapLinearFilter|LinearFilter|LinearMipmapNearestFilter|LinearMipmapLinearFilter)}
			* @default LinearMipmapLinearFilter
			*/
			this.minFilter = minFilter;
			/**
			* The number of samples taken along the axis through the pixel that has the
			* highest density of texels. By default, this value is `1`. A higher value
			* gives a less blurry result than a basic mipmap, at the cost of more
			* texture samples being used.
			*
			* @type {number}
			* @default Texture.DEFAULT_ANISOTROPY
			*/
			this.anisotropy = anisotropy;
			/**
			* The format of the texture.
			*
			* @type {number}
			* @default RGBAFormat
			*/
			this.format = format;
			/**
			* The default internal format is derived from {@link Texture#format} and {@link Texture#type} and
			* defines how the texture data is going to be stored on the GPU.
			*
			* This property allows to overwrite the default format.
			*
			* @type {?string}
			* @default null
			*/
			this.internalFormat = null;
			/**
			* The data type of the texture.
			*
			* @type {number}
			* @default UnsignedByteType
			*/
			this.type = type;
			/**
			* How much a single repetition of the texture is offset from the beginning,
			* in each direction U and V. Typical range is `0.0` to `1.0`.
			*
			* @type {Vector2}
			* @default (0,0)
			*/
			this.offset = new Vector2(0, 0);
			/**
			* How many times the texture is repeated across the surface, in each
			* direction U and V. If repeat is set greater than `1` in either direction,
			* the corresponding wrap parameter should also be set to `RepeatWrapping`
			* or `MirroredRepeatWrapping` to achieve the desired tiling effect.
			*
			* @type {Vector2}
			* @default (1,1)
			*/
			this.repeat = new Vector2(1, 1);
			/**
			* The point around which rotation occurs. A value of `(0.5, 0.5)` corresponds
			* to the center of the texture. Default is `(0, 0)`, the lower left.
			*
			* @type {Vector2}
			* @default (0,0)
			*/
			this.center = new Vector2(0, 0);
			/**
			* How much the texture is rotated around the center point, in radians.
			* Positive values are counter-clockwise.
			*
			* @type {number}
			* @default 0
			*/
			this.rotation = 0;
			/**
			* Whether to update the texture's uv-transformation {@link Texture#matrix}
			* from the properties {@link Texture#offset}, {@link Texture#repeat},
			* {@link Texture#rotation}, and {@link Texture#center}.
			*
			* Set this to `false` if you are specifying the uv-transform matrix directly.
			*
			* @type {boolean}
			* @default true
			*/
			this.matrixAutoUpdate = true;
			/**
			* The uv-transformation matrix of the texture.
			*
			* @type {Matrix3}
			*/
			this.matrix = new Matrix3();
			/**
			* Whether to generate mipmaps (if possible) for a texture.
			*
			* Set this to `false` if you are creating mipmaps manually.
			*
			* @type {boolean}
			* @default true
			*/
			this.generateMipmaps = true;
			/**
			* If set to `true`, the alpha channel, if present, is multiplied into the
			* color channels when the texture is uploaded to the GPU.
			*
			* Note that this property has no effect when using `ImageBitmap`. You need to
			* configure premultiply alpha on bitmap creation instead.
			*
			* @type {boolean}
			* @default false
			*/
			this.premultiplyAlpha = false;
			/**
			* If set to `true`, the texture is flipped along the vertical axis when
			* uploaded to the GPU.
			*
			* Note that this property has no effect when using `ImageBitmap`. You need to
			* configure the flip on bitmap creation instead.
			*
			* @type {boolean}
			* @default true
			*/
			this.flipY = true;
			/**
			* Specifies the alignment requirements for the start of each pixel row in memory.
			* The allowable values are `1` (byte-alignment), `2` (rows aligned to even-numbered bytes),
			* `4` (word-alignment), and `8` (rows start on double-word boundaries).
			*
			* @type {number}
			* @default 4
			*/
			this.unpackAlignment = 4;
			/**
			* Textures containing color data should be annotated with `SRGBColorSpace` or `LinearSRGBColorSpace`.
			*
			* @type {string}
			* @default NoColorSpace
			*/
			this.colorSpace = colorSpace;
			/**
			* An object that can be used to store custom data about the texture. It
			* should not hold references to functions as these will not be cloned.
			*
			* @type {Object}
			*/
			this.userData = {};
			/**
			* This can be used to only update a subregion or specific rows of the texture (for example, just the
			* first 3 rows). Use the `addUpdateRange()` function to add ranges to this array.
			*
			* @type {Array<Object>}
			*/
			this.updateRanges = [];
			/**
			* This starts at `0` and counts how many times {@link Texture#needsUpdate} is set to `true`.
			*
			* @type {number}
			* @readonly
			* @default 0
			*/
			this.version = 0;
			/**
			* A callback function, called when the texture is updated (e.g., when
			* {@link Texture#needsUpdate} has been set to true and then the texture is used).
			*
			* @type {?Function}
			* @default null
			*/
			this.onUpdate = null;
			/**
			* An optional back reference to the textures render target.
			*
			* @type {?(RenderTarget|WebGLRenderTarget)}
			* @default null
			*/
			this.renderTarget = null;
			/**
			* Indicates whether a texture belongs to a render target or not.
			*
			* @type {boolean}
			* @readonly
			* @default false
			*/
			this.isRenderTargetTexture = false;
			/**
			* Indicates if a texture should be handled like a texture array.
			*
			* @type {boolean}
			* @readonly
			* @default false
			*/
			this.isArrayTexture = image && image.depth && image.depth > 1 ? true : false;
			/**
			* Indicates whether this texture should be processed by `PMREMGenerator` or not
			* (only relevant for render target textures).
			*
			* @type {number}
			* @readonly
			* @default 0
			*/
			this.pmremVersion = 0;
			/**
			* Whether the texture should use one of the 16 bit integer formats which are normalized
			* to [0, 1] or [-1, 1] (depending on signed/unsigned) when sampled.
			*
			* @type {boolean}
			* @default false
			*/
			this.normalized = false;
		}
		/**
		* The width of the texture in pixels.
		*/
		get width() {
			return this.source.getSize(_tempVec3).x;
		}
		/**
		* The height of the texture in pixels.
		*/
		get height() {
			return this.source.getSize(_tempVec3).y;
		}
		/**
		* The depth of the texture in pixels.
		*/
		get depth() {
			return this.source.getSize(_tempVec3).z;
		}
		/**
		* The image object holding the texture data.
		*
		* @type {?Object}
		*/
		get image() {
			return this.source.data;
		}
		set image(value) {
			this.source.data = value;
		}
		/**
		* Updates the texture transformation matrix from the properties {@link Texture#offset},
		* {@link Texture#repeat}, {@link Texture#rotation}, and {@link Texture#center}.
		*/
		updateMatrix() {
			this.matrix.setUvTransform(this.offset.x, this.offset.y, this.repeat.x, this.repeat.y, this.rotation, this.center.x, this.center.y);
		}
		/**
		* Adds a range of data in the data texture to be updated on the GPU.
		*
		* @param {number} start - Position at which to start update.
		* @param {number} count - The number of components to update.
		*/
		addUpdateRange(start, count) {
			this.updateRanges.push({
				start,
				count
			});
		}
		/**
		* Clears the update ranges.
		*/
		clearUpdateRanges() {
			this.updateRanges.length = 0;
		}
		/**
		* Returns a new texture with copied values from this instance.
		*
		* @return {Texture} A clone of this instance.
		*/
		clone() {
			return new this.constructor().copy(this);
		}
		/**
		* Copies the values of the given texture to this instance.
		*
		* @param {Texture} source - The texture to copy.
		* @return {Texture} A reference to this instance.
		*/
		copy(source) {
			this.name = source.name;
			this.source = source.source;
			this.mipmaps = source.mipmaps.slice(0);
			this.mapping = source.mapping;
			this.channel = source.channel;
			this.wrapS = source.wrapS;
			this.wrapT = source.wrapT;
			this.magFilter = source.magFilter;
			this.minFilter = source.minFilter;
			this.anisotropy = source.anisotropy;
			this.format = source.format;
			this.internalFormat = source.internalFormat;
			this.type = source.type;
			this.normalized = source.normalized;
			this.offset.copy(source.offset);
			this.repeat.copy(source.repeat);
			this.center.copy(source.center);
			this.rotation = source.rotation;
			this.matrixAutoUpdate = source.matrixAutoUpdate;
			this.matrix.copy(source.matrix);
			this.generateMipmaps = source.generateMipmaps;
			this.premultiplyAlpha = source.premultiplyAlpha;
			this.flipY = source.flipY;
			this.unpackAlignment = source.unpackAlignment;
			this.colorSpace = source.colorSpace;
			this.renderTarget = source.renderTarget;
			this.isRenderTargetTexture = source.isRenderTargetTexture;
			this.isArrayTexture = source.isArrayTexture;
			this.userData = JSON.parse(JSON.stringify(source.userData));
			this.needsUpdate = true;
			return this;
		}
		/**
		* Sets this texture's properties based on `values`.
		* @param {Object} values - A container with texture parameters.
		*/
		setValues(values) {
			for (const key in values) {
				const newValue = values[key];
				if (newValue === void 0) {
					warn(`Texture.setValues(): parameter '${key}' has value of undefined.`);
					continue;
				}
				const currentValue = this[key];
				if (currentValue === void 0) {
					warn(`Texture.setValues(): property '${key}' does not exist.`);
					continue;
				}
				if (currentValue && newValue && currentValue.isVector2 && newValue.isVector2) currentValue.copy(newValue);
				else if (currentValue && newValue && currentValue.isVector3 && newValue.isVector3) currentValue.copy(newValue);
				else if (currentValue && newValue && currentValue.isMatrix3 && newValue.isMatrix3) currentValue.copy(newValue);
				else this[key] = newValue;
			}
		}
		/**
		* Serializes the texture into JSON.
		*
		* @param {?(Object|string)} meta - An optional value holding meta information about the serialization.
		* @return {Object} A JSON object representing the serialized texture.
		* @see {@link ObjectLoader#parse}
		*/
		toJSON(meta) {
			const isRootObject = meta === void 0 || typeof meta === "string";
			if (!isRootObject && meta.textures[this.uuid] !== void 0) return meta.textures[this.uuid];
			const output = {
				metadata: {
					version: 4.7,
					type: "Texture",
					generator: "Texture.toJSON"
				},
				uuid: this.uuid,
				name: this.name,
				image: this.source.toJSON(meta).uuid,
				mapping: this.mapping,
				channel: this.channel,
				repeat: [this.repeat.x, this.repeat.y],
				offset: [this.offset.x, this.offset.y],
				center: [this.center.x, this.center.y],
				rotation: this.rotation,
				wrap: [this.wrapS, this.wrapT],
				format: this.format,
				internalFormat: this.internalFormat,
				type: this.type,
				normalized: this.normalized,
				colorSpace: this.colorSpace,
				minFilter: this.minFilter,
				magFilter: this.magFilter,
				anisotropy: this.anisotropy,
				flipY: this.flipY,
				generateMipmaps: this.generateMipmaps,
				premultiplyAlpha: this.premultiplyAlpha,
				unpackAlignment: this.unpackAlignment
			};
			if (Object.keys(this.userData).length > 0) output.userData = this.userData;
			if (!isRootObject) meta.textures[this.uuid] = output;
			return output;
		}
		/**
		* Frees the GPU-related resources allocated by this instance. Call this
		* method whenever this instance is no longer used in your app.
		*
		* @fires Texture#dispose
		*/
		dispose() {
			/**
			* Fires when the texture has been disposed of.
			*
			* @event Texture#dispose
			* @type {Object}
			*/
			this.dispatchEvent({ type: "dispose" });
		}
		/**
		* Transforms the given uv vector with the textures uv transformation matrix.
		*
		* @param {Vector2} uv - The uv vector.
		* @return {Vector2} The transformed uv vector.
		*/
		transformUv(uv) {
			if (this.mapping !== 300) return uv;
			uv.applyMatrix3(this.matrix);
			if (uv.x < 0 || uv.x > 1) switch (this.wrapS) {
				case RepeatWrapping:
					uv.x = uv.x - Math.floor(uv.x);
					break;
				case ClampToEdgeWrapping:
					uv.x = uv.x < 0 ? 0 : 1;
					break;
				case MirroredRepeatWrapping: if (Math.abs(Math.floor(uv.x) % 2) === 1) uv.x = Math.ceil(uv.x) - uv.x;
				else uv.x = uv.x - Math.floor(uv.x);
			}
			if (uv.y < 0 || uv.y > 1) switch (this.wrapT) {
				case RepeatWrapping:
					uv.y = uv.y - Math.floor(uv.y);
					break;
				case ClampToEdgeWrapping:
					uv.y = uv.y < 0 ? 0 : 1;
					break;
				case MirroredRepeatWrapping: if (Math.abs(Math.floor(uv.y) % 2) === 1) uv.y = Math.ceil(uv.y) - uv.y;
				else uv.y = uv.y - Math.floor(uv.y);
			}
			if (this.flipY) uv.y = 1 - uv.y;
			return uv;
		}
		/**
		* Setting this property to `true` indicates the engine the texture
		* must be updated in the next render. This triggers a texture upload
		* to the GPU and ensures correct texture parameter configuration.
		*
		* @type {boolean}
		* @default false
		* @param {boolean} value
		*/
		set needsUpdate(value) {
			if (value === true) {
				this.version++;
				this.source.needsUpdate = true;
			}
		}
		/**
		* Setting this property to `true` indicates the engine the PMREM
		* must be regenerated.
		*
		* @type {boolean}
		* @default false
		* @param {boolean} value
		*/
		set needsPMREMUpdate(value) {
			if (value === true) this.pmremVersion++;
		}
	};
	/**
	* The default image for all textures.
	*
	* @static
	* @type {?Image}
	* @default null
	*/
	Texture.DEFAULT_IMAGE = null;
	/**
	* The default mapping for all textures.
	*
	* @static
	* @type {number}
	* @default UVMapping
	*/
	Texture.DEFAULT_MAPPING = 300;
	/**
	* The default anisotropy value for all textures.
	*
	* @static
	* @type {number}
	* @default 1
	*/
	Texture.DEFAULT_ANISOTROPY = 1;
	(class Vector4 {
		static {
			/**
			* This flag can be used for type testing.
			*
			* @type {boolean}
			* @readonly
			* @default true
			*/
			Vector4.prototype.isVector4 = true;
		}
		/**
		* Constructs a new 4D vector.
		*
		* @param {number} [x=0] - The x value of this vector.
		* @param {number} [y=0] - The y value of this vector.
		* @param {number} [z=0] - The z value of this vector.
		* @param {number} [w=1] - The w value of this vector.
		*/
		constructor(x = 0, y = 0, z = 0, w = 1) {
			/**
			* The x value of this vector.
			*
			* @type {number}
			*/
			this.x = x;
			/**
			* The y value of this vector.
			*
			* @type {number}
			*/
			this.y = y;
			/**
			* The z value of this vector.
			*
			* @type {number}
			*/
			this.z = z;
			/**
			* The w value of this vector.
			*
			* @type {number}
			*/
			this.w = w;
		}
		/**
		* Alias for {@link Vector4#z}.
		*
		* @type {number}
		*/
		get width() {
			return this.z;
		}
		set width(value) {
			this.z = value;
		}
		/**
		* Alias for {@link Vector4#w}.
		*
		* @type {number}
		*/
		get height() {
			return this.w;
		}
		set height(value) {
			this.w = value;
		}
		/**
		* Sets the vector components.
		*
		* @param {number} x - The value of the x component.
		* @param {number} y - The value of the y component.
		* @param {number} z - The value of the z component.
		* @param {number} w - The value of the w component.
		* @return {Vector4} A reference to this vector.
		*/
		set(x, y, z, w) {
			this.x = x;
			this.y = y;
			this.z = z;
			this.w = w;
			return this;
		}
		/**
		* Sets the vector components to the same value.
		*
		* @param {number} scalar - The value to set for all vector components.
		* @return {Vector4} A reference to this vector.
		*/
		setScalar(scalar) {
			this.x = scalar;
			this.y = scalar;
			this.z = scalar;
			this.w = scalar;
			return this;
		}
		/**
		* Sets the vector's x component to the given value
		*
		* @param {number} x - The value to set.
		* @return {Vector4} A reference to this vector.
		*/
		setX(x) {
			this.x = x;
			return this;
		}
		/**
		* Sets the vector's y component to the given value
		*
		* @param {number} y - The value to set.
		* @return {Vector4} A reference to this vector.
		*/
		setY(y) {
			this.y = y;
			return this;
		}
		/**
		* Sets the vector's z component to the given value
		*
		* @param {number} z - The value to set.
		* @return {Vector4} A reference to this vector.
		*/
		setZ(z) {
			this.z = z;
			return this;
		}
		/**
		* Sets the vector's w component to the given value
		*
		* @param {number} w - The value to set.
		* @return {Vector4} A reference to this vector.
		*/
		setW(w) {
			this.w = w;
			return this;
		}
		/**
		* Allows to set a vector component with an index.
		*
		* @param {number} index - The component index. `0` equals to x, `1` equals to y,
		* `2` equals to z, `3` equals to w.
		* @param {number} value - The value to set.
		* @return {Vector4} A reference to this vector.
		*/
		setComponent(index, value) {
			switch (index) {
				case 0:
					this.x = value;
					break;
				case 1:
					this.y = value;
					break;
				case 2:
					this.z = value;
					break;
				case 3:
					this.w = value;
					break;
				default: throw new Error("THREE.Vector4: index is out of range: " + index);
			}
			return this;
		}
		/**
		* Returns the value of the vector component which matches the given index.
		*
		* @param {number} index - The component index. `0` equals to x, `1` equals to y,
		* `2` equals to z, `3` equals to w.
		* @return {number} A vector component value.
		*/
		getComponent(index) {
			switch (index) {
				case 0: return this.x;
				case 1: return this.y;
				case 2: return this.z;
				case 3: return this.w;
				default: throw new Error("THREE.Vector4: index is out of range: " + index);
			}
		}
		/**
		* Returns a new vector with copied values from this instance.
		*
		* @return {Vector4} A clone of this instance.
		*/
		clone() {
			return new this.constructor(this.x, this.y, this.z, this.w);
		}
		/**
		* Copies the values of the given vector to this instance.
		*
		* @param {Vector3|Vector4} v - The vector to copy.
		* @return {Vector4} A reference to this vector.
		*/
		copy(v) {
			this.x = v.x;
			this.y = v.y;
			this.z = v.z;
			this.w = v.w !== void 0 ? v.w : 1;
			return this;
		}
		/**
		* Adds the given vector to this instance.
		*
		* @param {Vector4} v - The vector to add.
		* @return {Vector4} A reference to this vector.
		*/
		add(v) {
			this.x += v.x;
			this.y += v.y;
			this.z += v.z;
			this.w += v.w;
			return this;
		}
		/**
		* Adds the given scalar value to all components of this instance.
		*
		* @param {number} s - The scalar to add.
		* @return {Vector4} A reference to this vector.
		*/
		addScalar(s) {
			this.x += s;
			this.y += s;
			this.z += s;
			this.w += s;
			return this;
		}
		/**
		* Adds the given vectors and stores the result in this instance.
		*
		* @param {Vector4} a - The first vector.
		* @param {Vector4} b - The second vector.
		* @return {Vector4} A reference to this vector.
		*/
		addVectors(a, b) {
			this.x = a.x + b.x;
			this.y = a.y + b.y;
			this.z = a.z + b.z;
			this.w = a.w + b.w;
			return this;
		}
		/**
		* Adds the given vector scaled by the given factor to this instance.
		*
		* @param {Vector4} v - The vector.
		* @param {number} s - The factor that scales `v`.
		* @return {Vector4} A reference to this vector.
		*/
		addScaledVector(v, s) {
			this.x += v.x * s;
			this.y += v.y * s;
			this.z += v.z * s;
			this.w += v.w * s;
			return this;
		}
		/**
		* Subtracts the given vector from this instance.
		*
		* @param {Vector4} v - The vector to subtract.
		* @return {Vector4} A reference to this vector.
		*/
		sub(v) {
			this.x -= v.x;
			this.y -= v.y;
			this.z -= v.z;
			this.w -= v.w;
			return this;
		}
		/**
		* Subtracts the given scalar value from all components of this instance.
		*
		* @param {number} s - The scalar to subtract.
		* @return {Vector4} A reference to this vector.
		*/
		subScalar(s) {
			this.x -= s;
			this.y -= s;
			this.z -= s;
			this.w -= s;
			return this;
		}
		/**
		* Subtracts the given vectors and stores the result in this instance.
		*
		* @param {Vector4} a - The first vector.
		* @param {Vector4} b - The second vector.
		* @return {Vector4} A reference to this vector.
		*/
		subVectors(a, b) {
			this.x = a.x - b.x;
			this.y = a.y - b.y;
			this.z = a.z - b.z;
			this.w = a.w - b.w;
			return this;
		}
		/**
		* Multiplies the given vector with this instance.
		*
		* @param {Vector4} v - The vector to multiply.
		* @return {Vector4} A reference to this vector.
		*/
		multiply(v) {
			this.x *= v.x;
			this.y *= v.y;
			this.z *= v.z;
			this.w *= v.w;
			return this;
		}
		/**
		* Multiplies the given scalar value with all components of this instance.
		*
		* @param {number} scalar - The scalar to multiply.
		* @return {Vector4} A reference to this vector.
		*/
		multiplyScalar(scalar) {
			this.x *= scalar;
			this.y *= scalar;
			this.z *= scalar;
			this.w *= scalar;
			return this;
		}
		/**
		* Multiplies this vector with the given 4x4 matrix.
		*
		* @param {Matrix4} m - The 4x4 matrix.
		* @return {Vector4} A reference to this vector.
		*/
		applyMatrix4(m) {
			const x = this.x, y = this.y, z = this.z, w = this.w;
			const e = m.elements;
			this.x = e[0] * x + e[4] * y + e[8] * z + e[12] * w;
			this.y = e[1] * x + e[5] * y + e[9] * z + e[13] * w;
			this.z = e[2] * x + e[6] * y + e[10] * z + e[14] * w;
			this.w = e[3] * x + e[7] * y + e[11] * z + e[15] * w;
			return this;
		}
		/**
		* Divides this instance by the given vector.
		*
		* @param {Vector4} v - The vector to divide.
		* @return {Vector4} A reference to this vector.
		*/
		divide(v) {
			this.x /= v.x;
			this.y /= v.y;
			this.z /= v.z;
			this.w /= v.w;
			return this;
		}
		/**
		* Divides this vector by the given scalar.
		*
		* @param {number} scalar - The scalar to divide.
		* @return {Vector4} A reference to this vector.
		*/
		divideScalar(scalar) {
			return this.multiplyScalar(1 / scalar);
		}
		/**
		* Sets the x, y and z components of this
		* vector to the quaternion's axis and w to the angle.
		*
		* @param {Quaternion} q - The Quaternion to set.
		* @return {Vector4} A reference to this vector.
		*/
		setAxisAngleFromQuaternion(q) {
			this.w = 2 * Math.acos(q.w);
			const s = Math.sqrt(1 - q.w * q.w);
			if (s < 1e-4) {
				this.x = 1;
				this.y = 0;
				this.z = 0;
			} else {
				this.x = q.x / s;
				this.y = q.y / s;
				this.z = q.z / s;
			}
			return this;
		}
		/**
		* Sets the x, y and z components of this
		* vector to the axis of rotation and w to the angle.
		*
		* @param {Matrix4} m - A 4x4 matrix of which the upper left 3x3 matrix is a pure rotation matrix.
		* @return {Vector4} A reference to this vector.
		*/
		setAxisAngleFromRotationMatrix(m) {
			let angle, x, y, z;
			const epsilon = .01, epsilon2 = .1, te = m.elements, m11 = te[0], m12 = te[4], m13 = te[8], m21 = te[1], m22 = te[5], m23 = te[9], m31 = te[2], m32 = te[6], m33 = te[10];
			if (Math.abs(m12 - m21) < epsilon && Math.abs(m13 - m31) < epsilon && Math.abs(m23 - m32) < epsilon) {
				if (Math.abs(m12 + m21) < epsilon2 && Math.abs(m13 + m31) < epsilon2 && Math.abs(m23 + m32) < epsilon2 && Math.abs(m11 + m22 + m33 - 3) < epsilon2) {
					this.set(1, 0, 0, 0);
					return this;
				}
				angle = Math.PI;
				const xx = (m11 + 1) / 2;
				const yy = (m22 + 1) / 2;
				const zz = (m33 + 1) / 2;
				const xy = (m12 + m21) / 4;
				const xz = (m13 + m31) / 4;
				const yz = (m23 + m32) / 4;
				if (xx > yy && xx > zz) {
					if (xx < epsilon) {
						x = 0;
						y = .707106781;
						z = .707106781;
					} else {
						x = Math.sqrt(xx);
						y = xy / x;
						z = xz / x;
					}
				} else if (yy > zz) {
					if (yy < epsilon) {
						x = .707106781;
						y = 0;
						z = .707106781;
					} else {
						y = Math.sqrt(yy);
						x = xy / y;
						z = yz / y;
					}
				} else if (zz < epsilon) {
					x = .707106781;
					y = .707106781;
					z = 0;
				} else {
					z = Math.sqrt(zz);
					x = xz / z;
					y = yz / z;
				}
				this.set(x, y, z, angle);
				return this;
			}
			let s = Math.sqrt((m32 - m23) * (m32 - m23) + (m13 - m31) * (m13 - m31) + (m21 - m12) * (m21 - m12));
			if (Math.abs(s) < .001) s = 1;
			this.x = (m32 - m23) / s;
			this.y = (m13 - m31) / s;
			this.z = (m21 - m12) / s;
			this.w = Math.acos((m11 + m22 + m33 - 1) / 2);
			return this;
		}
		/**
		* Sets the vector components to the position elements of the
		* given transformation matrix.
		*
		* @param {Matrix4} m - The 4x4 matrix.
		* @return {Vector4} A reference to this vector.
		*/
		setFromMatrixPosition(m) {
			const e = m.elements;
			this.x = e[12];
			this.y = e[13];
			this.z = e[14];
			this.w = e[15];
			return this;
		}
		/**
		* If this vector's x, y, z or w value is greater than the given vector's x, y, z or w
		* value, replace that value with the corresponding min value.
		*
		* @param {Vector4} v - The vector.
		* @return {Vector4} A reference to this vector.
		*/
		min(v) {
			this.x = Math.min(this.x, v.x);
			this.y = Math.min(this.y, v.y);
			this.z = Math.min(this.z, v.z);
			this.w = Math.min(this.w, v.w);
			return this;
		}
		/**
		* If this vector's x, y, z or w value is less than the given vector's x, y, z or w
		* value, replace that value with the corresponding max value.
		*
		* @param {Vector4} v - The vector.
		* @return {Vector4} A reference to this vector.
		*/
		max(v) {
			this.x = Math.max(this.x, v.x);
			this.y = Math.max(this.y, v.y);
			this.z = Math.max(this.z, v.z);
			this.w = Math.max(this.w, v.w);
			return this;
		}
		/**
		* If this vector's x, y, z or w value is greater than the max vector's x, y, z or w
		* value, it is replaced by the corresponding value.
		* If this vector's x, y, z or w value is less than the min vector's x, y, z or w value,
		* it is replaced by the corresponding value.
		*
		* @param {Vector4} min - The minimum x, y and z values.
		* @param {Vector4} max - The maximum x, y and z values in the desired range.
		* @return {Vector4} A reference to this vector.
		*/
		clamp(min, max) {
			this.x = clamp(this.x, min.x, max.x);
			this.y = clamp(this.y, min.y, max.y);
			this.z = clamp(this.z, min.z, max.z);
			this.w = clamp(this.w, min.w, max.w);
			return this;
		}
		/**
		* If this vector's x, y, z or w values are greater than the max value, they are
		* replaced by the max value.
		* If this vector's x, y, z or w values are less than the min value, they are
		* replaced by the min value.
		*
		* @param {number} minVal - The minimum value the components will be clamped to.
		* @param {number} maxVal - The maximum value the components will be clamped to.
		* @return {Vector4} A reference to this vector.
		*/
		clampScalar(minVal, maxVal) {
			this.x = clamp(this.x, minVal, maxVal);
			this.y = clamp(this.y, minVal, maxVal);
			this.z = clamp(this.z, minVal, maxVal);
			this.w = clamp(this.w, minVal, maxVal);
			return this;
		}
		/**
		* If this vector's length is greater than the max value, it is replaced by
		* the max value.
		* If this vector's length is less than the min value, it is replaced by the
		* min value.
		*
		* @param {number} min - The minimum value the vector length will be clamped to.
		* @param {number} max - The maximum value the vector length will be clamped to.
		* @return {Vector4} A reference to this vector.
		*/
		clampLength(min, max) {
			const length = this.length();
			return this.divideScalar(length || 1).multiplyScalar(clamp(length, min, max));
		}
		/**
		* The components of this vector are rounded down to the nearest integer value.
		*
		* @return {Vector4} A reference to this vector.
		*/
		floor() {
			this.x = Math.floor(this.x);
			this.y = Math.floor(this.y);
			this.z = Math.floor(this.z);
			this.w = Math.floor(this.w);
			return this;
		}
		/**
		* The components of this vector are rounded up to the nearest integer value.
		*
		* @return {Vector4} A reference to this vector.
		*/
		ceil() {
			this.x = Math.ceil(this.x);
			this.y = Math.ceil(this.y);
			this.z = Math.ceil(this.z);
			this.w = Math.ceil(this.w);
			return this;
		}
		/**
		* The components of this vector are rounded to the nearest integer value
		*
		* @return {Vector4} A reference to this vector.
		*/
		round() {
			this.x = Math.round(this.x);
			this.y = Math.round(this.y);
			this.z = Math.round(this.z);
			this.w = Math.round(this.w);
			return this;
		}
		/**
		* The components of this vector are rounded towards zero (up if negative,
		* down if positive) to an integer value.
		*
		* @return {Vector4} A reference to this vector.
		*/
		roundToZero() {
			this.x = Math.trunc(this.x);
			this.y = Math.trunc(this.y);
			this.z = Math.trunc(this.z);
			this.w = Math.trunc(this.w);
			return this;
		}
		/**
		* Inverts this vector - i.e. sets x = -x, y = -y, z = -z, w = -w.
		*
		* @return {Vector4} A reference to this vector.
		*/
		negate() {
			this.x = -this.x;
			this.y = -this.y;
			this.z = -this.z;
			this.w = -this.w;
			return this;
		}
		/**
		* Calculates the dot product of the given vector with this instance.
		*
		* @param {Vector4} v - The vector to compute the dot product with.
		* @return {number} The result of the dot product.
		*/
		dot(v) {
			return this.x * v.x + this.y * v.y + this.z * v.z + this.w * v.w;
		}
		/**
		* Computes the square of the Euclidean length (straight-line length) from
		* (0, 0, 0, 0) to (x, y, z, w). If you are comparing the lengths of vectors, you should
		* compare the length squared instead as it is slightly more efficient to calculate.
		*
		* @return {number} The square length of this vector.
		*/
		lengthSq() {
			return this.x * this.x + this.y * this.y + this.z * this.z + this.w * this.w;
		}
		/**
		* Computes the  Euclidean length (straight-line length) from (0, 0, 0, 0) to (x, y, z, w).
		*
		* @return {number} The length of this vector.
		*/
		length() {
			return Math.sqrt(this.x * this.x + this.y * this.y + this.z * this.z + this.w * this.w);
		}
		/**
		* Computes the Manhattan length of this vector.
		*
		* @return {number} The length of this vector.
		*/
		manhattanLength() {
			return Math.abs(this.x) + Math.abs(this.y) + Math.abs(this.z) + Math.abs(this.w);
		}
		/**
		* Converts this vector to a unit vector - that is, sets it equal to a vector
		* with the same direction as this one, but with a vector length of `1`.
		*
		* @return {Vector4} A reference to this vector.
		*/
		normalize() {
			return this.divideScalar(this.length() || 1);
		}
		/**
		* Sets this vector to a vector with the same direction as this one, but
		* with the specified length.
		*
		* @param {number} length - The new length of this vector.
		* @return {Vector4} A reference to this vector.
		*/
		setLength(length) {
			return this.normalize().multiplyScalar(length);
		}
		/**
		* Linearly interpolates between the given vector and this instance, where
		* alpha is the percent distance along the line - alpha = 0 will be this
		* vector, and alpha = 1 will be the given one.
		*
		* @param {Vector4} v - The vector to interpolate towards.
		* @param {number} alpha - The interpolation factor, typically in the closed interval `[0, 1]`.
		* @return {Vector4} A reference to this vector.
		*/
		lerp(v, alpha) {
			this.x += (v.x - this.x) * alpha;
			this.y += (v.y - this.y) * alpha;
			this.z += (v.z - this.z) * alpha;
			this.w += (v.w - this.w) * alpha;
			return this;
		}
		/**
		* Linearly interpolates between the given vectors, where alpha is the percent
		* distance along the line - alpha = 0 will be first vector, and alpha = 1 will
		* be the second one. The result is stored in this instance.
		*
		* @param {Vector4} v1 - The first vector.
		* @param {Vector4} v2 - The second vector.
		* @param {number} alpha - The interpolation factor, typically in the closed interval `[0, 1]`.
		* @return {Vector4} A reference to this vector.
		*/
		lerpVectors(v1, v2, alpha) {
			this.x = v1.x + (v2.x - v1.x) * alpha;
			this.y = v1.y + (v2.y - v1.y) * alpha;
			this.z = v1.z + (v2.z - v1.z) * alpha;
			this.w = v1.w + (v2.w - v1.w) * alpha;
			return this;
		}
		/**
		* Returns `true` if this vector is equal with the given one.
		*
		* @param {Vector4} v - The vector to test for equality.
		* @return {boolean} Whether this vector is equal with the given one.
		*/
		equals(v) {
			return v.x === this.x && v.y === this.y && v.z === this.z && v.w === this.w;
		}
		/**
		* Sets this vector's x value to be `array[ offset ]`, y value to be `array[ offset + 1 ]`,
		* z value to be `array[ offset + 2 ]`, w value to be `array[ offset + 3 ]`.
		*
		* @param {Array<number>} array - An array holding the vector component values.
		* @param {number} [offset=0] - The offset into the array.
		* @return {Vector4} A reference to this vector.
		*/
		fromArray(array, offset = 0) {
			this.x = array[offset];
			this.y = array[offset + 1];
			this.z = array[offset + 2];
			this.w = array[offset + 3];
			return this;
		}
		/**
		* Writes the components of this vector to the given array. If no array is provided,
		* the method returns a new instance.
		*
		* @param {Array<number>} [array=[]] - The target array holding the vector components.
		* @param {number} [offset=0] - Index of the first element in the array.
		* @return {Array<number>} The vector components.
		*/
		toArray(array = [], offset = 0) {
			array[offset] = this.x;
			array[offset + 1] = this.y;
			array[offset + 2] = this.z;
			array[offset + 3] = this.w;
			return array;
		}
		/**
		* Sets the components of this vector from the given buffer attribute.
		*
		* @param {BufferAttribute} attribute - The buffer attribute holding vector data.
		* @param {number} index - The index into the attribute.
		* @return {Vector4} A reference to this vector.
		*/
		fromBufferAttribute(attribute, index) {
			this.x = attribute.getX(index);
			this.y = attribute.getY(index);
			this.z = attribute.getZ(index);
			this.w = attribute.getW(index);
			return this;
		}
		/**
		* Sets each component of this vector to a pseudo-random value between `0` and
		* `1`, excluding `1`.
		*
		* @return {Vector4} A reference to this vector.
		*/
		random() {
			this.x = Math.random();
			this.y = Math.random();
			this.z = Math.random();
			this.w = Math.random();
			return this;
		}
		*[Symbol.iterator]() {
			yield this.x;
			yield this.y;
			yield this.z;
			yield this.w;
		}
	});
	/**
	* Represents a 4x4 matrix.
	*
	* The most common use of a 4x4 matrix in 3D computer graphics is as a transformation matrix.
	* For an introduction to transformation matrices as used in WebGL, check out [this tutorial](https://www.opengl-tutorial.org/beginners-tutorials/tutorial-3-matrices)
	*
	* This allows a 3D vector representing a point in 3D space to undergo
	* transformations such as translation, rotation, shear, scale, reflection,
	* orthogonal or perspective projection and so on, by being multiplied by the
	* matrix. This is known as `applying` the matrix to the vector.
	*
	* A Note on Row-Major and Column-Major Ordering:
	*
	* The constructor and {@link Matrix3#set} method take arguments in
	* [row-major](https://en.wikipedia.org/wiki/Row-_and_column-major_order#Column-major_order)
	* order, while internally they are stored in the {@link Matrix3#elements} array in column-major order.
	* This means that calling:
	* ```js
	* const m = new THREE.Matrix4();
	* m.set( 11, 12, 13, 14,
	*        21, 22, 23, 24,
	*        31, 32, 33, 34,
	*        41, 42, 43, 44 );
	* ```
	* will result in the elements array containing:
	* ```js
	* m.elements = [ 11, 21, 31, 41,
	*                12, 22, 32, 42,
	*                13, 23, 33, 43,
	*                14, 24, 34, 44 ];
	* ```
	* and internally all calculations are performed using column-major ordering.
	* However, as the actual ordering makes no difference mathematically and
	* most people are used to thinking about matrices in row-major order, the
	* three.js documentation shows matrices in row-major order. Just bear in
	* mind that if you are reading the source code, you'll have to take the
	* transpose of any matrices outlined here to make sense of the calculations.
	*/
	var Matrix4 = class Matrix4 {
		static {
			/**
			* This flag can be used for type testing.
			*
			* @type {boolean}
			* @readonly
			* @default true
			*/
			Matrix4.prototype.isMatrix4 = true;
		}
		/**
		* Constructs a new 4x4 matrix. The arguments are supposed to be
		* in row-major order. If no arguments are provided, the constructor
		* initializes the matrix as an identity matrix.
		*
		* @param {number} [n11] - 1-1 matrix element.
		* @param {number} [n12] - 1-2 matrix element.
		* @param {number} [n13] - 1-3 matrix element.
		* @param {number} [n14] - 1-4 matrix element.
		* @param {number} [n21] - 2-1 matrix element.
		* @param {number} [n22] - 2-2 matrix element.
		* @param {number} [n23] - 2-3 matrix element.
		* @param {number} [n24] - 2-4 matrix element.
		* @param {number} [n31] - 3-1 matrix element.
		* @param {number} [n32] - 3-2 matrix element.
		* @param {number} [n33] - 3-3 matrix element.
		* @param {number} [n34] - 3-4 matrix element.
		* @param {number} [n41] - 4-1 matrix element.
		* @param {number} [n42] - 4-2 matrix element.
		* @param {number} [n43] - 4-3 matrix element.
		* @param {number} [n44] - 4-4 matrix element.
		*/
		constructor(n11, n12, n13, n14, n21, n22, n23, n24, n31, n32, n33, n34, n41, n42, n43, n44) {
			/**
			* A column-major list of matrix values.
			*
			* @type {Array<number>}
			*/
			this.elements = [
				1,
				0,
				0,
				0,
				0,
				1,
				0,
				0,
				0,
				0,
				1,
				0,
				0,
				0,
				0,
				1
			];
			if (n11 !== void 0) this.set(n11, n12, n13, n14, n21, n22, n23, n24, n31, n32, n33, n34, n41, n42, n43, n44);
		}
		/**
		* Sets the elements of the matrix.The arguments are supposed to be
		* in row-major order.
		*
		* @param {number} [n11] - 1-1 matrix element.
		* @param {number} [n12] - 1-2 matrix element.
		* @param {number} [n13] - 1-3 matrix element.
		* @param {number} [n14] - 1-4 matrix element.
		* @param {number} [n21] - 2-1 matrix element.
		* @param {number} [n22] - 2-2 matrix element.
		* @param {number} [n23] - 2-3 matrix element.
		* @param {number} [n24] - 2-4 matrix element.
		* @param {number} [n31] - 3-1 matrix element.
		* @param {number} [n32] - 3-2 matrix element.
		* @param {number} [n33] - 3-3 matrix element.
		* @param {number} [n34] - 3-4 matrix element.
		* @param {number} [n41] - 4-1 matrix element.
		* @param {number} [n42] - 4-2 matrix element.
		* @param {number} [n43] - 4-3 matrix element.
		* @param {number} [n44] - 4-4 matrix element.
		* @return {Matrix4} A reference to this matrix.
		*/
		set(n11, n12, n13, n14, n21, n22, n23, n24, n31, n32, n33, n34, n41, n42, n43, n44) {
			const te = this.elements;
			te[0] = n11;
			te[4] = n12;
			te[8] = n13;
			te[12] = n14;
			te[1] = n21;
			te[5] = n22;
			te[9] = n23;
			te[13] = n24;
			te[2] = n31;
			te[6] = n32;
			te[10] = n33;
			te[14] = n34;
			te[3] = n41;
			te[7] = n42;
			te[11] = n43;
			te[15] = n44;
			return this;
		}
		/**
		* Sets this matrix to the 4x4 identity matrix.
		*
		* @return {Matrix4} A reference to this matrix.
		*/
		identity() {
			this.set(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1);
			return this;
		}
		/**
		* Returns a matrix with copied values from this instance.
		*
		* @return {Matrix4} A clone of this instance.
		*/
		clone() {
			return new Matrix4().fromArray(this.elements);
		}
		/**
		* Copies the values of the given matrix to this instance.
		*
		* @param {Matrix4} m - The matrix to copy.
		* @return {Matrix4} A reference to this matrix.
		*/
		copy(m) {
			const te = this.elements;
			const me = m.elements;
			te[0] = me[0];
			te[1] = me[1];
			te[2] = me[2];
			te[3] = me[3];
			te[4] = me[4];
			te[5] = me[5];
			te[6] = me[6];
			te[7] = me[7];
			te[8] = me[8];
			te[9] = me[9];
			te[10] = me[10];
			te[11] = me[11];
			te[12] = me[12];
			te[13] = me[13];
			te[14] = me[14];
			te[15] = me[15];
			return this;
		}
		/**
		* Copies the translation component of the given matrix
		* into this matrix's translation component.
		*
		* @param {Matrix4} m - The matrix to copy the translation component.
		* @return {Matrix4} A reference to this matrix.
		*/
		copyPosition(m) {
			const te = this.elements, me = m.elements;
			te[12] = me[12];
			te[13] = me[13];
			te[14] = me[14];
			return this;
		}
		/**
		* Set the upper 3x3 elements of this matrix to the values of given 3x3 matrix.
		*
		* @param {Matrix3} m - The 3x3 matrix.
		* @return {Matrix4} A reference to this matrix.
		*/
		setFromMatrix3(m) {
			const me = m.elements;
			this.set(me[0], me[3], me[6], 0, me[1], me[4], me[7], 0, me[2], me[5], me[8], 0, 0, 0, 0, 1);
			return this;
		}
		/**
		* Extracts the basis vectors of this matrix into the three vectors provided.
		*
		* @param {Vector3} xAxis - The basis's x axis.
		* @param {Vector3} yAxis - The basis's y axis.
		* @param {Vector3} zAxis - The basis's z axis.
		* @return {Matrix4} A reference to this matrix.
		*/
		extractBasis(xAxis, yAxis, zAxis) {
			if (this.determinantAffine() === 0) {
				xAxis.set(1, 0, 0);
				yAxis.set(0, 1, 0);
				zAxis.set(0, 0, 1);
				return this;
			}
			xAxis.setFromMatrixColumn(this, 0);
			yAxis.setFromMatrixColumn(this, 1);
			zAxis.setFromMatrixColumn(this, 2);
			return this;
		}
		/**
		* Sets the given basis vectors to this matrix.
		*
		* @param {Vector3} xAxis - The basis's x axis.
		* @param {Vector3} yAxis - The basis's y axis.
		* @param {Vector3} zAxis - The basis's z axis.
		* @return {Matrix4} A reference to this matrix.
		*/
		makeBasis(xAxis, yAxis, zAxis) {
			this.set(xAxis.x, yAxis.x, zAxis.x, 0, xAxis.y, yAxis.y, zAxis.y, 0, xAxis.z, yAxis.z, zAxis.z, 0, 0, 0, 0, 1);
			return this;
		}
		/**
		* Extracts the rotation component of the given matrix
		* into this matrix's rotation component.
		*
		* Note: This method does not support reflection matrices.
		*
		* @param {Matrix4} m - The matrix.
		* @return {Matrix4} A reference to this matrix.
		*/
		extractRotation(m) {
			if (m.determinantAffine() === 0) return this.identity();
			const te = this.elements;
			const me = m.elements;
			const scaleX = 1 / _v1$7.setFromMatrixColumn(m, 0).length();
			const scaleY = 1 / _v1$7.setFromMatrixColumn(m, 1).length();
			const scaleZ = 1 / _v1$7.setFromMatrixColumn(m, 2).length();
			te[0] = me[0] * scaleX;
			te[1] = me[1] * scaleX;
			te[2] = me[2] * scaleX;
			te[3] = 0;
			te[4] = me[4] * scaleY;
			te[5] = me[5] * scaleY;
			te[6] = me[6] * scaleY;
			te[7] = 0;
			te[8] = me[8] * scaleZ;
			te[9] = me[9] * scaleZ;
			te[10] = me[10] * scaleZ;
			te[11] = 0;
			te[12] = 0;
			te[13] = 0;
			te[14] = 0;
			te[15] = 1;
			return this;
		}
		/**
		* Sets the rotation component (the upper left 3x3 matrix) of this matrix to
		* the rotation specified by the given Euler angles. The rest of
		* the matrix is set to the identity. Depending on the {@link Euler#order},
		* there are six possible outcomes. See [this page](https://en.wikipedia.org/wiki/Euler_angles#Rotation_matrix)
		* for a complete list.
		*
		* @param {Euler} euler - The Euler angles.
		* @return {Matrix4} A reference to this matrix.
		*/
		makeRotationFromEuler(euler) {
			const te = this.elements;
			const x = euler.x, y = euler.y, z = euler.z;
			const a = Math.cos(x), b = Math.sin(x);
			const c = Math.cos(y), d = Math.sin(y);
			const e = Math.cos(z), f = Math.sin(z);
			if (euler.order === "XYZ") {
				const ae = a * e, af = a * f, be = b * e, bf = b * f;
				te[0] = c * e;
				te[4] = -c * f;
				te[8] = d;
				te[1] = af + be * d;
				te[5] = ae - bf * d;
				te[9] = -b * c;
				te[2] = bf - ae * d;
				te[6] = be + af * d;
				te[10] = a * c;
			} else if (euler.order === "YXZ") {
				const ce = c * e, cf = c * f, de = d * e, df = d * f;
				te[0] = ce + df * b;
				te[4] = de * b - cf;
				te[8] = a * d;
				te[1] = a * f;
				te[5] = a * e;
				te[9] = -b;
				te[2] = cf * b - de;
				te[6] = df + ce * b;
				te[10] = a * c;
			} else if (euler.order === "ZXY") {
				const ce = c * e, cf = c * f, de = d * e, df = d * f;
				te[0] = ce - df * b;
				te[4] = -a * f;
				te[8] = de + cf * b;
				te[1] = cf + de * b;
				te[5] = a * e;
				te[9] = df - ce * b;
				te[2] = -a * d;
				te[6] = b;
				te[10] = a * c;
			} else if (euler.order === "ZYX") {
				const ae = a * e, af = a * f, be = b * e, bf = b * f;
				te[0] = c * e;
				te[4] = be * d - af;
				te[8] = ae * d + bf;
				te[1] = c * f;
				te[5] = bf * d + ae;
				te[9] = af * d - be;
				te[2] = -d;
				te[6] = b * c;
				te[10] = a * c;
			} else if (euler.order === "YZX") {
				const ac = a * c, ad = a * d, bc = b * c, bd = b * d;
				te[0] = c * e;
				te[4] = bd - ac * f;
				te[8] = bc * f + ad;
				te[1] = f;
				te[5] = a * e;
				te[9] = -b * e;
				te[2] = -d * e;
				te[6] = ad * f + bc;
				te[10] = ac - bd * f;
			} else if (euler.order === "XZY") {
				const ac = a * c, ad = a * d, bc = b * c, bd = b * d;
				te[0] = c * e;
				te[4] = -f;
				te[8] = d * e;
				te[1] = ac * f + bd;
				te[5] = a * e;
				te[9] = ad * f - bc;
				te[2] = bc * f - ad;
				te[6] = b * e;
				te[10] = bd * f + ac;
			}
			te[3] = 0;
			te[7] = 0;
			te[11] = 0;
			te[12] = 0;
			te[13] = 0;
			te[14] = 0;
			te[15] = 1;
			return this;
		}
		/**
		* Sets the rotation component of this matrix to the rotation specified by
		* the given Quaternion as outlined [here](https://en.wikipedia.org/wiki/Rotation_matrix#Quaternion)
		* The rest of the matrix is set to the identity.
		*
		* @param {Quaternion} q - The Quaternion.
		* @return {Matrix4} A reference to this matrix.
		*/
		makeRotationFromQuaternion(q) {
			return this.compose(_zero, q, _one);
		}
		/**
		* Sets the rotation component of the transformation matrix, looking from `eye` towards
		* `target`, and oriented by the up-direction.
		*
		* @param {Vector3} eye - The eye vector.
		* @param {Vector3} target - The target vector.
		* @param {Vector3} up - The up vector.
		* @return {Matrix4} A reference to this matrix.
		*/
		lookAt(eye, target, up) {
			const te = this.elements;
			_z.subVectors(eye, target);
			if (_z.lengthSq() === 0) _z.z = 1;
			_z.normalize();
			_x.crossVectors(up, _z);
			if (_x.lengthSq() === 0) {
				if (Math.abs(up.z) === 1) _z.x += 1e-4;
				else _z.z += 1e-4;
				_z.normalize();
				_x.crossVectors(up, _z);
			}
			_x.normalize();
			_y.crossVectors(_z, _x);
			te[0] = _x.x;
			te[4] = _y.x;
			te[8] = _z.x;
			te[1] = _x.y;
			te[5] = _y.y;
			te[9] = _z.y;
			te[2] = _x.z;
			te[6] = _y.z;
			te[10] = _z.z;
			return this;
		}
		/**
		* Post-multiplies this matrix by the given 4x4 matrix.
		*
		* @param {Matrix4} m - The matrix to multiply with.
		* @return {Matrix4} A reference to this matrix.
		*/
		multiply(m) {
			return this.multiplyMatrices(this, m);
		}
		/**
		* Pre-multiplies this matrix by the given 4x4 matrix.
		*
		* @param {Matrix4} m - The matrix to multiply with.
		* @return {Matrix4} A reference to this matrix.
		*/
		premultiply(m) {
			return this.multiplyMatrices(m, this);
		}
		/**
		* Multiples the given 4x4 matrices and stores the result
		* in this matrix.
		*
		* @param {Matrix4} a - The first matrix.
		* @param {Matrix4} b - The second matrix.
		* @return {Matrix4} A reference to this matrix.
		*/
		multiplyMatrices(a, b) {
			const ae = a.elements;
			const be = b.elements;
			const te = this.elements;
			const a11 = ae[0], a12 = ae[4], a13 = ae[8], a14 = ae[12];
			const a21 = ae[1], a22 = ae[5], a23 = ae[9], a24 = ae[13];
			const a31 = ae[2], a32 = ae[6], a33 = ae[10], a34 = ae[14];
			const a41 = ae[3], a42 = ae[7], a43 = ae[11], a44 = ae[15];
			const b11 = be[0], b12 = be[4], b13 = be[8], b14 = be[12];
			const b21 = be[1], b22 = be[5], b23 = be[9], b24 = be[13];
			const b31 = be[2], b32 = be[6], b33 = be[10], b34 = be[14];
			const b41 = be[3], b42 = be[7], b43 = be[11], b44 = be[15];
			te[0] = a11 * b11 + a12 * b21 + a13 * b31 + a14 * b41;
			te[4] = a11 * b12 + a12 * b22 + a13 * b32 + a14 * b42;
			te[8] = a11 * b13 + a12 * b23 + a13 * b33 + a14 * b43;
			te[12] = a11 * b14 + a12 * b24 + a13 * b34 + a14 * b44;
			te[1] = a21 * b11 + a22 * b21 + a23 * b31 + a24 * b41;
			te[5] = a21 * b12 + a22 * b22 + a23 * b32 + a24 * b42;
			te[9] = a21 * b13 + a22 * b23 + a23 * b33 + a24 * b43;
			te[13] = a21 * b14 + a22 * b24 + a23 * b34 + a24 * b44;
			te[2] = a31 * b11 + a32 * b21 + a33 * b31 + a34 * b41;
			te[6] = a31 * b12 + a32 * b22 + a33 * b32 + a34 * b42;
			te[10] = a31 * b13 + a32 * b23 + a33 * b33 + a34 * b43;
			te[14] = a31 * b14 + a32 * b24 + a33 * b34 + a34 * b44;
			te[3] = a41 * b11 + a42 * b21 + a43 * b31 + a44 * b41;
			te[7] = a41 * b12 + a42 * b22 + a43 * b32 + a44 * b42;
			te[11] = a41 * b13 + a42 * b23 + a43 * b33 + a44 * b43;
			te[15] = a41 * b14 + a42 * b24 + a43 * b34 + a44 * b44;
			return this;
		}
		/**
		* Multiplies every component of the matrix by the given scalar.
		*
		* @param {number} s - The scalar.
		* @return {Matrix4} A reference to this matrix.
		*/
		multiplyScalar(s) {
			const te = this.elements;
			te[0] *= s;
			te[4] *= s;
			te[8] *= s;
			te[12] *= s;
			te[1] *= s;
			te[5] *= s;
			te[9] *= s;
			te[13] *= s;
			te[2] *= s;
			te[6] *= s;
			te[10] *= s;
			te[14] *= s;
			te[3] *= s;
			te[7] *= s;
			te[11] *= s;
			te[15] *= s;
			return this;
		}
		/**
		* Computes and returns the determinant of this matrix.
		*
		* @return {number} The determinant.
		*/
		determinant() {
			const te = this.elements;
			const n11 = te[0], n12 = te[4], n13 = te[8], n14 = te[12];
			const n21 = te[1], n22 = te[5], n23 = te[9], n24 = te[13];
			const n31 = te[2], n32 = te[6], n33 = te[10], n34 = te[14];
			const n41 = te[3], n42 = te[7], n43 = te[11], n44 = te[15];
			const t11 = n23 * n34 - n24 * n33;
			const t12 = n22 * n34 - n24 * n32;
			const t13 = n22 * n33 - n23 * n32;
			const t21 = n21 * n34 - n24 * n31;
			const t22 = n21 * n33 - n23 * n31;
			const t23 = n21 * n32 - n22 * n31;
			return n11 * (n42 * t11 - n43 * t12 + n44 * t13) - n12 * (n41 * t11 - n43 * t21 + n44 * t22) + n13 * (n41 * t12 - n42 * t21 + n44 * t23) - n14 * (n41 * t13 - n42 * t22 + n43 * t23);
		}
		/**
		* Computes and returns the determinant of the 4x4 matrix, but assumes the
		* matrix is affine, saving some computations.
		*
		* For affine matrices (like an object's world matrix), this value equals the
		* full 4x4 {@link Matrix4#determinant} but is cheaper to compute.
		*
		* Assumes the bottom row is [0, 0, 0, 1].
		*
		* @return {number} The determinant of the matrix.
		*/
		determinantAffine() {
			const te = this.elements;
			const n11 = te[0], n12 = te[4], n13 = te[8];
			const n21 = te[1], n22 = te[5], n23 = te[9];
			const n31 = te[2], n32 = te[6], n33 = te[10];
			return n11 * (n22 * n33 - n23 * n32) - n12 * (n21 * n33 - n23 * n31) + n13 * (n21 * n32 - n22 * n31);
		}
		/**
		* Transposes this matrix in place.
		*
		* @return {Matrix4} A reference to this matrix.
		*/
		transpose() {
			const te = this.elements;
			let tmp;
			tmp = te[1];
			te[1] = te[4];
			te[4] = tmp;
			tmp = te[2];
			te[2] = te[8];
			te[8] = tmp;
			tmp = te[6];
			te[6] = te[9];
			te[9] = tmp;
			tmp = te[3];
			te[3] = te[12];
			te[12] = tmp;
			tmp = te[7];
			te[7] = te[13];
			te[13] = tmp;
			tmp = te[11];
			te[11] = te[14];
			te[14] = tmp;
			return this;
		}
		/**
		* Sets the position component for this matrix from the given vector,
		* without affecting the rest of the matrix.
		*
		* @param {number|Vector3} x - The x component of the vector or alternatively the vector object.
		* @param {number} y - The y component of the vector.
		* @param {number} z - The z component of the vector.
		* @return {Matrix4} A reference to this matrix.
		*/
		setPosition(x, y, z) {
			const te = this.elements;
			if (x.isVector3) {
				te[12] = x.x;
				te[13] = x.y;
				te[14] = x.z;
			} else {
				te[12] = x;
				te[13] = y;
				te[14] = z;
			}
			return this;
		}
		/**
		* Inverts this matrix, using the [analytic method](https://en.wikipedia.org/wiki/Invertible_matrix#Analytic_solution).
		* You can not invert with a determinant of zero. If you attempt this, the method produces
		* a zero matrix instead.
		*
		* @return {Matrix4} A reference to this matrix.
		*/
		invert() {
			const te = this.elements, n11 = te[0], n21 = te[1], n31 = te[2], n41 = te[3], n12 = te[4], n22 = te[5], n32 = te[6], n42 = te[7], n13 = te[8], n23 = te[9], n33 = te[10], n43 = te[11], n14 = te[12], n24 = te[13], n34 = te[14], n44 = te[15], t1 = n11 * n22 - n21 * n12, t2 = n11 * n32 - n31 * n12, t3 = n11 * n42 - n41 * n12, t4 = n21 * n32 - n31 * n22, t5 = n21 * n42 - n41 * n22, t6 = n31 * n42 - n41 * n32, t7 = n13 * n24 - n23 * n14, t8 = n13 * n34 - n33 * n14, t9 = n13 * n44 - n43 * n14, t10 = n23 * n34 - n33 * n24, t11 = n23 * n44 - n43 * n24, t12 = n33 * n44 - n43 * n34;
			const det = t1 * t12 - t2 * t11 + t3 * t10 + t4 * t9 - t5 * t8 + t6 * t7;
			if (det === 0) return this.set(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
			const detInv = 1 / det;
			te[0] = (n22 * t12 - n32 * t11 + n42 * t10) * detInv;
			te[1] = (n31 * t11 - n21 * t12 - n41 * t10) * detInv;
			te[2] = (n24 * t6 - n34 * t5 + n44 * t4) * detInv;
			te[3] = (n33 * t5 - n23 * t6 - n43 * t4) * detInv;
			te[4] = (n32 * t9 - n12 * t12 - n42 * t8) * detInv;
			te[5] = (n11 * t12 - n31 * t9 + n41 * t8) * detInv;
			te[6] = (n34 * t3 - n14 * t6 - n44 * t2) * detInv;
			te[7] = (n13 * t6 - n33 * t3 + n43 * t2) * detInv;
			te[8] = (n12 * t11 - n22 * t9 + n42 * t7) * detInv;
			te[9] = (n21 * t9 - n11 * t11 - n41 * t7) * detInv;
			te[10] = (n14 * t5 - n24 * t3 + n44 * t1) * detInv;
			te[11] = (n23 * t3 - n13 * t5 - n43 * t1) * detInv;
			te[12] = (n22 * t8 - n12 * t10 - n32 * t7) * detInv;
			te[13] = (n11 * t10 - n21 * t8 + n31 * t7) * detInv;
			te[14] = (n24 * t2 - n14 * t4 - n34 * t1) * detInv;
			te[15] = (n13 * t4 - n23 * t2 + n33 * t1) * detInv;
			return this;
		}
		/**
		* Scales each of the first three columns of this matrix by the corresponding component of the given vector.
		*
		* @param {Vector3} v - The scale vector.
		* @return {Matrix4} A reference to this matrix.
		*/
		scale(v) {
			const te = this.elements;
			const x = v.x, y = v.y, z = v.z;
			te[0] *= x;
			te[4] *= y;
			te[8] *= z;
			te[1] *= x;
			te[5] *= y;
			te[9] *= z;
			te[2] *= x;
			te[6] *= y;
			te[10] *= z;
			te[3] *= x;
			te[7] *= y;
			te[11] *= z;
			return this;
		}
		/**
		* Gets the maximum scale value of the three axes.
		*
		* @return {number} The maximum scale.
		*/
		getMaxScaleOnAxis() {
			const te = this.elements;
			const scaleXSq = te[0] * te[0] + te[1] * te[1] + te[2] * te[2];
			const scaleYSq = te[4] * te[4] + te[5] * te[5] + te[6] * te[6];
			const scaleZSq = te[8] * te[8] + te[9] * te[9] + te[10] * te[10];
			return Math.sqrt(Math.max(scaleXSq, scaleYSq, scaleZSq));
		}
		/**
		* Sets this matrix as a translation transform from the given vector.
		*
		* @param {number|Vector3} x - The amount to translate in the X axis or alternatively a translation vector.
		* @param {number} y - The amount to translate in the Y axis.
		* @param {number} z - The amount to translate in the z axis.
		* @return {Matrix4} A reference to this matrix.
		*/
		makeTranslation(x, y, z) {
			if (x.isVector3) this.set(1, 0, 0, x.x, 0, 1, 0, x.y, 0, 0, 1, x.z, 0, 0, 0, 1);
			else this.set(1, 0, 0, x, 0, 1, 0, y, 0, 0, 1, z, 0, 0, 0, 1);
			return this;
		}
		/**
		* Sets this matrix as a rotational transformation around the X axis by
		* the given angle.
		*
		* @param {number} theta - The rotation in radians.
		* @return {Matrix4} A reference to this matrix.
		*/
		makeRotationX(theta) {
			const c = Math.cos(theta), s = Math.sin(theta);
			this.set(1, 0, 0, 0, 0, c, -s, 0, 0, s, c, 0, 0, 0, 0, 1);
			return this;
		}
		/**
		* Sets this matrix as a rotational transformation around the Y axis by
		* the given angle.
		*
		* @param {number} theta - The rotation in radians.
		* @return {Matrix4} A reference to this matrix.
		*/
		makeRotationY(theta) {
			const c = Math.cos(theta), s = Math.sin(theta);
			this.set(c, 0, s, 0, 0, 1, 0, 0, -s, 0, c, 0, 0, 0, 0, 1);
			return this;
		}
		/**
		* Sets this matrix as a rotational transformation around the Z axis by
		* the given angle.
		*
		* @param {number} theta - The rotation in radians.
		* @return {Matrix4} A reference to this matrix.
		*/
		makeRotationZ(theta) {
			const c = Math.cos(theta), s = Math.sin(theta);
			this.set(c, -s, 0, 0, s, c, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1);
			return this;
		}
		/**
		* Sets this matrix as a rotational transformation around the given axis by
		* the given angle.
		*
		* @param {Vector3} axis - The normalized rotation axis.
		* @param {number} angle - The rotation in radians.
		* @return {Matrix4} A reference to this matrix.
		*/
		makeRotationAxis(axis, angle) {
			const c = Math.cos(angle);
			const s = Math.sin(angle);
			const t = 1 - c;
			const x = axis.x, y = axis.y, z = axis.z;
			const tx = t * x, ty = t * y;
			this.set(tx * x + c, tx * y - s * z, tx * z + s * y, 0, tx * y + s * z, ty * y + c, ty * z - s * x, 0, tx * z - s * y, ty * z + s * x, t * z * z + c, 0, 0, 0, 0, 1);
			return this;
		}
		/**
		* Sets this matrix as a scale transformation.
		*
		* @param {number} x - The amount to scale in the X axis.
		* @param {number} y - The amount to scale in the Y axis.
		* @param {number} z - The amount to scale in the Z axis.
		* @return {Matrix4} A reference to this matrix.
		*/
		makeScale(x, y, z) {
			this.set(x, 0, 0, 0, 0, y, 0, 0, 0, 0, z, 0, 0, 0, 0, 1);
			return this;
		}
		/**
		* Sets this matrix as a shear transformation.
		*
		* @param {number} xy - The amount to shear X by Y.
		* @param {number} xz - The amount to shear X by Z.
		* @param {number} yx - The amount to shear Y by X.
		* @param {number} yz - The amount to shear Y by Z.
		* @param {number} zx - The amount to shear Z by X.
		* @param {number} zy - The amount to shear Z by Y.
		* @return {Matrix4} A reference to this matrix.
		*/
		makeShear(xy, xz, yx, yz, zx, zy) {
			this.set(1, yx, zx, 0, xy, 1, zy, 0, xz, yz, 1, 0, 0, 0, 0, 1);
			return this;
		}
		/**
		* Sets this matrix to the transformation composed of the given position,
		* rotation (Quaternion) and scale.
		*
		* @param {Vector3} position - The position vector.
		* @param {Quaternion} quaternion - The rotation as a Quaternion.
		* @param {Vector3} scale - The scale vector.
		* @return {Matrix4} A reference to this matrix.
		*/
		compose(position, quaternion, scale) {
			const te = this.elements;
			const x = quaternion._x, y = quaternion._y, z = quaternion._z, w = quaternion._w;
			const x2 = x + x, y2 = y + y, z2 = z + z;
			const xx = x * x2, xy = x * y2, xz = x * z2;
			const yy = y * y2, yz = y * z2, zz = z * z2;
			const wx = w * x2, wy = w * y2, wz = w * z2;
			const sx = scale.x, sy = scale.y, sz = scale.z;
			te[0] = (1 - (yy + zz)) * sx;
			te[1] = (xy + wz) * sx;
			te[2] = (xz - wy) * sx;
			te[3] = 0;
			te[4] = (xy - wz) * sy;
			te[5] = (1 - (xx + zz)) * sy;
			te[6] = (yz + wx) * sy;
			te[7] = 0;
			te[8] = (xz + wy) * sz;
			te[9] = (yz - wx) * sz;
			te[10] = (1 - (xx + yy)) * sz;
			te[11] = 0;
			te[12] = position.x;
			te[13] = position.y;
			te[14] = position.z;
			te[15] = 1;
			return this;
		}
		/**
		* Decomposes this matrix into its position, rotation and scale components
		* and provides the result in the given objects.
		*
		* Note: Not all matrices are decomposable in this way. For example, if an
		* object has a non-uniformly scaled parent, then the object's world matrix
		* may not be decomposable, and this method may not be appropriate.
		*
		* @param {Vector3} position - The position vector.
		* @param {Quaternion} quaternion - The rotation as a Quaternion.
		* @param {Vector3} scale - The scale vector.
		* @return {Matrix4} A reference to this matrix.
		*/
		decompose(position, quaternion, scale) {
			const te = this.elements;
			position.x = te[12];
			position.y = te[13];
			position.z = te[14];
			const det = this.determinantAffine();
			if (det === 0) {
				scale.set(1, 1, 1);
				quaternion.identity();
				return this;
			}
			let sx = _v1$7.set(te[0], te[1], te[2]).length();
			const sy = _v1$7.set(te[4], te[5], te[6]).length();
			const sz = _v1$7.set(te[8], te[9], te[10]).length();
			if (det < 0) sx = -sx;
			_m1$2.copy(this);
			const invSX = 1 / sx;
			const invSY = 1 / sy;
			const invSZ = 1 / sz;
			_m1$2.elements[0] *= invSX;
			_m1$2.elements[1] *= invSX;
			_m1$2.elements[2] *= invSX;
			_m1$2.elements[4] *= invSY;
			_m1$2.elements[5] *= invSY;
			_m1$2.elements[6] *= invSY;
			_m1$2.elements[8] *= invSZ;
			_m1$2.elements[9] *= invSZ;
			_m1$2.elements[10] *= invSZ;
			quaternion.setFromRotationMatrix(_m1$2);
			scale.x = sx;
			scale.y = sy;
			scale.z = sz;
			return this;
		}
		/**
		* Creates a perspective projection matrix. This is used internally by
		* {@link PerspectiveCamera#updateProjectionMatrix}.
		
		* @param {number} left - Left boundary of the viewing frustum at the near plane.
		* @param {number} right - Right boundary of the viewing frustum at the near plane.
		* @param {number} top - Top boundary of the viewing frustum at the near plane.
		* @param {number} bottom - Bottom boundary of the viewing frustum at the near plane.
		* @param {number} near - The distance from the camera to the near plane.
		* @param {number} far - The distance from the camera to the far plane.
		* @param {(WebGLCoordinateSystem|WebGPUCoordinateSystem)} [coordinateSystem=WebGLCoordinateSystem] - The coordinate system.
		* @param {boolean} [reversedDepth=false] - Whether to use a reversed depth.
		* @return {Matrix4} A reference to this matrix.
		*/
		makePerspective(left, right, top, bottom, near, far, coordinateSystem = WebGLCoordinateSystem, reversedDepth = false) {
			const te = this.elements;
			const x = 2 * near / (right - left);
			const y = 2 * near / (top - bottom);
			const a = (right + left) / (right - left);
			const b = (top + bottom) / (top - bottom);
			let c, d;
			if (reversedDepth) {
				c = near / (far - near);
				d = far * near / (far - near);
			} else if (coordinateSystem === 2e3) {
				c = -(far + near) / (far - near);
				d = -2 * far * near / (far - near);
			} else if (coordinateSystem === 2001) {
				c = -far / (far - near);
				d = -far * near / (far - near);
			} else throw new Error("THREE.Matrix4.makePerspective(): Invalid coordinate system: " + coordinateSystem);
			te[0] = x;
			te[4] = 0;
			te[8] = a;
			te[12] = 0;
			te[1] = 0;
			te[5] = y;
			te[9] = b;
			te[13] = 0;
			te[2] = 0;
			te[6] = 0;
			te[10] = c;
			te[14] = d;
			te[3] = 0;
			te[7] = 0;
			te[11] = -1;
			te[15] = 0;
			return this;
		}
		/**
		* Creates a orthographic projection matrix. This is used internally by
		* {@link OrthographicCamera#updateProjectionMatrix}.
		
		* @param {number} left - Left boundary of the viewing frustum at the near plane.
		* @param {number} right - Right boundary of the viewing frustum at the near plane.
		* @param {number} top - Top boundary of the viewing frustum at the near plane.
		* @param {number} bottom - Bottom boundary of the viewing frustum at the near plane.
		* @param {number} near - The distance from the camera to the near plane.
		* @param {number} far - The distance from the camera to the far plane.
		* @param {(WebGLCoordinateSystem|WebGPUCoordinateSystem)} [coordinateSystem=WebGLCoordinateSystem] - The coordinate system.
		* @param {boolean} [reversedDepth=false] - Whether to use a reversed depth.
		* @return {Matrix4} A reference to this matrix.
		*/
		makeOrthographic(left, right, top, bottom, near, far, coordinateSystem = WebGLCoordinateSystem, reversedDepth = false) {
			const te = this.elements;
			const x = 2 / (right - left);
			const y = 2 / (top - bottom);
			const a = -(right + left) / (right - left);
			const b = -(top + bottom) / (top - bottom);
			let c, d;
			if (reversedDepth) {
				c = 1 / (far - near);
				d = far / (far - near);
			} else if (coordinateSystem === 2e3) {
				c = -2 / (far - near);
				d = -(far + near) / (far - near);
			} else if (coordinateSystem === 2001) {
				c = -1 / (far - near);
				d = -near / (far - near);
			} else throw new Error("THREE.Matrix4.makeOrthographic(): Invalid coordinate system: " + coordinateSystem);
			te[0] = x;
			te[4] = 0;
			te[8] = 0;
			te[12] = a;
			te[1] = 0;
			te[5] = y;
			te[9] = 0;
			te[13] = b;
			te[2] = 0;
			te[6] = 0;
			te[10] = c;
			te[14] = d;
			te[3] = 0;
			te[7] = 0;
			te[11] = 0;
			te[15] = 1;
			return this;
		}
		/**
		* Returns `true` if this matrix is equal with the given one.
		*
		* @param {Matrix4} matrix - The matrix to test for equality.
		* @return {boolean} Whether this matrix is equal with the given one.
		*/
		equals(matrix) {
			const te = this.elements;
			const me = matrix.elements;
			for (let i = 0; i < 16; i++) if (te[i] !== me[i]) return false;
			return true;
		}
		/**
		* Sets the elements of the matrix from the given array.
		*
		* @param {Array<number>} array - The matrix elements in column-major order.
		* @param {number} [offset=0] - Index of the first element in the array.
		* @return {Matrix4} A reference to this matrix.
		*/
		fromArray(array, offset = 0) {
			for (let i = 0; i < 16; i++) this.elements[i] = array[i + offset];
			return this;
		}
		/**
		* Writes the elements of this matrix to the given array. If no array is provided,
		* the method returns a new instance.
		*
		* @param {Array<number>} [array=[]] - The target array holding the matrix elements in column-major order.
		* @param {number} [offset=0] - Index of the first element in the array.
		* @return {Array<number>} The matrix elements in column-major order.
		*/
		toArray(array = [], offset = 0) {
			const te = this.elements;
			array[offset] = te[0];
			array[offset + 1] = te[1];
			array[offset + 2] = te[2];
			array[offset + 3] = te[3];
			array[offset + 4] = te[4];
			array[offset + 5] = te[5];
			array[offset + 6] = te[6];
			array[offset + 7] = te[7];
			array[offset + 8] = te[8];
			array[offset + 9] = te[9];
			array[offset + 10] = te[10];
			array[offset + 11] = te[11];
			array[offset + 12] = te[12];
			array[offset + 13] = te[13];
			array[offset + 14] = te[14];
			array[offset + 15] = te[15];
			return array;
		}
	};
	const _v1$7 = /*@__PURE__*/ new Vector3();
	const _m1$2 = /*@__PURE__*/ new Matrix4();
	const _zero = /*@__PURE__*/ new Vector3(0, 0, 0);
	const _one = /*@__PURE__*/ new Vector3(1, 1, 1);
	const _x = /*@__PURE__*/ new Vector3();
	const _y = /*@__PURE__*/ new Vector3();
	const _z = /*@__PURE__*/ new Vector3();
	const _matrix$2 = /*@__PURE__*/ new Matrix4();
	const _quaternion$4 = /*@__PURE__*/ new Quaternion();
	/**
	* A class representing Euler angles.
	*
	* Euler angles describe a rotational transformation by rotating an object on
	* its various axes in specified amounts per axis, and a specified axis
	* order.
	*
	* Iterating through an instance will yield its components (x, y, z,
	* order) in the corresponding order.
	*
	* ```js
	* const a = new THREE.Euler( 0, 1, 1.57, 'XYZ' );
	* const b = new THREE.Vector3( 1, 0, 1 );
	* b.applyEuler(a);
	* ```
	*/
	var Euler = class Euler {
		/**
		* Constructs a new euler instance.
		*
		* @param {number} [x=0] - The angle of the x axis in radians.
		* @param {number} [y=0] - The angle of the y axis in radians.
		* @param {number} [z=0] - The angle of the z axis in radians.
		* @param {string} [order=Euler.DEFAULT_ORDER] - A string representing the order that the rotations are applied.
		*/
		constructor(x = 0, y = 0, z = 0, order = Euler.DEFAULT_ORDER) {
			/**
			* This flag can be used for type testing.
			*
			* @type {boolean}
			* @readonly
			* @default true
			*/
			this.isEuler = true;
			this._x = x;
			this._y = y;
			this._z = z;
			this._order = order;
		}
		/**
		* The angle of the x axis in radians.
		*
		* @type {number}
		* @default 0
		*/
		get x() {
			return this._x;
		}
		set x(value) {
			this._x = value;
			this._onChangeCallback();
		}
		/**
		* The angle of the y axis in radians.
		*
		* @type {number}
		* @default 0
		*/
		get y() {
			return this._y;
		}
		set y(value) {
			this._y = value;
			this._onChangeCallback();
		}
		/**
		* The angle of the z axis in radians.
		*
		* @type {number}
		* @default 0
		*/
		get z() {
			return this._z;
		}
		set z(value) {
			this._z = value;
			this._onChangeCallback();
		}
		/**
		* A string representing the order that the rotations are applied.
		*
		* @type {string}
		* @default 'XYZ'
		*/
		get order() {
			return this._order;
		}
		set order(value) {
			this._order = value;
			this._onChangeCallback();
		}
		/**
		* Sets the Euler components.
		*
		* @param {number} x - The angle of the x axis in radians.
		* @param {number} y - The angle of the y axis in radians.
		* @param {number} z - The angle of the z axis in radians.
		* @param {string} [order] - A string representing the order that the rotations are applied.
		* @return {Euler} A reference to this Euler instance.
		*/
		set(x, y, z, order = this._order) {
			this._x = x;
			this._y = y;
			this._z = z;
			this._order = order;
			this._onChangeCallback();
			return this;
		}
		/**
		* Returns a new Euler instance with copied values from this instance.
		*
		* @return {Euler} A clone of this instance.
		*/
		clone() {
			return new this.constructor(this._x, this._y, this._z, this._order);
		}
		/**
		* Copies the values of the given Euler instance to this instance.
		*
		* @param {Euler} euler - The Euler instance to copy.
		* @return {Euler} A reference to this Euler instance.
		*/
		copy(euler) {
			this._x = euler._x;
			this._y = euler._y;
			this._z = euler._z;
			this._order = euler._order;
			this._onChangeCallback();
			return this;
		}
		/**
		* Sets the angles of this Euler instance from a pure rotation matrix.
		*
		* @param {Matrix4} m - A 4x4 matrix of which the upper 3x3 of matrix is a pure rotation matrix (i.e. unscaled).
		* @param {string} [order] - A string representing the order that the rotations are applied.
		* @param {boolean} [update=true] - Whether the internal `onChange` callback should be executed or not.
		* @return {Euler} A reference to this Euler instance.
		*/
		setFromRotationMatrix(m, order = this._order, update = true) {
			const te = m.elements;
			const m11 = te[0], m12 = te[4], m13 = te[8];
			const m21 = te[1], m22 = te[5], m23 = te[9];
			const m31 = te[2], m32 = te[6], m33 = te[10];
			switch (order) {
				case "XYZ":
					this._y = Math.asin(clamp(m13, -1, 1));
					if (Math.abs(m13) < .9999999) {
						this._x = Math.atan2(-m23, m33);
						this._z = Math.atan2(-m12, m11);
					} else {
						this._x = Math.atan2(m32, m22);
						this._z = 0;
					}
					break;
				case "YXZ":
					this._x = Math.asin(-clamp(m23, -1, 1));
					if (Math.abs(m23) < .9999999) {
						this._y = Math.atan2(m13, m33);
						this._z = Math.atan2(m21, m22);
					} else {
						this._y = Math.atan2(-m31, m11);
						this._z = 0;
					}
					break;
				case "ZXY":
					this._x = Math.asin(clamp(m32, -1, 1));
					if (Math.abs(m32) < .9999999) {
						this._y = Math.atan2(-m31, m33);
						this._z = Math.atan2(-m12, m22);
					} else {
						this._y = 0;
						this._z = Math.atan2(m21, m11);
					}
					break;
				case "ZYX":
					this._y = Math.asin(-clamp(m31, -1, 1));
					if (Math.abs(m31) < .9999999) {
						this._x = Math.atan2(m32, m33);
						this._z = Math.atan2(m21, m11);
					} else {
						this._x = 0;
						this._z = Math.atan2(-m12, m22);
					}
					break;
				case "YZX":
					this._z = Math.asin(clamp(m21, -1, 1));
					if (Math.abs(m21) < .9999999) {
						this._x = Math.atan2(-m23, m22);
						this._y = Math.atan2(-m31, m11);
					} else {
						this._x = 0;
						this._y = Math.atan2(m13, m33);
					}
					break;
				case "XZY":
					this._z = Math.asin(-clamp(m12, -1, 1));
					if (Math.abs(m12) < .9999999) {
						this._x = Math.atan2(m32, m22);
						this._y = Math.atan2(m13, m11);
					} else {
						this._x = Math.atan2(-m23, m33);
						this._y = 0;
					}
					break;
				default: warn("Euler: .setFromRotationMatrix() encountered an unknown order: " + order);
			}
			this._order = order;
			if (update === true) this._onChangeCallback();
			return this;
		}
		/**
		* Sets the angles of this Euler instance from a normalized quaternion.
		*
		* @param {Quaternion} q - A normalized Quaternion.
		* @param {string} [order] - A string representing the order that the rotations are applied.
		* @param {boolean} [update=true] - Whether the internal `onChange` callback should be executed or not.
		* @return {Euler} A reference to this Euler instance.
		*/
		setFromQuaternion(q, order, update) {
			_matrix$2.makeRotationFromQuaternion(q);
			return this.setFromRotationMatrix(_matrix$2, order, update);
		}
		/**
		* Sets the angles of this Euler instance from the given vector.
		*
		* @param {Vector3} v - The vector.
		* @param {string} [order] - A string representing the order that the rotations are applied.
		* @return {Euler} A reference to this Euler instance.
		*/
		setFromVector3(v, order = this._order) {
			return this.set(v.x, v.y, v.z, order);
		}
		/**
		* Resets the euler angle with a new order by creating a quaternion from this
		* euler angle and then setting this euler angle with the quaternion and the
		* new order.
		*
		* Warning: This discards revolution information.
		*
		* @param {string} [newOrder] - A string representing the new order that the rotations are applied.
		* @return {Euler} A reference to this Euler instance.
		*/
		reorder(newOrder) {
			_quaternion$4.setFromEuler(this);
			return this.setFromQuaternion(_quaternion$4, newOrder);
		}
		/**
		* Returns `true` if this Euler instance is equal with the given one.
		*
		* @param {Euler} euler - The Euler instance to test for equality.
		* @return {boolean} Whether this Euler instance is equal with the given one.
		*/
		equals(euler) {
			return euler._x === this._x && euler._y === this._y && euler._z === this._z && euler._order === this._order;
		}
		/**
		* Sets this Euler instance's components to values from the given array. The first three
		* entries of the array are assign to the x,y and z components. An optional fourth entry
		* defines the Euler order.
		*
		* @param {Array<number,number,number,?string>} array - An array holding the Euler component values.
		* @return {Euler} A reference to this Euler instance.
		*/
		fromArray(array) {
			this._x = array[0];
			this._y = array[1];
			this._z = array[2];
			if (array[3] !== void 0) this._order = array[3];
			this._onChangeCallback();
			return this;
		}
		/**
		* Writes the components of this Euler instance to the given array. If no array is provided,
		* the method returns a new instance.
		*
		* @param {Array<number,number,number,string>} [array=[]] - The target array holding the Euler components.
		* @param {number} [offset=0] - Index of the first element in the array.
		* @return {Array<number,number,number,string>} The Euler components.
		*/
		toArray(array = [], offset = 0) {
			array[offset] = this._x;
			array[offset + 1] = this._y;
			array[offset + 2] = this._z;
			array[offset + 3] = this._order;
			return array;
		}
		_onChange(callback) {
			this._onChangeCallback = callback;
			return this;
		}
		_onChangeCallback() {}
		*[Symbol.iterator]() {
			yield this._x;
			yield this._y;
			yield this._z;
			yield this._order;
		}
	};
	/**
	* The default Euler angle order.
	*
	* @static
	* @type {string}
	* @default 'XYZ'
	*/
	Euler.DEFAULT_ORDER = "XYZ";
	/**
	* A layers object assigns an 3D object to 1 or more of 32
	* layers numbered `0` to `31` - internally the layers are stored as a
	* bit mask], and by default all 3D objects are a member of layer `0`.
	*
	* This can be used to control visibility - an object must share a layer with
	* a camera to be visible when that camera's view is
	* rendered.
	*
	* All classes that inherit from {@link Object3D} have an `layers` property which
	* is an instance of this class.
	*/
	var Layers = class {
		/**
		* Constructs a new layers instance, with membership
		* initially set to layer `0`.
		*/
		constructor() {
			/**
			* A bit mask storing which of the 32 layers this layers object is currently
			* a member of.
			*
			* @type {number}
			*/
			this.mask = 1;
		}
		/**
		* Sets membership to the given layer, and remove membership all other layers.
		*
		* @param {number} layer - The layer to set.
		*/
		set(layer) {
			this.mask = (1 << layer | 0) >>> 0;
		}
		/**
		* Adds membership of the given layer.
		*
		* @param {number} layer - The layer to enable.
		*/
		enable(layer) {
			this.mask |= 1 << layer | 0;
		}
		/**
		* Adds membership to all layers.
		*/
		enableAll() {
			this.mask = -1;
		}
		/**
		* Toggles the membership of the given layer.
		*
		* @param {number} layer - The layer to toggle.
		*/
		toggle(layer) {
			this.mask ^= 1 << layer | 0;
		}
		/**
		* Removes membership of the given layer.
		*
		* @param {number} layer - The layer to enable.
		*/
		disable(layer) {
			this.mask &= ~(1 << layer | 0);
		}
		/**
		* Removes the membership from all layers.
		*/
		disableAll() {
			this.mask = 0;
		}
		/**
		* Returns `true` if this and the given layers object have at least one
		* layer in common.
		*
		* @param {Layers} layers - The layers to test.
		* @return {boolean } Whether this and the given layers object have at least one layer in common or not.
		*/
		test(layers) {
			return (this.mask & layers.mask) !== 0;
		}
		/**
		* Returns `true` if the given layer is enabled.
		*
		* @param {number} layer - The layer to test.
		* @return {boolean } Whether the given layer is enabled or not.
		*/
		isEnabled(layer) {
			return (this.mask & (1 << layer | 0)) !== 0;
		}
	};
	let _object3DId = 0;
	const _v1$6 = /*@__PURE__*/ new Vector3();
	const _q1 = /*@__PURE__*/ new Quaternion();
	const _m1$1 = /*@__PURE__*/ new Matrix4();
	const _target = /*@__PURE__*/ new Vector3();
	const _position$4 = /*@__PURE__*/ new Vector3();
	const _scale$3 = /*@__PURE__*/ new Vector3();
	const _quaternion$3 = /*@__PURE__*/ new Quaternion();
	const _xAxis = /*@__PURE__*/ new Vector3(1, 0, 0);
	const _yAxis = /*@__PURE__*/ new Vector3(0, 1, 0);
	const _zAxis = /*@__PURE__*/ new Vector3(0, 0, 1);
	/**
	* Fires when the object has been added to its parent object.
	*
	* @event Object3D#added
	* @type {Object}
	*/
	const _addedEvent = { type: "added" };
	/**
	* Fires when the object has been removed from its parent object.
	*
	* @event Object3D#removed
	* @type {Object}
	*/
	const _removedEvent = { type: "removed" };
	/**
	* Fires when a new child object has been added.
	*
	* @event Object3D#childadded
	* @type {Object}
	*/
	const _childaddedEvent = {
		type: "childadded",
		child: null
	};
	/**
	* Fires when a child object has been removed.
	*
	* @event Object3D#childremoved
	* @type {Object}
	*/
	const _childremovedEvent = {
		type: "childremoved",
		child: null
	};
	/**
	* This is the base class for most objects in three.js and provides a set of
	* properties and methods for manipulating objects in 3D space.
	*
	* @augments EventDispatcher
	*/
	var Object3D = class Object3D extends EventDispatcher {
		/**
		* Constructs a new 3D object.
		*/
		constructor() {
			super();
			/**
			* This flag can be used for type testing.
			*
			* @type {boolean}
			* @readonly
			* @default true
			*/
			this.isObject3D = true;
			/**
			* The ID of the 3D object.
			*
			* @name Object3D#id
			* @type {number}
			* @readonly
			*/
			Object.defineProperty(this, "id", { value: _object3DId++ });
			/**
			* The UUID of the 3D object.
			*
			* @type {string}
			* @readonly
			*/
			this.uuid = generateUUID();
			/**
			* The name of the 3D object.
			*
			* @type {string}
			*/
			this.name = "";
			/**
			* The type property is used for detecting the object type
			* in context of serialization/deserialization.
			*
			* @type {string}
			* @readonly
			*/
			this.type = "Object3D";
			/**
			* A reference to the parent object.
			*
			* @type {?Object3D}
			* @default null
			*/
			this.parent = null;
			/**
			* An array holding the child 3D objects of this instance.
			*
			* @type {Array<Object3D>}
			*/
			this.children = [];
			/**
			* Defines the `up` direction of the 3D object which influences
			* the orientation via methods like {@link Object3D#lookAt}.
			*
			* The default values for all 3D objects is defined by `Object3D.DEFAULT_UP`.
			*
			* @type {Vector3}
			*/
			this.up = Object3D.DEFAULT_UP.clone();
			const position = new Vector3();
			const rotation = new Euler();
			const quaternion = new Quaternion();
			const scale = new Vector3(1, 1, 1);
			function onRotationChange() {
				quaternion.setFromEuler(rotation, false);
			}
			function onQuaternionChange() {
				rotation.setFromQuaternion(quaternion, void 0, false);
			}
			rotation._onChange(onRotationChange);
			quaternion._onChange(onQuaternionChange);
			Object.defineProperties(this, {
				/**
				* Represents the object's local position.
				*
				* @name Object3D#position
				* @type {Vector3}
				* @default (0,0,0)
				*/
				position: {
					configurable: true,
					enumerable: true,
					value: position
				},
				/**
				* Represents the object's local rotation as Euler angles, in radians.
				*
				* @name Object3D#rotation
				* @type {Euler}
				* @default (0,0,0)
				*/
				rotation: {
					configurable: true,
					enumerable: true,
					value: rotation
				},
				/**
				* Represents the object's local rotation as Quaternions.
				*
				* @name Object3D#quaternion
				* @type {Quaternion}
				*/
				quaternion: {
					configurable: true,
					enumerable: true,
					value: quaternion
				},
				/**
				* Represents the object's local scale.
				*
				* @name Object3D#scale
				* @type {Vector3}
				* @default (1,1,1)
				*/
				scale: {
					configurable: true,
					enumerable: true,
					value: scale
				},
				/**
				* Represents the object's model-view matrix.
				*
				* @name Object3D#modelViewMatrix
				* @type {Matrix4}
				*/
				modelViewMatrix: { value: new Matrix4() },
				/**
				* Represents the object's normal matrix.
				*
				* @name Object3D#normalMatrix
				* @type {Matrix3}
				*/
				normalMatrix: { value: new Matrix3() }
			});
			/**
			* Represents the object's transformation matrix in local space.
			*
			* @type {Matrix4}
			*/
			this.matrix = new Matrix4();
			/**
			* Represents the object's transformation matrix in world space.
			* If the 3D object has no parent, then it's identical to the local transformation matrix
			*
			* @type {Matrix4}
			*/
			this.matrixWorld = new Matrix4();
			/**
			* When set to `true`, the engine automatically computes the local matrix from position,
			* rotation and scale every frame. If set to `false`, the app is responsible for recomputing
			* the local matrix by calling `updateMatrix()`.
			*
			* The default values for all 3D objects is defined by `Object3D.DEFAULT_MATRIX_AUTO_UPDATE`.
			*
			* @type {boolean}
			* @default true
			*/
			this.matrixAutoUpdate = Object3D.DEFAULT_MATRIX_AUTO_UPDATE;
			/**
			* When set to `true`, the engine automatically computes the world matrix from the current local
			* matrix and the object's transformation hierarchy. If set to `false`, the app is responsible for
			* recomputing the world matrix by directly updating the `matrixWorld` property.
			*
			* The default values for all 3D objects is defined by `Object3D.DEFAULT_MATRIX_WORLD_AUTO_UPDATE`.
			*
			* @type {boolean}
			* @default true
			*/
			this.matrixWorldAutoUpdate = Object3D.DEFAULT_MATRIX_WORLD_AUTO_UPDATE;
			/**
			* When set to `true`, it calculates the world matrix in that frame and resets this property
			* to `false`.
			*
			* @type {boolean}
			* @default false
			*/
			this.matrixWorldNeedsUpdate = false;
			/**
			* The layer membership of the 3D object. The 3D object is only visible if it has
			* at least one layer in common with the camera in use. This property can also be
			* used to filter out unwanted objects in ray-intersection tests when using {@link Raycaster}.
			*
			* @type {Layers}
			*/
			this.layers = new Layers();
			/**
			* When set to `true`, the 3D object gets rendered.
			*
			* @type {boolean}
			* @default true
			*/
			this.visible = true;
			/**
			* When set to `true`, the 3D object gets rendered into shadow maps.
			*
			* @type {boolean}
			* @default false
			*/
			this.castShadow = false;
			/**
			* When set to `true`, the 3D object is affected by shadows in the scene.
			*
			* @type {boolean}
			* @default false
			*/
			this.receiveShadow = false;
			/**
			* When set to `true`, the 3D object is honored by view frustum culling.
			*
			* @type {boolean}
			* @default true
			*/
			this.frustumCulled = true;
			/**
			* This value allows the default rendering order of scene graph objects to be
			* overridden although opaque and transparent objects remain sorted independently.
			* When this property is set for an instance of {@link Group},all descendants
			* objects will be sorted and rendered together. Sorting is from lowest to highest
			* render order.
			*
			* @type {number}
			* @default 0
			*/
			this.renderOrder = 0;
			/**
			* An array holding the animation clips of the 3D object.
			*
			* @type {Array<AnimationClip>}
			*/
			this.animations = [];
			/**
			* Custom depth material to be used when rendering to the depth map. Can only be used
			* in context of meshes. When shadow-casting with a {@link DirectionalLight} or {@link SpotLight},
			* if you are modifying vertex positions in the vertex shader you must specify a custom depth
			* material for proper shadows.
			*
			* Only relevant in context of {@link WebGLRenderer}.
			*
			* @type {(Material|undefined)}
			* @default undefined
			*/
			this.customDepthMaterial = void 0;
			/**
			* Same as {@link Object3D#customDepthMaterial}, but used with {@link PointLight}.
			*
			* Only relevant in context of {@link WebGLRenderer}.
			*
			* @type {(Material|undefined)}
			* @default undefined
			*/
			this.customDistanceMaterial = void 0;
			/**
			* Whether the 3D object is supposed to be static or not. If set to `true`, it means
			* the 3D object is not going to be changed after the initial renderer. This includes
			* geometry and material settings. A static 3D object can be processed by the renderer
			* slightly faster since certain state checks can be bypassed.
			*
			* Only relevant in context of {@link WebGPURenderer}.
			*
			* @type {boolean}
			* @default false
			*/
			this.static = false;
			/**
			* An object that can be used to store custom data about the 3D object. It
			* should not hold references to functions as these will not be cloned.
			*
			* @type {Object}
			*/
			this.userData = {};
			/**
			* The pivot point for rotation and scale transformations.
			* When set, rotation and scale are applied around this point
			* instead of the object's origin.
			*
			* @type {?Vector3}
			* @default null
			*/
			this.pivot = null;
		}
		/**
		* A callback that is executed immediately before a 3D object is rendered to a shadow map.
		*
		* @param {Renderer|WebGLRenderer} renderer - The renderer.
		* @param {Object3D} object - The 3D object.
		* @param {Camera} camera - The camera that is used to render the scene.
		* @param {Camera} shadowCamera - The shadow camera.
		* @param {BufferGeometry} geometry - The 3D object's geometry.
		* @param {Material} depthMaterial - The depth material.
		* @param {Object} group - The geometry group data.
		*/
		onBeforeShadow() {}
		/**
		* A callback that is executed immediately after a 3D object is rendered to a shadow map.
		*
		* @param {Renderer|WebGLRenderer} renderer - The renderer.
		* @param {Object3D} object - The 3D object.
		* @param {Camera} camera - The camera that is used to render the scene.
		* @param {Camera} shadowCamera - The shadow camera.
		* @param {BufferGeometry} geometry - The 3D object's geometry.
		* @param {Material} depthMaterial - The depth material.
		* @param {Object} group - The geometry group data.
		*/
		onAfterShadow() {}
		/**
		* A callback that is executed immediately before a 3D object is rendered.
		*
		* @param {Renderer|WebGLRenderer} renderer - The renderer.
		* @param {Object3D} object - The 3D object.
		* @param {Camera} camera - The camera that is used to render the scene.
		* @param {BufferGeometry} geometry - The 3D object's geometry.
		* @param {Material} material - The 3D object's material.
		* @param {Object} group - The geometry group data.
		*/
		onBeforeRender() {}
		/**
		* A callback that is executed immediately after a 3D object is rendered.
		*
		* @param {Renderer|WebGLRenderer} renderer - The renderer.
		* @param {Object3D} object - The 3D object.
		* @param {Camera} camera - The camera that is used to render the scene.
		* @param {BufferGeometry} geometry - The 3D object's geometry.
		* @param {Material} material - The 3D object's material.
		* @param {Object} group - The geometry group data.
		*/
		onAfterRender() {}
		/**
		* Applies the given transformation matrix to the object and updates the object's position,
		* rotation and scale.
		*
		* @param {Matrix4} matrix - The transformation matrix.
		*/
		applyMatrix4(matrix) {
			if (this.matrixAutoUpdate) this.updateMatrix();
			this.matrix.premultiply(matrix);
			this.matrix.decompose(this.position, this.quaternion, this.scale);
		}
		/**
		* Applies a rotation represented by given the quaternion to the 3D object.
		*
		* @param {Quaternion} q - The quaternion.
		* @return {Object3D} A reference to this instance.
		*/
		applyQuaternion(q) {
			this.quaternion.premultiply(q);
			return this;
		}
		/**
		* Sets the given rotation represented as an axis/angle couple to the 3D object.
		*
		* @param {Vector3} axis - The (normalized) axis vector.
		* @param {number} angle - The angle in radians.
		*/
		setRotationFromAxisAngle(axis, angle) {
			this.quaternion.setFromAxisAngle(axis, angle);
		}
		/**
		* Sets the given rotation represented as Euler angles to the 3D object.
		*
		* @param {Euler} euler - The Euler angles.
		*/
		setRotationFromEuler(euler) {
			this.quaternion.setFromEuler(euler, true);
		}
		/**
		* Sets the given rotation represented as rotation matrix to the 3D object.
		*
		* @param {Matrix4} m - Although a 4x4 matrix is expected, the upper 3x3 portion must be
		* a pure rotation matrix (i.e, unscaled).
		*/
		setRotationFromMatrix(m) {
			this.quaternion.setFromRotationMatrix(m);
		}
		/**
		* Sets the given rotation represented as a Quaternion to the 3D object.
		*
		* @param {Quaternion} q - The Quaternion
		*/
		setRotationFromQuaternion(q) {
			this.quaternion.copy(q);
		}
		/**
		* Rotates the 3D object along an axis in local space.
		*
		* @param {Vector3} axis - The (normalized) axis vector.
		* @param {number} angle - The angle in radians.
		* @return {Object3D} A reference to this instance.
		*/
		rotateOnAxis(axis, angle) {
			_q1.setFromAxisAngle(axis, angle);
			this.quaternion.multiply(_q1);
			return this;
		}
		/**
		* Rotates the 3D object along an axis in world space.
		*
		* @param {Vector3} axis - The (normalized) axis vector.
		* @param {number} angle - The angle in radians.
		* @return {Object3D} A reference to this instance.
		*/
		rotateOnWorldAxis(axis, angle) {
			_q1.setFromAxisAngle(axis, angle);
			this.quaternion.premultiply(_q1);
			return this;
		}
		/**
		* Rotates the 3D object around its X axis in local space.
		*
		* @param {number} angle - The angle in radians.
		* @return {Object3D} A reference to this instance.
		*/
		rotateX(angle) {
			return this.rotateOnAxis(_xAxis, angle);
		}
		/**
		* Rotates the 3D object around its Y axis in local space.
		*
		* @param {number} angle - The angle in radians.
		* @return {Object3D} A reference to this instance.
		*/
		rotateY(angle) {
			return this.rotateOnAxis(_yAxis, angle);
		}
		/**
		* Rotates the 3D object around its Z axis in local space.
		*
		* @param {number} angle - The angle in radians.
		* @return {Object3D} A reference to this instance.
		*/
		rotateZ(angle) {
			return this.rotateOnAxis(_zAxis, angle);
		}
		/**
		* Translate the 3D object by a distance along the given axis in local space.
		*
		* @param {Vector3} axis - The (normalized) axis vector.
		* @param {number} distance - The distance in world units.
		* @return {Object3D} A reference to this instance.
		*/
		translateOnAxis(axis, distance) {
			_v1$6.copy(axis).applyQuaternion(this.quaternion);
			this.position.add(_v1$6.multiplyScalar(distance));
			return this;
		}
		/**
		* Translate the 3D object by a distance along its X-axis in local space.
		*
		* @param {number} distance - The distance in world units.
		* @return {Object3D} A reference to this instance.
		*/
		translateX(distance) {
			return this.translateOnAxis(_xAxis, distance);
		}
		/**
		* Translate the 3D object by a distance along its Y-axis in local space.
		*
		* @param {number} distance - The distance in world units.
		* @return {Object3D} A reference to this instance.
		*/
		translateY(distance) {
			return this.translateOnAxis(_yAxis, distance);
		}
		/**
		* Translate the 3D object by a distance along its Z-axis in local space.
		*
		* @param {number} distance - The distance in world units.
		* @return {Object3D} A reference to this instance.
		*/
		translateZ(distance) {
			return this.translateOnAxis(_zAxis, distance);
		}
		/**
		* Converts the given vector from this 3D object's local space to world space.
		*
		* @param {Vector3} vector - The vector to convert.
		* @return {Vector3} The converted vector.
		*/
		localToWorld(vector) {
			this.updateWorldMatrix(true, false);
			return vector.applyMatrix4(this.matrixWorld);
		}
		/**
		* Converts the given vector from this 3D object's world space to local space.
		*
		* @param {Vector3} vector - The vector to convert.
		* @return {Vector3} The converted vector.
		*/
		worldToLocal(vector) {
			this.updateWorldMatrix(true, false);
			return vector.applyMatrix4(_m1$1.copy(this.matrixWorld).invert());
		}
		/**
		* Rotates the object to face a point in world space.
		*
		* This method does not support objects having non-uniformly-scaled parent(s).
		*
		* @param {number|Vector3} x - The x coordinate in world space. Alternatively, a vector representing a position in world space
		* @param {number} [y] - The y coordinate in world space.
		* @param {number} [z] - The z coordinate in world space.
		*/
		lookAt(x, y, z) {
			if (x.isVector3) _target.copy(x);
			else _target.set(x, y, z);
			const parent = this.parent;
			this.updateWorldMatrix(true, false);
			_position$4.setFromMatrixPosition(this.matrixWorld);
			if (this.isCamera || this.isLight) _m1$1.lookAt(_position$4, _target, this.up);
			else _m1$1.lookAt(_target, _position$4, this.up);
			this.quaternion.setFromRotationMatrix(_m1$1);
			if (parent) {
				_m1$1.extractRotation(parent.matrixWorld);
				_q1.setFromRotationMatrix(_m1$1);
				this.quaternion.premultiply(_q1.invert());
			}
		}
		/**
		* Adds the given 3D object as a child to this 3D object. An arbitrary number of
		* objects may be added. Any current parent on an object passed in here will be
		* removed, since an object can have at most one parent.
		*
		* @fires Object3D#added
		* @fires Object3D#childadded
		* @param {Object3D} object - The 3D object to add.
		* @return {Object3D} A reference to this instance.
		*/
		add(object) {
			if (arguments.length > 1) {
				for (let i = 0; i < arguments.length; i++) this.add(arguments[i]);
				return this;
			}
			if (object === this) {
				error("Object3D.add: object can't be added as a child of itself.", object);
				return this;
			}
			if (object && object.isObject3D) {
				object.removeFromParent();
				object.parent = this;
				this.children.push(object);
				object.dispatchEvent(_addedEvent);
				_childaddedEvent.child = object;
				this.dispatchEvent(_childaddedEvent);
				_childaddedEvent.child = null;
			} else error("Object3D.add: object not an instance of THREE.Object3D.", object);
			return this;
		}
		/**
		* Removes the given 3D object as child from this 3D object.
		* An arbitrary number of objects may be removed.
		*
		* @fires Object3D#removed
		* @fires Object3D#childremoved
		* @param {Object3D} object - The 3D object to remove.
		* @return {Object3D} A reference to this instance.
		*/
		remove(object) {
			if (arguments.length > 1) {
				for (let i = 0; i < arguments.length; i++) this.remove(arguments[i]);
				return this;
			}
			const index = this.children.indexOf(object);
			if (index !== -1) {
				object.parent = null;
				this.children.splice(index, 1);
				object.dispatchEvent(_removedEvent);
				_childremovedEvent.child = object;
				this.dispatchEvent(_childremovedEvent);
				_childremovedEvent.child = null;
			}
			return this;
		}
		/**
		* Removes this 3D object from its current parent.
		*
		* @fires Object3D#removed
		* @fires Object3D#childremoved
		* @return {Object3D} A reference to this instance.
		*/
		removeFromParent() {
			const parent = this.parent;
			if (parent !== null) parent.remove(this);
			return this;
		}
		/**
		* Removes all child objects.
		*
		* @fires Object3D#removed
		* @fires Object3D#childremoved
		* @return {Object3D} A reference to this instance.
		*/
		clear() {
			return this.remove(...this.children);
		}
		/**
		* Adds the given 3D object as a child of this 3D object, while maintaining the object's world
		* transform. This method does not support scene graphs having non-uniformly-scaled nodes(s).
		*
		* @fires Object3D#added
		* @fires Object3D#childadded
		* @param {Object3D} object - The 3D object to attach.
		* @return {Object3D} A reference to this instance.
		*/
		attach(object) {
			this.updateWorldMatrix(true, false);
			_m1$1.copy(this.matrixWorld).invert();
			if (object.parent !== null) {
				object.parent.updateWorldMatrix(true, false);
				_m1$1.multiply(object.parent.matrixWorld);
			}
			object.applyMatrix4(_m1$1);
			object.removeFromParent();
			object.parent = this;
			this.children.push(object);
			object.updateWorldMatrix(false, true);
			object.dispatchEvent(_addedEvent);
			_childaddedEvent.child = object;
			this.dispatchEvent(_childaddedEvent);
			_childaddedEvent.child = null;
			return this;
		}
		/**
		* Searches through the 3D object and its children, starting with the 3D object
		* itself, and returns the first with a matching ID.
		*
		* @param {number} id - The id.
		* @return {Object3D|undefined} The found 3D object. Returns `undefined` if no 3D object has been found.
		*/
		getObjectById(id) {
			return this.getObjectByProperty("id", id);
		}
		/**
		* Searches through the 3D object and its children, starting with the 3D object
		* itself, and returns the first with a matching name.
		*
		* @param {string} name - The name.
		* @return {Object3D|undefined} The found 3D object. Returns `undefined` if no 3D object has been found.
		*/
		getObjectByName(name) {
			return this.getObjectByProperty("name", name);
		}
		/**
		* Searches through the 3D object and its children, starting with the 3D object
		* itself, and returns the first with a matching property value.
		*
		* @param {string} name - The name of the property.
		* @param {any} value - The value.
		* @return {Object3D|undefined} The found 3D object. Returns `undefined` if no 3D object has been found.
		*/
		getObjectByProperty(name, value) {
			if (this[name] === value) return this;
			for (let i = 0, l = this.children.length; i < l; i++) {
				const object = this.children[i].getObjectByProperty(name, value);
				if (object !== void 0) return object;
			}
		}
		/**
		* Searches through the 3D object and its children, starting with the 3D object
		* itself, and returns all 3D objects with a matching property value.
		*
		* @param {string} name - The name of the property.
		* @param {any} value - The value.
		* @param {Array<Object3D>} result - The method stores the result in this array.
		* @return {Array<Object3D>} The found 3D objects.
		*/
		getObjectsByProperty(name, value, result = []) {
			if (this[name] === value) result.push(this);
			const children = this.children;
			for (let i = 0, l = children.length; i < l; i++) children[i].getObjectsByProperty(name, value, result);
			return result;
		}
		/**
		* Returns a vector representing the position of the 3D object in world space.
		*
		* @param {Vector3} target - The target vector the result is stored to.
		* @return {Vector3} The 3D object's position in world space.
		*/
		getWorldPosition(target) {
			this.updateWorldMatrix(true, false);
			return target.setFromMatrixPosition(this.matrixWorld);
		}
		/**
		* Returns a Quaternion representing the position of the 3D object in world space.
		*
		* @param {Quaternion} target - The target Quaternion the result is stored to.
		* @return {Quaternion} The 3D object's rotation in world space.
		*/
		getWorldQuaternion(target) {
			this.updateWorldMatrix(true, false);
			this.matrixWorld.decompose(_position$4, target, _scale$3);
			return target;
		}
		/**
		* Returns a vector representing the scale of the 3D object in world space.
		*
		* @param {Vector3} target - The target vector the result is stored to.
		* @return {Vector3} The 3D object's scale in world space.
		*/
		getWorldScale(target) {
			this.updateWorldMatrix(true, false);
			this.matrixWorld.decompose(_position$4, _quaternion$3, target);
			return target;
		}
		/**
		* Returns a vector representing the ("look") direction of the 3D object in world space.
		*
		* @param {Vector3} target - The target vector the result is stored to.
		* @return {Vector3} The 3D object's direction in world space.
		*/
		getWorldDirection(target) {
			this.updateWorldMatrix(true, false);
			const e = this.matrixWorld.elements;
			return target.set(e[8], e[9], e[10]).normalize();
		}
		/**
		* Abstract method to get intersections between a casted ray and this
		* 3D object. Renderable 3D objects such as {@link Mesh}, {@link Line} or {@link Points}
		* implement this method in order to use raycasting.
		*
		* @abstract
		* @param {Raycaster} raycaster - The raycaster.
		* @param {Array<Object>} intersects - An array holding the result of the method.
		*/
		raycast() {}
		/**
		* Abstract method to test whether this 3D object intersects the given frustum.
		* Renderable 3D objects such as {@link Mesh}, {@link Line} or {@link Points}
		* implement this method in order to use frustum culling.
		*
		* @abstract
		* @param {Frustum|FrustumArray} frustum - The frustum to test.
		* @return {boolean|undefined} Whether this 3D object intersects the given frustum or not.
		*/
		intersectsFrustum() {}
		/**
		* Executes the callback on this 3D object and all descendants.
		*
		* Note: Modifying the scene graph inside the callback is discouraged.
		*
		* @param {Function} callback - A callback function that allows to process the current 3D object.
		*/
		traverse(callback) {
			callback(this);
			const children = this.children;
			for (let i = 0, l = children.length; i < l; i++) children[i].traverse(callback);
		}
		/**
		* Like {@link Object3D#traverse}, but the callback will only be executed for visible 3D objects.
		* Descendants of invisible 3D objects are not traversed.
		*
		* Note: Modifying the scene graph inside the callback is discouraged.
		*
		* @param {Function} callback - A callback function that allows to process the current 3D object.
		*/
		traverseVisible(callback) {
			if (this.visible === false) return;
			callback(this);
			const children = this.children;
			for (let i = 0, l = children.length; i < l; i++) children[i].traverseVisible(callback);
		}
		/**
		* Like {@link Object3D#traverse}, but the callback will only be executed for all ancestors.
		*
		* Note: Modifying the scene graph inside the callback is discouraged.
		*
		* @param {Function} callback - A callback function that allows to process the current 3D object.
		*/
		traverseAncestors(callback) {
			const parent = this.parent;
			if (parent !== null) {
				callback(parent);
				parent.traverseAncestors(callback);
			}
		}
		/**
		* Updates the transformation matrix in local space by computing it from the current
		* position, rotation and scale values.
		*/
		updateMatrix() {
			this.matrix.compose(this.position, this.quaternion, this.scale);
			const pivot = this.pivot;
			if (pivot !== null) {
				const px = pivot.x, py = pivot.y, pz = pivot.z;
				const te = this.matrix.elements;
				te[12] += px - te[0] * px - te[4] * py - te[8] * pz;
				te[13] += py - te[1] * px - te[5] * py - te[9] * pz;
				te[14] += pz - te[2] * px - te[6] * py - te[10] * pz;
			}
			this.matrixWorldNeedsUpdate = true;
		}
		/**
		* Updates the transformation matrix in world space of this 3D objects and its descendants.
		*
		* To ensure correct results, this method also recomputes the 3D object's transformation matrix in
		* local space. The computation of the local and world matrix can be controlled with the
		* {@link Object3D#matrixAutoUpdate} and {@link Object3D#matrixWorldAutoUpdate} flags which are both
		* `true` by default.  Set these flags to `false` if you need more control over the update matrix process.
		*
		* @param {boolean} [force=false] - When set to `true`, a recomputation of world matrices is forced even
		* when {@link Object3D#matrixWorldNeedsUpdate} is `false`.
		*/
		updateMatrixWorld(force) {
			if (this.matrixAutoUpdate) this.updateMatrix();
			if (this.matrixWorldNeedsUpdate || force) {
				if (this.matrixWorldAutoUpdate === true) {
					if (this.parent === null) this.matrixWorld.copy(this.matrix);
					else this.matrixWorld.multiplyMatrices(this.parent.matrixWorld, this.matrix);
				}
				this.matrixWorldNeedsUpdate = false;
				force = true;
			}
			const children = this.children;
			for (let i = 0, l = children.length; i < l; i++) children[i].updateMatrixWorld(force);
		}
		/**
		* An alternative version of {@link Object3D#updateMatrixWorld} with more control over the
		* update of ancestor and descendant nodes.
		*
		* @param {boolean} [updateParents=false] Whether ancestor nodes should be updated or not.
		* @param {boolean} [updateChildren=false] Whether descendant nodes should be updated or not.
		* @param {boolean} [force=false] - When set to `true`, a recomputation of world matrices is forced even
		* when {@link Object3D#matrixWorldNeedsUpdate} is `false`.
		*/
		updateWorldMatrix(updateParents, updateChildren, force = false) {
			const parent = this.parent;
			if (updateParents === true && parent !== null) parent.updateWorldMatrix(true, false);
			if (this.matrixAutoUpdate) this.updateMatrix();
			if (this.matrixWorldNeedsUpdate || force) {
				if (this.matrixWorldAutoUpdate === true) {
					if (this.parent === null) this.matrixWorld.copy(this.matrix);
					else this.matrixWorld.multiplyMatrices(this.parent.matrixWorld, this.matrix);
				}
				this.matrixWorldNeedsUpdate = false;
				force = true;
			}
			if (updateChildren === true) {
				const children = this.children;
				for (let i = 0, l = children.length; i < l; i++) children[i].updateWorldMatrix(false, true, force);
			}
		}
		/**
		* Serializes the 3D object into JSON.
		*
		* @param {?(Object|string)} meta - An optional value holding meta information about the serialization.
		* @return {Object} A JSON object representing the serialized 3D object.
		* @see {@link ObjectLoader#parse}
		*/
		toJSON(meta) {
			const isRootObject = meta === void 0 || typeof meta === "string";
			const output = {};
			if (isRootObject) {
				meta = {
					geometries: {},
					materials: {},
					textures: {},
					images: {},
					shapes: {},
					skeletons: {},
					animations: {},
					nodes: {}
				};
				output.metadata = {
					version: 4.7,
					type: "Object",
					generator: "Object3D.toJSON"
				};
			}
			const object = {};
			object.uuid = this.uuid;
			object.type = this.type;
			object.name = this.name;
			object.castShadow = this.castShadow;
			object.receiveShadow = this.receiveShadow;
			object.visible = this.visible;
			object.frustumCulled = this.frustumCulled;
			object.renderOrder = this.renderOrder;
			object.static = this.static;
			object.matrixAutoUpdate = this.matrixAutoUpdate;
			if (Object.keys(this.userData).length > 0) object.userData = this.userData;
			object.layers = this.layers.mask;
			object.matrix = this.matrix.toArray();
			object.up = this.up.toArray();
			if (this.pivot !== null) object.pivot = this.pivot.toArray();
			if (this.morphTargetDictionary !== void 0) object.morphTargetDictionary = Object.assign({}, this.morphTargetDictionary);
			if (this.morphTargetInfluences !== void 0) object.morphTargetInfluences = this.morphTargetInfluences.slice();
			if (this.isInstancedMesh) {
				object.type = "InstancedMesh";
				object.count = this.count;
				object.instanceMatrix = this.instanceMatrix.toJSON();
				if (this.instanceColor !== null) object.instanceColor = this.instanceColor.toJSON();
			}
			if (this.isBatchedMesh) {
				object.type = "BatchedMesh";
				object.perObjectFrustumCulled = this.perObjectFrustumCulled;
				object.sortObjects = this.sortObjects;
				object.drawRanges = this._drawRanges;
				object.reservedRanges = this._reservedRanges;
				object.geometryInfo = this._geometryInfo.map((info) => ({
					...info,
					boundingBox: info.boundingBox ? info.boundingBox.toJSON() : void 0,
					boundingSphere: info.boundingSphere ? info.boundingSphere.toJSON() : void 0
				}));
				object.instanceInfo = this._instanceInfo.map((info) => ({ ...info }));
				object.availableInstanceIds = this._availableInstanceIds.slice();
				object.availableGeometryIds = this._availableGeometryIds.slice();
				object.nextIndexStart = this._nextIndexStart;
				object.nextVertexStart = this._nextVertexStart;
				object.geometryCount = this._geometryCount;
				object.maxInstanceCount = this._maxInstanceCount;
				object.maxVertexCount = this._maxVertexCount;
				object.maxIndexCount = this._maxIndexCount;
				object.geometryInitialized = this._geometryInitialized;
				object.matricesTexture = this._matricesTexture.toJSON(meta);
				object.indirectTexture = this._indirectTexture.toJSON(meta);
				if (this._colorsTexture !== null) object.colorsTexture = this._colorsTexture.toJSON(meta);
				if (this.boundingSphere !== null) object.boundingSphere = this.boundingSphere.toJSON();
				if (this.boundingBox !== null) object.boundingBox = this.boundingBox.toJSON();
			}
			function serialize(library, element) {
				if (library[element.uuid] === void 0) library[element.uuid] = element.toJSON(meta);
				return element.uuid;
			}
			if (this.isScene) {
				if (this.background) {
					if (this.background.isColor) object.background = this.background.toJSON();
					else if (this.background.isTexture) object.background = this.background.toJSON(meta).uuid;
				}
				if (this.environment && this.environment.isTexture && this.environment.isRenderTargetTexture !== true) object.environment = this.environment.toJSON(meta).uuid;
			} else if (this.isMesh || this.isLine || this.isPoints) {
				object.geometry = serialize(meta.geometries, this.geometry);
				const parameters = this.geometry.parameters;
				if (parameters !== void 0 && parameters.shapes !== void 0) {
					const shapes = parameters.shapes;
					if (Array.isArray(shapes)) for (let i = 0, l = shapes.length; i < l; i++) {
						const shape = shapes[i];
						serialize(meta.shapes, shape);
					}
					else serialize(meta.shapes, shapes);
				}
			}
			if (this.isSkinnedMesh) {
				object.bindMode = this.bindMode;
				object.bindMatrix = this.bindMatrix.toArray();
				if (this.skeleton !== void 0) {
					serialize(meta.skeletons, this.skeleton);
					object.skeleton = this.skeleton.uuid;
				}
			}
			if (this.material !== void 0) {
				if (Array.isArray(this.material)) {
					const uuids = [];
					for (let i = 0, l = this.material.length; i < l; i++) uuids.push(serialize(meta.materials, this.material[i]));
					object.material = uuids;
				} else object.material = serialize(meta.materials, this.material);
			}
			if (this.children.length > 0) {
				object.children = [];
				for (let i = 0; i < this.children.length; i++) object.children.push(this.children[i].toJSON(meta).object);
			}
			if (this.animations.length > 0) {
				object.animations = [];
				for (let i = 0; i < this.animations.length; i++) {
					const animation = this.animations[i];
					object.animations.push(serialize(meta.animations, animation));
				}
			}
			if (isRootObject) {
				const geometries = extractFromCache(meta.geometries);
				const materials = extractFromCache(meta.materials);
				const textures = extractFromCache(meta.textures);
				const images = extractFromCache(meta.images);
				const shapes = extractFromCache(meta.shapes);
				const skeletons = extractFromCache(meta.skeletons);
				const animations = extractFromCache(meta.animations);
				const nodes = extractFromCache(meta.nodes);
				if (geometries.length > 0) output.geometries = geometries;
				if (materials.length > 0) output.materials = materials;
				if (textures.length > 0) output.textures = textures;
				if (images.length > 0) output.images = images;
				if (shapes.length > 0) output.shapes = shapes;
				if (skeletons.length > 0) output.skeletons = skeletons;
				if (animations.length > 0) output.animations = animations;
				if (nodes.length > 0) output.nodes = nodes;
			}
			output.object = object;
			return output;
			function extractFromCache(cache) {
				const values = [];
				for (const key in cache) {
					const data = cache[key];
					delete data.metadata;
					values.push(data);
				}
				return values;
			}
		}
		/**
		* Returns a new 3D object with copied values from this instance.
		*
		* @param {boolean} [recursive=true] - When set to `true`, descendants of the 3D object are also cloned.
		* @return {Object3D} A clone of this instance.
		*/
		clone(recursive) {
			return new this.constructor().copy(this, recursive);
		}
		/**
		* Copies the values of the given 3D object to this instance.
		*
		* @param {Object3D} source - The 3D object to copy.
		* @param {boolean} [recursive=true] - When set to `true`, descendants of the 3D object are cloned.
		* @return {Object3D} A reference to this instance.
		*/
		copy(source, recursive = true) {
			this.name = source.name;
			this.up.copy(source.up);
			this.position.copy(source.position);
			this.rotation.order = source.rotation.order;
			this.quaternion.copy(source.quaternion);
			this.scale.copy(source.scale);
			this.pivot = source.pivot !== null ? source.pivot.clone() : null;
			this.matrix.copy(source.matrix);
			this.matrixWorld.copy(source.matrixWorld);
			this.matrixAutoUpdate = source.matrixAutoUpdate;
			this.matrixWorldAutoUpdate = source.matrixWorldAutoUpdate;
			this.matrixWorldNeedsUpdate = source.matrixWorldNeedsUpdate;
			this.layers.mask = source.layers.mask;
			this.visible = source.visible;
			this.castShadow = source.castShadow;
			this.receiveShadow = source.receiveShadow;
			this.frustumCulled = source.frustumCulled;
			this.renderOrder = source.renderOrder;
			this.static = source.static;
			this.animations = source.animations.slice();
			this.userData = JSON.parse(JSON.stringify(source.userData));
			if (recursive === true) for (let i = 0; i < source.children.length; i++) {
				const child = source.children[i];
				this.add(child.clone());
			}
			return this;
		}
		/**
		* Frees the GPU-related resources allocated by this instance. Call this
		* method whenever this instance is no longer used in your app.
		*
		* Geometries, materials and textures are potentially shared with other
		* 3D objects and must be disposed of separately.
		*
		* @fires Object3D#dispose
		*/
		dispose() {
			/**
			* Fires when the 3D object has been disposed of.
			*
			* @event Object3D#dispose
			* @type {Object}
			*/
			this.dispatchEvent({ type: "dispose" });
		}
	};
	/**
	* The default up direction for objects, also used as the default
	* position for {@link DirectionalLight} and {@link HemisphereLight}.
	*
	* @static
	* @type {Vector3}
	* @default (0,1,0)
	*/
	Object3D.DEFAULT_UP = /*@__PURE__*/ new Vector3(0, 1, 0);
	/**
	* The default setting for {@link Object3D#matrixAutoUpdate} for
	* newly created 3D objects.
	*
	* @static
	* @type {boolean}
	* @default true
	*/
	Object3D.DEFAULT_MATRIX_AUTO_UPDATE = true;
	/**
	* The default setting for {@link Object3D#matrixWorldAutoUpdate} for
	* newly created 3D objects.
	*
	* @static
	* @type {boolean}
	* @default true
	*/
	Object3D.DEFAULT_MATRIX_WORLD_AUTO_UPDATE = true;
	const _colorKeywords = {
		"aliceblue": 15792383,
		"antiquewhite": 16444375,
		"aqua": 65535,
		"aquamarine": 8388564,
		"azure": 15794175,
		"beige": 16119260,
		"bisque": 16770244,
		"black": 0,
		"blanchedalmond": 16772045,
		"blue": 255,
		"blueviolet": 9055202,
		"brown": 10824234,
		"burlywood": 14596231,
		"cadetblue": 6266528,
		"chartreuse": 8388352,
		"chocolate": 13789470,
		"coral": 16744272,
		"cornflowerblue": 6591981,
		"cornsilk": 16775388,
		"crimson": 14423100,
		"cyan": 65535,
		"darkblue": 139,
		"darkcyan": 35723,
		"darkgoldenrod": 12092939,
		"darkgray": 11119017,
		"darkgreen": 25600,
		"darkgrey": 11119017,
		"darkkhaki": 12433259,
		"darkmagenta": 9109643,
		"darkolivegreen": 5597999,
		"darkorange": 16747520,
		"darkorchid": 10040012,
		"darkred": 9109504,
		"darksalmon": 15308410,
		"darkseagreen": 9419919,
		"darkslateblue": 4734347,
		"darkslategray": 3100495,
		"darkslategrey": 3100495,
		"darkturquoise": 52945,
		"darkviolet": 9699539,
		"deeppink": 16716947,
		"deepskyblue": 49151,
		"dimgray": 6908265,
		"dimgrey": 6908265,
		"dodgerblue": 2003199,
		"firebrick": 11674146,
		"floralwhite": 16775920,
		"forestgreen": 2263842,
		"fuchsia": 16711935,
		"gainsboro": 14474460,
		"ghostwhite": 16316671,
		"gold": 16766720,
		"goldenrod": 14329120,
		"gray": 8421504,
		"green": 32768,
		"greenyellow": 11403055,
		"grey": 8421504,
		"honeydew": 15794160,
		"hotpink": 16738740,
		"indianred": 13458524,
		"indigo": 4915330,
		"ivory": 16777200,
		"khaki": 15787660,
		"lavender": 15132410,
		"lavenderblush": 16773365,
		"lawngreen": 8190976,
		"lemonchiffon": 16775885,
		"lightblue": 11393254,
		"lightcoral": 15761536,
		"lightcyan": 14745599,
		"lightgoldenrodyellow": 16448210,
		"lightgray": 13882323,
		"lightgreen": 9498256,
		"lightgrey": 13882323,
		"lightpink": 16758465,
		"lightsalmon": 16752762,
		"lightseagreen": 2142890,
		"lightskyblue": 8900346,
		"lightslategray": 7833753,
		"lightslategrey": 7833753,
		"lightsteelblue": 11584734,
		"lightyellow": 16777184,
		"lime": 65280,
		"limegreen": 3329330,
		"linen": 16445670,
		"magenta": 16711935,
		"maroon": 8388608,
		"mediumaquamarine": 6737322,
		"mediumblue": 205,
		"mediumorchid": 12211667,
		"mediumpurple": 9662683,
		"mediumseagreen": 3978097,
		"mediumslateblue": 8087790,
		"mediumspringgreen": 64154,
		"mediumturquoise": 4772300,
		"mediumvioletred": 13047173,
		"midnightblue": 1644912,
		"mintcream": 16121850,
		"mistyrose": 16770273,
		"moccasin": 16770229,
		"navajowhite": 16768685,
		"navy": 128,
		"oldlace": 16643558,
		"olive": 8421376,
		"olivedrab": 7048739,
		"orange": 16753920,
		"orangered": 16729344,
		"orchid": 14315734,
		"palegoldenrod": 15657130,
		"palegreen": 10025880,
		"paleturquoise": 11529966,
		"palevioletred": 14381203,
		"papayawhip": 16773077,
		"peachpuff": 16767673,
		"peru": 13468991,
		"pink": 16761035,
		"plum": 14524637,
		"powderblue": 11591910,
		"purple": 8388736,
		"rebeccapurple": 6697881,
		"red": 16711680,
		"rosybrown": 12357519,
		"royalblue": 4286945,
		"saddlebrown": 9127187,
		"salmon": 16416882,
		"sandybrown": 16032864,
		"seagreen": 3050327,
		"seashell": 16774638,
		"sienna": 10506797,
		"silver": 12632256,
		"skyblue": 8900331,
		"slateblue": 6970061,
		"slategray": 7372944,
		"slategrey": 7372944,
		"snow": 16775930,
		"springgreen": 65407,
		"steelblue": 4620980,
		"tan": 13808780,
		"teal": 32896,
		"thistle": 14204888,
		"tomato": 16737095,
		"turquoise": 4251856,
		"violet": 15631086,
		"wheat": 16113331,
		"white": 16777215,
		"whitesmoke": 16119285,
		"yellow": 16776960,
		"yellowgreen": 10145074
	};
	const _hslA = {
		h: 0,
		s: 0,
		l: 0
	};
	const _hslB = {
		h: 0,
		s: 0,
		l: 0
	};
	function hue2rgb(p, q, t) {
		if (t < 0) t += 1;
		if (t > 1) t -= 1;
		if (t < 1 / 6) return p + (q - p) * 6 * t;
		if (t < 1 / 2) return q;
		if (t < 2 / 3) return p + (q - p) * 6 * (2 / 3 - t);
		return p;
	}
	/**
	* A Color instance is represented by RGB components in the linear <i>working
	* color space</i>, which defaults to `LinearSRGBColorSpace`. Inputs
	* conventionally using `SRGBColorSpace` (such as hexadecimals and CSS
	* strings) are converted to the working color space automatically.
	*
	* ```js
	* // converted automatically from SRGBColorSpace to LinearSRGBColorSpace
	* const color = new THREE.Color().setHex( 0x112233 );
	* ```
	* Source color spaces may be specified explicitly, to ensure correct conversions.
	* ```js
	* // assumed already LinearSRGBColorSpace; no conversion
	* const color = new THREE.Color().setRGB( 0.5, 0.5, 0.5 );
	*
	* // converted explicitly from SRGBColorSpace to LinearSRGBColorSpace
	* const color = new THREE.Color().setRGB( 0.5, 0.5, 0.5, SRGBColorSpace );
	* ```
	* If THREE.ColorManagement is disabled, no conversions occur. For details,
	* see <i>Color management</i>. Iterating through a Color instance will yield
	* its components (r, g, b) in the corresponding order. A Color can be initialised
	* in any of the following ways:
	* ```js
	* //empty constructor - will default white
	* const color1 = new THREE.Color();
	*
	* //Hexadecimal color (recommended)
	* const color2 = new THREE.Color( 0xff0000 );
	*
	* //RGB string
	* const color3 = new THREE.Color("rgb(255, 0, 0)");
	* const color4 = new THREE.Color("rgb(100%, 0%, 0%)");
	*
	* //X11 color name - all 140 color names are supported.
	* //Note the lack of CamelCase in the name
	* const color5 = new THREE.Color( 'skyblue' );
	* //HSL string
	* const color6 = new THREE.Color("hsl(0, 100%, 50%)");
	*
	* //Separate RGB values between 0 and 1
	* const color7 = new THREE.Color( 1, 0, 0 );
	* ```
	*/
	var Color = class {
		/**
		* Constructs a new color.
		*
		* Note that standard method of specifying color in three.js is with a hexadecimal triplet,
		* and that method is used throughout the rest of the documentation.
		*
		* @param {(number|string|Color)} [r] - The red component of the color. If `g` and `b` are
		* not provided, it can be hexadecimal triplet, a CSS-style string or another `Color` instance.
		* @param {number} [g] - The green component.
		* @param {number} [b] - The blue component.
		*/
		constructor(r, g, b) {
			/**
			* This flag can be used for type testing.
			*
			* @type {boolean}
			* @readonly
			* @default true
			*/
			this.isColor = true;
			/**
			* The red component.
			*
			* @type {number}
			* @default 1
			*/
			this.r = 1;
			/**
			* The green component.
			*
			* @type {number}
			* @default 1
			*/
			this.g = 1;
			/**
			* The blue component.
			*
			* @type {number}
			* @default 1
			*/
			this.b = 1;
			return this.set(r, g, b);
		}
		/**
		* Sets the colors's components from the given values.
		*
		* @param {(number|string|Color)} [r] - The red component of the color. If `g` and `b` are
		* not provided, it can be hexadecimal triplet, a CSS-style string or another `Color` instance.
		* @param {number} [g] - The green component.
		* @param {number} [b] - The blue component.
		* @return {Color} A reference to this color.
		*/
		set(r, g, b) {
			if (g === void 0 && b === void 0) {
				const value = r;
				if (value && value.isColor) this.copy(value);
				else if (typeof value === "number") this.setHex(value);
				else if (typeof value === "string") this.setStyle(value);
			} else this.setRGB(r, g, b);
			return this;
		}
		/**
		* Sets the colors's components to the given scalar value.
		*
		* @param {number} scalar - The scalar value.
		* @return {Color} A reference to this color.
		*/
		setScalar(scalar) {
			this.r = scalar;
			this.g = scalar;
			this.b = scalar;
			return this;
		}
		/**
		* Sets this color from a hexadecimal value.
		*
		* @param {number} hex - The hexadecimal value.
		* @param {string} [colorSpace=SRGBColorSpace] - The color space.
		* @return {Color} A reference to this color.
		*/
		setHex(hex, colorSpace = SRGBColorSpace) {
			hex = Math.floor(hex);
			this.r = (hex >> 16 & 255) / 255;
			this.g = (hex >> 8 & 255) / 255;
			this.b = (hex & 255) / 255;
			ColorManagement.colorSpaceToWorking(this, colorSpace);
			return this;
		}
		/**
		* Sets this color from RGB values.
		*
		* @param {number} r - Red channel value between `0.0` and `1.0`.
		* @param {number} g - Green channel value between `0.0` and `1.0`.
		* @param {number} b - Blue channel value between `0.0` and `1.0`.
		* @param {string} [colorSpace=ColorManagement.workingColorSpace] - The color space.
		* @return {Color} A reference to this color.
		*/
		setRGB(r, g, b, colorSpace = ColorManagement.workingColorSpace) {
			this.r = r;
			this.g = g;
			this.b = b;
			ColorManagement.colorSpaceToWorking(this, colorSpace);
			return this;
		}
		/**
		* Sets this color from RGB values.
		*
		* @param {number} h - Hue value between `0.0` and `1.0`.
		* @param {number} s - Saturation value between `0.0` and `1.0`.
		* @param {number} l - Lightness value between `0.0` and `1.0`.
		* @param {string} [colorSpace=ColorManagement.workingColorSpace] - The color space.
		* @return {Color} A reference to this color.
		*/
		setHSL(h, s, l, colorSpace = ColorManagement.workingColorSpace) {
			h = euclideanModulo(h, 1);
			s = clamp(s, 0, 1);
			l = clamp(l, 0, 1);
			if (s === 0) this.r = this.g = this.b = l;
			else {
				const p = l <= .5 ? l * (1 + s) : l + s - l * s;
				const q = 2 * l - p;
				this.r = hue2rgb(q, p, h + 1 / 3);
				this.g = hue2rgb(q, p, h);
				this.b = hue2rgb(q, p, h - 1 / 3);
			}
			ColorManagement.colorSpaceToWorking(this, colorSpace);
			return this;
		}
		/**
		* Sets this color from a CSS-style string. For example, `rgb(250, 0,0)`,
		* `rgb(100%, 0%, 0%)`, `hsl(0, 100%, 50%)`, `#ff0000`, `#f00`, or `red` ( or
		* any [X11 color name](https://en.wikipedia.org/wiki/X11_color_names#Color_name_chart) -
		* all 140 color names are supported).
		*
		* @param {string} style - Color as a CSS-style string.
		* @param {string} [colorSpace=SRGBColorSpace] - The color space.
		* @return {Color} A reference to this color.
		*/
		setStyle(style, colorSpace = SRGBColorSpace) {
			function handleAlpha(string) {
				if (string === void 0) return;
				if (parseFloat(string) < 1) warn("Color: Alpha component of " + style + " will be ignored.");
			}
			let m;
			if (m = /^(\w+)\(([^\)]*)\)/.exec(style)) {
				let color;
				const name = m[1];
				const components = m[2];
				switch (name) {
					case "rgb":
					case "rgba":
						if (color = /^\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(components)) {
							handleAlpha(color[4]);
							return this.setRGB(Math.min(255, parseInt(color[1], 10)) / 255, Math.min(255, parseInt(color[2], 10)) / 255, Math.min(255, parseInt(color[3], 10)) / 255, colorSpace);
						}
						if (color = /^\s*(\d+)\%\s*,\s*(\d+)\%\s*,\s*(\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(components)) {
							handleAlpha(color[4]);
							return this.setRGB(Math.min(100, parseInt(color[1], 10)) / 100, Math.min(100, parseInt(color[2], 10)) / 100, Math.min(100, parseInt(color[3], 10)) / 100, colorSpace);
						}
						break;
					case "hsl":
					case "hsla":
						if (color = /^\s*(\d*\.?\d+)\s*,\s*(\d*\.?\d+)\%\s*,\s*(\d*\.?\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(components)) {
							handleAlpha(color[4]);
							return this.setHSL(parseFloat(color[1]) / 360, parseFloat(color[2]) / 100, parseFloat(color[3]) / 100, colorSpace);
						}
						break;
					default: warn("Color: Unknown color model " + style);
				}
			} else if (m = /^\#([A-Fa-f\d]+)$/.exec(style)) {
				const hex = m[1];
				const size = hex.length;
				if (size === 3) return this.setRGB(parseInt(hex.charAt(0), 16) / 15, parseInt(hex.charAt(1), 16) / 15, parseInt(hex.charAt(2), 16) / 15, colorSpace);
				else if (size === 6) return this.setHex(parseInt(hex, 16), colorSpace);
				else warn("Color: Invalid hex color " + style);
			} else if (style && style.length > 0) return this.setColorName(style, colorSpace);
			return this;
		}
		/**
		* Sets this color from a color name. Faster than {@link Color#setStyle} if
		* you don't need the other CSS-style formats.
		*
		* For convenience, the list of names is exposed in `Color.NAMES` as a hash.
		* ```js
		* Color.NAMES.aliceblue // returns 0xF0F8FF
		* ```
		*
		* @param {string} style - The color name.
		* @param {string} [colorSpace=SRGBColorSpace] - The color space.
		* @return {Color} A reference to this color.
		*/
		setColorName(style, colorSpace = SRGBColorSpace) {
			const hex = _colorKeywords[style.toLowerCase()];
			if (hex !== void 0) this.setHex(hex, colorSpace);
			else warn("Color: Unknown color " + style);
			return this;
		}
		/**
		* Returns a new color with copied values from this instance.
		*
		* @return {Color} A clone of this instance.
		*/
		clone() {
			return new this.constructor(this.r, this.g, this.b);
		}
		/**
		* Copies the values of the given color to this instance.
		*
		* @param {Color} color - The color to copy.
		* @return {Color} A reference to this color.
		*/
		copy(color) {
			this.r = color.r;
			this.g = color.g;
			this.b = color.b;
			return this;
		}
		/**
		* Copies the given color into this color, and then converts this color from
		* `SRGBColorSpace` to `LinearSRGBColorSpace`.
		*
		* @param {Color} color - The color to copy/convert.
		* @return {Color} A reference to this color.
		*/
		copySRGBToLinear(color) {
			this.r = SRGBToLinear(color.r);
			this.g = SRGBToLinear(color.g);
			this.b = SRGBToLinear(color.b);
			return this;
		}
		/**
		* Copies the given color into this color, and then converts this color from
		* `LinearSRGBColorSpace` to `SRGBColorSpace`.
		*
		* @param {Color} color - The color to copy/convert.
		* @return {Color} A reference to this color.
		*/
		copyLinearToSRGB(color) {
			this.r = LinearToSRGB(color.r);
			this.g = LinearToSRGB(color.g);
			this.b = LinearToSRGB(color.b);
			return this;
		}
		/**
		* Converts this color from `SRGBColorSpace` to `LinearSRGBColorSpace`.
		*
		* @return {Color} A reference to this color.
		*/
		convertSRGBToLinear() {
			this.copySRGBToLinear(this);
			return this;
		}
		/**
		* Converts this color from `LinearSRGBColorSpace` to `SRGBColorSpace`.
		*
		* @return {Color} A reference to this color.
		*/
		convertLinearToSRGB() {
			this.copyLinearToSRGB(this);
			return this;
		}
		/**
		* Returns the hexadecimal value of this color.
		*
		* @param {string} [colorSpace=SRGBColorSpace] - The color space.
		* @return {number} The hexadecimal value.
		*/
		getHex(colorSpace = SRGBColorSpace) {
			ColorManagement.workingToColorSpace(_color.copy(this), colorSpace);
			return Math.round(clamp(_color.r * 255, 0, 255)) * 65536 + Math.round(clamp(_color.g * 255, 0, 255)) * 256 + Math.round(clamp(_color.b * 255, 0, 255));
		}
		/**
		* Returns the hexadecimal value of this color as a string (for example, 'FFFFFF').
		*
		* @param {string} [colorSpace=SRGBColorSpace] - The color space.
		* @return {string} The hexadecimal value as a string.
		*/
		getHexString(colorSpace = SRGBColorSpace) {
			return ("000000" + this.getHex(colorSpace).toString(16)).slice(-6);
		}
		/**
		* Converts the colors RGB values into the HSL format and stores them into the
		* given target object.
		*
		* @param {{h:number,s:number,l:number}} target - The target object that is used to store the method's result.
		* @param {string} [colorSpace=ColorManagement.workingColorSpace] - The color space.
		* @return {{h:number,s:number,l:number}} The HSL representation of this color.
		*/
		getHSL(target, colorSpace = ColorManagement.workingColorSpace) {
			ColorManagement.workingToColorSpace(_color.copy(this), colorSpace);
			const r = _color.r, g = _color.g, b = _color.b;
			const max = Math.max(r, g, b);
			const min = Math.min(r, g, b);
			let hue, saturation;
			const lightness = (min + max) / 2;
			if (min === max) {
				hue = 0;
				saturation = 0;
			} else {
				const delta = max - min;
				saturation = lightness <= .5 ? delta / (max + min) : delta / (2 - max - min);
				switch (max) {
					case r:
						hue = (g - b) / delta + (g < b ? 6 : 0);
						break;
					case g:
						hue = (b - r) / delta + 2;
						break;
					case b: hue = (r - g) / delta + 4;
				}
				hue /= 6;
			}
			target.h = hue;
			target.s = saturation;
			target.l = lightness;
			return target;
		}
		/**
		* Returns the RGB values of this color and stores them into the given target object.
		*
		* @param {Color} target - The target color that is used to store the method's result.
		* @param {string} [colorSpace=ColorManagement.workingColorSpace] - The color space.
		* @return {Color} The RGB representation of this color.
		*/
		getRGB(target, colorSpace = ColorManagement.workingColorSpace) {
			ColorManagement.workingToColorSpace(_color.copy(this), colorSpace);
			target.r = _color.r;
			target.g = _color.g;
			target.b = _color.b;
			return target;
		}
		/**
		* Returns the value of this color as a CSS style string. Example: `rgb(255,0,0)`.
		*
		* @param {string} [colorSpace=SRGBColorSpace] - The color space.
		* @return {string} The CSS representation of this color.
		*/
		getStyle(colorSpace = SRGBColorSpace) {
			ColorManagement.workingToColorSpace(_color.copy(this), colorSpace);
			const r = _color.r, g = _color.g, b = _color.b;
			if (colorSpace !== "srgb") return `color(${colorSpace} ${r.toFixed(3)} ${g.toFixed(3)} ${b.toFixed(3)})`;
			return `rgb(${Math.round(r * 255)},${Math.round(g * 255)},${Math.round(b * 255)})`;
		}
		/**
		* Adds the given HSL values to this color's values.
		* Internally, this converts the color's RGB values to HSL, adds HSL
		* and then converts the color back to RGB.
		*
		* @param {number} h - Hue value between `0.0` and `1.0`.
		* @param {number} s - Saturation value between `0.0` and `1.0`.
		* @param {number} l - Lightness value between `0.0` and `1.0`.
		* @return {Color} A reference to this color.
		*/
		offsetHSL(h, s, l) {
			this.getHSL(_hslA);
			return this.setHSL(_hslA.h + h, _hslA.s + s, _hslA.l + l);
		}
		/**
		* Adds the RGB values of the given color to the RGB values of this color.
		*
		* @param {Color} color - The color to add.
		* @return {Color} A reference to this color.
		*/
		add(color) {
			this.r += color.r;
			this.g += color.g;
			this.b += color.b;
			return this;
		}
		/**
		* Adds the RGB values of the given colors and stores the result in this instance.
		*
		* @param {Color} color1 - The first color.
		* @param {Color} color2 - The second color.
		* @return {Color} A reference to this color.
		*/
		addColors(color1, color2) {
			this.r = color1.r + color2.r;
			this.g = color1.g + color2.g;
			this.b = color1.b + color2.b;
			return this;
		}
		/**
		* Adds the given scalar value to the RGB values of this color.
		*
		* @param {number} s - The scalar to add.
		* @return {Color} A reference to this color.
		*/
		addScalar(s) {
			this.r += s;
			this.g += s;
			this.b += s;
			return this;
		}
		/**
		* Subtracts the RGB values of the given color from the RGB values of this color.
		*
		* @param {Color} color - The color to subtract.
		* @return {Color} A reference to this color.
		*/
		sub(color) {
			this.r = Math.max(0, this.r - color.r);
			this.g = Math.max(0, this.g - color.g);
			this.b = Math.max(0, this.b - color.b);
			return this;
		}
		/**
		* Multiplies the RGB values of the given color with the RGB values of this color.
		*
		* @param {Color} color - The color to multiply.
		* @return {Color} A reference to this color.
		*/
		multiply(color) {
			this.r *= color.r;
			this.g *= color.g;
			this.b *= color.b;
			return this;
		}
		/**
		* Multiplies the given scalar value with the RGB values of this color.
		*
		* @param {number} s - The scalar to multiply.
		* @return {Color} A reference to this color.
		*/
		multiplyScalar(s) {
			this.r *= s;
			this.g *= s;
			this.b *= s;
			return this;
		}
		/**
		* Linearly interpolates this color's RGB values toward the RGB values of the
		* given color. The alpha argument can be thought of as the ratio between
		* the two colors, where `0.0` is this color and `1.0` is the first argument.
		*
		* @param {Color} color - The color to converge on.
		* @param {number} alpha - The interpolation factor in the closed interval `[0,1]`.
		* @return {Color} A reference to this color.
		*/
		lerp(color, alpha) {
			this.r += (color.r - this.r) * alpha;
			this.g += (color.g - this.g) * alpha;
			this.b += (color.b - this.b) * alpha;
			return this;
		}
		/**
		* Linearly interpolates between the given colors and stores the result in this instance.
		* The alpha argument can be thought of as the ratio between the two colors, where `0.0`
		* is the first and `1.0` is the second color.
		*
		* @param {Color} color1 - The first color.
		* @param {Color} color2 - The second color.
		* @param {number} alpha - The interpolation factor in the closed interval `[0,1]`.
		* @return {Color} A reference to this color.
		*/
		lerpColors(color1, color2, alpha) {
			this.r = color1.r + (color2.r - color1.r) * alpha;
			this.g = color1.g + (color2.g - color1.g) * alpha;
			this.b = color1.b + (color2.b - color1.b) * alpha;
			return this;
		}
		/**
		* Linearly interpolates this color's HSL values toward the HSL values of the
		* given color. It differs from {@link Color#lerp} by not interpolating straight
		* from one color to the other, but instead going through all the hues in between
		* those two colors. The alpha argument can be thought of as the ratio between
		* the two colors, where 0.0 is this color and 1.0 is the first argument.
		*
		* @param {Color} color - The color to converge on.
		* @param {number} alpha - The interpolation factor in the closed interval `[0,1]`.
		* @return {Color} A reference to this color.
		*/
		lerpHSL(color, alpha) {
			this.getHSL(_hslA);
			color.getHSL(_hslB);
			const h = lerp(_hslA.h, _hslB.h, alpha);
			const s = lerp(_hslA.s, _hslB.s, alpha);
			const l = lerp(_hslA.l, _hslB.l, alpha);
			this.setHSL(h, s, l);
			return this;
		}
		/**
		* Sets the color's RGB components from the given 3D vector.
		*
		* @param {Vector3} v - The vector to set.
		* @return {Color} A reference to this color.
		*/
		setFromVector3(v) {
			this.r = v.x;
			this.g = v.y;
			this.b = v.z;
			return this;
		}
		/**
		* Transforms this color with the given 3x3 matrix.
		*
		* @param {Matrix3} m - The matrix.
		* @return {Color} A reference to this color.
		*/
		applyMatrix3(m) {
			const r = this.r, g = this.g, b = this.b;
			const e = m.elements;
			this.r = e[0] * r + e[3] * g + e[6] * b;
			this.g = e[1] * r + e[4] * g + e[7] * b;
			this.b = e[2] * r + e[5] * g + e[8] * b;
			return this;
		}
		/**
		* Returns `true` if this color is equal with the given one.
		*
		* @param {Color} c - The color to test for equality.
		* @return {boolean} Whether this bounding color is equal with the given one.
		*/
		equals(c) {
			return c.r === this.r && c.g === this.g && c.b === this.b;
		}
		/**
		* Sets this color's RGB components from the given array.
		*
		* @param {Array<number>} array - An array holding the RGB values.
		* @param {number} [offset=0] - The offset into the array.
		* @return {Color} A reference to this color.
		*/
		fromArray(array, offset = 0) {
			this.r = array[offset];
			this.g = array[offset + 1];
			this.b = array[offset + 2];
			return this;
		}
		/**
		* Writes the RGB components of this color to the given array. If no array is provided,
		* the method returns a new instance.
		*
		* @param {Array<number>} [array=[]] - The target array holding the color components.
		* @param {number} [offset=0] - Index of the first element in the array.
		* @return {Array<number>} The color components.
		*/
		toArray(array = [], offset = 0) {
			array[offset] = this.r;
			array[offset + 1] = this.g;
			array[offset + 2] = this.b;
			return array;
		}
		/**
		* Sets the components of this color from the given buffer attribute.
		*
		* @param {BufferAttribute} attribute - The buffer attribute holding color data.
		* @param {number} index - The index into the attribute.
		* @return {Color} A reference to this color.
		*/
		fromBufferAttribute(attribute, index) {
			this.r = attribute.getX(index);
			this.g = attribute.getY(index);
			this.b = attribute.getZ(index);
			return this;
		}
		/**
		* This methods defines the serialization result of this class. Returns the color
		* as a hexadecimal value.
		*
		* @return {number} The hexadecimal value.
		*/
		toJSON() {
			return this.getHex();
		}
		*[Symbol.iterator]() {
			yield this.r;
			yield this.g;
			yield this.b;
		}
	};
	const _color = /*@__PURE__*/ new Color();
	/**
	* A dictionary with X11 color names.
	*
	* Note that multiple words such as Dark Orange become the string 'darkorange'.
	*
	* @static
	* @type {Object}
	*/
	Color.NAMES = _colorKeywords;
	/**
	* Converts an array to a specific type.
	*
	* @param {TypedArray|Array} array - The array to convert.
	* @param {TypedArray.constructor} type - The constructor of a typed array that defines the new type.
	* @return {TypedArray} The converted array.
	*/
	function convertArray(array, type) {
		if (!array || array.constructor === type) return array;
		if (typeof type.BYTES_PER_ELEMENT === "number") return new type(array);
		return Array.prototype.slice.call(array);
	}
	/**
	* Returns `true` if the given keyframe track settings hold Bezier tangent data.
	*
	* @param {?Object} settings - The settings of a keyframe track.
	* @return {boolean} Whether both tangent arrays are defined or not.
	*/
	function hasTangents(settings) {
		return settings !== void 0 && settings.inTangents !== void 0 && settings.outTangents !== void 0;
	}
	/**
	* Abstract base class of interpolants over parametric samples.
	*
	* The parameter domain is one dimensional, typically the time or a path
	* along a curve defined by the data.
	*
	* The sample values can have any dimensionality and derived classes may
	* apply special interpretations to the data.
	*
	* This class provides the interval seek in a Template Method, deferring
	* the actual interpolation to derived classes.
	*
	* Time complexity is O(1) for linear access crossing at most two points
	* and O(log N) for random access, where N is the number of positions.
	*
	* References: {@link http://www.oodesign.com/template-method-pattern.html}
	*
	* @abstract
	*/
	var Interpolant = class {
		/**
		* Constructs a new interpolant.
		*
		* @param {TypedArray} parameterPositions - The parameter positions hold the interpolation factors.
		* @param {TypedArray} sampleValues - The sample values.
		* @param {number} sampleSize - The sample size
		* @param {TypedArray} [resultBuffer] - The result buffer.
		*/
		constructor(parameterPositions, sampleValues, sampleSize, resultBuffer) {
			/**
			* The parameter positions.
			*
			* @type {TypedArray}
			*/
			this.parameterPositions = parameterPositions;
			/**
			* A cache index.
			*
			* @private
			* @type {number}
			* @default 0
			*/
			this._cachedIndex = 0;
			/**
			* The result buffer.
			*
			* @type {TypedArray}
			*/
			this.resultBuffer = resultBuffer !== void 0 ? resultBuffer : new sampleValues.constructor(sampleSize);
			/**
			* The sample values.
			*
			* @type {TypedArray}
			*/
			this.sampleValues = sampleValues;
			/**
			* The value size.
			*
			* @type {TypedArray}
			*/
			this.valueSize = sampleSize;
			/**
			* The interpolation settings.
			*
			* @type {?Object}
			* @default null
			*/
			this.settings = null;
			/**
			* The default settings object.
			*
			* @type {Object}
			*/
			this.DefaultSettings_ = {};
		}
		/**
		* Evaluate the interpolant at position `t`.
		*
		* @param {number} t - The interpolation factor.
		* @return {TypedArray} The result buffer.
		*/
		evaluate(t) {
			const pp = this.parameterPositions;
			let i1 = this._cachedIndex, t1 = pp[i1], t0 = pp[i1 - 1];
			validate_interval: {
				seek: {
					let right;
					linear_scan: {
						forward_scan: if (!(t < t1)) {
							for (let giveUpAt = i1 + 2;;) {
								if (t1 === void 0) {
									if (t < t0) break forward_scan;
									i1 = pp.length;
									this._cachedIndex = i1;
									return this.copySampleValue_(i1 - 1);
								}
								if (i1 === giveUpAt) break;
								t0 = t1;
								t1 = pp[++i1];
								if (t < t1) break seek;
							}
							right = pp.length;
							break linear_scan;
						}
						if (!(t >= t0)) {
							const t1global = pp[1];
							if (t < t1global) {
								i1 = 2;
								t0 = t1global;
							}
							for (let giveUpAt = i1 - 2;;) {
								if (t0 === void 0) {
									this._cachedIndex = 0;
									return this.copySampleValue_(0);
								}
								if (i1 === giveUpAt) break;
								t1 = t0;
								t0 = pp[--i1 - 1];
								if (t >= t0) break seek;
							}
							right = i1;
							i1 = 0;
							break linear_scan;
						}
						break validate_interval;
					}
					while (i1 < right) {
						const mid = i1 + right >>> 1;
						if (t < pp[mid]) right = mid;
						else i1 = mid + 1;
					}
					t1 = pp[i1];
					t0 = pp[i1 - 1];
					if (t0 === void 0) {
						this._cachedIndex = 0;
						return this.copySampleValue_(0);
					}
					if (t1 === void 0) {
						i1 = pp.length;
						this._cachedIndex = i1;
						return this.copySampleValue_(i1 - 1);
					}
				}
				this._cachedIndex = i1;
				this.intervalChanged_(i1, t0, t1);
			}
			return this.interpolate_(i1, t0, t, t1);
		}
		/**
		* Returns the interpolation settings.
		*
		* @return {Object} The interpolation settings.
		*/
		getSettings_() {
			return this.settings || this.DefaultSettings_;
		}
		/**
		* Copies a sample value to the result buffer.
		*
		* @param {number} index - An index into the sample value buffer.
		* @return {TypedArray} The result buffer.
		*/
		copySampleValue_(index) {
			const result = this.resultBuffer, values = this.sampleValues, stride = this.valueSize, offset = index * stride;
			for (let i = 0; i !== stride; ++i) result[i] = values[offset + i];
			return result;
		}
		/**
		* Copies a sample value to the result buffer.
		*
		* @abstract
		* @param {number} i1 - An index into the sample value buffer.
		* @param {number} t0 - The previous interpolation factor.
		* @param {number} t - The current interpolation factor.
		* @param {number} t1 - The next interpolation factor.
		* @return {TypedArray} The result buffer.
		*/
		interpolate_() {
			throw new Error("THREE.Interpolant: Call to abstract method.");
		}
		/**
		* Optional method that is executed when the interval has changed.
		*
		* @param {number} i1 - An index into the sample value buffer.
		* @param {number} t0 - The previous interpolation factor.
		* @param {number} t - The current interpolation factor.
		*/
		intervalChanged_() {}
	};
	/**
	* Fast and simple cubic spline interpolant.
	*
	* It was derived from a Hermitian construction setting the first derivative
	* at each sample position to the linear slope between neighboring positions
	* over their parameter interval.
	*
	* @augments Interpolant
	*/
	var CubicInterpolant = class extends Interpolant {
		/**
		* Constructs a new cubic interpolant.
		*
		* @param {TypedArray} parameterPositions - The parameter positions hold the interpolation factors.
		* @param {TypedArray} sampleValues - The sample values.
		* @param {number} sampleSize - The sample size
		* @param {TypedArray} [resultBuffer] - The result buffer.
		*/
		constructor(parameterPositions, sampleValues, sampleSize, resultBuffer) {
			super(parameterPositions, sampleValues, sampleSize, resultBuffer);
			this._weightPrev = -0;
			this._offsetPrev = -0;
			this._weightNext = -0;
			this._offsetNext = -0;
			this.DefaultSettings_ = {
				endingStart: ZeroCurvatureEnding,
				endingEnd: ZeroCurvatureEnding
			};
		}
		intervalChanged_(i1, t0, t1) {
			const pp = this.parameterPositions;
			let iPrev = i1 - 2, iNext = i1 + 1, tPrev = pp[iPrev], tNext = pp[iNext];
			if (tPrev === void 0) switch (this.getSettings_().endingStart) {
				case ZeroSlopeEnding:
					iPrev = i1;
					tPrev = 2 * t0 - t1;
					break;
				case WrapAroundEnding:
					iPrev = pp.length - 2;
					tPrev = t0 + pp[iPrev] - pp[iPrev + 1];
					break;
				default:
					iPrev = i1;
					tPrev = t1;
			}
			if (tNext === void 0) switch (this.getSettings_().endingEnd) {
				case ZeroSlopeEnding:
					iNext = i1;
					tNext = 2 * t1 - t0;
					break;
				case WrapAroundEnding:
					iNext = 1;
					tNext = t1 + pp[1] - pp[0];
					break;
				default:
					iNext = i1 - 1;
					tNext = t0;
			}
			const halfDt = (t1 - t0) * .5, stride = this.valueSize;
			this._weightPrev = halfDt / (t0 - tPrev);
			this._weightNext = halfDt / (tNext - t1);
			this._offsetPrev = iPrev * stride;
			this._offsetNext = iNext * stride;
		}
		interpolate_(i1, t0, t, t1) {
			const result = this.resultBuffer, values = this.sampleValues, stride = this.valueSize, o1 = i1 * stride, o0 = o1 - stride, oP = this._offsetPrev, oN = this._offsetNext, wP = this._weightPrev, wN = this._weightNext, p = (t - t0) / (t1 - t0), pp = p * p, ppp = pp * p;
			const sP = -wP * ppp + 2 * wP * pp - wP * p;
			const s0 = (1 + wP) * ppp + (-1.5 - 2 * wP) * pp + (-.5 + wP) * p + 1;
			const s1 = (-1 - wN) * ppp + (1.5 + wN) * pp + .5 * p;
			const sN = wN * ppp - wN * pp;
			for (let i = 0; i !== stride; ++i) result[i] = sP * values[oP + i] + s0 * values[o0 + i] + s1 * values[o1 + i] + sN * values[oN + i];
			return result;
		}
	};
	/**
	* A basic linear interpolant.
	*
	* @augments Interpolant
	*/
	var LinearInterpolant = class extends Interpolant {
		/**
		* Constructs a new linear interpolant.
		*
		* @param {TypedArray} parameterPositions - The parameter positions hold the interpolation factors.
		* @param {TypedArray} sampleValues - The sample values.
		* @param {number} sampleSize - The sample size
		* @param {TypedArray} [resultBuffer] - The result buffer.
		*/
		constructor(parameterPositions, sampleValues, sampleSize, resultBuffer) {
			super(parameterPositions, sampleValues, sampleSize, resultBuffer);
		}
		interpolate_(i1, t0, t, t1) {
			const result = this.resultBuffer, values = this.sampleValues, stride = this.valueSize, offset1 = i1 * stride, offset0 = offset1 - stride, weight1 = (t - t0) / (t1 - t0), weight0 = 1 - weight1;
			for (let i = 0; i !== stride; ++i) result[i] = values[offset0 + i] * weight0 + values[offset1 + i] * weight1;
			return result;
		}
	};
	/**
	* Interpolant that evaluates to the sample value at the position preceding
	* the parameter.
	*
	* @augments Interpolant
	*/
	var DiscreteInterpolant = class extends Interpolant {
		/**
		* Constructs a new discrete interpolant.
		*
		* @param {TypedArray} parameterPositions - The parameter positions hold the interpolation factors.
		* @param {TypedArray} sampleValues - The sample values.
		* @param {number} sampleSize - The sample size
		* @param {TypedArray} [resultBuffer] - The result buffer.
		*/
		constructor(parameterPositions, sampleValues, sampleSize, resultBuffer) {
			super(parameterPositions, sampleValues, sampleSize, resultBuffer);
		}
		interpolate_(i1) {
			return this.copySampleValue_(i1 - 1);
		}
	};
	/**
	* A Bezier interpolant using cubic Bezier curves with 2D control points.
	*
	* This interpolant supports the COLLADA/Maya style of Bezier animation where
	* each keyframe has explicit in/out tangent control points specified as
	* 2D coordinates (time, value).
	*
	* Tangent data is read from `inTangents` and `outTangents` on the interpolant
	* (populated by `KeyframeTrack.InterpolantFactoryMethodBezier`).
	*
	* For a track with N keyframes and stride S:
	* - Each tangent array has N * S * 2 values
	* - Layout: [k0_c0_time, k0_c0_value, k0_c1_time, k0_c1_value, ..., k0_cS_time, k0_cS_value,
	*            k1_c0_time, k1_c0_value, ...]
	*
	* @augments Interpolant
	*/
	var BezierInterpolant = class extends Interpolant {
		interpolate_(i1, t0, t, t1) {
			const result = this.resultBuffer;
			const values = this.sampleValues;
			const stride = this.valueSize;
			const offset1 = i1 * stride;
			const offset0 = offset1 - stride;
			const inTangents = this.inTangents;
			const outTangents = this.outTangents;
			if (!inTangents || !outTangents) {
				const weight1 = (t - t0) / (t1 - t0);
				const weight0 = 1 - weight1;
				for (let i = 0; i !== stride; ++i) result[i] = values[offset0 + i] * weight0 + values[offset1 + i] * weight1;
				return result;
			}
			const tangentStride = stride * 2;
			const i0 = i1 - 1;
			for (let i = 0; i !== stride; ++i) {
				const v0 = values[offset0 + i];
				const v1 = values[offset1 + i];
				const outTangentOffset = i0 * tangentStride + i * 2;
				const c0x = outTangents[outTangentOffset];
				const c0y = outTangents[outTangentOffset + 1];
				const inTangentOffset = i1 * tangentStride + i * 2;
				const c1x = inTangents[inTangentOffset];
				const c1y = inTangents[inTangentOffset + 1];
				const s = solveBezierParameter(t, t0, c0x, c1x, t1);
				result[i] = cubicBezier(s, v0, c0y, c1y, v1);
			}
			return result;
		}
	};
	function cubicBezier(s, p0, p1, p2, p3) {
		const k = 1 - s;
		return k * k * k * p0 + 3 * k * k * s * p1 + 3 * k * s * s * p2 + s * s * s * p3;
	}
	function cubicBezierSlope(s, p0, p1, p2, p3) {
		const k = 1 - s;
		return 3 * k * k * (p1 - p0) + 6 * k * s * (p2 - p1) + 3 * s * s * (p3 - p2);
	}
	function solveBezierParameter(x, x0, x1, x2, x3) {
		let s = (x - x0) / (x3 - x0);
		for (let i = 0; i < 8; i++) {
			const error = cubicBezier(s, x0, x1, x2, x3) - x;
			if (Math.abs(error) < 1e-10) break;
			const slope = cubicBezierSlope(s, x0, x1, x2, x3);
			if (Math.abs(slope) < 1e-10) break;
			s = Math.max(0, Math.min(1, s - error / slope));
		}
		return s;
	}
	/**
	* Represents a timed sequence of keyframes, which are composed of lists of
	* times and related values, and which are used to animate a specific property
	* of an object.
	*/
	var KeyframeTrack = class {
		/**
		* Constructs a new keyframe track.
		*
		* @param {string} name - The keyframe track's name.
		* @param {Array<number>} times - A list of keyframe times.
		* @param {Array<number|string|boolean>} values - A list of keyframe values.
		* @param {(InterpolateLinear|InterpolateDiscrete|InterpolateSmooth|InterpolateBezier)} [interpolation] - The interpolation type.
		*/
		constructor(name, times, values, interpolation) {
			if (name === void 0) throw new Error("THREE.KeyframeTrack: track name is undefined");
			if (times === void 0 || times.length === 0) throw new Error("THREE.KeyframeTrack: no keyframes in track named " + name);
			/**
			* The track's name can refer to morph targets or bones or
			* possibly other values within an animated object. See {@link PropertyBinding#parseTrackName}
			* for the forms of strings that can be parsed for property binding.
			*
			* @type {string}
			*/
			this.name = name;
			/**
			* The keyframe times.
			*
			* @type {Float32Array}
			*/
			this.times = convertArray(times, this.TimeBufferType);
			/**
			* The keyframe values.
			*
			* @type {Float32Array}
			*/
			this.values = convertArray(values, this.ValueBufferType);
			this.setInterpolation(interpolation || this.DefaultInterpolation);
		}
		/**
		* Converts the keyframe track to JSON.
		*
		* @static
		* @param {KeyframeTrack} track - The keyframe track to serialize.
		* @return {Object} The serialized keyframe track as JSON.
		*/
		static toJSON(track) {
			const trackType = track.constructor;
			let json;
			if (trackType.toJSON !== this.toJSON) json = trackType.toJSON(track);
			else {
				json = {
					"name": track.name,
					"times": convertArray(track.times, Array),
					"values": convertArray(track.values, Array)
				};
				const interpolation = track.getInterpolation();
				if (interpolation !== track.DefaultInterpolation) json.interpolation = interpolation;
				if (hasTangents(track.settings)) json.settings = {
					inTangents: convertArray(track.settings.inTangents, Array),
					outTangents: convertArray(track.settings.outTangents, Array)
				};
			}
			json.type = track.ValueTypeName;
			return json;
		}
		/**
		* Factory method for creating a new discrete interpolant.
		*
		* @static
		* @param {TypedArray} [result] - The result buffer.
		* @return {DiscreteInterpolant} The new interpolant.
		*/
		InterpolantFactoryMethodDiscrete(result) {
			return new DiscreteInterpolant(this.times, this.values, this.getValueSize(), result);
		}
		/**
		* Factory method for creating a new linear interpolant.
		*
		* @static
		* @param {TypedArray} [result] - The result buffer.
		* @return {LinearInterpolant} The new interpolant.
		*/
		InterpolantFactoryMethodLinear(result) {
			return new LinearInterpolant(this.times, this.values, this.getValueSize(), result);
		}
		/**
		* Factory method for creating a new smooth interpolant.
		*
		* @static
		* @param {TypedArray} [result] - The result buffer.
		* @return {CubicInterpolant} The new interpolant.
		*/
		InterpolantFactoryMethodSmooth(result) {
			return new CubicInterpolant(this.times, this.values, this.getValueSize(), result);
		}
		/**
		* Factory method for creating a new Bezier interpolant.
		*
		* The Bezier interpolant requires tangent data to be set via the `settings` property
		* on the track before creating the interpolant. The settings should contain:
		* - `inTangents`: Float32Array with [time, value] pairs per keyframe per component
		* - `outTangents`: Float32Array with [time, value] pairs per keyframe per component
		*
		* @static
		* @param {TypedArray} [result] - The result buffer.
		* @return {BezierInterpolant} The new interpolant.
		*/
		InterpolantFactoryMethodBezier(result) {
			const interpolant = new BezierInterpolant(this.times, this.values, this.getValueSize(), result);
			if (this.settings) {
				interpolant.inTangents = this.settings.inTangents;
				interpolant.outTangents = this.settings.outTangents;
			}
			return interpolant;
		}
		/**
		* Defines the interpolation factor method for this keyframe track.
		*
		* @param {(InterpolateLinear|InterpolateDiscrete|InterpolateSmooth|InterpolateBezier)} interpolation - The interpolation type.
		* @return {KeyframeTrack} A reference to this keyframe track.
		*/
		setInterpolation(interpolation) {
			let factoryMethod;
			switch (interpolation) {
				case InterpolateDiscrete:
					factoryMethod = this.InterpolantFactoryMethodDiscrete;
					break;
				case InterpolateLinear:
					factoryMethod = this.InterpolantFactoryMethodLinear;
					break;
				case InterpolateSmooth:
					factoryMethod = this.InterpolantFactoryMethodSmooth;
					break;
				case InterpolateBezier: factoryMethod = this.InterpolantFactoryMethodBezier;
			}
			if (factoryMethod === void 0) {
				const message = "unsupported interpolation for " + this.ValueTypeName + " keyframe track named " + this.name;
				if (this.createInterpolant === void 0) {
					if (interpolation !== this.DefaultInterpolation) this.setInterpolation(this.DefaultInterpolation);
					else throw new Error(message);
				}
				warn("KeyframeTrack:", message);
				return this;
			}
			this.createInterpolant = factoryMethod;
			return this;
		}
		/**
		* Returns the current interpolation type.
		*
		* @return {(InterpolateLinear|InterpolateDiscrete|InterpolateSmooth|InterpolateBezier)} The interpolation type.
		*/
		getInterpolation() {
			switch (this.createInterpolant) {
				case this.InterpolantFactoryMethodDiscrete: return InterpolateDiscrete;
				case this.InterpolantFactoryMethodLinear: return InterpolateLinear;
				case this.InterpolantFactoryMethodSmooth: return InterpolateSmooth;
				case this.InterpolantFactoryMethodBezier: return InterpolateBezier;
			}
		}
		/**
		* Returns the value size.
		*
		* @return {number} The value size.
		*/
		getValueSize() {
			return this.values.length / this.times.length;
		}
		/**
		* Moves all keyframes either forward or backward in time.
		*
		* @param {number} timeOffset - The offset to move the time values.
		* @return {KeyframeTrack} A reference to this keyframe track.
		*/
		shift(timeOffset) {
			if (timeOffset !== 0) {
				const times = this.times;
				for (let i = 0, n = times.length; i !== n; ++i) times[i] += timeOffset;
			}
			return this;
		}
		/**
		* Scale all keyframe times by a factor (useful for frame - seconds conversions).
		*
		* @param {number} timeScale - The time scale.
		* @return {KeyframeTrack} A reference to this keyframe track.
		*/
		scale(timeScale) {
			if (timeScale !== 1) {
				const times = this.times;
				for (let i = 0, n = times.length; i !== n; ++i) times[i] *= timeScale;
				if (hasTangents(this.settings)) {
					scaleTangentTimes(this.settings.inTangents, timeScale);
					scaleTangentTimes(this.settings.outTangents, timeScale);
				}
			}
			return this;
		}
		/**
		* Removes keyframes before and after animation without changing any values within the defined time range.
		*
		* Note: The method does not shift around keys to the start of the track time, because for interpolated
		* keys this will change their values
		*
		* @param {number} startTime - The start time.
		* @param {number} endTime - The end time.
		* @return {KeyframeTrack} A reference to this keyframe track.
		*/
		trim(startTime, endTime) {
			const times = this.times, nKeys = times.length;
			let from = 0, to = nKeys - 1;
			while (from !== nKeys && times[from] < startTime) ++from;
			while (to !== -1 && times[to] > endTime) --to;
			++to;
			if (from !== 0 || to !== nKeys) {
				if (from >= to) {
					to = Math.max(to, 1);
					from = to - 1;
				}
				const stride = this.getValueSize();
				this.times = times.slice(from, to);
				this.values = this.values.slice(from * stride, to * stride);
			}
			return this;
		}
		/**
		* Performs minimal validation on the keyframe track. Returns `true` if the values
		* are valid.
		*
		* @return {boolean} Whether the keyframes are valid or not.
		*/
		validate() {
			let valid = true;
			const valueSize = this.getValueSize();
			if (valueSize - Math.floor(valueSize) !== 0) {
				error("KeyframeTrack: Invalid value size in track.", this);
				valid = false;
			}
			const times = this.times, values = this.values, nKeys = times.length;
			if (nKeys === 0) {
				error("KeyframeTrack: Track is empty.", this);
				valid = false;
			}
			let prevTime = null;
			for (let i = 0; i !== nKeys; i++) {
				const currTime = times[i];
				if (typeof currTime === "number" && isNaN(currTime)) {
					error("KeyframeTrack: Time is not a valid number.", this, i, currTime);
					valid = false;
					break;
				}
				if (prevTime !== null && prevTime > currTime) {
					error("KeyframeTrack: Out of order keys.", this, i, currTime, prevTime);
					valid = false;
					break;
				}
				prevTime = currTime;
			}
			if (values !== void 0) {
				if (isTypedArray(values)) for (let i = 0, n = values.length; i !== n; ++i) {
					const value = values[i];
					if (isNaN(value)) {
						error("KeyframeTrack: Value is not a valid number.", this, i, value);
						valid = false;
						break;
					}
				}
			}
			return valid;
		}
		/**
		* Optimizes this keyframe track by removing equivalent sequential keys (which are
		* common in morph target sequences).
		*
		* @return {KeyframeTrack} A reference to this keyframe track.
		*/
		optimize() {
			const times = this.times.slice(), values = this.values.slice(), stride = this.getValueSize(), smoothInterpolation = this.getInterpolation() === InterpolateSmooth, lastIndex = times.length - 1;
			let writeIndex = 1;
			for (let i = 1; i < lastIndex; ++i) {
				let keep = false;
				const time = times[i];
				if (time !== times[i + 1] && (i !== 1 || time !== times[0])) {
					if (!smoothInterpolation) {
						const offset = i * stride, offsetP = offset - stride, offsetN = offset + stride;
						for (let j = 0; j !== stride; ++j) {
							const value = values[offset + j];
							if (value !== values[offsetP + j] || value !== values[offsetN + j]) {
								keep = true;
								break;
							}
						}
					} else keep = true;
				}
				if (keep) {
					if (i !== writeIndex) {
						times[writeIndex] = times[i];
						const readOffset = i * stride, writeOffset = writeIndex * stride;
						for (let j = 0; j !== stride; ++j) values[writeOffset + j] = values[readOffset + j];
					}
					++writeIndex;
				}
			}
			if (lastIndex > 0) {
				times[writeIndex] = times[lastIndex];
				for (let readOffset = lastIndex * stride, writeOffset = writeIndex * stride, j = 0; j !== stride; ++j) values[writeOffset + j] = values[readOffset + j];
				++writeIndex;
			}
			if (writeIndex !== times.length) {
				this.times = times.slice(0, writeIndex);
				this.values = values.slice(0, writeIndex * stride);
			} else {
				this.times = times;
				this.values = values;
			}
			return this;
		}
		/**
		* Returns a new keyframe track with copied values from this instance.
		*
		* @return {KeyframeTrack} A clone of this instance.
		*/
		clone() {
			const times = this.times.slice();
			const values = this.values.slice();
			const TypedKeyframeTrack = this.constructor;
			const track = new TypedKeyframeTrack(this.name, times, values);
			track.createInterpolant = this.createInterpolant;
			if (hasTangents(this.settings)) track.settings = {
				inTangents: this.settings.inTangents.slice(),
				outTangents: this.settings.outTangents.slice()
			};
			return track;
		}
	};
	function scaleTangentTimes(tangents, timeScale) {
		for (let i = 0, n = tangents.length; i !== n; i += 2) tangents[i] *= timeScale;
	}
	/**
	* The value type name.
	*
	* @type {string}
	* @default ''
	*/
	KeyframeTrack.prototype.ValueTypeName = "";
	/**
	* The time buffer type of this keyframe track.
	*
	* @type {TypedArray|Array}
	* @default Float32Array.constructor
	*/
	KeyframeTrack.prototype.TimeBufferType = Float32Array;
	/**
	* The value buffer type of this keyframe track.
	*
	* @type {TypedArray|Array}
	* @default Float32Array.constructor
	*/
	KeyframeTrack.prototype.ValueBufferType = Float32Array;
	/**
	* The default interpolation type of this keyframe track.
	*
	* @type {(InterpolateLinear|InterpolateDiscrete|InterpolateSmooth|InterpolateBezier)}
	* @default InterpolateLinear
	*/
	KeyframeTrack.prototype.DefaultInterpolation = InterpolateLinear;
	/**
	* A track for boolean keyframe values.
	*
	* @augments KeyframeTrack
	*/
	var BooleanKeyframeTrack = class extends KeyframeTrack {
		/**
		* Constructs a new boolean keyframe track.
		*
		* This keyframe track type has no `interpolation` parameter because the
		* interpolation is always discrete.
		*
		* @param {string} name - The keyframe track's name.
		* @param {Array<number>} times - A list of keyframe times.
		* @param {Array<boolean>} values - A list of keyframe values.
		*/
		constructor(name, times, values) {
			super(name, times, values);
		}
	};
	/**
	* The value type name.
	*
	* @type {string}
	* @default 'bool'
	*/
	BooleanKeyframeTrack.prototype.ValueTypeName = "bool";
	/**
	* The value buffer type of this keyframe track.
	*
	* @type {TypedArray|Array}
	* @default Array.constructor
	*/
	BooleanKeyframeTrack.prototype.ValueBufferType = Array;
	/**
	* The default interpolation type of this keyframe track.
	*
	* @type {(InterpolateLinear|InterpolateDiscrete|InterpolateSmooth)}
	* @default InterpolateDiscrete
	*/
	BooleanKeyframeTrack.prototype.DefaultInterpolation = InterpolateDiscrete;
	BooleanKeyframeTrack.prototype.InterpolantFactoryMethodLinear = void 0;
	BooleanKeyframeTrack.prototype.InterpolantFactoryMethodSmooth = void 0;
	/**
	* A track for color keyframe values.
	*
	* @augments KeyframeTrack
	*/
	var ColorKeyframeTrack = class extends KeyframeTrack {
		/**
		* Constructs a new color keyframe track.
		*
		* @param {string} name - The keyframe track's name.
		* @param {Array<number>} times - A list of keyframe times.
		* @param {Array<number>} values - A list of keyframe values.
		* @param {(InterpolateLinear|InterpolateDiscrete|InterpolateSmooth)} [interpolation] - The interpolation type.
		*/
		constructor(name, times, values, interpolation) {
			super(name, times, values, interpolation);
		}
	};
	/**
	* The value type name.
	*
	* @type {string}
	* @default 'color'
	*/
	ColorKeyframeTrack.prototype.ValueTypeName = "color";
	/**
	* A track for numeric keyframe values.
	*
	* @augments KeyframeTrack
	*/
	var NumberKeyframeTrack = class extends KeyframeTrack {
		/**
		* Constructs a new number keyframe track.
		*
		* @param {string} name - The keyframe track's name.
		* @param {Array<number>} times - A list of keyframe times.
		* @param {Array<number>} values - A list of keyframe values.
		* @param {(InterpolateLinear|InterpolateDiscrete|InterpolateSmooth)} [interpolation] - The interpolation type.
		*/
		constructor(name, times, values, interpolation) {
			super(name, times, values, interpolation);
		}
	};
	/**
	* The value type name.
	*
	* @type {string}
	* @default 'number'
	*/
	NumberKeyframeTrack.prototype.ValueTypeName = "number";
	/**
	* Spherical linear unit quaternion interpolant.
	*
	* @augments Interpolant
	*/
	var QuaternionLinearInterpolant = class extends Interpolant {
		/**
		* Constructs a new SLERP interpolant.
		*
		* @param {TypedArray} parameterPositions - The parameter positions hold the interpolation factors.
		* @param {TypedArray} sampleValues - The sample values.
		* @param {number} sampleSize - The sample size
		* @param {TypedArray} [resultBuffer] - The result buffer.
		*/
		constructor(parameterPositions, sampleValues, sampleSize, resultBuffer) {
			super(parameterPositions, sampleValues, sampleSize, resultBuffer);
		}
		interpolate_(i1, t0, t, t1) {
			const result = this.resultBuffer, values = this.sampleValues, stride = this.valueSize, alpha = (t - t0) / (t1 - t0);
			let offset = i1 * stride;
			for (let end = offset + stride; offset !== end; offset += 4) Quaternion.slerpFlat(result, 0, values, offset - stride, values, offset, alpha);
			return result;
		}
	};
	/**
	* A track for Quaternion keyframe values.
	*
	* @augments KeyframeTrack
	*/
	var QuaternionKeyframeTrack = class extends KeyframeTrack {
		/**
		* Constructs a new Quaternion keyframe track.
		*
		* @param {string} name - The keyframe track's name.
		* @param {Array<number>} times - A list of keyframe times.
		* @param {Array<number>} values - A list of keyframe values.
		* @param {(InterpolateLinear|InterpolateDiscrete|InterpolateSmooth)} [interpolation] - The interpolation type.
		*/
		constructor(name, times, values, interpolation) {
			super(name, times, values, interpolation);
		}
		/**
		* Overwritten so the method returns Quaternion based interpolant.
		*
		* @static
		* @param {TypedArray} [result] - The result buffer.
		* @return {QuaternionLinearInterpolant} The new interpolant.
		*/
		InterpolantFactoryMethodLinear(result) {
			return new QuaternionLinearInterpolant(this.times, this.values, this.getValueSize(), result);
		}
	};
	/**
	* The value type name.
	*
	* @type {string}
	* @default 'quaternion'
	*/
	QuaternionKeyframeTrack.prototype.ValueTypeName = "quaternion";
	QuaternionKeyframeTrack.prototype.InterpolantFactoryMethodSmooth = void 0;
	/**
	* A track for string keyframe values.
	*
	* @augments KeyframeTrack
	*/
	var StringKeyframeTrack = class extends KeyframeTrack {
		/**
		* Constructs a new string keyframe track.
		*
		* This keyframe track type has no `interpolation` parameter because the
		* interpolation is always discrete.
		*
		* @param {string} name - The keyframe track's name.
		* @param {Array<number>} times - A list of keyframe times.
		* @param {Array<string>} values - A list of keyframe values.
		*/
		constructor(name, times, values) {
			super(name, times, values);
		}
	};
	/**
	* The value type name.
	*
	* @type {string}
	* @default 'string'
	*/
	StringKeyframeTrack.prototype.ValueTypeName = "string";
	/**
	* The value buffer type of this keyframe track.
	*
	* @type {TypedArray|Array}
	* @default Array.constructor
	*/
	StringKeyframeTrack.prototype.ValueBufferType = Array;
	/**
	* The default interpolation type of this keyframe track.
	*
	* @type {(InterpolateLinear|InterpolateDiscrete|InterpolateSmooth)}
	* @default InterpolateDiscrete
	*/
	StringKeyframeTrack.prototype.DefaultInterpolation = InterpolateDiscrete;
	StringKeyframeTrack.prototype.InterpolantFactoryMethodLinear = void 0;
	StringKeyframeTrack.prototype.InterpolantFactoryMethodSmooth = void 0;
	/**
	* A track for vector keyframe values.
	*
	* @augments KeyframeTrack
	*/
	var VectorKeyframeTrack = class extends KeyframeTrack {
		/**
		* Constructs a new vector keyframe track.
		*
		* @param {string} name - The keyframe track's name.
		* @param {Array<number>} times - A list of keyframe times.
		* @param {Array<number>} values - A list of keyframe values.
		* @param {(InterpolateLinear|InterpolateDiscrete|InterpolateSmooth)} [interpolation] - The interpolation type.
		*/
		constructor(name, times, values, interpolation) {
			super(name, times, values, interpolation);
		}
	};
	/**
	* The value type name.
	*
	* @type {string}
	* @default 'vector'
	*/
	VectorKeyframeTrack.prototype.ValueTypeName = "vector";
	/**
	* Handles and keeps track of loaded and pending data. A default global
	* instance of this class is created and used by loaders if not supplied
	* manually.
	*
	* In general that should be sufficient, however there are times when it can
	* be useful to have separate loaders - for example if you want to show
	* separate loading bars for objects and textures.
	*
	* ```js
	* const manager = new THREE.LoadingManager();
	* manager.onLoad = () => console.log( 'Loading complete!' );
	*
	* const loader1 = new OBJLoader( manager );
	* const loader2 = new ColladaLoader( manager );
	* ```
	*/
	var LoadingManager = class {
		/**
		* Constructs a new loading manager.
		*
		* @param {Function} [onLoad] - Executes when all items have been loaded.
		* @param {Function} [onProgress] - Executes when single items have been loaded.
		* @param {Function} [onError] - Executes when an error occurs.
		*/
		constructor(onLoad, onProgress, onError) {
			const scope = this;
			let isLoading = false;
			let itemsLoaded = 0;
			let itemsTotal = 0;
			let urlModifier = void 0;
			const handlers = [];
			/**
			* Executes when an item starts loading.
			*
			* @type {Function|undefined}
			* @default undefined
			*/
			this.onStart = void 0;
			/**
			* Executes when all items have been loaded.
			*
			* @type {Function|undefined}
			* @default undefined
			*/
			this.onLoad = onLoad;
			/**
			* Executes when single items have been loaded.
			*
			* @type {Function|undefined}
			* @default undefined
			*/
			this.onProgress = onProgress;
			/**
			* Executes when an error occurs.
			*
			* @type {Function|undefined}
			* @default undefined
			*/
			this.onError = onError;
			/**
			* Used for aborting ongoing requests in loaders using this manager.
			*
			* @private
			* @type {AbortController | null}
			*/
			this._abortController = null;
			/**
			* This should be called by any loader using the manager when the loader
			* starts loading an item.
			*
			* @param {string} url - The URL to load.
			*/
			this.itemStart = function(url) {
				itemsTotal++;
				if (isLoading === false) {
					if (scope.onStart !== void 0) scope.onStart(url, itemsLoaded, itemsTotal);
				}
				isLoading = true;
			};
			/**
			* This should be called by any loader using the manager when the loader
			* ended loading an item.
			*
			* @param {string} url - The URL of the loaded item.
			*/
			this.itemEnd = function(url) {
				itemsLoaded++;
				if (scope.onProgress !== void 0) scope.onProgress(url, itemsLoaded, itemsTotal);
				if (itemsLoaded === itemsTotal) {
					isLoading = false;
					if (scope.onLoad !== void 0) scope.onLoad();
				}
			};
			/**
			* This should be called by any loader using the manager when the loader
			* encounters an error when loading an item.
			*
			* @param {string} url - The URL of the item that produces an error.
			*/
			this.itemError = function(url) {
				if (scope.onError !== void 0) scope.onError(url);
			};
			/**
			* Given a URL, uses the URL modifier callback (if any) and returns a
			* resolved URL. If no URL modifier is set, returns the original URL.
			*
			* @param {string} url - The URL to load.
			* @return {string} The resolved URL.
			*/
			this.resolveURL = function(url) {
				url = url.normalize("NFC");
				if (urlModifier) return urlModifier(url);
				return url;
			};
			/**
			* If provided, the callback will be passed each resource URL before a
			* request is sent. The callback may return the original URL, or a new URL to
			* override loading behavior. This behavior can be used to load assets from
			* .ZIP files, drag-and-drop APIs, and Data URIs.
			*
			* ```js
			* const blobs = {'fish.gltf': blob1, 'diffuse.png': blob2, 'normal.png': blob3};
			*
			* const manager = new THREE.LoadingManager();
			*
			* // Initialize loading manager with URL callback.
			* const objectURLs = [];
			* manager.setURLModifier( ( url ) => {
			*
			* 	url = URL.createObjectURL( blobs[ url ] );
			* 	objectURLs.push( url );
			* 	return url;
			*
			* } );
			*
			* // Load as usual, then revoke the blob URLs.
			* const loader = new GLTFLoader( manager );
			* loader.load( 'fish.gltf', (gltf) => {
			*
			* 	scene.add( gltf.scene );
			* 	objectURLs.forEach( ( url ) => URL.revokeObjectURL( url ) );
			*
			* } );
			* ```
			*
			* @param {function(string):string} transform - URL modifier callback. Called with an URL and must return a resolved URL.
			* @return {LoadingManager} A reference to this loading manager.
			*/
			this.setURLModifier = function(transform) {
				urlModifier = transform;
				return this;
			};
			/**
			* Registers a loader with the given regular expression. Can be used to
			* define what loader should be used in order to load specific files. A
			* typical use case is to overwrite the default loader for textures.
			*
			* ```js
			* // add handler for TGA textures
			* manager.addHandler( /\.tga$/i, new TGALoader() );
			* ```
			*
			* @param {string} regex - A regular expression.
			* @param {Loader} loader - A loader that should handle matched cases.
			* @return {LoadingManager} A reference to this loading manager.
			*/
			this.addHandler = function(regex, loader) {
				handlers.push(regex, loader);
				return this;
			};
			/**
			* Removes the loader for the given regular expression.
			*
			* @param {string} regex - A regular expression.
			* @return {LoadingManager} A reference to this loading manager.
			*/
			this.removeHandler = function(regex) {
				const index = handlers.indexOf(regex);
				if (index !== -1) handlers.splice(index, 2);
				return this;
			};
			/**
			* Can be used to retrieve the registered loader for the given file path.
			*
			* @param {string} file - The file path.
			* @return {?Loader} The registered loader. Returns `null` if no loader was found.
			*/
			this.getHandler = function(file) {
				for (let i = 0, l = handlers.length; i < l; i += 2) {
					const regex = handlers[i];
					const loader = handlers[i + 1];
					if (regex.global) regex.lastIndex = 0;
					if (regex.test(file)) return loader;
				}
				return null;
			};
			/**
			* Can be used to abort ongoing loading requests in loaders using this manager.
			* The abort only works if the loaders implement {@link Loader#abort} and `AbortSignal.any()`
			* is supported in the browser.
			*
			* @return {LoadingManager} A reference to this loading manager.
			*/
			this.abort = function() {
				this.abortController.abort();
				this._abortController = null;
				return this;
			};
		}
		/**
		* Used for aborting ongoing requests in loaders using this manager.
		*
		* @type {AbortController}
		*/
		get abortController() {
			if (!this._abortController) this._abortController = new AbortController();
			return this._abortController;
		}
	};
	/**
	* The global default loading manager.
	*
	* @constant
	* @type {LoadingManager}
	*/
	const DefaultLoadingManager = /*@__PURE__*/ new LoadingManager();
	/**
	* Abstract base class for loaders.
	*
	* @abstract
	*/
	var Loader = class {
		/**
		* Constructs a new loader.
		*
		* @param {LoadingManager} [manager] - The loading manager.
		*/
		constructor(manager) {
			/**
			* The loading manager.
			*
			* @type {LoadingManager}
			* @default DefaultLoadingManager
			*/
			this.manager = manager !== void 0 ? manager : DefaultLoadingManager;
			/**
			* The crossOrigin string to implement CORS for loading the url from a
			* different domain that allows CORS.
			*
			* @type {string}
			* @default 'anonymous'
			*/
			this.crossOrigin = "anonymous";
			/**
			* Whether the XMLHttpRequest uses credentials.
			*
			* @type {boolean}
			* @default false
			*/
			this.withCredentials = false;
			/**
			* The base path from which the asset will be loaded.
			*
			* @type {string}
			*/
			this.path = "";
			/**
			* The base path from which additional resources like textures will be loaded.
			*
			* @type {string}
			*/
			this.resourcePath = "";
			/**
			* The [request header](https://developer.mozilla.org/en-US/docs/Glossary/Request_header)
			* used in HTTP request.
			*
			* @type {Object<string, any>}
			*/
			this.requestHeader = {};
			if (typeof __THREE_DEVTOOLS__ !== "undefined") __THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe", { detail: this }));
		}
		/**
		* This method needs to be implemented by all concrete loaders. It holds the
		* logic for loading assets from the backend.
		*
		* @abstract
		* @param {string} url - The path/URL of the file to be loaded.
		* @param {Function} onLoad - Executed when the loading process has been finished.
		* @param {onProgressCallback} [onProgress] - Executed while the loading is in progress.
		* @param {onErrorCallback} [onError] - Executed when errors occur.
		*/
		load() {}
		/**
		* A async version of {@link Loader#load}.
		*
		* @param {string} url - The path/URL of the file to be loaded.
		* @param {onProgressCallback} [onProgress] - Executed while the loading is in progress.
		* @return {Promise} A Promise that resolves when the asset has been loaded.
		*/
		loadAsync(url, onProgress) {
			const scope = this;
			return new Promise(function(resolve, reject) {
				scope.load(url, resolve, onProgress, reject);
			});
		}
		/**
		* This method needs to be implemented by all concrete loaders. It holds the
		* logic for parsing the asset into three.js entities.
		*
		* @abstract
		* @param {any} data - The data to parse.
		*/
		parse() {}
		/**
		* Sets the `crossOrigin` String to implement CORS for loading the URL
		* from a different domain that allows CORS.
		*
		* @param {string} crossOrigin - The `crossOrigin` value.
		* @return {Loader} A reference to this instance.
		*/
		setCrossOrigin(crossOrigin) {
			this.crossOrigin = crossOrigin;
			return this;
		}
		/**
		* Whether the XMLHttpRequest uses credentials such as cookies, authorization
		* headers or TLS client certificates, see [XMLHttpRequest.withCredentials](https://developer.mozilla.org/en-US/docs/Web/API/XMLHttpRequest/withCredentials).
		*
		* Note: This setting has no effect if you are loading files locally or from the same domain.
		*
		* @param {boolean} value - The `withCredentials` value.
		* @return {Loader} A reference to this instance.
		*/
		setWithCredentials(value) {
			this.withCredentials = value;
			return this;
		}
		/**
		* Sets the base path for the asset.
		*
		* @param {string} path - The base path.
		* @return {Loader} A reference to this instance.
		*/
		setPath(path) {
			this.path = path;
			return this;
		}
		/**
		* Sets the base path for dependent resources like textures.
		*
		* @param {string} resourcePath - The resource path.
		* @return {Loader} A reference to this instance.
		*/
		setResourcePath(resourcePath) {
			this.resourcePath = resourcePath;
			return this;
		}
		/**
		* Sets the given request header.
		*
		* @param {Object} requestHeader - A [request header](https://developer.mozilla.org/en-US/docs/Glossary/Request_header)
		* for configuring the HTTP request.
		* @return {Loader} A reference to this instance.
		*/
		setRequestHeader(requestHeader) {
			this.requestHeader = requestHeader;
			return this;
		}
		/**
		* This method can be implemented in loaders for aborting ongoing requests.
		*
		* @abstract
		* @return {Loader} A reference to this instance.
		*/
		abort() {
			return this;
		}
	};
	/**
	* Callback for onProgress in loaders.
	*
	* @callback onProgressCallback
	* @param {ProgressEvent} event - An instance of `ProgressEvent` that represents the current loading status.
	*/
	/**
	* Callback for onError in loaders.
	*
	* @callback onErrorCallback
	* @param {Error} error - The error which occurred during the loading process.
	*/
	/**
	* The default material name that is used by loaders
	* when creating materials for loaded 3D objects.
	*
	* Note: Not all loaders might honor this setting.
	*
	* @static
	* @type {string}
	* @default '__DEFAULT'
	*/
	Loader.DEFAULT_MATERIAL_NAME = "__DEFAULT";
	const _RESERVED_CHARS_RE = "\\[\\]\\.:\\/";
	const _reservedRe = /* @__PURE__ */ new RegExp("[\\[\\]\\.:\\/]", "g");
	const _wordChar = "[^\\[\\]\\.:\\/]";
	const _wordCharOrDot = "[^" + _RESERVED_CHARS_RE.replace("\\.", "") + "]";
	const _directoryRe = /*@__PURE__*/ /((?:WC+[\/:])*)/.source.replace("WC", _wordChar);
	const _nodeRe = /*@__PURE__*/ /(WCOD+)?/.source.replace("WCOD", _wordCharOrDot);
	const _objectRe = /*@__PURE__*/ /(?:\.(WC+)(?:\[(.+)\])?)?/.source.replace("WC", _wordChar);
	const _propertyRe = /*@__PURE__*/ /\.(WC+)(?:\[(.+)\])?/.source.replace("WC", _wordChar);
	const _trackRe = new RegExp("^" + _directoryRe + _nodeRe + _objectRe + _propertyRe + "$");
	const _supportedObjectNames = [
		"material",
		"materials",
		"bones",
		"map"
	];
	var Composite = class {
		constructor(targetGroup, path, optionalParsedPath) {
			const parsedPath = optionalParsedPath || PropertyBinding.parseTrackName(path);
			this._targetGroup = targetGroup;
			this._bindings = targetGroup.subscribe_(path, parsedPath);
		}
		getValue(array, offset) {
			this.bind();
			const firstValidIndex = this._targetGroup.nCachedObjects_, binding = this._bindings[firstValidIndex];
			if (binding !== void 0) binding.getValue(array, offset);
		}
		setValue(array, offset) {
			const bindings = this._bindings;
			for (let i = this._targetGroup.nCachedObjects_, n = bindings.length; i !== n; ++i) bindings[i].setValue(array, offset);
		}
		bind() {
			const bindings = this._bindings;
			for (let i = this._targetGroup.nCachedObjects_, n = bindings.length; i !== n; ++i) bindings[i].bind();
		}
		unbind() {
			const bindings = this._bindings;
			for (let i = this._targetGroup.nCachedObjects_, n = bindings.length; i !== n; ++i) bindings[i].unbind();
		}
	};
	/**
	* This holds a reference to a real property in the scene graph; used internally.
	*/
	var PropertyBinding = class PropertyBinding {
		/**
		* Constructs a new property binding.
		*
		* @param {Object} rootNode - The root node.
		* @param {string} path - The path.
		* @param {?Object} [parsedPath] - The parsed path.
		*/
		constructor(rootNode, path, parsedPath) {
			/**
			* The object path to the animated property.
			*
			* @type {string}
			*/
			this.path = path;
			/**
			* An object holding information about the path.
			*
			* @type {Object}
			*/
			this.parsedPath = parsedPath || PropertyBinding.parseTrackName(path);
			/**
			* The object owns the animated property.
			*
			* @type {?Object}
			*/
			this.node = PropertyBinding.findNode(rootNode, this.parsedPath.nodeName);
			/**
			* The root node.
			*
			* @type {Object3D|Skeleton}
			*/
			this.rootNode = rootNode;
			this.getValue = this._getValue_unbound;
			this.setValue = this._setValue_unbound;
		}
		/**
		* Factory method for creating a property binding from the given parameters.
		*
		* @static
		* @param {Object} root - The root node.
		* @param {string} path - The path.
		* @param {?Object} [parsedPath] - The parsed path.
		* @return {PropertyBinding|Composite} The created property binding or composite.
		*/
		static create(root, path, parsedPath) {
			if (!(root && root.isAnimationObjectGroup)) return new PropertyBinding(root, path, parsedPath);
			else return new PropertyBinding.Composite(root, path, parsedPath);
		}
		/**
		* Replaces spaces with underscores and removes unsupported characters from
		* node names, to ensure compatibility with parseTrackName().
		*
		* @param {string} name - Node name to be sanitized.
		* @return {string} The sanitized node name.
		*/
		static sanitizeNodeName(name) {
			return name.replace(/\s/g, "_").replace(_reservedRe, "");
		}
		/**
		* Parses the given track name (an object path to an animated property) and
		* returns an object with information about the path. Matches strings in the following forms:
		*
		* - nodeName.property
		* - nodeName.property[accessor]
		* - nodeName.material.property[accessor]
		* - uuid.property[accessor]
		* - uuid.objectName[objectIndex].propertyName[propertyIndex]
		* - parentName/nodeName.property
		* - parentName/parentName/nodeName.property[index]
		* - .bone[Armature.DEF_cog].position
		* - scene:helium_balloon_model:helium_balloon_model.position
		*
		* @static
		* @param {string} trackName - The track name to parse.
		* @return {Object} The parsed track name as an object.
		*/
		static parseTrackName(trackName) {
			const matches = _trackRe.exec(trackName);
			if (matches === null) throw new Error("THREE.PropertyBinding: Cannot parse trackName: " + trackName);
			const results = {
				nodeName: matches[2],
				objectName: matches[3],
				objectIndex: matches[4],
				propertyName: matches[5],
				propertyIndex: matches[6]
			};
			const lastDot = results.nodeName && results.nodeName.lastIndexOf(".");
			if (lastDot !== void 0 && lastDot !== -1) {
				const objectName = results.nodeName.substring(lastDot + 1);
				if (_supportedObjectNames.indexOf(objectName) !== -1) {
					results.nodeName = results.nodeName.substring(0, lastDot);
					results.objectName = objectName;
				}
			}
			if (results.propertyName === null || results.propertyName.length === 0) throw new Error("THREE.PropertyBinding: can not parse propertyName from trackName: " + trackName);
			return results;
		}
		/**
		* Searches for a node in the hierarchy of the given root object by the given
		* node name.
		*
		* @static
		* @param {Object} root - The root object.
		* @param {string|number} nodeName - The name of the node.
		* @return {?Object} The found node. Returns `null` if no object was found.
		*/
		static findNode(root, nodeName) {
			if (nodeName === void 0 || nodeName === "" || nodeName === "." || nodeName === -1 || nodeName === root.name || nodeName === root.uuid) return root;
			if (root.skeleton) {
				const bone = root.skeleton.getBoneByName(nodeName);
				if (bone !== void 0) return bone;
			}
			if (root.children) {
				const searchNodeSubtree = function(children) {
					for (let i = 0; i < children.length; i++) {
						const childNode = children[i];
						if (childNode.name === nodeName || childNode.uuid === nodeName) return childNode;
						const result = searchNodeSubtree(childNode.children);
						if (result) return result;
					}
					return null;
				};
				const subTreeNode = searchNodeSubtree(root.children);
				if (subTreeNode) return subTreeNode;
			}
			return null;
		}
		_getValue_unavailable() {}
		_setValue_unavailable() {}
		_getValue_direct(buffer, offset) {
			buffer[offset] = this.targetObject[this.propertyName];
		}
		_getValue_array(buffer, offset) {
			const source = this.resolvedProperty;
			for (let i = 0, n = source.length; i !== n; ++i) buffer[offset++] = source[i];
		}
		_getValue_arrayElement(buffer, offset) {
			buffer[offset] = this.resolvedProperty[this.propertyIndex];
		}
		_getValue_toArray(buffer, offset) {
			this.resolvedProperty.toArray(buffer, offset);
		}
		_setValue_direct(buffer, offset) {
			this.targetObject[this.propertyName] = buffer[offset];
		}
		_setValue_direct_setNeedsUpdate(buffer, offset) {
			this.targetObject[this.propertyName] = buffer[offset];
			this.targetObject.needsUpdate = true;
		}
		_setValue_direct_setMatrixWorldNeedsUpdate(buffer, offset) {
			this.targetObject[this.propertyName] = buffer[offset];
			this.targetObject.matrixWorldNeedsUpdate = true;
		}
		_setValue_array(buffer, offset) {
			const dest = this.resolvedProperty;
			for (let i = 0, n = dest.length; i !== n; ++i) dest[i] = buffer[offset++];
		}
		_setValue_array_setNeedsUpdate(buffer, offset) {
			const dest = this.resolvedProperty;
			for (let i = 0, n = dest.length; i !== n; ++i) dest[i] = buffer[offset++];
			this.targetObject.needsUpdate = true;
		}
		_setValue_array_setMatrixWorldNeedsUpdate(buffer, offset) {
			const dest = this.resolvedProperty;
			for (let i = 0, n = dest.length; i !== n; ++i) dest[i] = buffer[offset++];
			this.targetObject.matrixWorldNeedsUpdate = true;
		}
		_setValue_arrayElement(buffer, offset) {
			this.resolvedProperty[this.propertyIndex] = buffer[offset];
		}
		_setValue_arrayElement_setNeedsUpdate(buffer, offset) {
			this.resolvedProperty[this.propertyIndex] = buffer[offset];
			this.targetObject.needsUpdate = true;
		}
		_setValue_arrayElement_setMatrixWorldNeedsUpdate(buffer, offset) {
			this.resolvedProperty[this.propertyIndex] = buffer[offset];
			this.targetObject.matrixWorldNeedsUpdate = true;
		}
		_setValue_fromArray(buffer, offset) {
			this.resolvedProperty.fromArray(buffer, offset);
		}
		_setValue_fromArray_setNeedsUpdate(buffer, offset) {
			this.resolvedProperty.fromArray(buffer, offset);
			this.targetObject.needsUpdate = true;
		}
		_setValue_fromArray_setMatrixWorldNeedsUpdate(buffer, offset) {
			this.resolvedProperty.fromArray(buffer, offset);
			this.targetObject.matrixWorldNeedsUpdate = true;
		}
		_getValue_unbound(targetArray, offset) {
			this.bind();
			this.getValue(targetArray, offset);
		}
		_setValue_unbound(sourceArray, offset) {
			this.bind();
			this.setValue(sourceArray, offset);
		}
		/**
		* Creates a getter / setter pair for the property tracked by this binding.
		*/
		bind() {
			let targetObject = this.node;
			const parsedPath = this.parsedPath;
			const objectName = parsedPath.objectName;
			const propertyName = parsedPath.propertyName;
			let propertyIndex = parsedPath.propertyIndex;
			if (!targetObject) {
				targetObject = PropertyBinding.findNode(this.rootNode, parsedPath.nodeName);
				this.node = targetObject;
			}
			this.getValue = this._getValue_unavailable;
			this.setValue = this._setValue_unavailable;
			if (!targetObject) {
				warn("PropertyBinding: No target node found for track: " + this.path + ".");
				return;
			}
			if (objectName) {
				let objectIndex = parsedPath.objectIndex;
				switch (objectName) {
					case "materials":
						if (!targetObject.material) {
							error("PropertyBinding: Can not bind to material as node does not have a material.", this);
							return;
						}
						if (!targetObject.material.materials) {
							error("PropertyBinding: Can not bind to material.materials as node.material does not have a materials array.", this);
							return;
						}
						targetObject = targetObject.material.materials;
						break;
					case "bones":
						if (!targetObject.skeleton) {
							error("PropertyBinding: Can not bind to bones as node does not have a skeleton.", this);
							return;
						}
						targetObject = targetObject.skeleton.bones;
						for (let i = 0; i < targetObject.length; i++) if (targetObject[i].name === objectIndex) {
							objectIndex = i;
							break;
						}
						break;
					case "map":
						if ("map" in targetObject) {
							targetObject = targetObject.map;
							break;
						}
						if (!targetObject.material) {
							error("PropertyBinding: Can not bind to material as node does not have a material.", this);
							return;
						}
						if (!targetObject.material.map) {
							error("PropertyBinding: Can not bind to material.map as node.material does not have a map.", this);
							return;
						}
						targetObject = targetObject.material.map;
						break;
					default:
						if (targetObject[objectName] === void 0) {
							error("PropertyBinding: Can not bind to objectName of node undefined.", this);
							return;
						}
						targetObject = targetObject[objectName];
				}
				if (objectIndex !== void 0) {
					if (targetObject[objectIndex] === void 0) {
						error("PropertyBinding: Trying to bind to objectIndex of objectName, but is undefined.", this, targetObject);
						return;
					}
					targetObject = targetObject[objectIndex];
				}
			}
			const nodeProperty = targetObject[propertyName];
			if (nodeProperty === void 0) {
				const nodeName = parsedPath.nodeName;
				error("PropertyBinding: Trying to update property for track: " + nodeName + "." + propertyName + " but it wasn't found.", targetObject);
				return;
			}
			let versioning = this.Versioning.None;
			this.targetObject = targetObject;
			if (targetObject.isMaterial === true) versioning = this.Versioning.NeedsUpdate;
			else if (targetObject.isObject3D === true) versioning = this.Versioning.MatrixWorldNeedsUpdate;
			let bindingType = this.BindingType.Direct;
			if (propertyIndex !== void 0) {
				if (propertyName === "morphTargetInfluences") {
					if (!targetObject.geometry) {
						error("PropertyBinding: Can not bind to morphTargetInfluences because node does not have a geometry.", this);
						return;
					}
					if (!targetObject.geometry.morphAttributes) {
						error("PropertyBinding: Can not bind to morphTargetInfluences because node does not have a geometry.morphAttributes.", this);
						return;
					}
					if (targetObject.morphTargetDictionary[propertyIndex] !== void 0) propertyIndex = targetObject.morphTargetDictionary[propertyIndex];
				}
				bindingType = this.BindingType.ArrayElement;
				this.resolvedProperty = nodeProperty;
				this.propertyIndex = propertyIndex;
			} else if (nodeProperty.fromArray !== void 0 && nodeProperty.toArray !== void 0) {
				bindingType = this.BindingType.HasFromToArray;
				this.resolvedProperty = nodeProperty;
			} else if (Array.isArray(nodeProperty)) {
				bindingType = this.BindingType.EntireArray;
				this.resolvedProperty = nodeProperty;
			} else this.propertyName = propertyName;
			this.getValue = this.GetterByBindingType[bindingType];
			this.setValue = this.SetterByBindingTypeAndVersioning[bindingType][versioning];
		}
		/**
		* Unbinds the property.
		*/
		unbind() {
			this.node = null;
			this.getValue = this._getValue_unbound;
			this.setValue = this._setValue_unbound;
		}
	};
	PropertyBinding.Composite = Composite;
	PropertyBinding.prototype.BindingType = {
		Direct: 0,
		EntireArray: 1,
		ArrayElement: 2,
		HasFromToArray: 3
	};
	PropertyBinding.prototype.Versioning = {
		None: 0,
		NeedsUpdate: 1,
		MatrixWorldNeedsUpdate: 2
	};
	PropertyBinding.prototype.GetterByBindingType = [
		PropertyBinding.prototype._getValue_direct,
		PropertyBinding.prototype._getValue_array,
		PropertyBinding.prototype._getValue_arrayElement,
		PropertyBinding.prototype._getValue_toArray
	];
	PropertyBinding.prototype.SetterByBindingTypeAndVersioning = [
		[
			PropertyBinding.prototype._setValue_direct,
			PropertyBinding.prototype._setValue_direct_setNeedsUpdate,
			PropertyBinding.prototype._setValue_direct_setMatrixWorldNeedsUpdate
		],
		[
			PropertyBinding.prototype._setValue_array,
			PropertyBinding.prototype._setValue_array_setNeedsUpdate,
			PropertyBinding.prototype._setValue_array_setMatrixWorldNeedsUpdate
		],
		[
			PropertyBinding.prototype._setValue_arrayElement,
			PropertyBinding.prototype._setValue_arrayElement_setNeedsUpdate,
			PropertyBinding.prototype._setValue_arrayElement_setMatrixWorldNeedsUpdate
		],
		[
			PropertyBinding.prototype._setValue_fromArray,
			PropertyBinding.prototype._setValue_fromArray_setNeedsUpdate,
			PropertyBinding.prototype._setValue_fromArray_setMatrixWorldNeedsUpdate
		]
	];
	(class Matrix2 {
		static {
			/**
			* This flag can be used for type testing.
			*
			* @type {boolean}
			* @readonly
			* @default true
			*/
			Matrix2.prototype.isMatrix2 = true;
		}
		/**
		* Constructs a new 2x2 matrix. The arguments are supposed to be
		* in row-major order. If no arguments are provided, the constructor
		* initializes the matrix as an identity matrix.
		*
		* @param {number} [n11] - 1-1 matrix element.
		* @param {number} [n12] - 1-2 matrix element.
		* @param {number} [n21] - 2-1 matrix element.
		* @param {number} [n22] - 2-2 matrix element.
		*/
		constructor(n11, n12, n21, n22) {
			/**
			* A column-major list of matrix values.
			*
			* @type {Array<number>}
			*/
			this.elements = [
				1,
				0,
				0,
				1
			];
			if (n11 !== void 0) this.set(n11, n12, n21, n22);
		}
		/**
		* Sets this matrix to the 2x2 identity matrix.
		*
		* @return {Matrix2} A reference to this matrix.
		*/
		identity() {
			this.set(1, 0, 0, 1);
			return this;
		}
		/**
		* Sets the elements of the matrix from the given array.
		*
		* @param {Array<number>} array - The matrix elements in column-major order.
		* @param {number} [offset=0] - Index of the first element in the array.
		* @return {Matrix2} A reference to this matrix.
		*/
		fromArray(array, offset = 0) {
			for (let i = 0; i < 4; i++) this.elements[i] = array[i + offset];
			return this;
		}
		/**
		* Sets the elements of the matrix.The arguments are supposed to be
		* in row-major order.
		*
		* @param {number} n11 - 1-1 matrix element.
		* @param {number} n12 - 1-2 matrix element.
		* @param {number} n21 - 2-1 matrix element.
		* @param {number} n22 - 2-2 matrix element.
		* @return {Matrix2} A reference to this matrix.
		*/
		set(n11, n12, n21, n22) {
			const te = this.elements;
			te[0] = n11;
			te[2] = n12;
			te[1] = n21;
			te[3] = n22;
			return this;
		}
	});
	if (typeof __THREE_DEVTOOLS__ !== "undefined") __THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("register", { detail: { revision: "186" } }));
	if (typeof window !== "undefined") {
		if (window.__THREE__) warn("WARNING: Multiple instances of Three.js being imported.");
		else window.__THREE__ = "186";
	}
	//#endregion
	//#region src/avatar/headOrientationRig.ts
	const ROUND_OFF = 1e-5;
	function similarityRotation(matrix) {
		const e = matrix.elements;
		if (!e.every(Number.isFinite) || [
			e[3],
			e[7],
			e[11]
		].some((v) => Math.abs(v) > ROUND_OFF) || Math.abs(e[15] - 1) > ROUND_OFF) return null;
		const axes = [
			new Vector3(e[0], e[1], e[2]),
			new Vector3(e[4], e[5], e[6]),
			new Vector3(e[8], e[9], e[10])
		];
		const sizes = axes.map((v) => Math.hypot(v.x, v.y, v.z));
		if (sizes.some((s) => !Number.isFinite(s) || s <= 0)) return null;
		if (sizes.some((s) => Math.abs(s / sizes[0] - 1) > ROUND_OFF)) return null;
		axes.forEach((v, i) => {
			v.divideScalar(sizes[i]);
		});
		const [x, y, z] = axes;
		if (Math.max(Math.abs(x.dot(y)), Math.abs(x.dot(z)), Math.abs(y.dot(z))) > ROUND_OFF || Math.abs(x.clone().cross(y).dot(z) - 1) > ROUND_OFF) return null;
		return new Quaternion().setFromRotationMatrix(new Matrix4().makeBasis(x, y, z)).normalize();
	}
	/** Declared layout, never inferred from translation. SDK matrices map canonical face to
	* detected face; one accepted face does not prove a single person or pose/face identity.
	* Only copied rotation leaves this boundary; no landmarks or translation are retained.
	*/
	function readHeadOrientation(result, layout) {
		try {
			if (layout !== "column-major" && layout !== "row-major") return null;
			const faces = result.faceLandmarks;
			const matrices = result.facialTransformationMatrixes;
			if (!Array.isArray(faces) || faces.length !== 1 || !Array.isArray(matrices) || matrices.length !== 1) return null;
			const points = faces[0];
			if (!Array.isArray(points) || ![468, 478].includes(points.length) || !Array.from(points).every((p) => p && [
				p.x,
				p.y,
				p.z
			].every(Number.isFinite) && p.x > 0 && p.x < 1 && p.y > 0 && p.y < 1)) return null;
			const { rows, columns, data } = matrices[0];
			if (rows !== 4 || columns !== 4 || !Array.isArray(data) || data.length !== 16) return null;
			const matrix = new Matrix4().fromArray(data);
			if (layout === "row-major") matrix.transpose();
			const rotation = similarityRotation(matrix);
			return rotation ? Object.freeze(rotation.toArray()) : null;
		} catch {
			return null;
		}
	}
	//#endregion
	//#region src/avatar/observedHandRig.ts
	const sides = ["left", "right"];
	Object.freeze(sides.flatMap((side) => {
		const suffix = side === "left" ? "L" : "R";
		return Array.from({ length: 15 }, (_, i) => Object.freeze({
			side,
			bone: `finger${Math.floor(i / 3) + 1}-${i % 3 + 1}${suffix}`,
			parent: i % 3 ? `finger${Math.floor(i / 3) + 1}-${i % 3}${suffix}` : i < 3 ? `wrist${suffix}` : `metacarpal${Math.floor(i / 3)}${suffix}`,
			from: Math.floor(i / 3) * 4 + 1 + i % 3,
			to: Math.floor(i / 3) * 4 + 2 + i % 3
		}));
	}));
	function copyHandObservations(value) {
		if (!Array.isArray(value) || value.length > 2) return Object.freeze([]);
		const copied = [];
		const seen = /* @__PURE__ */ new Set();
		for (const hand of value) {
			const side = hand?.side;
			if (!sides.includes(side) || seen.has(side)) return Object.freeze([]);
			seen.add(side);
			const image = hand.landmarks, world = hand.worldLandmarks;
			if (!Array.isArray(image) || !Array.isArray(world) || image.length !== 21 || world.length !== 21) continue;
			const points = (array) => Object.freeze(Array.from(array, (p) => Object.freeze(p ? {
				x: p.x,
				y: p.y,
				z: p.z
			} : {
				x: NaN,
				y: NaN,
				z: NaN
			})));
			copied.push(Object.freeze({
				side,
				landmarks: points(image),
				worldLandmarks: points(world)
			}));
		}
		return Object.freeze(copied);
	}
	//#endregion
	//#region src/pose/ownedPoseFrame.ts
	function copyPosePoints(poses) {
		if (!Array.isArray(poses) || poses.length > 2) throw new Error();
		return Object.freeze(poses.map((points) => {
			if (!Array.isArray(points) || points.length > 33) throw new Error();
			return Object.freeze(points.map((point) => {
				const { x, y, z, visibility, presence } = point;
				if (typeof x !== "number" || typeof y !== "number" || typeof z !== "number") throw new Error();
				if (presence !== void 0 && typeof presence !== "number") throw new Error();
				return Object.freeze({
					x,
					y,
					z,
					...typeof visibility === "number" ? { visibility } : {},
					...presence === void 0 ? {} : { presence }
				});
			}));
		}));
	}
	//#endregion
	//#region src/pose/bodyHandVideoSource.ts
	/** SDK labels are candidates, not anatomical/person proof. No score threshold, mirror
	* swap, gesture or deprecated handednesses field. Caller handles a foreign getter failure. */
	function readNativeHands(value) {
		const image = value.landmarks, world = value.worldLandmarks, labels = value.handedness;
		if (!Array.isArray(image) || !Array.isArray(world) || !Array.isArray(labels) || image.length > 2 || image.length !== world.length || image.length !== labels.length) return Object.freeze([]);
		const candidates = [], seen = /* @__PURE__ */ new Set();
		for (let i = 0; i < image.length; i++) {
			const categories = labels[i];
			if (!Array.isArray(categories) || categories.length !== 1) return Object.freeze([]);
			const name = categories[0]?.categoryName, score = categories[0]?.score;
			if (name !== "Left" && name !== "Right" || seen.has(name) || !Number.isFinite(score) || score < 0 || score > 1) return Object.freeze([]);
			seen.add(name);
			candidates.push({
				side: name === "Left" ? "left" : "right",
				landmarks: image[i],
				worldLandmarks: world[i]
			});
		}
		return copyHandObservations(candidates);
	}
	//#endregion
	//#region src/pose/workerNativeEngine.ts
	async function prepareWorkerNativeEngine(config, signal) {
		const releases = [];
		let disposed = false, cleanupFailed = false;
		function dispose() {
			if (!disposed) {
				disposed = true;
				for (const release of releases.reverse()) try {
					release();
				} catch {
					cleanupFailed = true;
				}
				releases.length = 0;
			}
			if (cleanupFailed) throw new ResourceCleanupError();
		}
		function own(task) {
			releases.push(() => task.close());
			signal.throwIfAborted();
			return task;
		}
		try {
			signal.throwIfAborted();
			if (typeof OffscreenCanvas !== "function") throw new Error();
			const path = (asset) => new URL(asset, self.location.href).href;
			const vision = await ah.forVisionTasks(path(WASM_BASE_PATH));
			signal.throwIfAborted();
			async function load(create) {
				try {
					return await create("GPU");
				} catch {
					signal.throwIfAborted();
					return create("CPU");
				}
			}
			const body = own(await load((delegate) => Kc.createFromOptions(vision, {
				canvas: new OffscreenCanvas(1, 1),
				baseOptions: {
					modelAssetPath: path(POSE_MODELS[config.model].path),
					delegate
				},
				runningMode: "VIDEO",
				numPoses: 2
			})));
			const face = config.face ? own(await load((delegate) => mc.createFromOptions(vision, {
				canvas: new OffscreenCanvas(1, 1),
				baseOptions: {
					modelAssetPath: path(FACE_MODEL_PATH),
					delegate
				},
				runningMode: "VIDEO",
				numFaces: 1,
				outputFacialTransformationMatrixes: true,
				outputFaceBlendshapes: false
			}))) : void 0;
			const hands = config.hands ? own(await load((delegate) => Ac.createFromOptions(vision, {
				canvas: new OffscreenCanvas(1, 1),
				baseOptions: {
					modelAssetPath: path(GESTURE_MODEL_PATH),
					delegate
				},
				runningMode: "VIDEO",
				numHands: 2
			}))) : void 0;
			return Object.freeze({
				detect(frame, at) {
					if (disposed || signal.aborted) throw new Error("Worker inference unavailable");
					const result = body.detectForVideo(frame, at);
					let copied, inferenceFailed = false, resultCleanupFailed = false;
					try {
						const landmarks = copyPosePoints(result.landmarks), worldLandmarks = copyPosePoints(result.worldLandmarks);
						const single = landmarks.length === 1 && worldLandmarks.length === 1 && [landmarks[0], worldLandmarks[0]].every((points) => points.length === 33 && points.every((p) => [
							p.x,
							p.y,
							p.z
						].every(Number.isFinite)));
						const nativeFace = face?.detectForVideo(frame, at);
						const headOrientation = single && nativeFace ? readHeadOrientation(nativeFace, config.matrixLayout) : null;
						const nativeHands = hands?.recognizeForVideo(frame, at);
						copied = Object.freeze({
							landmarks,
							worldLandmarks,
							...face ? { headOrientation } : {},
							...hands ? { hands: single && nativeHands ? readNativeHands(nativeHands) : Object.freeze([]) } : {}
						});
					} catch {
						inferenceFailed = true;
					} finally {
						try {
							result.close();
						} catch {
							resultCleanupFailed = true;
						}
					}
					if (resultCleanupFailed) throw new ResourceCleanupError();
					if (inferenceFailed || !copied) throw new Error("Worker inference unavailable");
					return copied;
				},
				dispose
			});
		} catch {
			dispose();
			throw new Error("Worker inference unavailable");
		}
	}
	//#endregion
	//#region src/pose/nativeInference.worker.ts
	const scope = self;
	const runtime = createWorkerInferenceRuntime({
		prepare: prepareWorkerNativeEngine,
		send: (message) => scope.postMessage(message)
	});
	scope.addEventListener("message", (event) => runtime.receive(event.data));
	//#endregion
})();
