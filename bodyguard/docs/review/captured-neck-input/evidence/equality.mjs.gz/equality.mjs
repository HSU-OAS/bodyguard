import assert from 'node:assert/strict'
import { readFileSync, writeFileSync, readdirSync } from 'node:fs'
import { createHash } from 'node:crypto'
const work="/Applications/학교 내부/2026-2학기/오픈소스 AI SW 융합 프로젝트/BODYGUARD-captured-neck-input",proof="/private/tmp/bodyguard-neck-input.0FrXPy",prior="/Applications/학교 내부/2026-2학기/오픈소스 AI SW 융합 프로젝트/BODYGUARD-native-worker-recovery"
const label=process.argv[2]
const sha=b=>createHash('sha256').update(b).digest('hex')
const dirs=[prior+'/bodyguard/frontend/dist/assets',work+'/bodyguard/frontend/dist/assets']
const assets=dirs.map(dir=>Object.fromEntries(readdirSync(dir).filter(n=>/\.(css|js)$/.test(n)).map(n=>[n.endsWith('.css')?'css':'js',{name:n,bytes:readFileSync(dir+'/'+n).length,sha256:sha(readFileSync(dir+'/'+n))}])))
const equal=['js','css'].every(k=>assets[0][k].sha256===assets[1][k].sha256)
writeFileSync(proof+'/public-byte-'+label+'.json',JSON.stringify({equal,assets},null,2),{flag:'wx'})
console.log(JSON.stringify({equal,assets}))
assert(equal,'Public output must remain unchanged')
