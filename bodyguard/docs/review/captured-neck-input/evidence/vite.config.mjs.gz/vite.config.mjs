export default {build:{outDir:"/private/tmp/bodyguard-neck-input.0FrXPy/probe",emptyOutDir:false,minify:false,
lib:{entry:"/Applications/학교 내부/2026-2학기/오픈소스 AI SW 융합 프로젝트/BODYGUARD-captured-neck-input/bodyguard/frontend/e2e/fixtures/capturedNeckProbe.ts",formats:['es'],fileName:()=> 'probe.js'}}}
