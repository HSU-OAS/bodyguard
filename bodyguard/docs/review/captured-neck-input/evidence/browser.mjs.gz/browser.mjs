// Actual Chrome + fake camera/native SDK. Only fixed booleans/counts escape the page.
import assert from 'node:assert/strict'
import { createServer } from 'node:http'
import { readFileSync,writeFileSync } from 'node:fs'
import { createHash } from 'node:crypto'
import { chromium } from "/Applications/학교 내부/2026-2학기/오픈소스 AI SW 융합 프로젝트/BODYGUARD-captured-neck-input/bodyguard/frontend/node_modules/@playwright/test/index.mjs"
const work="/Applications/학교 내부/2026-2학기/오픈소스 AI SW 융합 프로젝트/BODYGUARD-captured-neck-input", proof="/private/tmp/bodyguard-neck-input.0FrXPy", assets=work+'/bodyguard/frontend/public'
const label=process.argv[2]; assert(/^[a-z-]+$/.test(label))
const sha=b=>createHash('sha256').update(b).digest('hex')
const paths=['src/posture/capturedImage.ts','src/posture/neckSideObservation.ts','src/posture/landmarks.ts','src/avatar/observedPoseRig.ts','src/pose/ownedPoseFrame.ts','src/pose/videoPoseSource.ts','src/coaching/nativePlaybackResources.ts','e2e/fixtures/capturedNeckProbe.ts']
const sources=()=>Object.fromEntries(paths.map(p=>[p,sha(readFileSync(work+'/bodyguard/frontend/'+p))]))
const before=sources(), bundle=readFileSync(proof+'/probe/probe.js','utf8')
const workers=[...new Set(bundle.match(/nativeInference\.worker-[\w-]+\.js/g)??[])];assert.equal(workers.length,1)
const results=[],errors=[]; let external=0, failed=false
const server=createServer((req,res)=>{
 const path=new URL(req.url,'http://localhost').pathname;res.setHeader('Content-Security-Policy',"connect-src 'self'")
 if(path==='/'){res.setHeader('Content-Type','text/html');res.end('<html><script type="module">import{mountCapturedNeckProbe}from"/probe.js";window.mountProbe=mountCapturedNeckProbe;</script></html>');return}
 let bytes
 if(path==='/probe.js')bytes=bundle
 else if(path==='/assets/'+workers[0])bytes=readFileSync(proof+'/probe'+path)
 else if(/^\/mediapipe\/wasm\/vision_wasm_(?:module_|nosimd_)?internal\.(?:js|wasm)$/.test(path)||path==='/models/pose_landmarker_lite.task')bytes=readFileSync(assets+path)
 else{res.writeHead(404);res.end();return}
 res.setHeader('Content-Type',path.endsWith('.js')?'application/javascript':path.endsWith('.wasm')?'application/wasm':'application/octet-stream');res.end(bytes)
})
await new Promise(r=>server.listen(0,'127.0.0.1',r));const origin='http://127.0.0.1:'+server.address().port
const browser=await chromium.launch({channel:'chrome',args:['--use-fake-device-for-media-stream','--use-fake-ui-for-media-stream']})
try{
 for(const mode of ['main','worker']){
  const context=await browser.newContext({permissions:['camera'],serviceWorkers:'block'}),page=await context.newPage()
  let workerStarts=0,workerCloses=0
  page.on('pageerror',e=>errors.push(e.name))
  page.on('worker',worker=>{workerStarts++;worker.on('close',()=>workerCloses++)})
  await context.route('**/*',route=>{if(!route.request().url().startsWith(origin+'/')){external++;return route.abort()}return route.continue()})
  try{
   await page.goto(origin);await page.waitForFunction(()=>typeof window.mountProbe==='function')
   await page.evaluate(async mode=>{window.probe=await window.mountProbe(mode)},mode)
   for(let i=0;i<3;i++)await page.evaluate(()=>window.probe.read())
   const running=await page.evaluate(()=>window.probe.snapshot())
   assert.equal(running.nativeResults,3);assert.equal(running.unavailable,3)
   assert.equal(running.syntheticChecks,3);assert.equal(running.syntheticChecksPassed,true)
   assert.equal(running.sourceGeometryMatches,true)
   const final=await page.evaluate(()=>window.probe.close())
   assert.equal(final.closes,final.frames);assert.equal(final.tracksEnded&&final.detached,true)
   await page.waitForTimeout(100);assert.equal(workerStarts,workerCloses)
   results.push({mode,running,final,workerStarts,workerCloses,storage:await page.evaluate(()=>[localStorage.length,sessionStorage.length])})
  }finally{await context.close()}
 }
 assert.equal(external,0);assert.deepEqual(errors,[])
}catch(e){failed=true;errors.push(e.name);throw e}
finally{
 await browser.close();await new Promise(r=>server.close(r));const after=sources();assert.deepEqual(before,after)
 const result={at:new Date().toISOString(),passed:!failed,results,external,errors,sourcesBefore:before,sourcesAfter:after,actualHuman:0,physicalCameras:0,syntheticPositiveOnly:true,productPolicyApproved:false}
 writeFileSync(proof+'/browser-'+label+'.json',JSON.stringify(result,null,2),{flag:'wx'});console.log(JSON.stringify(result))
}
