// Fresh local test DB; fixed actual browser/native/account commands, no production changes.
import { spawnSync } from 'node:child_process'
import { readFileSync,writeFileSync,existsSync } from 'node:fs'
import { createHash } from 'node:crypto'
import assert from 'node:assert/strict'
import { gunzipSync } from 'node:zlib'
const work="/Applications/학교 내부/2026-2학기/오픈소스 AI SW 융합 프로젝트/BODYGUARD-captured-neck-input",proof="/private/tmp/bodyguard-neck-input.0FrXPy",owner="/private/tmp/bodyguard-native-feedback-proof.haIAU9",db="/private/tmp/bodyguard-auth-test.QoYyzx"
const fe=work+'/bodyguard/frontend',backend=work+'/bodyguard/backend'
const python="/Applications/학교 내부/2026-2학기/오픈소스 AI SW 융합 프로젝트/BODYGUARD-account-web/bodyguard/backend/.venv/bin/python"
const pg='/opt/homebrew/opt/postgresql@18/bin/'
const paths=['src/pose/ownedPoseFrame.ts','src/pose/videoPoseSource.ts','src/coaching/nativePlaybackResources.ts','src/posture/capturedImage.ts','src/posture/neckSideObservation.ts','e2e/nativeworker.spec.ts','e2e/fixtures/nativeHeadAuthProbe.ts']
const sha=b=>createHash('sha256').update(b).digest('hex')
const sources=()=>Object.fromEntries(paths.map(p=>[p,sha(readFileSync(fe+'/'+p))]))
function run(label,command,args,cwd=work,env={}){
 assert(/^[a-z-]+$/.test(label));const before=sources(),startedAt=new Date().toISOString()
 const r=spawnSync(command,args,{cwd,env:{...process.env,...env},encoding:'utf8',maxBuffer:24*1024*1024})
 for(const [k,bytes]of [['stdout',r.stdout],['stderr',r.stderr]])writeFileSync(proof+'/'+label+'.'+k+'.txt',bytes??'',{flag:'wx'})
 const receipt={command,args,cwd,startedAt,finishedAt:new Date().toISOString(),exit:r.status,sourcesBefore:before,sourcesAfter:sources()}
 writeFileSync(proof+'/'+label+'.receipt.json',JSON.stringify(receipt,null,2),{flag:'wx'})
 console.log(JSON.stringify({label,exit:r.status,stdout:r.stdout?.slice(-1500),stderr:r.stderr?.slice(-1300)}))
 if(r.status!==0)process.exit(r.status??1)
}
const [action,label,suffix,gender]=process.argv.slice(2)
if(action==='init'){
 assert(!existsSync(db+'/data'))
 run('db-init',pg+'initdb',['-D',db+'/data','--username=bodyguard_test','--auth=trust','--no-locale','--encoding=UTF8'])
 run('db-start',pg+'pg_ctl',['-D',db+'/data','-l',db+'/server.log','-o',"-k "+db+" -c listen_addresses='' -p 5432",'-w','start'])
 run('db-create',pg+'createdb',['-h',db,'-U','bodyguard_test','bodyguard_test'])
 run('db-identity',pg+'psql',['-h',db,'-U','bodyguard_test','-d','bodyguard_test','-At','-c',"select current_database(),current_user; show server_version_num; show listen_addresses;"])
 for(const [gender,expected]of [['male','cc85bcd449f3f31347e4f7174986d41e4aca3067990f5d8a2e6ba3a099171927'],['female','27c10902aa377e995bdbc115ab773cf22f8ea38582c49820304a33ad7685f25a']]){
  const bytes=readFileSync('/private/tmp/bodyguard-native-feedback-proof.GxCCZQ/'+gender+'.glb');assert.equal(sha(bytes),expected)
  writeFileSync(owner+'/'+gender+'.glb',bytes,{flag:'wx'})
 }
}else if(action==='test'){
 assert(['nativeworker','nativefeedback'].includes(label))
 if(gender)assert(['male','female'].includes(gender))
 run('owner-'+label+(suffix?'-'+suffix:''),python,['-m','tests.run_browser',label],backend,{
 PATH:proof+'/bin:'+fe+'/node_modules/.bin:'+process.env.PATH,
 ...(gender?{BODYGUARD_NATIVE_TEST_GENDER:gender}:{}),
 BODYGUARD_TEST_NATIVE_FEEDBACK_PROBE:owner+(label==='nativeworker'?'/probe-worker':'/probe-main'),
 BODYGUARD_TEST_DATABASE_URL:'postgresql+psycopg://bodyguard_test@/bodyguard_test?host='+db})
}else if(action==='fixture'){
 const bytes=gunzipSync(readFileSync(work+'/bodyguard/docs/review/native-feedback/evidence/authored-fixture.json.gz'))
 assert.equal(sha(bytes),'d91a93e39f09005097db58a50d27dd2db0e35382a19d755bd56515f9d4e2ddf6')
 writeFileSync(owner+'/authored-fixture.json',bytes,{flag:'wx'})
 console.log(JSON.stringify({reusedPreservedBlenderFixture:true,sha:sha(bytes),clinicalPositive:false}))
}else if(action==='stop')run('db-stop',pg+'pg_ctl',['-D',db+'/data','-m','fast','-w','stop'])
else throw new Error('Fixed action required')
