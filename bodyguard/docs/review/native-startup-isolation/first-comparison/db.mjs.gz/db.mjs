import assert from 'node:assert/strict'
import {spawnSync} from 'node:child_process'
import {realpathSync,statSync,existsSync,writeFileSync} from 'node:fs'
const db="/private/tmp/bodyguard-auth-test.mZQOez", proof="/private/tmp/bodyguard-native-feedback-proof.LHZ88F", bin='/opt/homebrew/opt/postgresql@18/bin/'
assert(/^\/private\/tmp\/bodyguard-auth-test\.[A-Za-z0-9]+$/.test(db))
assert.equal(realpathSync(db),db)
assert.equal(statSync(db).uid,process.getuid())
const mode=process.argv[2]
assert(['start','stop'].includes(mode))
if(mode==='start')assert(!existsSync(db+'/data'))
const steps=mode==='stop'?[['stop','pg_ctl',['-D',db+'/data','-m','fast','-w','stop']]]:[
 ['init','initdb',['-D',db+'/data','--auth=trust','--no-locale','--encoding=UTF8','--username=bodyguard_test']],
 ['start','pg_ctl',['-D',db+'/data','-l',db+'/postgres.log','-o',"-k "+db+" -c listen_addresses='' -p 5432",'-w','start']],
 ['create','createdb',['-h',db,'-U','bodyguard_test','bodyguard_test']],
 ['identity','psql',['-h',db,'-U','bodyguard_test','-d','bodyguard_test','-At','-c',"SELECT current_database(),current_user,current_setting('server_version'),current_setting('listen_addresses');"]],
]
for(const[name,cmd,args]of steps){const r=spawnSync(bin+cmd,args,{encoding:'utf8',maxBuffer:5*1024*1024});writeFileSync(proof+'/db-'+name+'.log',(r.stdout??'')+(r.stderr??''),{flag:'wx'});writeFileSync(proof+'/db-'+name+'.receipt.json',JSON.stringify({cmd,args,status:r.status}),{flag:'wx'});console.log(name,r.status);assert.equal(r.status,0)}
if(mode==='stop')assert(!existsSync(db+'/data/postmaster.pid'))
