import assert from 'node:assert/strict'
import {readFileSync,readdirSync,writeFileSync,existsSync,readlinkSync,realpathSync,lstatSync,unlinkSync} from 'node:fs'
import {execFileSync} from 'node:child_process'
import {createHash} from 'node:crypto'
import {resolve} from 'node:path'
const proof="/private/tmp/bodyguard-native-feedback-proof.LHZ88F",baseline="/Applications/학교 내부/2026-2학기/오픈소스 AI SW 융합 프로젝트/BODYGUARD-native-startup-isolation",current="/Applications/학교 내부/2026-2학기/오픈소스 AI SW 융합 프로젝트/BODYGUARD-native-neck-observation"
const sha=b=>createHash('sha256').update(b).digest('hex'),json=p=>JSON.parse(readFileSync(p)),runs=[]
for(const[root,label]of[[baseline,'baseline-main-timing'],[current,'paired-current-timing']]){
  const receipt=json(proof+'/browser-'+label+'.receipt.json'),before=json(proof+'/browser-'+label+'-source-before.json'),after=json(proof+'/browser-'+label+'-source-after.json')
  assert.equal(receipt.status,0);assert.deepEqual(before,after)
  assert.equal(before.head,root===baseline?'5a1a3d8ec1149cf029c486aee35de1dc33a2f167':'884700e3cebfce2b1c0c51fdca2cce4788e6dc4b')
  for(const[path,hash]of Object.entries(before.sources)){assert.equal(sha(readFileSync(root+'/'+path)),hash);assert.equal(sha(execFileSync('git',['show',before.head+':'+path],{cwd:root})),hash)}
  const candidates=readdirSync(root+'/bodyguard/frontend/test-results').filter(n=>n.startsWith('nativefeedback-')).map(n=>({name:n,path:root+'/bodyguard/frontend/test-results/'+n})).filter(r=>{if(!existsSync(r.path+'/report.json'))return false;const at=Date.parse(json(r.path+'/report.json').stats.startTime);return at>=Date.parse(receipt.start)&&at<=Date.parse(receipt.end)})
  assert.equal(candidates.length,1);const run=candidates[0],report=json(run.path+'/report.json')
  assert.equal(report.stats.expected,1);assert.equal(report.stats.unexpected,0);assert.equal(report.stats.skipped,0);assert.equal(report.stats.flaky,0)
  const folders=readdirSync(run.path).filter(n=>existsSync(run.path+'/'+n+'/native-hands-summary.json'));assert.equal(folders.length,1)
  const data=json(run.path+'/'+folders[0]+'/native-hands-summary.json'),end=data.final
  assert.equal(data.external,0);assert.equal(data.errors.length,0);assert.equal(end.nativePeopleMax,0);assert.equal(end.models,0);assert(end.tracksEnded&&end.allFramesClosed);assert.equal(end.frameCloses,end.frames);assert.equal(end.nativeCloses,end.nativeCalls)
  const timing=end.startupTiming;assert.equal(timing.invalid,false);assert.equal(timing.closed,true)
  const events=timing.events,get=s=>events.find(e=>e.stage===s)
  runs.push({label,head:before.head,date:report.stats.startTime,source:before.sources,reportPath:run.path+'/report.json',summaryPath:run.path+'/'+folders[0]+'/native-hands-summary.json',stats:report.stats,timing,sdkPreparedMs:get('hands-sdk').endMs,avatarPreparedMs:get('avatar').endMs,firstResultMs:get('result').endMs,caseDurationMs:report.stats.duration})
}
assert.deepEqual(json(proof+'/assets.json'),json('/private/tmp/bodyguard-native-neck-proof.8Stg1c/assets.json'))
assert(!existsSync('/private/tmp/bodyguard-auth-test.mZQOez/data/postmaster.pid'))
const result={story:'S6.9',runs,sequence:'main then current; one male case each, not counterbalanced',modelBytesUnchanged:true,limitsUnchanged:true,pollMs:5000,retry:0,actualChrome:true,actualSDK:true,isolatedSQL:true,fakeCamera:true,syntheticMail:true,actualPeople:0,physicalCamera:0,deterministicNewCodeStartupFailureReproduced:false,causalityEstablished:false,globalStartupP2StillOpen:true,pr90MandatoryRegressionStillFailed:true,fullMandatoryStoryVerificationRun:false,allStagesComplete:false,dbStopped:true}
writeFileSync(proof+'/comparison.json',JSON.stringify(result,null,2),{flag:'wx'})
for(const root of [baseline,current]){
  const link=root+'/bodyguard/frontend/node_modules',target=resolve(root,'../BODYGUARD-owned-alert-lifecycle/bodyguard/frontend/node_modules')
  assert(lstatSync(link).isSymbolicLink());assert.equal(readlinkSync(link),'../../../BODYGUARD-owned-alert-lifecycle/bodyguard/frontend/node_modules');assert.equal(realpathSync(link),realpathSync(target));unlinkSync(link)
}
console.log(JSON.stringify({runs:runs.map(r=>({label:r.label,head:r.head,sdkPreparedMs:r.sdkPreparedMs,avatarPreparedMs:r.avatarPreparedMs,firstResultMs:r.firstResultMs,stats:r.stats})),causalityEstablished:false,pr90MandatoryRegressionStillFailed:true,removedOnlyOwnedLinks:true}))
