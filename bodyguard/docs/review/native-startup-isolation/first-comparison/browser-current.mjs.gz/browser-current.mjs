import assert from 'node:assert/strict'
import {spawnSync,execFileSync} from 'node:child_process'
import {readFileSync,writeFileSync,existsSync} from 'node:fs'
import {createHash} from 'node:crypto'
const proof="/private/tmp/bodyguard-native-feedback-proof.LHZ88F",work="/Applications/학교 내부/2026-2학기/오픈소스 AI SW 융합 프로젝트/BODYGUARD-native-neck-observation",fe=work+'/bodyguard/frontend',db="/private/tmp/bodyguard-auth-test.mZQOez"
const [gender,label,scope='neck']=process.argv.slice(2)
assert(['male','female'].includes(gender)); assert(/^[a-z][a-z-]*$/.test(label)); assert(['neck','existing'].includes(scope))
assert(!existsSync(proof+'/browser-'+label+'.receipt.json'))
const sha=b=>createHash('sha256').update(b).digest('hex')
const git=(...args)=>execFileSync('git',args,{cwd:work,encoding:'utf8'})
const hash=()=>Object.fromEntries(git('ls-files','-z','--cached','--others','--exclude-standard','bodyguard/frontend/src','bodyguard/frontend/e2e','bodyguard/backend/tests/run_browser.py').split('\0').filter(Boolean).map(path=>[path,sha(readFileSync(work+'/'+path))]))
const before=hash(), head=git('rev-parse','HEAD').trim(),start=new Date().toISOString()
writeFileSync(proof+'/browser-'+label+'-source-before.json',JSON.stringify({head,sources:before},null,2),{flag:'wx'})
const r=spawnSync("/Applications/학교 내부/2026-2학기/오픈소스 AI SW 융합 프로젝트/BODYGUARD-account-web/bodyguard/backend/.venv/bin/python",['-m','tests.run_browser','nativefeedback'],{cwd:work+'/bodyguard/backend',encoding:'utf8',maxBuffer:32*1024*1024,env:{...process.env,PATH:proof+'/bin:'+fe+'/node_modules/.bin:'+process.env.PATH,BODYGUARD_TEST_NATIVE_FEEDBACK_PROBE:proof+'/probe-'+label,BODYGUARD_TEST_NATIVE_NECK:'1',BODYGUARD_NATIVE_TEST_GENDER:gender,BODYGUARD_NATIVE_TEST_SCOPE:scope,BODYGUARD_TEST_DATABASE_URL:'postgresql+psycopg://bodyguard_test@/bodyguard_test?host='+db}})
for(const key of ['stdout','stderr'])writeFileSync(proof+'/browser-'+label+'.'+key,r[key]??'',{flag:'wx'})
const after=hash()
writeFileSync(proof+'/browser-'+label+'-source-after.json',JSON.stringify({head,sources:after},null,2),{flag:'wx'})
writeFileSync(proof+'/browser-'+label+'.receipt.json',JSON.stringify({gender,scope,head,start,end:new Date().toISOString(),status:r.status,signal:r.signal,fakeCamera:true,physicalCamera:false,actualPeople:0,actualAPI:true,isolatedSQL:true,syntheticMail:true,syntheticPositiveCoordinates:true,productSDKPolicyApproved:false},null,2),{flag:'wx'})
assert.deepEqual(before,after)
console.log(JSON.stringify({gender,scope,status:r.status}), (r.stdout??'').slice(-1200), (r.stderr??'').slice(-450))
process.exitCode=r.status??1
