import assert from 'node:assert/strict'
import {spawnSync} from 'node:child_process'
import {readFileSync,writeFileSync,mkdirSync,cpSync,existsSync} from 'node:fs'
import {createHash} from 'node:crypto'
import {gunzipSync} from 'node:zlib'
const work="/Applications/학교 내부/2026-2학기/오픈소스 AI SW 융합 프로젝트/BODYGUARD-native-startup-isolation",proof="/private/tmp/bodyguard-native-feedback-proof.LHZ88F",prior="/Applications/학교 내부/2026-2학기/오픈소스 AI SW 융합 프로젝트/BODYGUARD-native-trunk",fe=work+'/bodyguard/frontend'
const sha=b=>createHash('sha256').update(b).digest('hex')
const resources={}
for(const name of ['pose_landmarker_lite','pose_landmarker_full','pose_landmarker_heavy','face_landmarker','gesture_recognizer']){
 const src=prior+'/bodyguard/frontend/public/models/'+name+'.task', dst=fe+'/public/models/'+name+'.task'
 assert(existsSync(src)); assert(!existsSync(dst))
 mkdirSync(fe+'/public/models',{recursive:true});cpSync(src,dst,{errorOnExist:true,force:false})
 assert.equal(sha(readFileSync(src)),sha(readFileSync(dst)))
 resources[name]={bytes:readFileSync(dst).length,sha256:sha(readFileSync(dst)),existingLocalCache:true}
}
for(const[gender,hash]of [['male','cc85bcd449f3f31347e4f7174986d41e4aca3067990f5d8a2e6ba3a099171927'],['female','27c10902aa377e995bdbc115ab773cf22f8ea38582c49820304a33ad7685f25a']]){
 const r=spawnSync('git',['show','25a9bd6c7392890e3b5d5d6ae1046bb7087d56ad:bodyguard/frontend/src/avatar/models/bodyguard-'+gender+'-candidate-a37.glb'],{cwd:work,maxBuffer:128*1024*1024})
 assert.equal(r.status,0); assert.equal(sha(r.stdout),hash)
 writeFileSync(proof+'/'+gender+'.glb',r.stdout,{flag:'wx'})
 resources[gender]={bytes:r.stdout.length,sha256:hash,finalAvatar:false,sculptChanged:false}
}
writeFileSync(proof+'/authored-fixture.json',gunzipSync(readFileSync(work+'/bodyguard/docs/review/native-feedback/evidence/authored-fixture.json.gz')),{flag:'wx'})
writeFileSync(proof+'/assets.json',JSON.stringify(resources,null,2),{flag:'wx'})
const r=spawnSync('node',['scripts/prepare-assets.mjs'],{cwd:fe,encoding:'utf8'})
writeFileSync(proof+'/assets.stdout',r.stdout??'',{flag:'wx'});writeFileSync(proof+'/assets.stderr',r.stderr??'',{flag:'wx'});assert.equal(r.status,0)
console.log(JSON.stringify({modelCacheCopied:5,glbPreserved:2,networkDownloads:0,newSculpt:0}))
