import assert from 'node:assert/strict'
import {spawnSync} from 'node:child_process'
import {existsSync,lstatSync,readlinkSync,realpathSync,statSync,symlinkSync,writeFileSync,unlinkSync} from 'node:fs'
import {resolve} from 'node:path'
const proof="/private/tmp/bodyguard-native-feedback-proof.LHZ88F", db="/private/tmp/bodyguard-auth-test.mZQOez", main="/Applications/학교 내부/2026-2학기/오픈소스 AI SW 융합 프로젝트/BODYGUARD-native-startup-isolation", current="/Applications/학교 내부/2026-2학기/오픈소스 AI SW 융합 프로젝트/BODYGUARD-native-neck-observation"
const bin='/opt/homebrew/opt/postgresql@18/bin/', cache=resolve(main,'../BODYGUARD-owned-alert-lifecycle/bodyguard/frontend/node_modules')
assert.equal(realpathSync(db),db);assert.equal(statSync(db).uid,process.getuid());assert(!existsSync(db+'/data/postmaster.pid'))
assert(!existsSync(proof+'/counterbalanced.receipt.json'))
const steps=[], start=new Date().toISOString()
function run(name,cmd,args,options={}){
 const r=spawnSync(cmd,args,{encoding:'utf8',maxBuffer:32*1024*1024,...options})
 writeFileSync(proof+'/counter-'+name+'.log',(r.stdout??'')+(r.stderr??''),{flag:'wx'})
 const receipt={name,cmd,args,start:options.at??null,end:new Date().toISOString(),status:r.status,signal:r.signal}
 writeFileSync(proof+'/counter-'+name+'.receipt.json',JSON.stringify(receipt,null,2),{flag:'wx'})
 steps.push(receipt);console.log(name,r.status);return r
}
const links=[]
let started=false
try{
 for(const root of [main,current]){
  const link=root+'/bodyguard/frontend/node_modules', target='../../../BODYGUARD-owned-alert-lifecycle/bodyguard/frontend/node_modules'
  assert(!existsSync(link));symlinkSync(target,link);assert.equal(realpathSync(link),realpathSync(cache));links.push(link)
 }
 assert.equal(run('db-resume',bin+'pg_ctl',['-D',db+'/data','-l',db+'/postgres.log','-o',"-k "+db+" -c listen_addresses='' -p 5432",'-w','start']).status,0);started=true
 for(const [name,helper,label]of[
  ['main-first','browser.mjs','counter-main-first'],
  ['current-first','browser-current.mjs','counter-current-first'],
  ['current-last','browser-current.mjs','counter-current-last'],
  ['main-last','browser.mjs','counter-main-last']
 ]){
  run(name,'/opt/homebrew/bin/node',[proof+'/'+helper,'male',label,'existing'],{at:new Date().toISOString()})
 }
}finally{
 if(started)assert.equal(run('db-stop',bin+'pg_ctl',['-D',db+'/data','-m','fast','-w','stop']).status,0)
 assert(!existsSync(db+'/data/postmaster.pid'))
 for(const link of links){
  assert(lstatSync(link).isSymbolicLink());assert.equal(readlinkSync(link),'../../../BODYGUARD-owned-alert-lifecycle/bodyguard/frontend/node_modules');assert.equal(realpathSync(link),realpathSync(cache));unlinkSync(link)
 }
 writeFileSync(proof+'/counterbalanced.receipt.json',JSON.stringify({start,end:new Date().toISOString(),sequence:'main,current,current,main',steps,dbStopped:true,ownedLinksRemoved:true,rawDataRecorded:false,causalityEstablished:false},null,2),{flag:'wx'})
}
