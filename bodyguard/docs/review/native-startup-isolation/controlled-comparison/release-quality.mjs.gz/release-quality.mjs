// NFR-08: actual scoped commands against immutable source, preserve every stdout/stderr/receipt.
import assert from 'node:assert/strict'
import {spawnSync,execFileSync} from 'node:child_process'
import {readFileSync,readdirSync,writeFileSync} from 'node:fs'
import {createHash} from 'node:crypto'
const proof="/private/tmp/bodyguard-native-feedback-proof.LHZ88F",work="/Applications/학교 내부/2026-2학기/오픈소스 AI SW 융합 프로젝트/BODYGUARD-native-startup-isolation",fe=work+'/bodyguard/frontend'
const sha=b=>createHash('sha256').update(b).digest('hex')
const hash=()=>Object.fromEntries(execFileSync('git',['ls-files','-z','--cached','--others','--exclude-standard','bodyguard/frontend/src','bodyguard/frontend/e2e','bodyguard/frontend/scripts','bodyguard/frontend/package.json','bodyguard/frontend/pnpm-lock.yaml','bodyguard/frontend/tsconfig.json','bodyguard/frontend/vite.config.ts'],{cwd:work,encoding:'utf8'}).split('\0').filter(Boolean).map(path=>[path,sha(readFileSync(work+'/'+path))]))
const before=hash();writeFileSync(proof+'/release-quality-source-before.json',JSON.stringify(before,null,2),{flag:'wx'})
const receipts=[]
for(const[name,cmd,args,cwd]of[
 ['unit','node_modules/.bin/vitest',['run','--reporter=json','--outputFile='+proof+'/release-quality-unit.json'],fe],
 ['biome','node_modules/.bin/biome',['check','.'],fe],
 ['typecheck','node_modules/.bin/tsc',['--noEmit'],fe],
 ['assets','/opt/homebrew/bin/node',['scripts/prepare-assets.mjs'],fe],
 ['build','node_modules/.bin/vite',['build'],fe],
 ['guard','/opt/homebrew/bin/node',['scripts/check-selection-production.mjs'],fe],
 ['diff','git',['diff','--check'],work]
]){
 const start=new Date().toISOString(), r=spawnSync(cmd,args,{cwd,encoding:'utf8',maxBuffer:32*1024*1024})
 for(const key of ['stdout','stderr'])writeFileSync(proof+'/release-quality-'+name+'.'+key,r[key]??'',{flag:'wx'})
 const receipt={name,cmd,args,start,end:new Date().toISOString(),status:r.status,signal:r.signal}
 writeFileSync(proof+'/release-quality-'+name+'.receipt.json',JSON.stringify(receipt,null,2),{flag:'wx'})
 receipts.push(receipt);console.log(name,r.status)
}
const after=hash();writeFileSync(proof+'/release-quality-source-after.json',JSON.stringify(after,null,2),{flag:'wx'});assert.deepEqual(before,after)
const unit=JSON.parse(readFileSync(proof+'/release-quality-unit.json'));assert.equal(unit.numFailedTests,0);assert.equal(unit.numPendingTests,0);assert.equal(unit.numTotalTests,1336);assert.equal(unit.numPassedTests,1336)
const expected=JSON.parse(readFileSync("/Applications/학교 내부/2026-2학기/오픈소스 AI SW 융합 프로젝트/BODYGUARD-native-neck-observation/bodyguard/docs/review/native-neck/summary.json")).assets
const assets=readdirSync(fe+'/dist/assets').filter(name=>/^index-.*\.(js|css)$/.test(name)).sort().map(name=>{const bytes=readFileSync(fe+'/dist/assets/'+name);return{name,bytes:bytes.length,sha256:sha(bytes)}})
assert.deepEqual(assets,expected)
writeFileSync(proof+'/release-quality-result.json',JSON.stringify({source:before,receipts,unit:{total:unit.numTotalTests,passed:unit.numPassedTests,failed:unit.numFailedTests,skipped:unit.numPendingTests},newAnalysisTests:35,assets,publicBytesUnchanged:true,productCodeChanges:0,rootCauseResolved:false,pr90MandatoryGatePassed:false},null,2),{flag:'wx'})
assert(receipts.every(r=>r.status===0));console.log(JSON.stringify({unit:1336,newAnalysis:35,publicBytesUnchanged:true}))
