// NFR-08: bounded offline native timing analysis with originals/HEAD checks. No new native run.
import assert from 'node:assert/strict'
import {readFileSync,readdirSync,existsSync,writeFileSync} from 'node:fs'
import {execFileSync} from 'node:child_process'
import {createHash} from 'node:crypto'
import {gunzipSync} from 'node:zlib'
import {analyzeNativeStartupRuns} from "/Applications/학교 내부/2026-2학기/오픈소스 AI SW 융합 프로젝트/BODYGUARD-native-startup-isolation/bodyguard/frontend/e2e/fixtures/nativeStartupAnalysis.ts"
const proof="/private/tmp/bodyguard-native-feedback-proof.LHZ88F", baseline="/Applications/학교 내부/2026-2학기/오픈소스 AI SW 융합 프로젝트/BODYGUARD-native-startup-isolation",candidate="/Applications/학교 내부/2026-2학기/오픈소스 AI SW 융합 프로젝트/BODYGUARD-native-neck-observation", sha=b=>createHash('sha256').update(b).digest('hex'),json=p=>JSON.parse(readFileSync(p))
const evidence=[], input=[]
const assets=readFileSync(proof+'/assets.json')
assert.deepEqual(JSON.parse(assets),json('/private/tmp/bodyguard-native-neck-proof.8Stg1c/assets.json'))
const sdk=json(baseline+'/bodyguard/frontend/node_modules/@mediapipe/tasks-vision/package.json').version
const publicExpected=json(candidate+'/bodyguard/docs/review/native-neck/summary.json').assets
for(const[label,variant,root]of[
 ['baseline-main-timing','baseline',baseline],
 ['paired-current-timing','candidate',candidate],
 ['counter-main-first','baseline',baseline],
 ['counter-current-first','candidate',candidate],
 ['counter-current-last','candidate',candidate],
 ['counter-main-last','baseline',baseline]
]){
 const receiptPath=proof+'/browser-'+label+'.receipt.json',beforePath=proof+'/browser-'+label+'-source-before.json',afterPath=proof+'/browser-'+label+'-source-after.json'
 const receipt=json(receiptPath),before=json(beforePath),after=json(afterPath)
 assert.deepEqual(before,after);assert.equal(receipt.head,before.head)
 assert.equal(before.head,variant==='baseline'?'5a1a3d8ec1149cf029c486aee35de1dc33a2f167':'884700e3cebfce2b1c0c51fdca2cce4788e6dc4b')
 // These captures predate the new offline analyzer/tests. Compare immutable native code to exact executed HEAD,
 // not the later diagnostic additions or the repository's current HEAD.
 for(const[path,hash]of Object.entries(before.sources)){
  assert.equal(sha(readFileSync(root+'/'+path)),hash)
  assert.equal(sha(execFileSync('git',['show',before.head+':'+path],{cwd:root})),hash)
 }
 const reports=readdirSync(root+'/bodyguard/frontend/test-results').filter(x=>x.startsWith('nativefeedback-')).map(x=>root+'/bodyguard/frontend/test-results/'+x).filter(path=>{
  if(!existsSync(path+'/report.json'))return false
  const at=Date.parse(json(path+'/report.json').stats.startTime)
  return at>=Date.parse(receipt.start)&&at<=Date.parse(receipt.end)
 })
 assert.equal(reports.length,1); const folder=reports[0],reportPath=folder+'/report.json',report=json(reportPath)
 const specs=[];function walk(suite){specs.push(...suite.specs??[]);for(const child of suite.suites??[])walk(child)};for(const suite of report.suites)walk(suite)
 assert.equal(specs.length,1);assert.equal(specs[0].title,'male native first-start stage timing without raw input')
 const tests=specs[0].tests;assert.equal(tests.length,1);assert.equal(tests[0].results.length,1);assert.equal(tests[0].results[0].retry,0);assert.equal(tests[0].timeout,60000)
 const summaries=readdirSync(folder).filter(x=>existsSync(folder+'/'+x+'/native-hands-summary.json'));assert.equal(summaries.length,1)
 const summaryPath=folder+'/'+summaries[0]+'/native-hands-summary.json',summary=json(summaryPath),end=summary.final
 assert.equal(summary.external,0);assert.deepEqual(summary.errors,[]);assert.equal(end.nativePeopleMax,0);assert.equal(end.models,0)
 assert(end.tracksEnded&&end.allFramesClosed);assert.equal(end.frameCloses,end.frames);assert.equal(end.nativeCloses,end.nativeCalls)
 input.push({id:label,variant,gender:receipt.gender,head:before.head,beforeSha:sha(readFileSync(beforePath)),afterSha:sha(readFileSync(afterPath)),browser:summary.browser,sdk,assetsSha:sha(assets),receiptStart:receipt.start,reportStart:report.stats.startTime,receiptEnd:receipt.end,exitCode:receipt.status,pollMs:5000,caseTimeoutMs:tests[0].timeout,retries:0,fakeCamera:receipt.fakeCamera,actualPeople:receipt.actualPeople,physicalCamera:receipt.physicalCamera,stats:Object.fromEntries(['expected','unexpected','skipped','flaky'].map(k=>[k,report.stats[k]])),timing:end.startupTiming})
 evidence.push({label,receiptPath,beforePath,afterPath,reportPath,summaryPath})
}
const mandatory=[], totals={passed:0,failed:0,skipped:0}
const old=candidate+'/bodyguard/docs/review/native-neck',manifest=json(old+'/manifest.json')
for(const label of ['final-neck-male','final-neck-female','regression-male','regression-female']){
 const name='browser-report-'+label+'.json.gz',entry=manifest.find(x=>x.name===name),zip=readFileSync(old+'/'+name)
 assert(entry);assert.equal(sha(zip),entry.sha256);const bytes=gunzipSync(zip);assert.equal(sha(bytes),entry.originalSha256)
 const report=JSON.parse(bytes);assert.equal(report.stats.flaky,0)
 totals.passed+=report.stats.expected;totals.failed+=report.stats.unexpected;totals.skipped+=report.stats.skipped
 mandatory.push({label,sourcePath:old+'/'+name,sha256:entry.sha256,stats:report.stats})
}
assert.deepEqual(totals,{passed:13,failed:13,skipped:0})
assert(!existsSync('/private/tmp/bodyguard-auth-test.mZQOez/data/postmaster.pid'))
const analysis=analyzeNativeStartupRuns(input)
assert.equal(analysis.valid,true)
writeFileSync(proof+'/analysis-input.json',JSON.stringify(input,null,2),{flag:'wx'})
writeFileSync(proof+'/analysis-result.json',JSON.stringify({story:'S6.9',analysis,mandatory:{head:'884700e3cebfce2b1c0c51fdca2cce4788e6dc4b',totals,retestsReplaceMandatory:false,reports:mandatory},evidence,publicExpected,allStagesComplete:false,sourceGatePassed:true,actualChrome:true,actualSDK:true,actualAPI:true,isolatedSQL:true,fakeCamera:true,actualPeople:0,physicalCamera:false,dbStopped:true,rootCauseEstablished:false,globalStartupP2StillOpen:true,pr90RemainsDraft:true},null,2),{flag:'wx'})
console.log(JSON.stringify({analysis,mandatory:totals,rootCauseEstablished:false,globalStartupP2StillOpen:true},null,2))
