// NFR-08: collect exact originals without overwriting any earlier evidence or models.
import assert from 'node:assert/strict'
import {readFileSync,readdirSync,writeFileSync,mkdirSync} from 'node:fs'
import {createHash} from 'node:crypto'
import {gzipSync} from 'node:zlib'
const proof="/private/tmp/bodyguard-native-feedback-proof.LHZ88F",dest="/Applications/학교 내부/2026-2학기/오픈소스 AI SW 융합 프로젝트/BODYGUARD-native-startup-isolation/bodyguard/docs/review/native-startup-isolation/controlled-comparison",sha=b=>createHash('sha256').update(b).digest('hex')
mkdirSync(dest,{recursive:true})
const files=[]
const add=(path,name)=>files.push({path,name})
const result=JSON.parse(readFileSync(proof+'/analysis-result.json'))
for(const e of result.evidence){
 add(e.receiptPath,'receipt-'+e.label+'.json')
 add(e.beforePath,'source-before-'+e.label+'.json')
 add(e.afterPath,'source-after-'+e.label+'.json')
 add(e.reportPath,'report-'+e.label+'.json')
 add(e.summaryPath,'summary-'+e.label+'.json')
 add(proof+'/browser-'+e.label+'.stdout','browser-'+e.label+'.stdout')
 add(proof+'/browser-'+e.label+'.stderr','browser-'+e.label+'.stderr')
}
for(const item of result.mandatory.reports){
 // Already compressed originals are decompressed once below, preserving their original SHA.
 add(item.sourcePath,'mandatory-'+item.label+'.json')
}
for(const name of readdirSync(proof)){
 if(name.startsWith('counter-')||name.startsWith('release-quality-')||[
 'counterbalanced.mjs','counterbalanced.receipt.json','analyze.mjs','quality.mjs',
 'final-quality.mjs','release-quality.mjs','quality-result.json','final-quality-result.json',
 'assets.json','analysis-input.json','analysis-result.json','analysis-red.json','analysis-first.json',
 'analysis-green.json','analysis-review-red.json','analysis-reviewed-green.json'
 ].includes(name))add(proof+'/'+name,name)
}
const {gunzipSync}=await import('node:zlib')
const manifest=[],names=new Set()
for(const file of files){
 assert(!names.has(file.name));names.add(file.name)
 const raw=readFileSync(file.path),original=file.path.endsWith('.gz')?gunzipSync(raw):raw
 const compressed=gzipSync(original),name=file.name+'.gz'
 writeFileSync(dest+'/'+name,compressed,{flag:'wx'})
 manifest.push({name,bytes:compressed.length,sha256:sha(compressed),originalBytes:original.length,originalSha256:sha(original)})
}
assert(manifest.length<=128)
writeFileSync(dest+'/manifest.json',JSON.stringify(manifest.sort((a,b)=>a.name.localeCompare(b.name)),null,2),{flag:'wx'})
console.log(JSON.stringify({files:manifest.length,originalBytes:manifest.reduce((sum,x)=>sum+x.originalBytes,0),compressedBytes:manifest.reduce((sum,x)=>sum+x.bytes,0),modelsOrInputFramesCopied:false,previousEvidenceOverwritten:false}))
