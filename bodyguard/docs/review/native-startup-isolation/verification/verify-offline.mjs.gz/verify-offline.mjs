// NFR-08: same verifier bytes in owned offline positive/missing/corrupt fixtures.
import assert from 'node:assert/strict'
import {spawnSync} from 'node:child_process'
import {readFileSync,readdirSync,mkdirSync,copyFileSync,symlinkSync,writeFileSync,realpathSync,lstatSync,readlinkSync,unlinkSync,existsSync} from 'node:fs'
import {createHash} from 'node:crypto'
const proof="/private/tmp/bodyguard-native-feedback-proof.LHZ88F",work="/Applications/학교 내부/2026-2학기/오픈소스 AI SW 융합 프로젝트/BODYGUARD-native-startup-isolation",sha=b=>createHash('sha256').update(b).digest('hex'),receipts=[]
const script='bodyguard/frontend/scripts/verify-native-startup-isolation.mjs',module='bodyguard/frontend/e2e/fixtures/nativeStartupAnalysis.ts',data='bodyguard/docs/review/native-startup-isolation/controlled-comparison'
const current=JSON.parse(readFileSync(proof+'/release-quality-source-after.json'))
for(const[path,digest]of Object.entries(current))assert.equal(sha(readFileSync(work+'/'+path)),digest)
for(const mode of ['positive','missing','corrupt']){
 const target=proof+'/offline-'+mode,folder=target+'/'+data
 mkdirSync(folder,{recursive:true});mkdirSync(target+'/bodyguard/frontend/scripts',{recursive:true});mkdirSync(target+'/bodyguard/frontend/e2e/fixtures',{recursive:true})
 for(const relative of [script,module]){copyFileSync(work+'/'+relative,target+'/'+relative);assert.equal(sha(readFileSync(target+'/'+relative)),sha(readFileSync(work+'/'+relative)))}
 const affected='analysis-input.json.gz'
 for(const name of readdirSync(work+'/'+data)){
  if(name===affected&&mode==='missing')continue
  if(name===affected&&mode==='corrupt'){const bytes=Buffer.from(readFileSync(work+'/'+data+'/'+name));bytes[bytes.length-1]^=1;writeFileSync(folder+'/'+name,bytes,{flag:'wx'})}
  else copyFileSync(work+'/'+data+'/'+name,folder+'/'+name)
 }
 // Only read exact executed git objects; no git mutations in this fixture.
 symlinkSync(work+'/.git',target+'/.git');assert.equal(realpathSync(target+'/.git'),realpathSync(work+'/.git'))
 const start=new Date().toISOString(),r=spawnSync('/opt/homebrew/bin/node',[target+'/'+script],{cwd:target,encoding:'utf8',maxBuffer:10*1024*1024})
 for(const key of ['stdout','stderr'])writeFileSync(proof+'/offline-'+mode+'.'+key,r[key]??'',{flag:'wx'})
 const receipt={mode,start,end:new Date().toISOString(),status:r.status,signal:r.signal,sameVerifierBytes:true,sameAnalyzerBytes:true,offlineReplayOnly:true}
 writeFileSync(proof+'/offline-'+mode+'.receipt.json',JSON.stringify(receipt,null,2),{flag:'wx'});receipts.push(receipt)
 if(mode==='positive'){assert.equal(r.status,0);const output=JSON.parse(r.stdout);assert.equal(output.originalHashesVerified,true);assert.equal(output.analysis.productGatePassed,false);assert.deepEqual(output.mandatory,{passed:13,failed:13,skipped:0})}
 else{assert.equal(r.status,1);assert.equal(r.stdout,'');assert.equal(r.stderr,'Native startup evidence verification failed\n')}
 assert(lstatSync(target+'/.git').isSymbolicLink());assert.equal(readlinkSync(target+'/.git'),work+'/.git');unlinkSync(target+'/.git')
}
assert(!existsSync('/private/tmp/bodyguard-auth-test.mZQOez/data/postmaster.pid'))
const link=work+'/bodyguard/frontend/node_modules'
assert(lstatSync(link).isSymbolicLink());assert.equal(readlinkSync(link),'../../../BODYGUARD-owned-alert-lifecycle/bodyguard/frontend/node_modules');assert.equal(realpathSync(link),realpathSync(work+'/../BODYGUARD-owned-alert-lifecycle/bodyguard/frontend/node_modules'));unlinkSync(link)
writeFileSync(proof+'/offline-result.json',JSON.stringify({receipts,mandatoryFailuresPreserved:true,rootCauseResolved:false,productGatePassed:false,dbStopped:true,removedOwnedLinkOnly:true},null,2),{flag:'wx'})
console.log(JSON.stringify({receipts,rootCauseResolved:false,removedOwnedLinksOnly:true}))
