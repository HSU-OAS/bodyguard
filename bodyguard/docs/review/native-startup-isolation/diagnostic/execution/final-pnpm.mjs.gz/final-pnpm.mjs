#!/opt/homebrew/bin/node
// One unchanged native regression suite; no skips/retry/timeout overrides.
import assert from 'node:assert/strict'
import {spawnSync} from 'node:child_process'
const cwd="/Applications/학교 내부/2026-2학기/오픈소스 AI SW 융합 프로젝트/BODYGUARD-native-startup-isolation/bodyguard/frontend"
assert.equal(process.cwd(),cwd)
const[command,...args]=process.argv.slice(2)
const steps=command==='build'&&args.length===0
 ?[['/opt/homebrew/bin/node',['scripts/prepare-assets.mjs']],['node_modules/.bin/tsc',['--noEmit']],['node_modules/.bin/vite',['build']]]
 :command==='exec'&&args[0]==='playwright'?[['node_modules/.bin/playwright',args.slice(1)]]:null
assert(steps)
if(command==='exec'&&process.env.BODYGUARD_DIAGNOSTIC_REMAINING==='1')steps[0][1].push('--grep','(?:^| )female native held result→(?:logout|server401|pagehide|unmount)→no old resume/save$')
if(command==='exec'&&process.env.BODYGUARD_DIAGNOSTIC_HARDENED==='1')steps[0][1].push('--grep','(?:^| )male native first-start stage timing without raw input$')
for(const[cmd,a]of steps){const r=spawnSync(cmd,a,{cwd,env:process.env,stdio:'inherit'});if(r.status!==0)process.exit(r.status??1)}
