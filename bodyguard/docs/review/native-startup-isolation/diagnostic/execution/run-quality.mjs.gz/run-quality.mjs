import assert from 'node:assert/strict'
import {spawnSync,execFileSync} from 'node:child_process'
import {readFileSync,writeFileSync,readdirSync,mkdirSync,copyFileSync} from 'node:fs'
import {createHash} from 'node:crypto'
const proof="/private/tmp/bodyguard-native-feedback-proof.COdW5w",work="/Applications/학교 내부/2026-2학기/오픈소스 AI SW 융합 프로젝트/BODYGUARD-native-startup-isolation",fe=work+'/bodyguard/frontend'
const [label,scope]=process.argv.slice(2)
assert(/^[a-z][a-z-]+$/.test(label));assert(['type','all'].includes(scope))
const sha=b=>createHash('sha256').update(b).digest('hex'),git=(...a)=>execFileSync('git',a,{cwd:work,encoding:'utf8'})
const paths=()=>git('ls-files','-z','--cached','--others','--exclude-standard','bodyguard/frontend/src','bodyguard/frontend/e2e','bodyguard/frontend/scripts','bodyguard/frontend/package.json','bodyguard/frontend/pnpm-lock.yaml','bodyguard/frontend/tsconfig.json','bodyguard/frontend/vite.config.ts').split('\0').filter(Boolean)
const source=()=>Object.fromEntries(paths().map(p=>[p,sha(readFileSync(work+'/'+p))]))
const before=source();writeFileSync(proof+'/'+label+'-source-before.json',JSON.stringify({head:git('rev-parse','HEAD').trim(),sources:before},null,2),{flag:'wx'})
for(const p of paths().filter(p=>/nativeStartupDiagnostic|native-startup-diagnostic|nativeHeadAuthProbe|nativehead\.spec/.test(p))){const dst=proof+'/'+label+'-source/'+p;mkdirSync(dst.slice(0,dst.lastIndexOf('/')),{recursive:true});copyFileSync(work+'/'+p,dst,1)}
const commands=scope==='type'?[['typecheck','node_modules/.bin/tsc',['--noEmit'],fe]]:[
 ['unit','node_modules/.bin/vitest',['run','--reporter=json','--outputFile='+proof+'/'+label+'-unit.json'],fe],
 ['biome','node_modules/.bin/biome',['check','.'],fe],
 ['typecheck','node_modules/.bin/tsc',['--noEmit'],fe],
 ['assets','/opt/homebrew/bin/node',['scripts/prepare-assets.mjs'],fe],
 ['build','node_modules/.bin/vite',['build'],fe],
 ['guard','/opt/homebrew/bin/node',['scripts/check-selection-production.mjs'],fe],
 ['diff','git',['diff','--check'],work]
]
const receipts=[]
for(const[name,cmd,args,cwd] of commands){const start=new Date().toISOString(),r=spawnSync(cmd,args,{cwd,encoding:'utf8',maxBuffer:32*1024*1024});for(const k of ['stdout','stderr'])writeFileSync(proof+'/'+label+'-'+name+'.'+k,r[k]??'',{flag:'wx'});const receipt={name,cmd,args,start,end:new Date().toISOString(),status:r.status,signal:r.signal};writeFileSync(proof+'/'+label+'-'+name+'.receipt.json',JSON.stringify(receipt,null,2),{flag:'wx'});receipts.push(receipt);console.log(name,r.status)}
const after=source();writeFileSync(proof+'/'+label+'-source-after.json',JSON.stringify(after,null,2),{flag:'wx'});assert.deepEqual(before,after)
const result={receipts,sourceUnchanged:true}
if(scope==='all'){const unit=JSON.parse(readFileSync(proof+'/'+label+'-unit.json'));result.unit={total:unit.numTotalTests,passed:unit.numPassedTests,failed:unit.numFailedTests,skipped:unit.numPendingTests};result.assets=readdirSync(fe+'/dist/assets').filter(n=>/^index-.*\.(js|css)$/.test(n)).sort().map(name=>{const b=readFileSync(fe+'/dist/assets/'+name);return{name,bytes:b.length,sha256:sha(b)}});const expected=JSON.parse(readFileSync(work+'/bodyguard/docs/review/native-startup-isolation/author-review.json')).publicAssets;result.publicBytesUnchanged=result.assets.every(a=>[ 'b5d4f81164c8d3c196e853b3404382bc15077986aa626cd0c3c72571b6325ac0','043cb9bdb5d82a3baa9a8463c7a641cbe92ace213303f20c6c7f91e9a14ac82e'].includes(a.sha256));assert(result.publicBytesUnchanged);console.log(JSON.stringify(result.unit))}
writeFileSync(proof+'/'+label+'-result.json',JSON.stringify(result,null,2),{flag:'wx'})
process.exitCode=receipts.every(r=>r.status===0)?0:1
