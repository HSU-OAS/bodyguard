import assert from 'node:assert/strict'
import {spawnSync,execFileSync} from 'node:child_process'
import {readFileSync,writeFileSync,existsSync,statSync,realpathSync} from 'node:fs'
import {createHash} from 'node:crypto'
const proof="/private/tmp/bodyguard-native-feedback-proof.COdW5w",work="/Applications/학교 내부/2026-2학기/오픈소스 AI SW 융합 프로젝트/BODYGUARD-native-startup-isolation",db="/private/tmp/bodyguard-auth-test.mZQOez",fe=work+'/bodyguard/frontend'
assert.equal(realpathSync(db),db);assert.equal(statSync(db).uid,process.getuid());assert(!existsSync(db+'/data/postmaster.pid'))
const bin='/opt/homebrew/opt/postgresql@18/bin/',sha=b=>createHash('sha256').update(b).digest('hex'),git=(...a)=>execFileSync('git',a,{cwd:work,encoding:'utf8'})
const runId=process.argv[2]??'';assert(['','actual'].includes(runId))
const source=()=>Object.fromEntries(git('ls-files','-z','--cached','--others','--exclude-standard','bodyguard/frontend/src','bodyguard/frontend/e2e','bodyguard/backend/tests/run_browser.py').split('\0').filter(Boolean).map(p=>[p,sha(readFileSync(work+'/'+p))]))
function run(label,cmd,args,options={}){label=(runId?runId+'-':'')+label;const start=new Date().toISOString(),r=spawnSync(cmd,args,{encoding:'utf8',maxBuffer:64*1024*1024,...options});for(const k of ['stdout','stderr'])writeFileSync(proof+'/'+label+'.'+k,r[k]??'',{flag:'wx'});writeFileSync(proof+'/'+label+'.receipt.json',JSON.stringify({cmd,args,start,end:new Date().toISOString(),status:r.status,signal:r.signal},null,2),{flag:'wx'});console.log(label,r.status);return r}
let started=false
try{
 assert.equal(run('db-start',bin+'pg_ctl',['-D',db+'/data','-l',db+'/postgres.log','-o',"-k "+db+" -c listen_addresses='' -p 5432",'-w','start']).status,0);started=true
 assert.equal(run('db-identity',bin+'psql',['-h',db,'-U','bodyguard_test','-d','bodyguard_test','-At','-c',"SELECT current_database(),current_user,current_setting('server_version'),current_setting('listen_addresses');"]).status,0)
 const before=source(),head=git('rev-parse','HEAD').trim();writeFileSync(proof+'/browser-source-before.json',JSON.stringify({head,sources:before},null,2),{flag:'wx'})
 const env={...process.env,PATH:proof+'/bin:'+fe+'/node_modules/.bin:'+process.env.PATH,BODYGUARD_TEST_NATIVE_FEEDBACK_PROBE:proof+'/probe-diagnostic',BODYGUARD_TEST_NATIVE_STARTUP_DIAGNOSTICS:'1',BODYGUARD_TEST_DATABASE_URL:'postgresql+psycopg://bodyguard_test@/bodyguard_test?host='+db}
 delete env.BODYGUARD_TEST_NATIVE_NECK;delete env.BODYGUARD_NATIVE_TEST_GENDER;delete env.BODYGUARD_NATIVE_TEST_SCOPE
 const r=run('browser','/Applications/학교 내부/2026-2학기/오픈소스 AI SW 융합 프로젝트/BODYGUARD-account-web/bodyguard/backend/.venv/bin/python',['-m','tests.run_browser','nativefeedback'],{cwd:work+'/bodyguard/backend',env})
 const after=source();writeFileSync(proof+'/browser-source-after.json',JSON.stringify({head,sources:after},null,2),{flag:'wx'});assert.deepEqual(before,after)
 process.exitCode=r.status??1
}finally{
 if(started)assert.equal(run('db-stop',bin+'pg_ctl',['-D',db+'/data','-m','fast','-w','stop']).status,0)
 assert(!existsSync(db+'/data/postmaster.pid'))
}
