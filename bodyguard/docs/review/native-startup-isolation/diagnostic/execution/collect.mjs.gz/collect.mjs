// Mechanical preservation of actual reports and technical diagnostics; no images/models/body input.
import assert from 'node:assert/strict'
import {execFileSync,spawnSync} from 'node:child_process'
import {readFileSync,writeFileSync,readdirSync,statSync,existsSync,mkdirSync} from 'node:fs'
import {createHash} from 'node:crypto'
import {gzipSync} from 'node:zlib'
const proof="/private/tmp/bodyguard-native-feedback-proof.COdW5w",work="/Applications/학교 내부/2026-2학기/오픈소스 AI SW 융합 프로젝트/BODYGUARD-native-startup-isolation",fe=work+'/bodyguard/frontend',destination=work+'/bodyguard/docs/review/native-startup-isolation/diagnostic'
assert(!existsSync(destination));assert(!existsSync('/private/tmp/bodyguard-auth-test.mZQOez/data/postmaster.pid'))
const sha=b=>createHash('sha256').update(b).digest('hex'),json=p=>JSON.parse(readFileSync(p)),git=(...a)=>execFileSync('git',a,{cwd:work,encoding:'utf8'})
const phases=[['initial','nativefeedback-20261008T154224067997Z',20,4],['remaining','nativefeedback-20261008T154716753810Z',4,0],['hardened','nativefeedback-20261008T154948203428Z',1,0]]
const cases=[],rawFiles=[]
for(const[phase,folder,passed,failed]of phases){
 const root=fe+'/test-results/'+folder,report=json(root+'/report.json')
 assert.equal(report.stats.expected,passed);assert.equal(report.stats.unexpected,failed);assert.equal(report.stats.skipped,0);assert.equal(report.stats.flaky,0)
 const specs=[];function walk(s){specs.push(...s.specs??[]);for(const c of s.suites??[])walk(c)};for(const s of report.suites)walk(s)
 assert.equal(specs.length,passed+failed)
 rawFiles.push([phase+'/report.json',root+'/report.json'])
 const diagnosticRows=[]
 for(const name of readdirSync(root)){
  const dir=root+'/'+name;if(!statSync(dir).isDirectory())continue
  for(const file of ['native-hands-summary.json','native-startup-timing.json','before-close.json','error-context.md'])if(existsSync(dir+'/'+file))rawFiles.push([phase+'/'+name+'/'+file,dir+'/'+file])
  if(!existsSync(dir+'/native-hands-summary.json'))continue
  const summary=json(dir+'/native-hands-summary.json')
  assert.equal(summary.actualHuman,false);assert.equal(summary.actualCamera,false)
  assert.equal(summary.external,0);assert.equal(summary.errors.length,0)
  const value=summary.final?.startupDiagnostic?summary.final:[...summary.stages].reverse().find(s=>s.snapshot?.startupDiagnostic)?.snapshot
  assert(value?.startupDiagnostic);const diagnostic=value.startupDiagnostic,timing=value.startupTiming
  assert.equal(diagnostic.invalid,false);assert.equal(diagnostic.closed,true);assert.equal(diagnostic.observerState,'closed');assert(diagnostic.events.length<=30);assert(diagnostic.longTasks.length<=64)
  const cameras=diagnostic.events.filter(e=>e.stage==='camera'),boundary=cameras[1]?.startMs??Infinity
  const firstSdk=diagnostic.events.filter(e=>e.stage.endsWith('-sdk')&&e.startMs<boundary)
  const firstResult=timing.events.find(e=>e.stage==='result')
  diagnosticRows.push({name,cameraCount:cameras.length,eventsTruncated:diagnostic.eventsTruncated,longTasksTruncated:diagnostic.longTasksTruncated,filesetCallDurationsMs:diagnostic.events.filter(e=>e.stage==='fileset').map(e=>e.endMs===null?null:e.endMs-e.startMs),sdkAttempts:diagnostic.events.filter(e=>e.stage.endsWith('-sdk')),firstSdkEndMs:Math.max(...firstSdk.map(e=>e.endMs??-Infinity)),firstResultEndMs:firstResult?.endMs??null,firstResultDurationMs:firstResult?.endMs===null||!firstResult?null:firstResult.endMs-firstResult.startMs,longTasks:diagnostic.longTasks})
 }
 assert.equal(diagnosticRows.length,passed)
 const rows=specs.map(spec=>{assert.equal(spec.tests.length,1);const t=spec.tests[0];assert.equal(t.timeout,60000);assert.equal(t.results.length,1);assert.equal(t.results[0].retry,0);return{title:spec.title,status:t.results[0].status,primaryError:t.results[0].error?.message??null}})
 if(phase==='initial')for(const row of rows.filter(r=>r.status==='failed'))assert(/Received:[\s\S]*429/.test(row.primaryError))
 cases.push({phase,startTime:report.stats.startTime,stats:report.stats,rows,diagnosticRows})
}
const quality=json(proof+'/hardened-result.json');assert.deepEqual(quality.unit,{total:1352,passed:1352,failed:0,skipped:0});assert(quality.receipts.every(r=>r.status===0)&&quality.publicBytesUnchanged)
for(const prefix of ['','remaining-','hardened-']){const before=json(proof+'/'+prefix+'browser-source-before.json'),after=json(proof+'/'+prefix+'browser-source-after.json');assert.deepEqual(before,after)}
const finalSource=json(proof+'/hardened-source-before.json').sources,finalNativeSource=json(proof+'/hardened-browser-source-before.json').sources
for(const[path,hash]of Object.entries(finalSource))assert.equal(sha(readFileSync(work+'/'+path)),hash)
for(const[path,hash]of Object.entries(finalNativeSource))if(finalSource[path])assert.equal(finalSource[path],hash)
const offlineStart=new Date().toISOString(),offline=spawnSync('/opt/homebrew/bin/node',['scripts/verify-native-startup-isolation.mjs'],{cwd:fe,encoding:'utf8'})
for(const k of ['stdout','stderr'])writeFileSync(proof+'/offline.'+k,offline[k]??'',{flag:'wx'})
writeFileSync(proof+'/offline.receipt.json',JSON.stringify({command:['node','scripts/verify-native-startup-isolation.mjs'],start:offlineStart,end:new Date().toISOString(),status:offline.status},null,2),{flag:'wx'});assert.equal(offline.status,0)
const results={scope:'Private diagnostic baseline, not PR90 neck regression',cases,firstBatch:{passed:20,failed:4,reason:'signup429 before camera; cleanup SecurityError also retained'},previouslyUnexecutedSdkCases:{passed:4,failed:0,isolatedFreshTestSchema:true,securityRateLimitsUnchanged:true},postLiteralBoundaryFix:{passed:1,failed:0,representativeOnly:true},unit:quality.unit,newDiagnosticTests:16,assets:quality.assets,rootCauseEstablished:false,oldStartupFailureReproduced:false,previousPr90Mandatory:{passed:13,failed:13,replaced:false},productOrPublicUIChanged:false,actualPeople:0,physicalCameras:0,dbStopped:true,allStagesComplete:false}
writeFileSync(proof+'/diagnostic-result.json',JSON.stringify(results,null,2),{flag:'wx'})
for(const n of readdirSync(proof)){if(/\.(?:json|stdout|stderr|mjs|ts)$/.test(n)&&statSync(proof+'/'+n).isFile())rawFiles.push(['execution/'+n,proof+'/'+n])}
for(const label of ['final','type-red','hardened']){function add(dir,relative=''){for(const e of readdirSync(dir,{withFileTypes:true})){const p=dir+'/'+e.name,r=relative+e.name;if(e.isDirectory())add(p,r+'/');else rawFiles.push(['source/'+label+'/'+r,p])}}add(proof+'/'+label+'-source')}
rawFiles.push(['execution/final-pnpm.mjs',proof+'/bin/pnpm'])
const inputs=rawFiles.map(([name,path])=>({name,path}));assert.equal(new Set(inputs.map(i=>i.name)).size,inputs.length)
mkdirSync(destination,{recursive:true});const manifest=[]
for(const{name,path}of inputs){const original=readFileSync(path);assert(original.length<=8*1024*1024);const zip=gzipSync(original),file=name+'.gz',dst=destination+'/'+file;mkdirSync(dst.slice(0,dst.lastIndexOf('/')),{recursive:true});writeFileSync(dst,zip,{flag:'wx'});manifest.push({file,originalBytes:original.length,originalSha256:sha(original),compressedBytes:zip.length,compressedSha256:sha(zip)})}
for(const prefix of ['probe-diagnostic','probe-remaining','probe-hardened']){const b=readFileSync(proof+'/'+prefix+'/probe.js');manifest.push({preservedTemporaryFile:prefix+'/probe.js',bytes:b.length,sha256:sha(b),committed:false})}
writeFileSync(destination+'/manifest.json',JSON.stringify({entries:manifest,rootCauseEstablished:false,oldMandatoryFailurePreserved:true},null,2),{flag:'wx'})
console.log(JSON.stringify({artifacts:inputs.length,quality:1352,initial:'20pass/4signup failures',remaining:'4pass',hardened:'1pass',causalityEstablished:false}))
