import assert from 'node:assert/strict'
import {readFileSync,copyFileSync,constants} from 'node:fs'
import {createHash} from 'node:crypto'
const source="/private/tmp/bodyguard-native-feedback-proof.LHZ88F",target="/private/tmp/bodyguard-native-feedback-proof.COdW5w"
const assets=JSON.parse(readFileSync(source+'/assets.json'))
for(const name of ['male.glb','female.glb','authored-fixture.json','assets.json']){
 const input=source+'/'+name;copyFileSync(input,target+'/'+name,constants.COPYFILE_EXCL)
 assert.deepEqual(readFileSync(input),readFileSync(target+'/'+name))
 if(name.endsWith('.glb'))assert.equal(createHash('sha256').update(readFileSync(input)).digest('hex'),assets[name.split('.')[0]].sha256)
}
console.log('Original A37/assets preserved, no sculpt/export/download')
