import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {execFileSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import {gzipSync} from 'node:zlib';
import {createRequire} from 'node:module';
const work="/Applications/학교 내부/2026-2학기/오픈소스 AI SW 융합 프로젝트/BODYGUARD-native-hands",proof="/private/tmp/bodyguard-native-hands-proof.0unYMn",positive="/private/tmp/bodyguard-hand-proof.wleKdM",headProbe="/private/tmp/bodyguard-native-body-head-proof.B4uEUh",runtime="af6656e9a8b1345c7e9dafc7fb52d2b3a789b12c";
const sha=b=>createHash('sha256').update(b).digest('hex'),json=p=>JSON.parse(fs.readFileSync(p));
const dir=work+'/bodyguard/docs/review/native-hands',dst=dir+'/evidence';
assert(!fs.existsSync(dst));fs.mkdirSync(dst,{recursive:true});
const evidence=[];
function add(name,b,compress=false){const original=b;if(compress){name+='.gz';b=gzipSync(b);}fs.writeFileSync(dst+'/'+name,b,{flag:'wx'});evidence.push({file:name,bytes:b.length,sha256:sha(b),...(compress?{originalSha256:sha(original)}:{})});}
for(const n of fs.readdirSync(proof).filter(n=>/\.(json|log|mjs|js)$/.test(n)).sort())add(n,fs.readFileSync(proof+'/'+n),true);
add('pnpm-test-launcher',fs.readFileSync(proof+'/bin/pnpm'),true);
for(const [label,d]of [['native-final',proof+'/probe'],['head-regression',headProbe+'/probe'],['generated-positive',positive+'/probe']])add(label+'-probe.js',fs.readFileSync(d+'/probe.js'),true);
const receipts={native:json(proof+'/browser-final-receipt.json'),head:json(proof+'/browser-head-regression-receipt.json'),positive:json(proof+'/positive-browser-final.json')};
for(const r of Object.values(receipts)){assert.equal(r.head,runtime);assert.equal(r.exit,0);assert.deepEqual(r.sourceBefore,r.sourceAfter);}
const checks=json(proof+'/final-checks-final.json');assert.equal(checks.head,runtime);assert(checks.results.every(r=>r.exit===0));
const unit=json(proof+'/frontend-final.json');assert.equal(unit.numFailedTests,0);assert.equal(unit.numPendingTests,0);
assert.equal(json(proof+'/guard-intentional-red.json').exit,1);assert.equal(json(proof+'/guard-restored-green.json').exit,0);
assert.equal(json(proof+'/ruff-final.json').exit,0);assert.equal(json(proof+'/db-stop-receipt.json').exit,0);
const results=work+'/bodyguard/frontend/test-results',all=fs.readdirSync(results).filter(n=>/^(nativehands|nativehead)-/.test(n)).sort();
const browsers=[];
for(const run of all){
 const root=results+'/'+run,report=json(root+'/report.json');
 assert.equal(report.stats.expected,12);assert.equal(report.stats.unexpected,0);assert.equal(report.stats.skipped,0);assert.equal(report.stats.flaky,0);assert.equal(report.errors.length,0);
 add(run+'-report.json',fs.readFileSync(root+'/report.json'),true);
 const withHands=run.startsWith('nativehands'),finalNative=run===all.filter(n=>n.startsWith('nativehands')).at(-1),finalHead=run.startsWith('nativehead');
 const traces=[];
 for(const caseName of fs.readdirSync(root).filter(n=>fs.statSync(root+'/'+n).isDirectory())){
  const summaryName=withHands?'native-hands-summary.json':'native-head-summary.json',file=root+'/'+caseName+'/'+summaryName;
  if(!fs.existsSync(file))continue;
  const trace=json(file);assert.equal(trace.external,0);assert.deepEqual(trace.errors,[]);
  const closed=trace.final??trace.stages.find(s=>s.name==='native-closed-before-public-record')?.snapshot;
  assert(closed);assert.equal(closed.models,0);assert(closed.tracksEnded&&closed.detached&&closed.allFramesClosed);assert.equal(closed.nativeCloses,closed.nativeCalls);assert.equal(closed.frameCloses,closed.frames);assert.equal(closed.frameErrors,0);assert(closed.sameInput);assert.equal(closed.faceCalls,closed.nativeCalls);assert.equal(closed.handCalls,withHands?closed.nativeCalls:0);assert.equal(closed.handDetectorCloses,withHands?closed.cameras:0);assert.equal(closed.nativeHandsMax,0);assert.equal(closed.nativePeopleMax,0);assert.equal(closed.nativeFacesMax,0);assert.deepEqual(closed.memory,closed.baseline);
  add(run+'-'+caseName+'-'+summaryName,fs.readFileSync(file),true);
  traces.push({case:caseName,browser:trace.browser,posts:trace.posts,counters:trace.counters,closed:{sameInput:closed.sameInput,nativePeopleMax:closed.nativePeopleMax,nativeFacesMax:closed.nativeFacesMax,nativeHandsMax:closed.nativeHandsMax,cameras:closed.cameras,bodyCalls:closed.nativeCalls,faceCalls:closed.faceCalls,handCalls:closed.handCalls,handCloses:closed.handDetectorCloses}});
  for(const gender of ['male','female'])for(const [kind,name]of [['avatar','avatar-'+gender+'.png'],['record','native-record-'+gender+'.png']]){
   if(!fs.existsSync(root+'/'+caseName+'/'+name))continue;
   add(run+'-'+name,fs.readFileSync(root+'/'+caseName+'/'+name));
   if(finalNative)add('native-final-'+gender+'-'+kind+'.png',fs.readFileSync(root+'/'+caseName+'/'+name));
   if(finalHead)add('head-regression-'+gender+'-'+kind+'.png',fs.readFileSync(root+'/'+caseName+'/'+name));
  }
 }
 assert.equal(traces.length,12);browsers.push({run,withHands,stats:report.stats,traces});
}
const generated=json(positive+'/browser-native-integration.json');assert.equal(generated.head,runtime);assert.deepEqual(generated.sourceBefore,generated.sourceAfter);assert.equal(generated.external,0);assert.equal(generated.camera,0);assert.deepEqual(generated.errors,[]);assert(generated.samples.length===2&&generated.samples.every(s=>s.passed));
add('generated-positive-result.json',fs.readFileSync(positive+'/browser-native-integration.json'),true);
add('reused-authored-read.json',fs.readFileSync(positive+'/authored-read.json'),true);
for(const gender of ['male','female'])for(const pose of ['bend','turn'])add('generated-positive-'+gender+'-'+pose+'.png',fs.readFileSync(positive+'/native-integration-'+gender+'-'+pose+'.png'));
const sourceNames=[
 'bodyguard/frontend/src/coaching/nativePlaybackResources.ts','bodyguard/frontend/src/coaching/nativePlaybackResources.test.ts','bodyguard/frontend/src/coaching/ownedPlaybackResources.ts','bodyguard/frontend/src/coaching/resources.ts','bodyguard/frontend/src/coaching/useRecordedCoaching.ts',
 'bodyguard/frontend/src/pose/bodyHandVideoSource.ts','bodyguard/frontend/src/pose/bodyHandVideoSource.test.ts','bodyguard/frontend/src/pose/bodyFaceVideoSource.ts','bodyguard/frontend/src/pose/videoPoseSource.ts','bodyguard/frontend/src/pose/ownedPoseFrame.ts','bodyguard/frontend/src/pose/hands.ts','bodyguard/frontend/src/pose/face.ts','bodyguard/frontend/src/pose/landmarker.ts','bodyguard/frontend/src/pose/camera.ts',
 'bodyguard/frontend/src/avatar/ownedAvatarPair.ts','bodyguard/frontend/src/avatar/observedHandRig.ts','bodyguard/frontend/src/avatar/observedPoseRig.ts','bodyguard/frontend/src/avatar/eightWeightSkin.ts',
 'bodyguard/frontend/e2e/fixtures/nativeHeadAuthProbe.ts','bodyguard/frontend/e2e/fixtures/nativeHead.vite.ts','bodyguard/frontend/e2e/nativehead.spec.ts','bodyguard/frontend/e2e/nativehands.spec.ts','bodyguard/frontend/e2e/fixtures/observedHandsProbe.ts','bodyguard/frontend/scripts/test-observed-hands-browser.mjs','bodyguard/frontend/scripts/check-selection-production.mjs','bodyguard/frontend/playwright.account.config.ts','bodyguard/backend/tests/run_browser.py','bodyguard/backend/tests/conftest.py','bodyguard/frontend/pnpm-lock.yaml'];
const source=Object.fromEntries(sourceNames.map(n=>{const b=execFileSync('git',['show',runtime+':'+n],{cwd:work,maxBuffer:10000000});assert.equal(sha(b),sha(fs.readFileSync(work+'/'+n)));return[n,sha(b)];}));
const expected={js:'b5d4f81164c8d3c196e853b3404382bc15077986aa626cd0c3c72571b6325ac0',css:'043cb9bdb5d82a3baa9a8463c7a641cbe92ace213303f20c6c7f91e9a14ac82e'},publicDir=work+'/bodyguard/frontend/dist',files=fs.readdirSync(publicDir+'/assets').filter(n=>/\.(js|css)$/.test(n));
assert.equal(files.length,2);
const publicAssets=files.map(n=>{const b=fs.readFileSync(publicDir+'/assets/'+n),s=sha(b);assert.equal(s,expected[n.split('.').at(-1)]);return{name:n,bytes:b.length,sha256:s};});
assert.equal(fs.readdirSync(publicDir,{recursive:true}).filter(n=>n.endsWith('.glb')).length,0);
const modelNames=fs.readdirSync(publicDir+'/models').filter(n=>n.endsWith('.task'));assert.equal(modelNames.length,5);
const models=modelNames.map(n=>{const b=fs.readFileSync(publicDir+'/models/'+n);assert.equal(sha(b),sha(fs.readFileSync("/Applications/학교 내부/2026-2학기/오픈소스 AI SW 융합 프로젝트/BODYGUARD-owned-alert-lifecycle"+'/bodyguard/frontend/public/models/'+n)));return{name:n,bytes:b.length,sha256:sha(b)};});
const notices=dir+'/notices';fs.mkdirSync(notices,{recursive:true});
const licenses=[];
for(const name of ['three','react','react-dom','scheduler']){
 const packageFile=name==='scheduler'?createRequire(work+'/bodyguard/frontend/node_modules/react-dom/package.json').resolve('scheduler/package.json'):work+'/bodyguard/frontend/node_modules/'+name+'/package.json';
 const pkg=json(packageFile),b=fs.readFileSync(path.dirname(packageFile)+'/LICENSE');
 fs.writeFileSync(notices+'/'+name+'-MIT.txt',b,{flag:'wx'});licenses.push({name,version:pkg.version,declared:pkg.license,installedLicenseSha256:sha(b)});
}
fs.copyFileSync(work+'/bodyguard/docs/review/native-body-head/notices/Apache-2.0.txt',notices+'/Apache-2.0.txt',fs.constants.COPYFILE_EXCL);
const sdk=json(work+'/bodyguard/frontend/node_modules/@mediapipe/tasks-vision/package.json');licenses.push({name:sdk.name,version:sdk.version,declared:sdk.license,rootLicenseOrNoticeFound:false,canonicalApacheTextNotInstalledOriginal:true});
const summary={runtime,baseline:'3841f3b6403dcc2758826f2df86af593e96ffa81',source,evidence,frontend:{passed:unit.numPassedTests,failed:0,pending:0},checks:checks.results,browsers,generatedPositive:{browser:generated.browser,samples:generated.samples.map(s=>({gender:s.gender,passed:s.passed,states:s.stages.length})),actualSdk:false,actualHuman:false,actualCamera:false},assets:json(proof+'/asset-preparation.json'),publicAssets,models,licenses,nativeHandConnection:true,actualNativePositive:false,actualHuman:false,actualPhysicalCamera:false,newSculptOrGlb:false,finalAppearanceApproved:false,publicUiChanged:false,productionSdkPolicyChanged:false,clinicalThresholdsChanged:false,qualifiedReleaseMotions:0,stagesComplete:false,review:{kind:'author security/performance/correctness/acceptance review; not independent reviewer',unresolvedStoryP1P2:0},limitations:['shared input and SDK side labels are not same-person proof','generated positive display is not native or participant accuracy','unmeasured neck/trunk/metacarpal/axial twist and clinical feedback remain','renderer PBR baseline cache is not whole GPU/worker/long-session proof','production SDK egress, rights, approved design, final appearance, physical cameras and all release gates remain']};
fs.writeFileSync(dir+'/summary.json',JSON.stringify(summary,null,2),{flag:'wx'});console.log(JSON.stringify({runtime,sources:sourceNames.length,evidence:evidence.length,frontend:summary.frontend,browserRuns:browsers.map(r=>({run:r.run,stats:r.stats})),publicAssets}));
