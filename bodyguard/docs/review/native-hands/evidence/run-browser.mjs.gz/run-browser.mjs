import {readFileSync,writeFileSync,existsSync} from 'node:fs';
import {spawnSync,execFileSync} from 'node:child_process';
import {createHash} from 'node:crypto';
const [work,proof,db,python,label,suite='nativehands']=process.argv.slice(2);
if(work!=="/Applications/학교 내부/2026-2학기/오픈소스 AI SW 융합 프로젝트/BODYGUARD-native-hands"||proof!=="/private/tmp/bodyguard-native-hands-proof.0unYMn"||db!=="/private/tmp/bodyguard-auth-test.aGJm2Z"||!['nativehands','nativehead'].includes(suite)||!/^[a-z0-9-]+$/.test(label))throw Error('Owned scope required');
if(existsSync(proof+'/browser-'+label+'-receipt.json')||existsSync(proof+'/browser-'+label+'.log'))throw Error('Preserve browser evidence');
const env={...process.env,PATH:proof+'/bin:'+work+'/bodyguard/frontend/node_modules/.bin:'+process.env.PATH,
 BODYGUARD_TEST_DATABASE_URL:'postgresql+psycopg://bodyguard_test@/bodyguard_test?host='+db};
for(const key of ['BODYGUARD_TEST_COACHING_AUTH_PROBE','BODYGUARD_TEST_NATIVE_AUTH_PROBE','BODYGUARD_TEST_NATIVE_RECOVERY_PROBE','BODYGUARD_TEST_NATIVE_HEAD_PROBE','BODYGUARD_TEST_NATIVE_HANDS_PROBE'])delete env[key];
env[suite==='nativehands'?'BODYGUARD_TEST_NATIVE_HANDS_PROBE':'BODYGUARD_TEST_NATIVE_HEAD_PROBE']=suite==='nativehands'?proof+'/probe':process.env.BODYGUARD_HEAD_REGRESSION_PROBE;
if(!env[suite==='nativehands'?'BODYGUARD_TEST_NATIVE_HANDS_PROBE':'BODYGUARD_TEST_NATIVE_HEAD_PROBE'])throw Error('Probe required');
const names=['bodyguard/frontend/src/coaching/nativePlaybackResources.ts','bodyguard/frontend/src/pose/bodyHandVideoSource.ts','bodyguard/frontend/src/pose/videoPoseSource.ts','bodyguard/frontend/src/avatar/observedHandRig.ts','bodyguard/frontend/src/pose/hands.ts','bodyguard/frontend/e2e/fixtures/nativeHeadAuthProbe.ts','bodyguard/frontend/e2e/nativehead.spec.ts','bodyguard/frontend/e2e/nativehands.spec.ts','bodyguard/frontend/e2e/fixtures/nativeHead.vite.ts','bodyguard/frontend/playwright.account.config.ts','bodyguard/backend/tests/run_browser.py'];
const hashes=()=>Object.fromEntries(names.map(n=>[n,createHash('sha256').update(readFileSync(work+'/'+n)).digest('hex')]));
const before=hashes(),started=new Date().toISOString();
const r=spawnSync(python,['-m','tests.run_browser',suite],{cwd:work+'/bodyguard/backend',env,maxBuffer:50*1024*1024});
writeFileSync(proof+'/browser-'+label+'.log',Buffer.concat([r.stdout??Buffer.alloc(0),r.stderr??Buffer.alloc(0)]),{flag:'wx'});
const receipt={started,finished:new Date().toISOString(),command:[python,'-m','tests.run_browser',suite],exit:r.status,signal:r.signal,head:execFileSync('git',['rev-parse','HEAD'],{cwd:work,encoding:'utf8'}).trim(),sourceBefore:before,sourceAfter:hashes(),actualApiDbAuthProvider:true,actualSdk:true,fakeCamera:true,fakeMail:true,heldResult:'test-only async wrapper after native final result',actualHuman:false,actualPhysicalCamera:false,actualNativePositive:false,productSdkPolicyApproved:false};
writeFileSync(proof+'/browser-'+label+'-receipt.json',JSON.stringify(receipt,null,2),{flag:'wx'});
console.log(JSON.stringify(receipt));process.exitCode=r.status??1;
