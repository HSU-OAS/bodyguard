import assert from 'node:assert/strict';
import {readFileSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
const root="/private/tmp/bodyguard-native-hands-proof.0unYMn",positive="/private/tmp/bodyguard-hand-proof.wleKdM",head="/private/tmp/bodyguard-native-body-head-proof.B4uEUh",old='/private/tmp/bodyguard-hand-proof.UXNzqK';
const sha=b=>createHash('sha256').update(b).digest('hex');
const records=[];
for(const gender of ['male','female']){
 const b=readFileSync(root+'/'+gender+'.glb');
 for(const dir of [positive,head])writeFileSync(dir+'/'+gender+'.glb',b,{flag:'wx'});
 records.push({gender,bytes:b.length,sha256:sha(b)});
}
const authored=readFileSync(old+'/authored-read.json');
assert.equal(JSON.parse(authored).exit,0);
writeFileSync(positive+'/authored-read.json',authored,{flag:'wx'});
writeFileSync(root+'/regression-asset-provenance.json',JSON.stringify({assets:records,authoredRead:{source:old+'/authored-read.json',sha256:sha(authored),reexecutedBlender:false,originalAssetUnchanged:true},generatedPositiveIsActualNativePositive:false},null,2),{flag:'wx'});
console.log('Owned regression assets copied; original read-only Blender inspection reused, not reexecuted.');
