import {mkdirSync,copyFileSync,constants} from 'node:fs';
const root="/private/tmp/bodyguard-native-hands-proof.0unYMn";
mkdirSync(root+'/guard/scripts',{recursive:true});
copyFileSync("/Applications/학교 내부/2026-2학기/오픈소스 AI SW 융합 프로젝트/BODYGUARD-native-hands/bodyguard/frontend/scripts/check-selection-production.mjs",root+'/guard/scripts/check-selection-production.mjs',constants.COPYFILE_EXCL);
copyFileSync(root+'/guard/dist/assets/private-leak.js',root+'/guard-original-private-leak.js',constants.COPYFILE_EXCL);
