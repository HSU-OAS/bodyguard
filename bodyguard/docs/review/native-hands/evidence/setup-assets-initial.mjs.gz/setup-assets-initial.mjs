import assert from 'node:assert/strict';
import {readFileSync,writeFileSync,mkdirSync,readdirSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
const work="/Applications/학교 내부/2026-2학기/오픈소스 AI SW 융합 프로젝트/BODYGUARD-native-hands",proof="/private/tmp/bodyguard-native-hands-proof.0unYMn",base="/Applications/학교 내부/2026-2학기/오픈소스 AI SW 융합 프로젝트/BODYGUARD-owned-alert-lifecycle";
const sha=b=>createHash('sha256').update(b).digest('hex');
const models=readdirSync(base+'/bodyguard/frontend/public/models').filter(n=>n.endsWith('.task')).sort();
assert.equal(models.length,5);
mkdirSync(work+'/bodyguard/frontend/public/models',{recursive:true});
const receipts=[];
for(const n of models){const b=readFileSync(base+'/bodyguard/frontend/public/models/'+n);writeFileSync(work+'/bodyguard/frontend/public/models/'+n,b,{flag:'wx'});receipts.push({name:n,bytes:b.length,sha256:sha(b)});}
for(const gender of ['male','female']){const name='bodyguard/frontend/src/avatar/models/bodyguard-'+gender+'-candidate-a37.glb',b=execFileSync('git',['show','25a9bd6c7392890e3b5d5d6ae1046bb7087d56ad:'+name],{cwd:work,maxBuffer:35*1024*1024});assert(readFileSync(work+'/'+name).equals(b));writeFileSync(proof+'/'+gender+'.glb',b,{flag:'wx'});receipts.push({name,bytes:b.length,sha256:sha(b),unchanged:true});}
writeFileSync(proof+'/asset-preparation.json',JSON.stringify(receipts,null,2),{flag:'wx'});console.log(JSON.stringify(receipts));
