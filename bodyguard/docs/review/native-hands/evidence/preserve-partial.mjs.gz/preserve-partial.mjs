import assert from 'node:assert/strict';
import {existsSync,renameSync} from 'node:fs';
const source="/Applications/학교 내부/2026-2학기/오픈소스 AI SW 융합 프로젝트/BODYGUARD-native-hands/bodyguard/docs/review/native-hands",dst="/private/tmp/bodyguard-native-hands-proof.0unYMn/collector-first-partial";
assert(existsSync(source));assert(!existsSync(dst));renameSync(source,dst);
console.log('Partial first archive preserved. No original evidence deleted.');
