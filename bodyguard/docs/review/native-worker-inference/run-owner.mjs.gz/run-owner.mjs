// Mechanical execution receipts, only fixed status/source hashes (no camera/body data).
import { spawnSync } from 'node:child_process'
import { readFileSync, writeFileSync, mkdirSync, existsSync, cpSync } from 'node:fs'
import { createHash } from 'node:crypto'
import assert from 'node:assert/strict'
const work = "/Applications/학교 내부/2026-2학기/오픈소스 AI SW 융합 프로젝트/BODYGUARD-native-worker-inference"
const proof = '/private/tmp/bodyguard-worker-proof.Q4Nkem', owner = '/private/tmp/bodyguard-native-feedback-proof.GxCCZQ', db = '/private/tmp/bodyguard-auth-test.u7Aqi0'
const fe = work+'/bodyguard/frontend', backend = work+'/bodyguard/backend'
const python = "/Applications/학교 내부/2026-2학기/오픈소스 AI SW 융합 프로젝트/BODYGUARD-account-web/bodyguard/backend/.venv/bin/python"
const pg = '/opt/homebrew/opt/postgresql@18/bin/'
const sha = value => createHash('sha256').update(value).digest('hex')
const selected = ['src/pose/workerInference.ts','src/pose/workerInferenceRuntime.ts','src/pose/workerNativeEngine.ts','src/pose/nativeInference.worker.ts','src/coaching/nativePlaybackResources.ts','e2e/fixtures/nativeHeadAuthProbe.ts','e2e/nativeworker.spec.ts','playwright.account.config.ts']
const sources = () => Object.fromEntries(selected.map(p=>[p,sha(readFileSync(fe+'/'+p))]))
function run(label,command,args,cwd=work,env={}) {
  assert(/^[a-z0-9-]+$/.test(label))
  const before=sources(), startedAt=new Date().toISOString()
  const r=spawnSync(command,args,{cwd,env:{...process.env,...env},encoding:'utf8',maxBuffer:16*1024*1024})
  writeFileSync(proof+'/'+label+'.stdout.txt',r.stdout??'',{flag:'wx'})
  writeFileSync(proof+'/'+label+'.stderr.txt',r.stderr??'',{flag:'wx'})
  const receipt={startedAt,finishedAt:new Date().toISOString(),command,args,cwd,exit:r.status,signal:r.signal,error:r.error?.name??null,sourcesBefore:before,sourcesAfter:sources()}
  writeFileSync(proof+'/'+label+'.receipt.json',JSON.stringify(receipt,null,2),{flag:'wx'})
  console.log(JSON.stringify({label,exit:r.status,signal:r.signal,error:r.error?.name??null,stdout:(r.stdout??'').slice(-8000),stderr:(r.stderr??'').slice(-5000)}))
  if(r.status!==0)process.exit(r.status??1)
}
const action=process.argv[2], label=process.argv[3]??'first'
if(action==='init') {
  assert(!existsSync(db+'/data'))
  run('db-init',pg+'initdb',['-D',db+'/data','--username=bodyguard_test','--auth=trust','--no-locale','--encoding=UTF8'])
  run('db-start',pg+'pg_ctl',['-D',db+'/data','-l',db+'/server.log','-o',"-k "+db+" -c listen_addresses='' -p 5432",'-w','start'])
  run('db-create',pg+'createdb',['-h',db,'-U','bodyguard_test','bodyguard_test'])
  run('db-identity',pg+'psql',['-h',db,'-U','bodyguard_test','-d','bodyguard_test','-At','-c',"select current_database(),current_user; show server_version_num; show listen_addresses;"])
} else if(action==='restart') {
  run('db-restart',pg+'pg_ctl',['-D',db+'/data','-l',db+'/server.log','-o',"-k "+db+" -c listen_addresses='' -p 5432",'-w','start'])
} else if(action==='copy') {
  const cache="/Applications/학교 내부/2026-2학기/오픈소스 AI SW 융합 프로젝트/BODYGUARD-owned-alert-lifecycle/bodyguard/frontend/public"
  for(const name of ['models','mediapipe']) { assert(!existsSync(fe+'/public/'+name)); cpSync(cache+'/'+name,fe+'/public/'+name,{recursive:true,errorOnExist:true}) }
  for(const [gender,expected] of [['male','cc85bcd449f3f31347e4f7174986d41e4aca3067990f5d8a2e6ba3a099171927'],['female','27c10902aa377e995bdbc115ab773cf22f8ea38582c49820304a33ad7685f25a']]) {
    const bytes=readFileSync('/private/tmp/bodyguard-native-feedback-proof.COdW5w/'+gender+'.glb')
    assert.equal(sha(bytes),expected)
    writeFileSync(owner+'/'+gender+'.glb',bytes,{flag:'wx'})
  }
} else if(action==='test') {
  run('owner-'+label,python,['-m','tests.run_browser','nativeworker'],backend,{PATH:fe+'/node_modules/.bin:'+process.env.PATH,BODYGUARD_TEST_NATIVE_FEEDBACK_PROBE:owner+'/probe-worker',BODYGUARD_TEST_DATABASE_URL:'postgresql+psycopg://bodyguard_test@/bodyguard_test?host='+db})
} else if(action==='stop') run('db-stop-'+label,pg+'pg_ctl',['-D',db+'/data','-m','fast','-w','stop'])
else throw new Error('Fixed action required')
