// Mechanical execution evidence: only fixed states/counts/times/hashes, not frames/body.
import assert from 'node:assert/strict'
import { createServer } from 'node:http'
import { readFileSync, readdirSync, writeFileSync } from 'node:fs'
import { join } from 'node:path'
import { createHash } from 'node:crypto'
import { chromium } from "/Applications/학교 내부/2026-2학기/오픈소스 AI SW 융합 프로젝트/BODYGUARD-owned-alert-lifecycle/bodyguard/frontend/node_modules/@playwright/test/index.mjs"
const proof = "/private/tmp/bodyguard-worker-proof.Q4Nkem", work = "/Applications/학교 내부/2026-2학기/오픈소스 AI SW 융합 프로젝트/BODYGUARD-native-worker-inference", assets = "/Applications/학교 내부/2026-2학기/오픈소스 AI SW 융합 프로젝트/BODYGUARD-owned-alert-lifecycle/bodyguard/frontend/public"
const sha = bytes => createHash('sha256').update(bytes).digest('hex')
const sourcePaths = ['src/pose/workerInference.ts','src/pose/workerInferenceRuntime.ts','src/pose/workerNativeEngine.ts','src/pose/nativeInference.worker.ts','e2e/fixtures/workerPoseProbe.ts','src/coaching/nativePlaybackResources.ts']
const sources = () => Object.fromEntries(sourcePaths.map(p => [p,sha(readFileSync(work+'/bodyguard/frontend/'+p))]))
const before = sources(), files = [...new Set(readFileSync(proof+'/probe/probe.js','utf8').match(/nativeInference\.worker-[\w-]+\.js/g) ?? [])]
assert.equal(files.length,1)
const workerName = files[0], paths = [], results = [], errors = [], external = []
const label = process.argv[2] ?? 'first'
assert(/^[a-z-]+$/.test(label))
const server = createServer((req,res) => {
  const path = new URL(req.url,'http://localhost').pathname
  paths.push(path)
  res.setHeader('Content-Security-Policy',"connect-src 'self'")
  let file
  if(path === '/') {
    res.setHeader('Content-Type','text/html')
    res.end('<!doctype html><html lang="ko"><body><button id="control">내부 Worker 검증</button><script type="module">import{mountWorkerPoseProbe}from"/probe.js";window.probe=mountWorkerPoseProbe();window.heartbeat={ticks:0,maxGap:0};let last=performance.now();window.beat=setInterval(()=>{const now=performance.now();window.heartbeat.maxGap=Math.max(window.heartbeat.maxGap,now-last);window.heartbeat.ticks++;last=now},16)</script></body></html>')
    return
  }
  if(path === '/probe.js') file = proof+'/probe/probe.js'
  else if(path === '/assets/'+workerName) file = proof+'/probe/assets/'+workerName
  else if(/^\/mediapipe\/wasm\/vision_wasm_(?:module_|nosimd_)?internal\.(?:js|wasm)$/.test(path)) file = assets+path
  else if(/^\/models\/(?:pose_landmarker_lite|face_landmarker|gesture_recognizer)\.task$/.test(path)) file = assets+path
  else { res.writeHead(404);res.end();return }
  try { res.setHeader('Content-Type',path.endsWith('.js')?'application/javascript':path.endsWith('.wasm')?'application/wasm':'application/octet-stream');res.end(readFileSync(file)) }
  catch { res.writeHead(404);res.end() }
})
await new Promise(r=>server.listen(0,'127.0.0.1',r))
const origin = 'http://127.0.0.1:'+server.address().port
const browser = await chromium.launch({channel:'chrome',args:['--use-fake-device-for-media-stream','--use-fake-ui-for-media-stream']})
let failed = false
try {
  for(const name of ['normal','cancel-preparing','cancel-inference']) {
    const context = await browser.newContext({permissions:['camera'],serviceWorkers:'block'}), page = await context.newPage()
    context.on('request',request=>{if(!request.url().startsWith(origin+'/'))external.push(new URL(request.url()).origin)})
    await context.route('**/*',route=>route.request().url().startsWith(origin+'/')?route.continue():route.abort())
    page.on('pageerror',e=>errors.push(e.name))
    let item = {name,passed:false}
    try {
      await page.goto(origin)
      await page.waitForFunction(()=>typeof window.probe === 'object',{timeout:5000})
      await page.evaluate(()=>{void window.probe.begin()})
      if(name === 'cancel-preparing') {
        await page.waitForFunction(()=>window.probe.snapshot().workerCreated,null,{timeout:5000})
        const beforeCancel = await page.evaluate(()=>window.probe.snapshot())
        assert.equal(beforeCancel.state,'preparing')
        const value = await page.evaluate(()=>window.probe.close())
        assert.equal(value.state,'closed'); assert(value.tracksEnded && value.detached)
        item = {...item,passed:true,beforeCancel,final:value}
      } else {
        await page.waitForFunction(()=>['running','failed'].includes(window.probe.snapshot().state),null,{timeout:5000})
        const ready = await page.evaluate(()=>window.probe.snapshot())
        assert.equal(ready.state,'running')
        if(name === 'normal') {
          for(let i=0;i<3;i++)await page.evaluate(()=>window.probe.read())
          const value = await page.evaluate(()=>window.probe.close()), heartbeat = await page.evaluate(()=>window.heartbeat)
          assert.equal(value.frames,3);assert.equal(value.nonempty,0);assert(value.tracksEnded && value.detached);assert(heartbeat.ticks>3)
          item = {...item,passed:true,final:value,heartbeat}
        } else {
          const value = await page.evaluate(async()=>{const read=window.probe.read();const value=await window.probe.close();await read;return value})
          assert.equal(value.state,'closed');assert(value.tracksEnded && value.detached)
          item = {...item,passed:true,final:value}
        }
      }
    } catch(e) { item = {...item,error:e.name}; failed=true }
    finally { await page.evaluate(()=>clearInterval(window.beat)).catch(()=>{}); await context.close();results.push(item) }
  }
} finally {
  await browser.close();await new Promise(r=>server.close(r))
  const after=sources();assert.deepEqual(before,after)
  const report={timestamp:new Date().toISOString(),scope:'private worker actual Chrome/SDK, fake camera; not avatar/clinical/native-owner release gate',sourcesBefore:before,sourcesAfter:after,worker:{file:workerName,sha256:sha(readFileSync(proof+'/probe/assets/'+workerName))},results,externalRequests:external.length,errors,requestedPaths:[...new Set(paths)],actualPeople:0,physicalCameras:0,productPolicyApproved:false}
  writeFileSync(proof+'/browser-'+label+'.json',JSON.stringify(report,null,2),{flag:'wx'})
  console.log(JSON.stringify({results,external:external.length,errors}))
}
if(failed || external.length || errors.length)process.exitCode=1
