// Mechanical copying/compression and verification of already-produced evidence.
import { readFileSync, writeFileSync, readdirSync, mkdirSync, statSync } from 'node:fs'
import { gzipSync } from 'node:zlib'
import { createHash } from 'node:crypto'
import assert from 'node:assert/strict'
const work="/Applications/학교 내부/2026-2학기/오픈소스 AI SW 융합 프로젝트/BODYGUARD-native-worker-inference", proof='/private/tmp/bodyguard-worker-proof.Q4Nkem', owner='/private/tmp/bodyguard-native-feedback-proof.GxCCZQ'
const target=work+'/bodyguard/docs/review/native-worker-inference'
mkdirSync(target,{recursive:true})
const sha=bytes=>createHash('sha256').update(bytes).digest('hex')
const files=[]
function preserve(source,name){
  const bytes=readFileSync(source), compressed=gzipSync(bytes)
  writeFileSync(target+'/'+name+'.gz',compressed,{flag:'wx'})
  files.push({source,file:name+'.gz',bytes:bytes.length,sha256:sha(bytes),compressedSha256:sha(compressed)})
}
for(const name of readdirSync(proof)) if(statSync(proof+'/'+name).isFile()) preserve(proof+'/'+name,name)
function walk(directory,prefix){for(const name of readdirSync(directory)){const source=directory+'/'+name,p=prefix+'/'+name;if(statSync(source).isDirectory())walk(source,p);else if(/\.json$|error-context\.md$/.test(name))preserve(source,p.replaceAll('/','__'))}}
for(const name of readdirSync(work+'/bodyguard/frontend/test-results')) if(name.startsWith('nativeworker-'))walk(work+'/bodyguard/frontend/test-results/'+name,name)
const sources={}
for(const name of ['src/pose/workerInference.ts','src/pose/workerInferenceRuntime.ts','src/pose/workerNativeEngine.ts','src/pose/nativeInference.worker.ts','src/coaching/nativePlaybackResources.ts','e2e/fixtures/nativeHeadAuthProbe.ts','e2e/nativeworker.spec.ts','e2e/fixtures/workerPoseProbe.ts'])sources[name]=sha(readFileSync(work+'/bodyguard/frontend/'+name))
const avatars=Object.fromEntries(['male','female'].map(gender=>[gender,sha(readFileSync(owner+'/'+gender+'.glb'))]))
const assets=Object.fromEntries(readdirSync(work+'/bodyguard/frontend/public/models').map(name=>[name,sha(readFileSync(work+'/bodyguard/frontend/public/models/'+name))]))
const browser=JSON.parse(readFileSync(proof+'/browser-accepted.json'))
assert.deepEqual(browser.sourcesBefore,browser.sourcesAfter)
for(const [name,value] of Object.entries(browser.sourcesAfter))assert.equal(value,sources[name])
const run=JSON.parse(readFileSync(proof+'/owner-fourth.receipt.json'))
assert.deepEqual(run.sourcesBefore,run.sourcesAfter)
for(const [name,value] of Object.entries(run.sourcesAfter))assert.equal(value,sources[name])
const full=JSON.parse(readFileSync(proof+'/full-accepted-units.json'))
assert.equal(full.numFailedTests,0); assert.equal(full.numPassedTests,full.numTotalTests)
const ownerPath=readdirSync(work+'/bodyguard/frontend/test-results').filter(name=>name.startsWith('nativeworker-')).sort().at(-1)
const ownerReport=JSON.parse(readFileSync(work+'/bodyguard/frontend/test-results/'+ownerPath+'/report.json'))
assert.equal(ownerReport.stats.expected,6);assert.equal(ownerReport.stats.unexpected,0);assert.equal(ownerReport.stats.skipped,0)
const manifest={timestamp:new Date().toISOString(),base:'202486d4d0e11d1f812c021aa63d30ffe3b2707a',files,sources,avatars,assets,results:{unit:full.numTotalTests,owner:ownerReport.stats,browser:browser.results},actualPeople:0,physicalCameras:0,releaseQualifiedMotions:0,productEgressPolicyApproved:false,finalAvatarApproved:false,oldStartupP2Resolved:false,allStagesComplete:false}
writeFileSync(target+'/manifest.json',JSON.stringify(manifest,null,2),{flag:'wx'})
console.log(JSON.stringify({files:files.length,unit:full.numTotalTests,owner:ownerReport.stats,browser:browser.results.map(x=>({name:x.name,passed:x.passed})),allStagesComplete:false}))
