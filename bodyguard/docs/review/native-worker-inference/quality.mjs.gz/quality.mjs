// Mechanical validation receipts and byte comparisons; no raw body data.
import { spawnSync } from 'node:child_process'
import { readFileSync, writeFileSync, readdirSync } from 'node:fs'
import { createHash } from 'node:crypto'
import assert from 'node:assert/strict'
const work="/Applications/학교 내부/2026-2학기/오픈소스 AI SW 융합 프로젝트/BODYGUARD-native-worker-inference", proof='/private/tmp/bodyguard-worker-proof.Q4Nkem', fe=work+'/bodyguard/frontend'
const label=process.argv[2]; assert(/^[a-z0-9-]+$/.test(label))
const sha=value=>createHash('sha256').update(value).digest('hex')
const commands={
  units:['node_modules/.bin/vitest',['run','--maxWorkers','1','--reporter=json','--outputFile='+proof+'/full-'+label+'.json']],
  lint:['node_modules/.bin/biome',['check','.']],
  types:['node_modules/.bin/tsc',['--noEmit']],
  build:['pnpm',['build']],
  guard:['node',['scripts/check-selection-production.mjs']],
  pythonlint:["/Applications/학교 내부/2026-2학기/오픈소스 AI SW 융합 프로젝트/BODYGUARD-account-web/bodyguard/backend/.venv/bin/python",['-m','ruff','check','tests/run_browser.py']],
}
const key=process.argv[3], [command,args]=commands[key]
const cwd=key==='pythonlint'?work+'/bodyguard/backend':fe, startedAt=new Date().toISOString()
const r=spawnSync(command,args,{cwd,encoding:'utf8',maxBuffer:24*1024*1024})
writeFileSync(proof+'/'+label+'.stdout.txt',r.stdout??'',{flag:'wx'})
writeFileSync(proof+'/'+label+'.stderr.txt',r.stderr??'',{flag:'wx'})
const receipt={command,args,cwd,startedAt,finishedAt:new Date().toISOString(),exit:r.status,signal:r.signal,error:r.error?.name??null}
if(key==='build' && r.status===0){
  receipt.assets=Object.fromEntries(readdirSync(fe+'/dist/assets').map(name=>[name,{bytes:readFileSync(fe+'/dist/assets/'+name).length,sha256:sha(readFileSync(fe+'/dist/assets/'+name))}]))
  for(const [ext,expected] of [['js','b5d4f81164c8d3c196e853b3404382bc15077986aa626cd0c3c72571b6325ac0'],['css','043cb9bdb5d82a3baa9a8463c7a641cbe92ace213303f20c6c7f91e9a14ac82e']]) {
    const found=Object.entries(receipt.assets).filter(([name])=>name.endsWith('.'+ext));assert.equal(found.length,1);assert.equal(found[0][1].sha256,expected)
  }
  receipt.publicBytesEqual=true
}
writeFileSync(proof+'/'+label+'.receipt.json',JSON.stringify(receipt,null,2),{flag:'wx'})
console.log(JSON.stringify({...receipt,stdout:(r.stdout??'').slice(-5000),stderr:(r.stderr??'').slice(-5000)}))
process.exitCode=r.status??1
