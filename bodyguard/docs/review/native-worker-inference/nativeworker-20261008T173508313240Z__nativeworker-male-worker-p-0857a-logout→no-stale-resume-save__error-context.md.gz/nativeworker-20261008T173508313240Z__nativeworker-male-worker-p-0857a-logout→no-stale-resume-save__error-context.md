# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: nativeworker.spec.ts >> male worker preparation→logout→no stale resume/save
- Location: e2e/nativeworker.spec.ts:208:3

# Error details

```
Error: expect(received).toMatchObject(expected)

- Expected  - 1
+ Received  + 1

  Object {
-   "hook": "preparing",
+   "hook": "prepared",
  }
```

# Page snapshot

```yaml
- generic [ref=e1]:
  - generic [ref=e3]:
    - button "본문으로 이동" [ref=e4]
    - banner [ref=e5]:
      - link "BODYGUARD 서비스 소개" [ref=e6] [cursor=pointer]:
        - /url: /
        - text: BODYGUARD.
      - navigation "계정 메뉴" [ref=e7]:
        - link "내 시작" [ref=e8] [cursor=pointer]:
          - /url: /start
        - link "자세 기록" [ref=e9] [cursor=pointer]:
          - /url: /posture-records
        - link "수행 기록" [ref=e10] [cursor=pointer]:
          - /url: /records
        - link "내 계정" [ref=e11] [cursor=pointer]:
          - /url: /account
    - main [ref=e12]:
      - generic [ref=e13]:
        - paragraph [ref=e14]: MY BODYGUARD
        - heading "내 몸을 위한 시작" [active] [level=1] [ref=e15]
        - paragraph [ref=e16]: worker-357de0bc-1e58-4db0-85f1-f50403805426@example.com
        - link "스트레칭 시작 경로 선택" [ref=e17] [cursor=pointer]:
          - /url: /explore
        - paragraph [ref=e18]:
          - link "내 수행 기록 확인" [ref=e19] [cursor=pointer]:
            - /url: /records
        - paragraph [ref=e20]:
          - link "내 자세 기록 확인" [ref=e21] [cursor=pointer]:
            - /url: /posture-records
        - paragraph [ref=e22]:
          - link "계정 관리" [ref=e23] [cursor=pointer]:
            - /url: /account
        - generic [ref=e24]:
          - heading "첫 코칭 흐름을 준비하고 있습니다" [level=2] [ref=e25]
          - paragraph [ref=e26]: 동작 검증과 남녀 3D 아바타 제작이 끝나면 스트레칭 선택과 코칭을 이곳에 연결합니다. 지금은 계정 기능을 사용할 수 있습니다.
          - paragraph [ref=e27]: 카메라는 켜지지 않았습니다.
        - button "로그아웃" [ref=e28] [cursor=pointer]
    - contentinfo [ref=e29]:
      - generic [ref=e30]: BODYGUARD
      - paragraph [ref=e31]: 일상을 위한 스트레칭과 자세 코칭 · 출시 준비 중
      - navigation "서비스 안내" [ref=e32]:
        - link "도움말" [ref=e33] [cursor=pointer]:
          - /url: /help
        - link "카메라·데이터 안내" [ref=e34] [cursor=pointer]:
          - /url: /data
  - paragraph [ref=e36]: 미완성 아바타 · 가짜 카메라 · Worker 내부 검증
```

# Test source

```ts
  113 |         actualHuman: false,
  114 |         actualCamera: false,
  115 |         productPolicyApproved: false,
  116 |       },
  117 |       null,
  118 |       2,
  119 |     ),
  120 |   )
  121 | })
  122 | async function join(context: BrowserContext) {
  123 |   const csrf = async () =>
  124 |     (await (await context.request.get('/api/v1/auth/csrf')).json()).csrf_token
  125 |   const email = `worker-${randomUUID()}@example.com`
  126 |   const response = await context.request.post('/api/v1/auth/signup', {
  127 |     headers: { Origin: origin, 'X-CSRF-Token': await csrf() },
  128 |     data: { email, password: 'Worker 가상 계정 검증 비밀번호 12345' },
  129 |   })
  130 |   expect(response.status()).toBe(202)
  131 |   let code = ''
  132 |   await expect
  133 |     .poll(() => {
  134 |       code = JSON.parse(readFileSync(mailbox as string, 'utf8'))[email] ?? ''
  135 |       return code
  136 |     })
  137 |     .toMatch(/^[0-9]{6}$/)
  138 |   expect(
  139 |     (
  140 |       await context.request.post('/api/v1/auth/verify', {
  141 |         headers: { Origin: origin, 'X-CSRF-Token': await csrf() },
  142 |         data: { challenge_id: (await response.json()).challenge_id, code },
  143 |       })
  144 |     ).status(),
  145 |   ).toBe(201)
  146 | }
  147 | async function mount(page: Page, gender: 'male' | 'female') {
  148 |   await page.goto('/start')
  149 |   await page.evaluate(async (gender) => {
  150 |     const path = '/__private-native-head-probe.js',
  151 |       module = (await import(path)) as { mountNativeHeadAuthProbe: typeof mountNativeHeadAuthProbe }
  152 |     const canvas = document.createElement('canvas')
  153 |     document.body.append(canvas)
  154 |     const label = document.createElement('p')
  155 |     label.textContent = '미완성 아바타 · 가짜 카메라 · Worker 내부 검증'
  156 |     document.body.append(label)
  157 |     ;(window as unknown as WindowProbe).nativeAuthProbe = module.mountNativeHeadAuthProbe(
  158 |       canvas,
  159 |       gender,
  160 |       {
  161 |         cameraReferences: { left: [0, 0, 0, 1], right: [0, 0, 0, 1] },
  162 |         sceneFromCamera: [0, 0, 0, 1],
  163 |       },
  164 |       false,
  165 |       false,
  166 |       false,
  167 |       false,
  168 |       false,
  169 |       true,
  170 |     )
  171 |   }, gender)
  172 |   await expect
  173 |     .poll(() => state(page))
  174 |     .toMatchObject({ auth: 'ready', hook: 'idle', cameras: 0, workerConfigured: true })
  175 |   await page.evaluate(() => (window as unknown as WindowProbe).nativeAuthProbe.prepare())
  176 |   expect(await state(page)).toMatchObject({ hook: 'prepared', cameras: 0, models: 0 })
  177 | }
  178 | async function running(page: Page, before = 0) {
  179 |   await page.evaluate(() => (window as unknown as WindowProbe).nativeAuthProbe.start())
  180 |   await expect.poll(async () => (await state(page)).frameCloses).toBeGreaterThanOrEqual(before + 3)
  181 |   expect(await state(page)).toMatchObject({
  182 |     session: 'running',
  183 |     models: 2,
  184 |     framing: [true, true],
  185 |     verifiedMs: 0,
  186 |     rawVideoHidden: true,
  187 |   })
  188 |   expect(page.workers()).toHaveLength(1)
  189 | }
  190 | for (const gender of ['male', 'female'] as const) {
  191 |   test(`${gender} worker→two avatars→stop→own interrupted record`, async ({ page, context }) => {
  192 |     await join(context)
  193 |     await mount(page, gender)
  194 |     await running(page)
  195 |     await page.evaluate(() => (window as unknown as WindowProbe).nativeAuthProbe.stop())
  196 |     expect(await state(page)).toMatchObject({ tracksEnded: true, verifiedMs: 0 })
  197 |     await page.evaluate(() => (window as unknown as WindowProbe).nativeAuthProbe.save())
  198 |     expect(posts).toBe(1)
  199 |     const rows = (await (await context.request.get('/api/v1/records/stretch')).json()).items
  200 |     expect(rows).toHaveLength(1)
  201 |     expect(rows[0]).toMatchObject({
  202 |       outcome: 'interrupted',
  203 |       observed_ms: 0,
  204 |       repetitions: 0,
  205 |       provenance: 'client-reported',
  206 |     })
  207 |   })
  208 |   test(`${gender} worker preparation→logout→no stale resume/save`, async ({ page, context }) => {
  209 |     await join(context)
  210 |     await mount(page, gender)
  211 |     await page.evaluate(() => (window as unknown as WindowProbe).nativeAuthProbe.start())
  212 |     await expect.poll(() => workerStarts).toBe(1)
> 213 |     expect(await state(page)).toMatchObject({ hook: 'preparing' })
      |                               ^ Error: expect(received).toMatchObject(expected)
  214 |     await page.evaluate(() => (window as unknown as WindowProbe).nativeAuthProbe.signOut())
  215 |     await expect
  216 |       .poll(() => state(page))
  217 |       .toMatchObject({ owned: false, tracksEnded: true, models: 0 })
  218 |     await page.evaluate(async () => {
  219 |       await (window as unknown as WindowProbe).nativeAuthProbe.resume()
  220 |       await (window as unknown as WindowProbe).nativeAuthProbe.save()
  221 |     })
  222 |     expect(posts).toBe(0)
  223 |   })
  224 |   test(`${gender} worker running→same-account refresh→explicit new owner`, async ({
  225 |     page,
  226 |     context,
  227 |   }) => {
  228 |     await join(context)
  229 |     await mount(page, gender)
  230 |     await running(page)
  231 |     const before = (await state(page)).frameCloses
  232 |     await page.evaluate(() => (window as unknown as WindowProbe).nativeAuthProbe.refresh())
  233 |     await expect
  234 |       .poll(() => state(page))
  235 |       .toMatchObject({ auth: 'ready', hook: 'idle', owned: false, tracksEnded: true, models: 0 })
  236 |     await page.evaluate(() => (window as unknown as WindowProbe).nativeAuthProbe.prepare())
  237 |     expect(await state(page)).toMatchObject({ hook: 'prepared', cameras: 1 })
  238 |     await running(page, before)
  239 |     expect(await state(page)).toMatchObject({ cameras: 2, verifiedMs: 0 })
  240 |     expect(posts).toBe(0)
  241 |   })
  242 | }
  243 | 
```