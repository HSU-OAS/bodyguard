// FR-M-03/FR-U-04: isolated review of a frozen, unfinished client snapshot.
import { afterEach, describe, expect, it, vi } from 'vitest'
import { prepareBaselines } from './api/baselines'

afterEach(() => vi.restoreAllMocks())
const authority = { status: 'ready', user: { id: 'fixture-owner', email: 'fixture@example.com' } }
function deferred<T>() {
  let resolve!: (value: T) => void
  const promise = new Promise<T>((accept) => { resolve = accept })
  return { promise, resolve }
}
async function prepared(data: (init: RequestInit) => unknown) {
  const deadline = new AbortController()
  vi.spyOn(AbortSignal, 'timeout').mockImplementation(() => deadline.signal)
  vi.stubGlobal('fetch', vi.fn(async (url: string, init: RequestInit) => {
    if (url === '/api/v1/me') return new Response(JSON.stringify(authority.user))
    if (url === '/api/v1/auth/csrf') return new Response(JSON.stringify({ csrf_token: 'a'.repeat(64) }))
    return data(init)
  }))
  const lifetime = new AbortController()
  const context = await prepareBaselines({
    authority: authority as never, readAuthority: () => authority as never, signal: lifetime.signal,
  })
  return { context, deadline }
}
describe('15s request lease must not accept results after its timeout', () => {
  it('ordinary active-null response remains valid', async () => {
    const { context } = await prepared(() => new Response('null'))
    expect(await context.active(new AbortController().signal)).toBeNull()
    context.close()
  })
  it('rejects an abort-ignoring fetch that resolves after the request deadline', async () => {
    const result = deferred<Response>()
    let combined!: AbortSignal
    const { context, deadline } = await prepared((init) => {
      combined = init.signal as AbortSignal
      return result.promise
    })
    const pending = context.active(new AbortController().signal)
    const assertion = expect(pending).rejects.toBeInstanceOf(Error)
    deadline.abort()
    expect(combined.aborted).toBe(true)
    result.resolve(new Response('null'))
    await assertion
    context.close()
  })
  it('rejects late JSON decoded after the request deadline', async () => {
    const result = deferred<unknown>()
    let decoding = false
    const { context, deadline } = await prepared(() => ({
      ok: true, status: 200, headers: new Headers(),
      json() { decoding = true; return result.promise },
    }))
    const pending = context.active(new AbortController().signal)
    const assertion = expect(pending).rejects.toBeInstanceOf(Error)
    await Promise.resolve()
    await Promise.resolve()
    expect(decoding).toBe(true)
    deadline.abort()
    result.resolve(null)
    await assertion
    context.close()
  })
})
