import assert from 'node:assert/strict'
import { createHash } from 'node:crypto'
import { existsSync, mkdirSync, readdirSync, readFileSync, writeFileSync } from 'node:fs'
import { join, resolve } from 'node:path'
import { spawnSync } from 'node:child_process'
import { gunzipSync, gzipSync } from 'node:zlib'

const frontend = process.cwd(), root = resolve(frontend, '..')
const proof = '/private/tmp/bodyguard-body-gate.Zk0t7T'
const before = '/private/tmp/bodyguard-owned-models.HRKDvB'
const after = '/private/tmp/bodyguard-owned-models.9RhUop'
const camera = '/private/tmp/bodyguard-camera-preparation.b3LXp9'
const destination = join(root, 'docs/review/body-gated-inference')
assert(!existsSync(destination), 'Preserve all previous evidence')
const hash = bytes => createHash('sha256').update(bytes).digest('hex')
const sourceFiles = [
  'src/pose/workerNativeEngine.ts', 'src/pose/bodyFaceVideoSource.ts', 'src/pose/bodyHandVideoSource.ts',
  'src/pose/workerNativeEngine.test.ts', 'src/pose/bodyFaceVideoSource.test.ts', 'src/pose/bodyHandVideoSource.test.ts',
  'src/pose/workerInference.ts', 'src/pose/workerInferenceRuntime.ts', 'src/pose/ownedPoseFrame.ts',
  'src/pose/ownedModelAssets.ts', 'e2e/fixtures/ownedModelProbe.ts', 'scripts/test-owned-model-preparation.mjs',
  'scripts/build-owned-model-preparation.mjs', 'scripts/test-camera-preparation.mjs',
  'scripts/check-owned-models.mjs', 'scripts/check-selection-production.mjs', 'scripts/sdk-network-policy.ts',
  'src/pages/MinuteSummaryPage.test.tsx', 'src/pages/MinuteSummaryPage.tsx',
]
const source = Object.fromEntries(sourceFiles.map(file => [file, hash(readFileSync(join(frontend, file)))]))
const commands = [
  ['pnpm', ['typecheck']],
  ['pnpm', ['check']],
  ['node', ['--experimental-strip-types', 'scripts/check-owned-models.mjs']],
  ['node', ['scripts/check-selection-production.mjs']],
  ['git', ['diff', '--check']],
]
const quality = []
for (const [command, args] of commands) {
  const result = spawnSync(command, args, { cwd: frontend, encoding: 'utf8' })
  const name = `quality-${quality.length}.log`
  writeFileSync(join(proof, name), `${result.stdout ?? ''}${result.stderr ?? ''}`, { flag: 'wx' })
  quality.push({ command: [command, ...args], exit: result.status, evidence: name })
  assert.equal(result.status, 0, name)
}
const final = JSON.parse(readFileSync(join(proof, 'full-frontend-standalone.json')))
assert.equal(final.numFailedTests, 0)
assert.equal(final.numPendingTests, 0)
assert.equal(final.numPassedTests, 1875)
const isolated = JSON.parse(readFileSync(join(after, 'after-body-gate-standalone.json')))
const regression = JSON.parse(readFileSync(join(after, 'after-regression.json')))
for (const [report, length] of [[isolated, 4], [regression, 6]]) {
  assert.equal(report.failure, null)
  assert.equal(report.results.length, length)
  assert.equal(report.external, 0)
  assert.equal(report.serversStopped, true)
  assert.deepEqual(report.errors, [])
  for (const row of report.results) {
    assert.equal(row.phase, 'complete')
    assert.equal(row.workers, 1)
    assert.equal(row.closed, 1)
    assert.equal(row.storage, 0)
  }
  for (const [file, sha] of Object.entries(report.source)) assert.equal(source[file], sha)
}
const nativeCamera = JSON.parse(readFileSync(join(camera, 'body-gate-camera.json')))
assert.equal(nativeCamera.failure, null)
assert.equal(nativeCamera.cases.length, 8)
assert.equal(nativeCamera.external, 0)
assert.equal(nativeCamera.avatars, 0)
assert.deepEqual(nativeCamera.errors, [])

mkdirSync(join(destination, 'evidence'), { recursive: true })
const artifacts = []
function archive(name, bytes, origin, originalGzip = false) {
  const file = `evidence/${name}.gz`
  const raw = originalGzip ? gunzipSync(bytes) : bytes
  const compressed = originalGzip ? bytes : gzipSync(bytes)
  const target = join(destination, file)
  mkdirSync(resolve(target, '..'), { recursive: true })
  writeFileSync(target, compressed, { flag: 'wx' })
  artifacts.push({ file, origin, bytes: compressed.length, sha256: hash(compressed), rawBytes: raw.length, rawSha256: hash(raw) })
}
for (const name of readdirSync(proof)) {
  const file = join(proof, name)
  archive(`run/${name.replace(/\.gz$/, '')}`, readFileSync(file), file, name.endsWith('.gz'))
}
for (const [name, directory] of [['before', before], ['after', after]]) {
  for (const file of readdirSync(directory)) {
    if (file.endsWith('.json')) archive(`${name}/${file}`, readFileSync(join(directory, file)), join(directory, file))
  }
  for (const output of ['probe', 'product']) {
    for (const file of readdirSync(join(directory, output), { recursive: true })) {
      if (/\.(js|html|css|json|txt)$/.test(file)) {
        const original = join(directory, output, file)
        archive(`${name}/${output}/${file}`, readFileSync(original), original)
      }
    }
  }
}
archive('camera/body-gate-camera.json', readFileSync(join(camera, 'body-gate-camera.json')), join(camera, 'body-gate-camera.json'))
for (const file of readdirSync(camera).filter(name => name.endsWith('.png'))) {
  const bytes = readFileSync(join(camera, file))
  writeFileSync(join(destination, file), bytes, { flag: 'wx' })
  artifacts.push({ file, origin: join(camera, file), bytes: bytes.length, sha256: hash(bytes) })
}
for (const file of sourceFiles) archive(`source/${file}`, readFileSync(join(frontend, file)), join(frontend, file))

const builds = {}
for (const [name, directory] of [['before', before], ['after', after], ['standard', join(frontend, 'dist')]]) {
  const directoryRoot = name === 'standard' ? directory : join(directory, 'product')
  builds[name] = Object.fromEntries(readdirSync(join(directoryRoot, 'assets'))
    .filter(file => /\.(js|css)$/.test(file))
    .map(file => {
      const bytes = readFileSync(join(directoryRoot, 'assets', file))
      return [file, { bytes: bytes.length, sha256: hash(bytes) }]
    }))
}
assert.deepEqual(builds.before, builds.after)
assert.deepEqual(builds.after, builds.standard)
const prior = gunzipSync(readFileSync(join(proof, 'before-workerNativeEngine.ts.gz')))
for (const label of ['before-body-gate', 'before-body-gate-repeat']) {
  const report = JSON.parse(readFileSync(join(before, `${label}.json`)))
  assert.equal(report.source['src/pose/workerNativeEngine.ts'], hash(prior))
  assert.equal(report.source['e2e/fixtures/ownedModelProbe.ts'], source['e2e/fixtures/ownedModelProbe.ts'])
}
for (const [file, sha] of Object.entries(source)) assert.equal(hash(readFileSync(join(frontend, file))), sha)
const manifest = { createdAt: new Date().toISOString(), source, artifacts }
const verification = {
  story: 'S3.C10', base: 'c57c1a331ae4f264138e72dc6c797aaf23950243',
  branch: 'codex/body-gated-worker-inference', source, quality,
  frontend: { passed: final.numPassedTests, failed: 0, skip: 0, files: final.testResults.length },
  nativeBlank: { contexts: 4, framesPerContext: 3, syntheticInput: true, actualHuman: false, failure: isolated.failure },
  nativeRegression: { contexts: 6, failure: regression.failure },
  camera: { cases: nativeCamera.cases, nativeSDK: true, nativeFakeCamera: true, authAPI: 'controlled fixture', actualHuman: false, avatarRequests: 0 },
  publicBuild: builds, publicBytesUnchanged: true,
  failuresPreserved: ['RED10', 'before native first inference twice', 'candidate paired-load cleanup assertion', 'first typecheck fixture type', 'full regression summary pagination focus once'],
  priorStartupP2Resolved: false, stage1to6Complete: false,
  untouched: ['avatar/source/GLB', 'clinical rules', 'public UI', 'backend/API/schema', 'CI', 'env/secrets', 'operators/providers/deployment'],
  scopedReview: { authorOnly: true, unresolvedP1P2: 0, independentReview: false },
}
writeFileSync(join(destination, 'manifest.json'), `${JSON.stringify(manifest, null, 2)}\n`, { flag: 'wx' })
writeFileSync(join(destination, 'verification.json'), `${JSON.stringify(verification, null, 2)}\n`, { flag: 'wx' })
console.log(JSON.stringify({ destination, artifacts: artifacts.length, compressedBytes: artifacts.reduce((sum, file) => sum + file.bytes, 0), frontend: verification.frontend, publicBytesUnchanged: true }))
