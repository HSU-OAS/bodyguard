# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: withdrawal.spec.ts >> AW-B07 전체 데이터 취소·본인만 탈퇴·동일 이메일 웹 재가입
- Location: e2e/withdrawal.spec.ts:232:1

# Error details

```
Error: spawnSync /Applications/학교 내부/2026-2학기/오픈소스 AI SW 융합 프로젝트/BODYGUARD-record-dashboard/bodyguard/backend/.venv/bin/python ETIMEDOUT
```

# Page snapshot

```yaml
- generic [ref=e3]:
  - button "본문으로 이동" [ref=e4]
  - banner [ref=e5]:
    - link "BODYGUARD 서비스 소개" [ref=e6] [cursor=pointer]:
      - /url: /
      - text: BODYGUARD.
    - navigation "계정 메뉴" [ref=e7]:
      - link "내 시작" [ref=e8] [cursor=pointer]:
        - /url: /start
      - link "자세 기록" [ref=e9] [cursor=pointer]:
        - /url: /posture-records
      - link "수행 기록" [ref=e10] [cursor=pointer]:
        - /url: /records
      - link "내 계정" [ref=e11] [cursor=pointer]:
        - /url: /account
  - main [ref=e12]:
    - generic [ref=e13]:
      - paragraph [ref=e14]: MY ACCOUNT
      - heading "내 계정" [active] [level=1] [ref=e15]
      - region [ref=e16]:
        - heading "로그인 정보" [level=2] [ref=e17]
        - generic [ref=e18]:
          - term [ref=e19]: 확인된 이메일
          - definition [ref=e20]: account-web-bd2a2a04-19d5-4389-bd78-05465c6b166c@example.com
        - button "로그아웃" [ref=e21] [cursor=pointer]
      - region [ref=e22]:
        - heading "수행 기록" [level=2] [ref=e23]
        - paragraph [ref=e24]: 기간별로 조회·삭제합니다.
        - link "수행 기록 관리" [ref=e25] [cursor=pointer]:
          - /url: /records
      - region [ref=e26]:
        - heading "자세 기록" [level=2] [ref=e27]
        - paragraph [ref=e28]: 1분별 측정 시간·부위별 편차 조회와 기간별 삭제.
        - link "자세 기록 관리" [ref=e29] [cursor=pointer]:
          - /url: /posture-records
      - region [ref=e30]:
        - heading "알림 설정" [level=2] [ref=e31]
        - paragraph [ref=e32]: 시간·소리를 저장합니다. 실제 알림은 연결 전입니다.
        - link "알림 설정 관리" [ref=e33] [cursor=pointer]:
          - /url: /account/notifications
      - region [ref=e34]:
        - heading "회원 탈퇴" [level=2] [ref=e35]
        - paragraph [ref=e36]: 본인 확인 후 계정과 자세·수행 기록을 삭제합니다.
        - link "회원 탈퇴 안내" [ref=e37] [cursor=pointer]:
          - /url: /account/delete
  - contentinfo [ref=e38]:
    - generic [ref=e39]: BODYGUARD
    - paragraph [ref=e40]: 일상을 위한 스트레칭과 자세 코칭 · 출시 준비 중
    - navigation "서비스 안내" [ref=e41]:
      - link "도움말" [ref=e42] [cursor=pointer]:
        - /url: /help
      - link "카메라·데이터 안내" [ref=e43] [cursor=pointer]:
        - /url: /data
```

# Test source

```ts
  8   | 
  9   | const origin = 'http://localhost:4173'
  10  | const password = '격리된 계정 웹 시험 비밀번호 12345'
  11  | const mailbox = process.env.BODYGUARD_TEST_MAILBOX
  12  | const clock = process.env.BODYGUARD_TEST_RECORD_CLOCK
  13  | if (
  14  |   !mailbox?.startsWith('/private/tmp/bodyguard-browser-') ||
  15  |   !clock?.startsWith('/private/tmp/bodyguard-browser-')
  16  | )
  17  |   throw new Error('Isolated mailbox/clock required')
  18  | let requests: string[] = [],
  19  |   cameraCalls = 0,
  20  |   errors: string[] = []
  21  | test.beforeEach(async ({ context, page }) => {
  22  |   requests = []
  23  |   cameraCalls = 0
  24  |   errors = []
  25  |   writeFileSync(clock as string, '{"offset_seconds":0}')
  26  |   context.on('request', (request) => requests.push(request.url()))
  27  |   page.on('pageerror', (error) => errors.push(error.message))
  28  |   await context.exposeBinding('__accountWebCamera', () => {
  29  |     cameraCalls++
  30  |   })
  31  |   await context.addInitScript(() => {
  32  |     navigator.mediaDevices.getUserMedia = () => {
  33  |       void (window as unknown as { __accountWebCamera: () => Promise<void> }).__accountWebCamera()
  34  |       return Promise.reject(new Error('Unexpected camera request'))
  35  |     }
  36  |   })
  37  | })
  38  | test.afterEach(async ({ page }) => {
  39  |   writeFileSync(clock as string, '{"offset_seconds":0}')
  40  |   expect(cameraCalls).toBe(0)
  41  |   expect(errors).toEqual([])
  42  |   expect(requests.every((url) => new URL(url).origin === origin)).toBe(true)
  43  |   expect(requests.some((url) => /\.glb|\.task|\.wasm|mediapipe/.test(url))).toBe(false)
  44  |   expect(await page.evaluate(() => [localStorage.length, sessionStorage.length])).toEqual([0, 0])
  45  | })
  46  | async function post(context: BrowserContext, path: string, data?: unknown) {
  47  |   const csrf = await (await context.request.get(`${origin}/api/v1/auth/csrf`)).json()
  48  |   return context.request.post(`${origin}/api/v1${path}`, {
  49  |     headers: { Origin: origin, 'X-CSRF-Token': csrf.csrf_token },
  50  |     data,
  51  |   })
  52  | }
  53  | async function mailCode(email: string) {
  54  |   let code = ''
  55  |   await expect
  56  |     .poll(() => {
  57  |       code = JSON.parse(readFileSync(mailbox as string, 'utf8'))[email] ?? ''
  58  |       return code
  59  |     })
  60  |     .toMatch(/^[0-9]{6}$/)
  61  |   return code
  62  | }
  63  | async function join(context: BrowserContext) {
  64  |   const email = `account-web-${randomUUID()}@example.com`
  65  |   const result = await post(context, '/auth/signup', { email, password })
  66  |   expect(result.status()).toBe(202)
  67  |   const verified = await post(context, '/auth/verify', {
  68  |     challenge_id: (await result.json()).challenge_id,
  69  |     code: await mailCode(email),
  70  |   })
  71  |   expect(verified.status()).toBe(201)
  72  |   return email
  73  | }
  74  | async function seed(context: BrowserContext) {
  75  |   const end = new Date(Date.now() - 1000)
  76  |   const row = {
  77  |     id: randomUUID(),
  78  |     motion_id: 'synthetic-withdrawal',
  79  |     protocol_version: 'fixture-not-release',
  80  |     started_at: new Date(end.getTime() - 40000).toISOString(),
  81  |     ended_at: end.toISOString(),
  82  |     outcome: 'interrupted',
  83  |     observed_ms: 12000,
  84  |     repetitions: 0,
  85  |   }
  86  |   expect((await post(context, '/records/stretch', row)).status()).toBe(201)
  87  |   return row.id
  88  | }
  89  | async function begin(page: Page, email: string) {
  90  |   await page.goto('/account')
  91  |   await expect(page.getByText(email, { exact: true })).toBeVisible()
  92  |   await page.getByRole('link', { name: '회원 탈퇴 안내' }).click()
  93  |   await page.getByRole('button', { name: '탈퇴 인증 코드 받기' }).click()
  94  |   await expect(page.getByLabel('탈퇴 인증 코드')).toBeVisible()
  95  |   return mailCode(email)
  96  | }
  97  | async function consent(page: Page, code: string) {
  98  |   await page.getByLabel('탈퇴 인증 코드').fill(code)
  99  |   await page.getByLabel('확인문').fill('탈퇴')
  100 |   await page.getByRole('button', { name: '계정과 기록 삭제', exact: true }).click()
  101 | }
  102 | 
  103 | // FR-U-05: process-private read-only SQL oracle; never exposed to the browser.
  104 | function storedCounts(owners: Record<string, string>) {
  105 |   const python = process.env.BODYGUARD_TEST_BACKEND_PYTHON
  106 |   if (!python?.startsWith('/')) throw new Error('Owned backend interpreter required')
  107 |   return JSON.parse(
> 108 |     execFileSync(python, ['-m', 'tests.withdrawal_data_probe'], {
      |     ^ Error: spawnSync /Applications/학교 내부/2026-2학기/오픈소스 AI SW 융합 프로젝트/BODYGUARD-record-dashboard/bodyguard/backend/.venv/bin/python ETIMEDOUT
  109 |       cwd: fileURLToPath(new URL('../../backend/', import.meta.url)),
  110 |       input: JSON.stringify(owners),
  111 |       encoding: 'utf8',
  112 |       timeout: 5000,
  113 |       maxBuffer: 4096,
  114 |     }),
  115 |   ) as Record<string, Record<string, number>>
  116 | }
  117 | const preferenceDefaults = {
  118 |   posture_enabled: true,
  119 |   posture_minutes: 5,
  120 |   sitting_enabled: true,
  121 |   sitting_minutes: 50,
  122 |   sound_enabled: false,
  123 | }
  124 | async function readOwned(context: BrowserContext, path: string) {
  125 |   const response = await context.request.get(`${origin}/api/v1${path}`)
  126 |   expect(response.status()).toBe(200)
  127 |   return response.json()
  128 | }
  129 | async function seedAll(context: BrowserContext, deviation: number) {
  130 |   const owner = (await readOwned(context, '/me')).id as string
  131 |   const record = await seed(context)
  132 |   const baselines: string[] = []
  133 |   for (const value of [deviation, deviation + 1]) {
  134 |     const id = randomUUID()
  135 |     expect(
  136 |       (
  137 |         await post(context, '/baselines', {
  138 |           id,
  139 |           client_version: 'Fixture+V1',
  140 |           neck: null,
  141 |           trunk: null,
  142 |           shoulder: { method: 'fixture-shoulder', unit: 'deg', value },
  143 |         })
  144 |       ).status(),
  145 |     ).toBe(201)
  146 |     baselines.push(id)
  147 |   }
  148 |   const empty = { unit: 'deg', dev_mean: null, measured_sec: 0, bad_sec: 0 }
  149 |   expect(
  150 |     (
  151 |       await post(context, '/summaries/batch', {
  152 |         items: [
  153 |           {
  154 |             minute_start: new Date(
  155 |               Math.floor(Date.now() / 60000) * 60000 - 5 * 60000,
  156 |             ).toISOString(),
  157 |             baseline_id: baselines[0],
  158 |             client_version: 'Fixture+V1',
  159 |             coverage_sec: 60,
  160 |             measured_sec: 30,
  161 |             unmeasurable_sec: 20,
  162 |             present_sec: 45,
  163 |             background_sec: 10,
  164 |             any_bad_sec: 15,
  165 |             neck: { ...empty, method: 'fixture-neck' },
  166 |             trunk: { ...empty, method: 'fixture-trunk' },
  167 |             shoulder: {
  168 |               ...empty,
  169 |               method: 'fixture-shoulder',
  170 |               dev_mean: deviation,
  171 |               measured_sec: 30,
  172 |               bad_sec: 15,
  173 |             },
  174 |           },
  175 |         ],
  176 |       })
  177 |     ).status(),
  178 |   ).toBe(201)
  179 |   const preferences = {
  180 |     ...preferenceDefaults,
  181 |     posture_enabled: false,
  182 |     posture_minutes: 15,
  183 |     sitting_minutes: deviation === 1.25 ? 90 : 75,
  184 |     sound_enabled: true,
  185 |   }
  186 |   expect((await post(context, '/settings/notifications', preferences)).status()).toBe(200)
  187 |   return { owner, record, baselines, preferences }
  188 | }
  189 | async function snapshotAll(context: BrowserContext, ids: Awaited<ReturnType<typeof seedAll>>) {
  190 |   return {
  191 |     records: await readOwned(context, '/records/stretch'),
  192 |     summaries: await readOwned(context, '/summaries'),
  193 |     active: await readOwned(context, '/baselines/active'),
  194 |     past: await readOwned(context, `/baselines/${ids.baselines[0]}`),
  195 |     current: await readOwned(context, `/baselines/${ids.baselines[1]}`),
  196 |     preferences: await readOwned(context, '/settings/notifications'),
  197 |   }
  198 | }
  199 | async function noOverflow(page: Page) {
  200 |   expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true)
  201 | }
  202 | async function contrast(element: Locator, property: 'color' | 'borderTopColor' | 'outlineColor') {
  203 |   return element.evaluate((node, prop) => {
  204 |     let parent: Element | null = node,
  205 |       background = 'rgb(255, 255, 255)'
  206 |     while (parent) {
  207 |       const value = getComputedStyle(parent).backgroundColor
  208 |       if (value !== 'rgba(0, 0, 0, 0)' && value !== 'transparent') {
```