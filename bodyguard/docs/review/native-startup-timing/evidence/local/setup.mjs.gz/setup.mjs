import assert from 'node:assert/strict'
import fs from 'node:fs'
import {spawnSync} from 'node:child_process'
import {createHash} from 'node:crypto'
const work="/Applications/학교 내부/2026-2학기/오픈소스 AI SW 융합 프로젝트/BODYGUARD-startup-latency",proof="/private/tmp/bodyguard-startup-latency-proof.W7zNAZ",browser="/private/tmp/bodyguard-native-feedback-proof.k3Skez",db="/private/tmp/bodyguard-auth-test.7syivQ",old="/private/tmp/bodyguard-adaptive-reference-proof.UYNLTU",oldBrowser="/private/tmp/bodyguard-native-feedback-proof.rA4Lb7"
const cache=work.replace('BODYGUARD-startup-latency','BODYGUARD-owned-alert-lifecycle')+'/bodyguard/frontend/public/models'
const digest=b=>createHash('sha256').update(b).digest('hex')
fs.mkdirSync(work+'/bodyguard/frontend/public/models',{recursive:true})
const assets=[]
for(const n of fs.readdirSync(cache).filter(n=>n.endsWith('.task'))){
 const b=fs.readFileSync(cache+'/'+n),dst=work+'/bodyguard/frontend/public/models/'+n
 fs.copyFileSync(cache+'/'+n,dst,fs.constants.COPYFILE_EXCL);assert(fs.readFileSync(dst).equals(b))
 assets.push({name:n,bytes:b.length,sha256:digest(b)})
}
for(const n of ['male.glb','female.glb','authored-fixture.json']){
 const b=fs.readFileSync(oldBrowser+'/'+n);fs.copyFileSync(oldBrowser+'/'+n,browser+'/'+n,fs.constants.COPYFILE_EXCL)
 assert(fs.readFileSync(browser+'/'+n).equals(b));assets.push({name:n,bytes:b.length,sha256:digest(b),reused:true})
}
fs.writeFileSync(proof+'/assets.json',JSON.stringify(assets,null,2),{flag:'wx'})
fs.mkdirSync(proof+'/bin')
let shim=fs.readFileSync(old+'/bin/pnpm','utf8').replaceAll('BODYGUARD-adaptive-reference','BODYGUARD-startup-latency')
fs.writeFileSync(proof+'/bin/pnpm',shim,{flag:'wx',mode:0o755})
let runner=fs.readFileSync(old+'/browser.mjs','utf8')
for(const[a,b]of[['BODYGUARD-adaptive-reference','BODYGUARD-startup-latency'],[old,proof],[oldBrowser,browser],['/private/tmp/bodyguard-auth-test.hpGuWj',db]]){
 assert(runner.includes(a));runner=runner.replaceAll(a,b)
}
runner=runner.replace("'bodyguard/frontend/src/avatar','bodyguard/frontend/src/coaching'","'bodyguard/frontend/src'")
fs.writeFileSync(proof+'/browser.mjs',runner,{flag:'wx'})
let unit=fs.readFileSync(proof+'/run.mjs','utf8')
unit=unit.replace("'bodyguard/frontend/src/avatar','bodyguard/frontend/src/coaching'","'bodyguard/frontend/src'")
fs.writeFileSync(proof+'/run.mjs',unit)
assert.equal(fs.realpathSync(db),db);assert.equal(fs.statSync(db).uid,process.getuid());assert(!fs.existsSync(db+'/data'))
const bin='/opt/homebrew/opt/postgresql@18/bin/'
for(const[label,command,args]of[
 ['init',bin+'initdb',['-D',db+'/data','--auth=trust','--no-locale','--encoding=UTF8','--username=bodyguard_test']],
 ['start',bin+'pg_ctl',['-D',db+'/data','-l',db+'/postgres.log','-o','-k '+db+" -c listen_addresses='' -p 5432",'-w','start']],
 ['create',bin+'createdb',['-h',db,'-U','bodyguard_test','bodyguard_test']],
 ['identity',bin+'psql',['-h',db,'-U','bodyguard_test','-d','bodyguard_test','-At','-c',"SELECT current_database(),current_user,current_setting('server_version'),current_setting('listen_addresses');"]],
]){
 const r=spawnSync(command,args,{maxBuffer:5*1024*1024});fs.writeFileSync(proof+'/db-'+label+'.log',Buffer.concat([r.stdout??Buffer.alloc(0),r.stderr??Buffer.alloc(0)]),{flag:'wx'})
 console.log(JSON.stringify({label,exit:r.status}));assert.equal(r.status,0,label)
}
