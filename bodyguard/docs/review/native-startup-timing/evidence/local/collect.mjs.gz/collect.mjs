import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import {createHash} from 'node:crypto'
import {execFileSync} from 'node:child_process'
import {gzipSync} from 'node:zlib'
const work="/Applications/학교 내부/2026-2학기/오픈소스 AI SW 융합 프로젝트/BODYGUARD-startup-latency",proof="/private/tmp/bodyguard-startup-latency-proof.W7zNAZ",runtime='245508ce92a7c722ae1f6b94c7d1600db54e0839'
const root=work+'/bodyguard/docs/review/native-startup-timing',manifest=[]
const sha=b=>createHash('sha256').update(b).digest('hex')
function put(name,b,compress=false){
 const content=compress?gzipSync(b,{level:9}):b,file=root+'/'+name+(compress?'.gz':'')
 fs.mkdirSync(path.dirname(file),{recursive:true});fs.writeFileSync(file,content,{flag:'wx'})
 manifest.push({path:path.relative(root,file),bytes:content.length,sha256:sha(content),...(compress?{uncompressedBytes:b.length,uncompressedSha256:sha(b)}:{})})
}
for(const n of fs.readdirSync(proof).filter(n=>/\.(?:json|stdout|stderr|log|ts|mjs|md)$/.test(n)))put('evidence/local/'+n,fs.readFileSync(proof+'/'+n),true)
const browser=proof+'/browser-first-outputs/nativefeedback-20261008T103914842670Z'
put('evidence/browser/report.json',fs.readFileSync(browser+'/report.json'),true)
const timings=[]
for(const dir of fs.readdirSync(browser)){
 const f=browser+'/'+dir+'/native-startup-timing.json';if(!fs.existsSync(f))continue
 for(const n of ['native-startup-timing.json','before-close.json','native-hands-summary.json'])put('evidence/browser/'+dir+'/'+n,fs.readFileSync(browser+'/'+dir+'/'+n),true)
 const data=JSON.parse(fs.readFileSync(f)),first=n=>data.events.find(e=>e.stage===n)
 timings.push({gender:dir.includes('female')?'female':'male',cameraMs:first('camera').endMs-first('camera').startMs,sdkMs:['body-sdk','face-sdk','hands-sdk'].map(n=>first(n).endMs-first(n).startMs),avatarMs:first('avatar').endMs-first('avatar').startMs,firstRendererCallMs:first('render').endMs-first('render').startMs,firstResultLifetimeMs:first('result').endMs-first('result').startMs,firstResultReturnedFromCameraStartMs:first('result').endMs,thirdResultReturnedFromCameraStartMs:data.events.filter(e=>e.stage==='result')[2].endMs})
}
for(const n of ['bodyguard/frontend/e2e/fixtures/nativeHeadAuthProbe.ts','bodyguard/frontend/e2e/fixtures/nativeStartupTiming.ts','bodyguard/frontend/e2e/nativehead.spec.ts','bodyguard/frontend/src/native-startup-timing.test.ts','bodyguard/docs/stories/native-startup-timing.md']){
 const b=execFileSync('git',['show',runtime+':'+n],{cwd:work,maxBuffer:16*1024*1024});assert(b.equals(fs.readFileSync(work+'/'+n)));put('source/'+n,b)
}
const audit=JSON.parse(fs.readFileSync(proof+'/candidate-audit.json'))
const result={runtime,base:audit.base,actual:{...audit.frontend,chromePassed:20,chromeFailed:0,chromeSkipped:0,chromeRetries:0,sourceStable:true,publicByteEqual:true,actualAuthApiIsolatedDb:true,actualSdk:true,fakeCamera:true,fakeMail:true,syntheticMotionGates:true,actualHuman:false,actualPhysicalCamera:false,nativePositiveDetections:0,qualifiedMotions:0,rootCauseReproduced:false,productStartupP2Resolved:false,finalAppearanceApproved:false,stages1to6Complete:false},timings,publicAssets:audit.assets,preservedOriginalProof:proof,privateBundlePreserved:"/private/tmp/bodyguard-native-feedback-proof.k3Skez",excludedFromManifest:['Compiled SDK/React/Three probe bundles and large GLB/models/source duplicates','Actual raw video/coordinates/auth cookies (not recorded)','Later README/status/commit/PR/merge records'],manifest}
fs.writeFileSync(root+'/summary.json',JSON.stringify(result,null,2),{flag:'wx'});console.log(JSON.stringify({files:manifest.length,packedBytes:manifest.reduce((n,r)=>n+r.bytes,0),runtime,timings}))
