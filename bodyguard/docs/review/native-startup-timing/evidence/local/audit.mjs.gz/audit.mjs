import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import {createHash} from 'node:crypto'
import {execFileSync} from 'node:child_process'
const work="/Applications/학교 내부/2026-2학기/오픈소스 AI SW 융합 프로젝트/BODYGUARD-startup-latency",proof="/private/tmp/bodyguard-startup-latency-proof.W7zNAZ",baseline="/Applications/학교 내부/2026-2학기/오픈소스 AI SW 융합 프로젝트/BODYGUARD-adaptive-reference"
const sha=b=>createHash('sha256').update(b).digest('hex')
const tracked=()=>execFileSync('git',['ls-files','-z','--cached','--others','--exclude-standard','bodyguard/frontend/src','bodyguard/frontend/e2e','bodyguard/docs/stories/native-startup-timing.md'],{cwd:work,encoding:'utf8'}).split('\0').filter(Boolean)
const source=Object.fromEntries(tracked().map(n=>[n,sha(fs.readFileSync(work+'/'+n))]))
const verified=[]
for(const label of ['timing-unit-final','timing-full','timing-biome','browser-first','timing-types-final','timing-build','timing-guard']){
 const r=JSON.parse(fs.readFileSync(proof+'/'+label+'.json'));assert.equal(r.exit,0,label)
 assert.deepEqual(r.sourceBefore,r.sourceAfter,label+' source changed')
 for(const [name,hash] of Object.entries(r.sourceAfter)) assert.equal(sha(fs.readFileSync(work+'/'+name)),hash,label+' candidate mismatch: '+name)
 for(const name of tracked().filter(n=>n.endsWith('.ts')||n.endsWith('.tsx'))) assert.equal(r.sourceAfter[name],source[name],label+' TS coverage mismatch: '+name)
 verified.push({label,scope:Object.keys(r.sourceAfter).length})
}
const assets=[]
for(const n of fs.readdirSync(work+'/bodyguard/frontend/dist/assets').filter(n=>/\.(js|css)$/.test(n))){
 const b=fs.readFileSync(work+'/bodyguard/frontend/dist/assets/'+n);assert(b.equals(fs.readFileSync(baseline+'/bodyguard/frontend/dist/assets/'+n)))
 assert(!b.toString().includes('nativeStartupTiming'));assets.push({name:n,bytes:b.length,sha256:sha(b),baselineByteEqual:true})
}
const unit=JSON.parse(fs.readFileSync(proof+'/timing-full.report.json'));assert.equal(unit.numFailedTests,0);assert.equal(unit.numPendingTests,0)
const browser=JSON.parse(fs.readFileSync(proof+'/browser-first-outputs/nativefeedback-20261008T103914842670Z/report.json'))
assert.equal(browser.stats.expected,20);assert.equal(browser.stats.unexpected,0);assert.equal(browser.stats.skipped,0);assert.equal(browser.stats.flaky,0)
const out={base:execFileSync('git',['rev-parse','HEAD'],{cwd:work,encoding:'utf8'}).trim(),verified,source,assets,frontend:{passed:unit.numPassedTests,failed:unit.numFailedTests,skipped:unit.numPendingTests},chrome:browser.stats,actualHuman:false,actualPhysicalCamera:false,qualifiedMotions:0,rootCauseReproduced:false,productStartupP2Resolved:false}
fs.writeFileSync(proof+'/candidate-audit.json',JSON.stringify(out,null,2),{flag:'wx'});console.log(JSON.stringify({verified,sourceFiles:Object.keys(source).length,assets,frontend:out.frontend,chrome:out.chrome}))
