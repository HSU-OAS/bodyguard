# 計測 증거 대조 helper의 첫 실패

2026-10-08 audit.mjs 첫 실행 exit1: `browser-first candidate mismatch`.
브라우저 receipt는 backend/tests/run_browser.py를 포함하고 Story를 제외하는데,
로컬 receipt는 Story를 포함하고 backend runner를 제외한다. 서로 다른 집합 전체를
동일하다고 잘못 비교했다. 실제 코드 변경/Chrome 실패가 아니다.
원본 helper는 audit-before-scope-fix.mjs로 보존했다. 수정 후에는 각 receipt의
전체 scope를 실제 파일에 대조하고 모든 TS/TSX 포함 여부도 별도로 검사한다.
첫 실행 terminal의 전체 대형 assertion output은 파일로 캡처하지 않았으며,
이 기록을 원본 stdout 파일이라고 표시하지 않는다.
