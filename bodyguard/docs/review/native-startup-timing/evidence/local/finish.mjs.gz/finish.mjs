import assert from 'node:assert/strict'
import fs from 'node:fs'
import {spawnSync} from 'node:child_process'
const work="/Applications/학교 내부/2026-2학기/오픈소스 AI SW 융합 프로젝트/BODYGUARD-startup-latency",proof="/private/tmp/bodyguard-startup-latency-proof.W7zNAZ",db="/private/tmp/bodyguard-auth-test.7syivQ"
assert.equal(fs.realpathSync(db),db);assert.equal(fs.statSync(db).uid,process.getuid())
const bin='/opt/homebrew/opt/postgresql@18/bin/'
const identity=spawnSync(bin+'psql',['-h',db,'-U','bodyguard_test','-d','bodyguard_test','-At','-c',"SELECT current_setting('data_directory'),current_setting('listen_addresses');"],{encoding:'utf8'})
assert.equal(identity.status,0);assert.equal(identity.stdout.trim(),db+'/data|')
const result=spawnSync(bin+'pg_ctl',['-D',db+'/data','-m','fast','-w','stop'],{encoding:'utf8'})
fs.writeFileSync(proof+'/db-stop.stdout',result.stdout,{flag:'wx'});fs.writeFileSync(proof+'/db-stop.stderr',result.stderr,{flag:'wx'})
assert.equal(result.status,0);assert(!fs.existsSync(db+'/data/postmaster.pid'))
const link=work+'/bodyguard/frontend/node_modules',target=work.replace('BODYGUARD-startup-latency','BODYGUARD-owned-alert-lifecycle')+'/bodyguard/frontend/node_modules'
assert(fs.lstatSync(link).isSymbolicLink());assert.equal(fs.realpathSync(link),fs.realpathSync(target));fs.unlinkSync(link)
const record={stopped:true,exit:result.status,isolatedSocket:db,listenAddresses:'',dataPreserved:fs.existsSync(db+'/data/PG_VERSION'),ownSymlinkRemoved:true,cachePreserved:fs.existsSync(target),finished:new Date().toISOString()}
fs.writeFileSync(proof+'/db-stop.json',JSON.stringify(record,null,2),{flag:'wx'});console.log(JSON.stringify(record))
