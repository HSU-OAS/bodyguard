import {spawnSync} from 'node:child_process'
import fs from 'node:fs'
const proof="/private/tmp/bodyguard-reference-proof.vtuLnj"
for(const [label,command,args] of [
  ['unit-committed','./node_modules/.bin/vitest',['run','--reporter=json','--outputFile='+proof+'/frontend-committed.json']],
  ['types-committed','./node_modules/.bin/tsc',['--noEmit']],
  ['biome-committed','./node_modules/.bin/biome',['check','.']],
  ['assets-committed','node',['scripts/prepare-assets.mjs']],
  ['build-committed','./node_modules/.bin/vite',['build']],
  ['guard-committed','node',['scripts/check-selection-production.mjs']],
  ['ruff-committed',"/Applications/학교 내부/2026-2학기/오픈소스 AI SW 융합 프로젝트/BODYGUARD-account-web/bodyguard/backend/.venv/bin/python",['-m','ruff','check','scripts/create-reference-fixture.py']],
  ['diff-committed','git',['diff','--check']],
]) {
  const r=spawnSync('node',[proof+'/run.mjs',label,command,...args],{stdio:'inherit'})
  if(r.status!==0)process.exit(r.status??1)
}
console.log(JSON.stringify({complete:true}))
