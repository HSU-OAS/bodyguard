import assert from 'node:assert/strict'
import {execFileSync} from 'node:child_process'
import {createHash} from 'node:crypto'
import fs from 'node:fs'
import path from 'node:path'
const work="/Applications/학교 내부/2026-2학기/오픈소스 AI SW 융합 프로젝트/BODYGUARD-reference-playback",proof="/private/tmp/bodyguard-reference-proof.vtuLnj"
const cache='/private/tmp/bodyguard-hand-proof.UXNzqK'
const sha=b=>createHash('sha256').update(b).digest('hex')
const copy=(from,to)=>{
  const data=fs.readFileSync(from)
  if(fs.existsSync(to))assert(fs.readFileSync(to).equals(data))
  else fs.writeFileSync(to,data,{flag:'wx'})
  return {bytes:data.length,sha:sha(data)}
}
const assets={}
for(const gender of ['male','female']) {
  const original=execFileSync('git',['show','25a9bd6c7392890e3b5d5d6ae1046bb7087d56ad:bodyguard/frontend/src/avatar/models/bodyguard-'+gender+'-candidate-a37.glb'],{cwd:work,maxBuffer:32*1024*1024})
  assert(original.equals(fs.readFileSync(path.join(cache,gender+'.glb'))))
  assets[gender]=copy(path.join(cache,gender+'.glb'),path.join(proof,gender+'.glb'))
}
const blend=fs.readFileSync(path.join(cache,'a37.blend'))
const gitBlend=execFileSync('git',['show','25a9bd6c7392890e3b5d5d6ae1046bb7087d56ad:bodyguard/assets/blender/bodyguard_avatar_candidate_a37.blend'],{cwd:work,maxBuffer:40*1024*1024})
assert(blend.equals(gitBlend))
assets.originalBlendUnchanged={bytes:blend.length,sha:sha(blend)}
const corrected=JSON.parse(fs.readFileSync(path.join(proof,'blender-fixture-corrected.json'),'utf8'))
assert.equal(corrected.exit,0)
assert.equal(fs.readFileSync(path.join(proof,'blender-fixture-corrected.stderr'),'utf8'),'')
const line=fs.readFileSync(path.join(proof,'blender-fixture-corrected.stdout'),'utf8').split('\n').find(l=>l.startsWith('BODYGUARD_REFERENCE_FIXTURE '))
assert(line)
const fixture=JSON.parse(line.slice('BODYGUARD_REFERENCE_FIXTURE '.length))
assert.equal(fixture.fixture_not_release,true)
fs.writeFileSync(path.join(proof,'authored-fixture.json'),JSON.stringify(fixture,null,2),{flag:'wx'})
const modelDir=path.join(work,'bodyguard/frontend/public/models')
fs.mkdirSync(modelDir,{recursive:true})
const installed="/Applications/학교 내부/2026-2학기/오픈소스 AI SW 융합 프로젝트/BODYGUARD-owned-alert-lifecycle"
for(const name of fs.readdirSync(path.join(installed,'bodyguard/frontend/public/models')).filter(n=>/\.task$|\.tflite$/.test(n)))
  assets[name]=copy(path.join(installed,'bodyguard/frontend/public/models',name),path.join(modelDir,name))
fs.writeFileSync(path.join(proof,'asset-preservation.json'),JSON.stringify(assets,null,2),{flag:'wx'})
console.log(JSON.stringify(assets))
