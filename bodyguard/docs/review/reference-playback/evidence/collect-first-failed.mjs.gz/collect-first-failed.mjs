import assert from 'node:assert/strict'
import {execFileSync} from 'node:child_process'
import {createHash} from 'node:crypto'
import fs from 'node:fs'
import path from 'node:path'
import {gzipSync,gunzipSync} from 'node:zlib'
const work="/Applications/학교 내부/2026-2학기/오픈소스 AI SW 융합 프로젝트/BODYGUARD-reference-playback",proof="/private/tmp/bodyguard-reference-proof.vtuLnj",runtime="2c24b659f703b2c97adaa6be06a5153d42ee5e4f"
const base="/Applications/학교 내부/2026-2학기/오픈소스 AI SW 융합 프로젝트/BODYGUARD-native-hands"
const target=path.join(work,'bodyguard/docs/review/reference-playback')
assert.equal(execFileSync('git',['rev-parse','HEAD'],{cwd:work,encoding:'utf8'}).trim(),runtime)
assert(!fs.existsSync(target));fs.mkdirSync(target,{recursive:true})
const sha=b=>createHash('sha256').update(b).digest('hex')
const read=n=>JSON.parse(fs.readFileSync(path.join(proof,n),'utf8'))
const finalLabels=['unit-committed','types-committed','biome-committed','assets-committed','build-committed',
  'guard-committed','ruff-committed','diff-committed','blender-committed','browser-build-final','run-browser-final','guard-restored']
for(const label of finalLabels) {
  const r=read(label+'.json');assert.equal(r.exit,0);assert.equal(r.head,runtime)
  assert.deepEqual(r.sourceBefore,r.sourceAfter)
}
const units=read('frontend-committed.json');assert(units.success)
assert.equal(units.numFailedTests,0);assert.equal(units.numPendingTests,0)
const browser=read('browser-final.json');assert.equal(browser.head,runtime)
assert.equal(browser.camera,0);assert.equal(browser.external,0);assert.equal(browser.errors.length,0)
assert.equal(browser.samples.length,2);assert(browser.samples.every(s=>s.passed))
assert.deepEqual(browser.sourceBefore,browser.sourceAfter)
for(const [name,hash] of Object.entries(browser.sourceBefore))
  assert.equal(hash,sha(execFileSync('git',['show',runtime+':bodyguard/frontend/'+name],{cwd:work})))
const authored=read('authored-fixture.json')
const marker=fs.readFileSync(path.join(proof,'blender-committed.stdout'),'utf8').split('\n')
  .find(l=>l.startsWith('BODYGUARD_REFERENCE_FIXTURE '))
assert(marker);assert.deepEqual(JSON.parse(marker.slice('BODYGUARD_REFERENCE_FIXTURE '.length)),authored)
assert.equal(fs.readFileSync(path.join(proof,'blender-committed.stderr'),'utf8'),'')
const sourceNames=[
 'bodyguard/docs/stories/reference-playback.md',
 ...execFileSync('git',['diff','--name-only',"24c9c0dcab13f96e1e3b397324fca38babf72ad0",runtime],{cwd:work,encoding:'utf8'}).trim().split('\n'),
 ...['src/avatar/eightWeightSkin.ts','src/avatar/directionalRig.ts','src/avatar/observedPoseRig.ts',
 'src/avatar/headOrientationRig.ts','src/avatar/observedHandRig.ts','src/pose/ownedPosePlayback.ts',
 'src/stretch/progression.ts','src/coaching/session.ts','src/coaching/resources.ts',
 'package.json','pnpm-lock.yaml','vite.config.ts'].map(n=>'bodyguard/frontend/'+n),
]
const sources=[]
for(const name of [...new Set(sourceNames)]) {
  const b=execFileSync('git',['show',runtime+':'+name],{cwd:work,maxBuffer:10*1024*1024})
  const relative='source/'+name,out=path.join(target,relative)
  fs.mkdirSync(path.dirname(out),{recursive:true});fs.writeFileSync(out,b,{flag:'wx'})
  sources.push({path:relative,gitPath:name,sha:sha(b),bytes:b.length})
}
const artifacts=[]
function archive(from,relative) {
  const b=fs.readFileSync(from),compress=!relative.endsWith('.png')
  const name='evidence/'+relative+(compress?'.gz':'')
  const out=path.join(target,name),data=compress?gzipSync(b):b
  fs.mkdirSync(path.dirname(out),{recursive:true});fs.writeFileSync(out,data,{flag:'wx'})
  artifacts.push({path:name,sha:sha(data),bytes:data.length,originalSHA:sha(b),originalBytes:b.length,gzip:compress})
}
for(const name of fs.readdirSync(proof)) {
  const from=path.join(proof,name)
  if(fs.statSync(from).isFile()&&!name.endsWith('.glb'))archive(from,name)
  else if(/^(probe-|public-first)/.test(name)) {
    for(const child of fs.readdirSync(from))archive(path.join(from,child),name+'/'+child)
  }
}
const publicFiles={}
for(const name of fs.readdirSync(path.join(work,'bodyguard/frontend/dist/assets'))) {
  const b=fs.readFileSync(path.join(work,'bodyguard/frontend/dist/assets',name))
  const old=fs.readFileSync(path.join(base,'bodyguard/frontend/dist/assets',name))
  assert(b.equals(old));publicFiles[name]={bytes:b.length,sha:sha(b)}
  archive(path.join(work,'bodyguard/frontend/dist/assets',name),'public-final/'+name)
}
const license=fs.readFileSync(path.join(work,'bodyguard/frontend/node_modules/three/LICENSE'))
fs.mkdirSync(path.join(target,'notices'))
fs.writeFileSync(path.join(target,'notices/three-MIT.txt'),license,{flag:'wx'})
const summary={
 story:'S2.T17',runtime,baseline:"24c9c0dcab13f96e1e3b397324fca38babf72ad0",
 verification:{frontend:{tests:units.numTotalTests,passed:units.numPassedTests,failed:0,skipped:0},
  browser:{passed:2,failed:0,version:browser.browser,actualWebGL:true,actualBlender:authored.blender,
    camera:0,SDK:false,approvedMotion:false,releaseAvatar:false},
  finalLabels,publicFiles,assetPreservation:read('asset-preservation.json')},
 review:{type:'author-only',unresolvedStoryP1:0,unresolvedStoryP2:0},
 release:{qualifiedMotions:0,stage2Complete:false,stages1to6Complete:false},
 sources,artifacts,notice:{path:'notices/three-MIT.txt',sha:sha(license),bytes:license.length},
}
fs.writeFileSync(path.join(target,'summary.json'),JSON.stringify(summary,null,2),{flag:'wx'})
for(const item of artifacts) {
  const b=fs.readFileSync(path.join(target,item.path));assert.equal(sha(b),item.sha)
  assert.equal(sha(item.gzip?gunzipSync(b):b),item.originalSHA)
}
console.log(JSON.stringify({sources:sources.length,artifacts:artifacts.length,tests:units.numTotalTests,target}))
