import assert from 'node:assert/strict'
import { spawnSync, execFileSync } from 'node:child_process'
import { createHash } from 'node:crypto'
import { existsSync, readFileSync, writeFileSync } from 'node:fs'
import { join } from 'node:path'
const work = "/Applications/학교 내부/2026-2학기/오픈소스 AI SW 융합 프로젝트/BODYGUARD-reference-playback"
const proof = "/private/tmp/bodyguard-reference-proof.vtuLnj"
const [label, command, ...args] = process.argv.slice(2)
assert(/^[a-z][a-z0-9-]*$/.test(label ?? ''))
const receipt = join(proof, label + '.json')
assert(!existsSync(receipt))
const hash = b => createHash('sha256').update(b).digest('hex')
const hashes = () => {
  const files = execFileSync('git', ['ls-files', '--cached', '--others', '--exclude-standard',
    'bodyguard/frontend/src/avatar', 'bodyguard/frontend/e2e/fixtures/reference*',
    'bodyguard/frontend/scripts/*reference*', 'bodyguard/docs/stories/reference-playback.md'],
    { cwd: work, encoding:'utf8' }).trim().split('\n').filter(Boolean)
  return Object.fromEntries([...new Set(files)].map(n => [n, hash(readFileSync(join(work,n)))]))
}
const report = {
 head:execFileSync('git',['rev-parse','HEAD'],{cwd:work,encoding:'utf8'}).trim(),
 sourceBefore:hashes(),startedAt:new Date().toISOString(),command,args
}
const result = spawnSync(command,args,{
 cwd:join(work,'bodyguard/frontend'),env:process.env,encoding:'utf8',maxBuffer:64*1024*1024
})
writeFileSync(join(proof,label+'.stdout'),result.stdout ?? '',{flag:'wx'})
writeFileSync(join(proof,label+'.stderr'),result.stderr ?? '',{flag:'wx'})
Object.assign(report,{exit:result.status,signal:result.signal,error:result.error?.code ?? null,
 finishedAt:new Date().toISOString(),sourceAfter:hashes()})
writeFileSync(receipt,JSON.stringify(report,null,2),{flag:'wx'})
console.log(JSON.stringify({label,exit:report.exit,receipt,stdout:result.stdout?.slice(-2500),stderr:result.stderr?.slice(-1500)}))
process.exitCode=result.status ?? 1
