# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: integration.spec.ts >> WEB-I01 공개→가입→탐색 준비→기록 상세·취소·삭제→계정·로그아웃
- Location: e2e/integration.spec.ts:66:1

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByText('완료는 수행 흐름의 종료를 뜻하며, 자세 정확성이나 효과를 보장하는 점수가 아닙니다.')
Expected: visible
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" getByText('완료는 수행 흐름의 종료를 뜻하며, 자세 정확성이나 효과를 보장하는 점수가 아닙니다.') with timeout 5000ms
  - waiting for getByText('완료는 수행 흐름의 종료를 뜻하며, 자세 정확성이나 효과를 보장하는 점수가 아닙니다.')

```

```yaml
- button "본문으로 이동"
- banner:
  - link "BODYGUARD 서비스 소개":
    - /url: /
    - text: BODYGUARD
  - navigation "계정 메뉴":
    - link "내 시작":
      - /url: /start
    - link "자세 기록":
      - /url: /posture-records
    - link "수행 기록":
      - /url: /records
    - link "내 계정":
      - /url: /account
- main:
  - paragraph: MY BODYGUARD / RECORDS
  - heading "수행 기록 상세" [level=1]
  - paragraph: ‘완료’는 수행 종료입니다. 자세 정확성·효과를 보장하지 않습니다.
  - heading "fixture-web-integration" [level=2]
  - paragraph: 중단
  - term: 시작
  - definition:
    - time: 2026. 10. 10. 오후 04:32
  - term: 종료
  - definition:
    - time: 2026. 10. 10. 오후 04:33
  - term: 관찰된 수행 시간
  - definition: 1분 5초
  - term: 반복 요약
  - definition: 0회
  - term: 규칙 버전
  - definition: fixture-not-release
  - paragraph: 수행 요약만 저장하며, 영상·관절 좌표는 저장하지 않습니다.
  - link "기록 목록으로 돌아가기":
    - /url: /records?from=2026-10-04&to=2026-10-10
  - link "내 시작으로 돌아가기":
    - /url: /start
- contentinfo:
  - text: BODYGUARD
  - paragraph: 일상을 위한 스트레칭과 자세 코칭 · 출시 준비 중
  - navigation "서비스 안내":
    - link "도움말":
      - /url: /help
    - link "카메라·데이터 안내":
      - /url: /data
```

# Test source

```ts
  33  | test.afterEach(async ({ page }, info) => {
  34  |   const storageLengths = await page.evaluate(() => [localStorage.length, sessionStorage.length])
  35  |   await info.attach('integration-boundaries.json', {
  36  |     body: Buffer.from(
  37  |       JSON.stringify({
  38  |         actualWebHttpSql: true,
  39  |         actualProvider: false,
  40  |         actualHumanCamera: false,
  41  |         actualExercise: false,
  42  |         cameraCalls,
  43  |         unexpectedRequests,
  44  |         pageErrors,
  45  |         storageLengths,
  46  |         browserVersion: page.context().browser()?.version(),
  47  |       }),
  48  |     ),
  49  |     contentType: 'application/json',
  50  |   })
  51  |   expect(cameraCalls).toBe(0)
  52  |   expect(unexpectedRequests).toEqual([])
  53  |   expect(pageErrors).toEqual([])
  54  |   expect(storageLengths).toEqual([0, 0])
  55  | })
  56  | async function post(context: BrowserContext, path: string, data?: unknown) {
  57  |   const response = await context.request.get('/api/v1/auth/csrf')
  58  |   expect(response.status()).toBe(200)
  59  |   const csrf = await response.json()
  60  |   return context.request.post(`/api/v1${path}`, {
  61  |     headers: { Origin: origin, 'X-CSRF-Token': csrf.csrf_token },
  62  |     data,
  63  |   })
  64  | }
  65  | 
  66  | test('WEB-I01 공개→가입→탐색 준비→기록 상세·취소·삭제→계정·로그아웃', async ({
  67  |   page,
  68  |   context,
  69  | }, info) => {
  70  |   await page.goto('/')
  71  |   await expect(page.getByRole('heading', { name: '내 몸을 이해하는 스트레칭' })).toBeVisible()
  72  |   await page
  73  |     .getByRole('navigation', { name: '서비스 안내' })
  74  |     .getByRole('link', { name: '도움말', exact: true })
  75  |     .click()
  76  |   await expect(page.getByRole('heading', { level: 1, name: '도움말' })).toBeFocused()
  77  |   await page.getByRole('link', { name: '카메라·데이터 안내 보기' }).click()
  78  |   await expect(page.getByRole('heading', { name: '카메라와 데이터 안내' })).toBeFocused()
  79  |   await page
  80  |     .getByRole('navigation', { name: '서비스 안내' })
  81  |     .getByRole('link', { name: '도움말', exact: true })
  82  |     .click()
  83  |   await page.getByRole('link', { name: '이메일 가입', exact: true }).click()
  84  |   const email = `integration-${randomUUID()}@example.com`
  85  |   await page.getByLabel('이메일', { exact: true }).fill(email)
  86  |   await page.getByLabel('비밀번호', { exact: true }).fill('합성 통합 시험 비밀번호 12345')
  87  |   await page.getByRole('button', { name: '인증 코드 받기', exact: true }).click()
  88  |   await expect(page.getByRole('heading', { name: '이메일을 확인해 주세요' })).toBeVisible()
  89  |   let code = ''
  90  |   await expect
  91  |     .poll(() => {
  92  |       code = JSON.parse(readFileSync(mailbox as string, 'utf8'))[email] ?? ''
  93  |       return /^[0-9]{6}$/.test(code)
  94  |     })
  95  |     .toBe(true)
  96  |   await page.getByLabel('인증 코드', { exact: true }).fill(code)
  97  |   await page.getByRole('button', { name: '인증하고 시작하기' }).click()
  98  |   await expect(page.getByRole('heading', { name: '내 몸을 위한 시작' })).toBeVisible()
  99  |   await page.getByRole('link', { name: '스트레칭 시작 경로 선택', exact: true }).click()
  100 |   await expect(page.getByRole('status')).toContainText('현재 이용 가능한 동작이 없습니다')
  101 |   await page.getByRole('button', { name: '추천받기', exact: true }).click()
  102 |   await page.getByRole('radio', { name: '어깨', exact: true }).check()
  103 |   await expect(page.getByRole('status')).toContainText('신체 확인 정보가 없어')
  104 |   await page.screenshot({
  105 |     path: info.outputPath('integration-explore-pending.png'),
  106 |     fullPage: true,
  107 |   })
  108 |   await page.getByRole('link', { name: '내 시작으로 돌아가기' }).click()
  109 |   await page.getByRole('link', { name: '내 수행 기록 확인' }).click()
  110 |   await expect(page.getByText('이 기간에는 수행 기록이 없습니다', { exact: true })).toBeVisible()
  111 |   // Fixture insertion is not a coaching producer and not evidence of an actual stretch.
  112 |   const ended = new Date(Date.now() - 120_000)
  113 |   const record = {
  114 |     id: randomUUID(),
  115 |     motion_id: 'fixture-web-integration',
  116 |     protocol_version: 'fixture-not-release',
  117 |     started_at: new Date(ended.getTime() - 90_000).toISOString(),
  118 |     ended_at: ended.toISOString(),
  119 |     outcome: 'interrupted',
  120 |     observed_ms: 65_000,
  121 |     repetitions: 0,
  122 |   }
  123 |   const saved = await post(context, '/records/stretch', record)
  124 |   expect(saved.status()).toBe(201)
  125 |   expect((await saved.json()).provenance).toBe('client-reported')
  126 |   await page.reload()
  127 |   await page.getByRole('link', { name: /^fixture-web-integration .*기록 상세/ }).click()
  128 |   await expect(page.getByRole('heading', { name: '수행 기록 상세' })).toBeVisible()
  129 |   await expect(
  130 |     page.getByText(
  131 |       '완료는 수행 흐름의 종료를 뜻하며, 자세 정확성이나 효과를 보장하는 점수가 아닙니다.',
  132 |     ),
> 133 |   ).toBeVisible()
      |     ^ Error: expect(locator).toBeVisible() failed
  134 |   await page.screenshot({ path: info.outputPath('integration-record-detail.png'), fullPage: true })
  135 |   await page.getByRole('link', { name: '기록 목록으로 돌아가기' }).click()
  136 |   await page.getByRole('button', { name: '이 기간 기록 삭제', exact: true }).click()
  137 |   await expect(page.getByText('삭제 대상: 1건', { exact: true })).toBeVisible()
  138 |   await page.getByRole('button', { name: '취소', exact: true }).click()
  139 |   await expect(
  140 |     page.getByRole('link', { name: /^fixture-web-integration .*기록 상세/ }),
  141 |   ).toBeVisible()
  142 |   await page.getByRole('button', { name: '이 기간 기록 삭제', exact: true }).click()
  143 |   await page.getByRole('button', { name: '기록 삭제', exact: true }).click()
  144 |   await expect(page.getByText('1건의 수행 기록을 삭제했습니다.', { exact: true })).toBeVisible()
  145 |   const records = await context.request.get('/api/v1/records/stretch')
  146 |   expect(records.status()).toBe(200)
  147 |   expect((await records.json()).items).toEqual([])
  148 |   await page.getByRole('link', { name: '내 계정', exact: true }).click()
  149 |   await expect(page.getByRole('heading', { level: 1, name: '내 계정' })).toBeFocused()
  150 |   await page.setViewportSize({ width: 700, height: 900 })
  151 |   expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true)
  152 |   await page.screenshot({ path: info.outputPath('integration-account-700.png'), fullPage: true })
  153 |   // FR-U-04/NFR-08: bounded test-only operation boundary; never credentials or bodies.
  154 |   let logoutConfirmed = 0
  155 |   let logoutFailed = 0
  156 |   let csrfFailed = 0
  157 |   page.on('response', (response) => {
  158 |     if (new URL(response.url()).pathname === '/api/v1/auth/logout' && response.status() === 204)
  159 |       logoutConfirmed++
  160 |   })
  161 |   page.on('requestfailed', (request) => {
  162 |     const path = new URL(request.url()).pathname
  163 |     if (path === '/api/v1/auth/logout') logoutFailed++
  164 |     if (path === '/api/v1/auth/csrf') csrfFailed++
  165 |   })
  166 |   const confirmedLogout = page.waitForResponse(
  167 |     (response) =>
  168 |       new URL(response.url()).origin === origin &&
  169 |       new URL(response.url()).pathname === '/api/v1/auth/logout' &&
  170 |       response.request().method() === 'POST',
  171 |     { timeout: 5000 },
  172 |   )
  173 |   await page.getByRole('button', { name: '로그아웃', exact: true }).focus()
  174 |   await page.keyboard.press('Enter')
  175 |   expect((await confirmedLogout).status()).toBe(204)
  176 |   await expect(page.getByRole('heading', { name: '다시 만나 반갑습니다' })).toBeVisible()
  177 |   const movedBeforeConfirmation = logoutConfirmed === 0
  178 |   try {
  179 |     expect(movedBeforeConfirmation).toBe(false)
  180 |     await page.goto('/records')
  181 |     await expect(page.getByRole('heading', { name: '다시 만나 반갑습니다' })).toBeVisible()
  182 |     expect((await context.request.get('/api/v1/me')).status()).toBe(401)
  183 |   } finally {
  184 |     await info.attach('logout-completion-boundary.json', {
  185 |       contentType: 'application/json',
  186 |       body: Buffer.from(
  187 |         JSON.stringify({ movedBeforeConfirmation, logoutConfirmed, logoutFailed, csrfFailed }),
  188 |       ),
  189 |     })
  190 |   }
  191 | })
  192 | 
  193 | test('WEB-I02 계정 장애 주입·공개 안내 보존·production 개발 경로 차단', async ({ page }, info) => {
  194 |   await page.route('**/api/v1/me', (route) => route.abort('failed'))
  195 |   await page.goto('/account')
  196 |   await expect(page.getByRole('heading', { name: '연결을 확인해 주세요' })).toBeVisible()
  197 |   await expect(page.getByRole('button', { name: '로그아웃', exact: true })).toHaveCount(0)
  198 |   await page
  199 |     .getByRole('navigation', { name: '서비스 안내' })
  200 |     .getByRole('link', { name: '도움말', exact: true })
  201 |     .click()
  202 |   await expect(page.getByRole('heading', { name: '도움말', level: 1 })).toBeVisible()
  203 |   await page.getByRole('link', { name: '카메라·데이터 안내 보기' }).click()
  204 |   await page.reload()
  205 |   await expect(page.getByRole('heading', { name: '카메라와 데이터 안내' })).toBeVisible()
  206 |   await page.setViewportSize({ width: 700, height: 900 })
  207 |   expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true)
  208 |   await page.screenshot({
  209 |     path: info.outputPath('integration-public-offline-700.png'),
  210 |     fullPage: true,
  211 |   })
  212 |   for (const path of ['/dev/measure', '/dev/select']) {
  213 |     await page.goto(path)
  214 |     await expect(page.getByRole('heading', { name: '페이지를 찾을 수 없습니다' })).toBeVisible()
  215 |     await expect(page.getByRole('button', { name: '측정 시작', exact: true })).toHaveCount(0)
  216 |   }
  217 | })
  218 | 
```