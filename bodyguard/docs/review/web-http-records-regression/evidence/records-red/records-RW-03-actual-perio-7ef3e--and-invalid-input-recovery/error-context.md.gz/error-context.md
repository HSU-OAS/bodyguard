# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: records.spec.ts >> RW-03 actual period filter and invalid input recovery
- Location: e2e/records.spec.ts:347:1

# Error details

```
Error: expect(locator).toContainText(expected) failed

Locator: getByRole('alert')
Expected substring: "올바른 날짜"
Received string:    "오늘까지의 날짜로 시작일·종료일 순서를 확인해 주세요."
Timeout: 5000ms

Call log:
  - Expect "toContainText" getByRole('alert') with timeout 5000ms
  - waiting for getByRole('alert')
    14 × locator resolved to <p role="alert" class="form-error">오늘까지의 날짜로 시작일·종료일 순서를 확인해 주세요.</p>
       - unexpected value "오늘까지의 날짜로 시작일·종료일 순서를 확인해 주세요."

```

```yaml
- alert: 오늘까지의 날짜로 시작일·종료일 순서를 확인해 주세요.
```

# Test source

```ts
  262 | }, info) => {
  263 |   await join(context)
  264 |   await seed(context)
  265 |   const outside = await seed(context, 2, 'interrupted', 14)
  266 |   await page.goto('/records')
  267 |   await expect(page.getByRole('table')).toBeVisible()
  268 |   await page.getByRole('button', { name: '이 기간 기록 삭제', exact: true }).click()
  269 |   await expect(page.getByText('삭제 대상: 1건', { exact: true })).toBeVisible()
  270 |   await page.screenshot({ path: info.outputPath('deletion-preview.png'), fullPage: true })
  271 |   await page.getByRole('button', { name: '취소', exact: true }).click()
  272 |   expect((await (await context.request.get('/api/v1/records/stretch')).json()).items).toHaveLength(
  273 |     2,
  274 |   )
  275 |   await expect(page.getByRole('button', { name: '이 기간 기록 삭제', exact: true })).toBeFocused()
  276 |   await page.keyboard.press('Enter')
  277 |   await expect(page.getByText('삭제 대상: 1건', { exact: true })).toBeVisible()
  278 |   await page.setViewportSize({ width: 700, height: 800 })
  279 |   expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true)
  280 |   await page.screenshot({ path: info.outputPath('deletion-preview-narrow.png'), fullPage: true })
  281 |   await page.getByRole('button', { name: '기록 삭제', exact: true }).click()
  282 |   await expect(page.getByText('1건의 수행 기록을 삭제했습니다.', { exact: true })).toBeVisible()
  283 |   await expect(
  284 |     page.getByRole('heading', { name: '이 기간에는 수행 기록이 없습니다' }),
  285 |   ).toBeVisible()
  286 |   const remaining = (await (await context.request.get('/api/v1/records/stretch')).json()).items
  287 |   expect(remaining.map((item: { id: string }) => item.id)).toEqual([outside.id])
  288 |   await page.screenshot({ path: info.outputPath('deletion-result.png'), fullPage: true })
  289 | })
  290 | async function filter(page: Page, from: string, to: string) {
  291 |   await page.getByLabel('시작일', { exact: true }).fill(from)
  292 |   await page.getByLabel('종료일', { exact: true }).fill(to)
  293 |   await page.getByRole('button', { name: '기간 조회', exact: true }).click()
  294 | }
  295 | 
  296 | test('RW-01 protected entry and genuine empty record period', async ({ page, context }, info) => {
  297 |   const errors: string[] = []
  298 |   page.on('pageerror', (error) => errors.push(error.message))
  299 |   await page.goto('/records')
  300 |   await expect(page.getByRole('heading', { name: '다시 만나 반갑습니다' })).toBeVisible()
  301 |   expect((await context.request.get('/api/v1/records/stretch')).status()).toBe(401)
  302 |   await join(context)
  303 |   await page.goto('/start')
  304 |   await page.getByRole('link', { name: '내 수행 기록 확인' }).click()
  305 |   await expect(page.getByRole('heading', { name: '내 수행 기록' })).toBeFocused()
  306 |   await expect(
  307 |     page.getByRole('heading', { name: '이 기간에는 수행 기록이 없습니다' }),
  308 |   ).toBeVisible()
  309 |   await expect(page.getByRole('table')).toHaveCount(0)
  310 |   await page.screenshot({ path: info.outputPath('records-empty.png'), fullPage: true })
  311 |   await page.getByRole('link', { name: '스트레칭 시작 경로 선택' }).click()
  312 |   await expect(page.getByRole('heading', { name: '스트레칭 시작 경로' })).toBeVisible()
  313 |   expect(errors).toEqual([])
  314 | })
  315 | test('RW-02 actual summaries, detail, Back period and long record narrow layout', async ({
  316 |   page,
  317 |   context,
  318 | }, info) => {
  319 |   await join(context)
  320 |   const record = await seed(context, 1, 'completed', 0, true)
  321 |   await seed(context, 2, 'skipped')
  322 |   await seed(context, 3, 'interrupted')
  323 |   await page.goto('/records')
  324 |   await expect(page.getByRole('table')).toBeVisible()
  325 |   await expect(page.getByRole('row')).toHaveCount(4)
  326 |   await expect(page.getByText('완료', { exact: true })).toBeVisible()
  327 |   await expect(page.getByText('건너뜀', { exact: true })).toBeVisible()
  328 |   await expect(page.getByText('중단', { exact: true })).toBeVisible()
  329 |   const original = await page.getByLabel('시작일').inputValue()
  330 |   await page.screenshot({ path: info.outputPath('records-list.png'), fullPage: true })
  331 |   await page.setViewportSize({ width: 700, height: 800 })
  332 |   expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true)
  333 |   await page.screenshot({ path: info.outputPath('records-list-narrow.png'), fullPage: true })
  334 |   await page.getByRole('link', { name: new RegExp(`^${record.motion_id}.*기록 상세$`) }).click()
  335 |   await expect(page.getByRole('heading', { name: '수행 기록 상세' })).toBeFocused()
  336 |   await expect(page.getByText('fixture-not-release', { exact: true })).toBeVisible()
  337 |   await expect(page.getByText('1분 5초', { exact: true })).toBeVisible()
  338 |   await expect(page.getByText('1회', { exact: true })).toBeVisible()
  339 |   expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true)
  340 |   await page.screenshot({ path: info.outputPath('record-detail-narrow.png'), fullPage: true })
  341 |   await page.getByRole('link', { name: '기록 목록으로 돌아가기' }).click()
  342 |   await expect(page.getByLabel('시작일')).toHaveValue(original)
  343 |   await expect(page.getByRole('table')).toBeVisible()
  344 |   await page.goBack()
  345 |   await expect(page.getByRole('heading', { name: '수행 기록 상세' })).toBeVisible()
  346 | })
  347 | test('RW-03 actual period filter and invalid input recovery', async ({ page, context }, info) => {
  348 |   await join(context)
  349 |   const historical = await seed(context, 7, 'interrupted', 14)
  350 |   await seed(context)
  351 |   await page.goto('/records')
  352 |   await expect(page.getByRole('link', { name: /^fixture-1 .*기록 상세/ })).toBeVisible()
  353 |   await expect(page.getByRole('link', { name: /^fixture-7 .*기록 상세/ })).toHaveCount(0)
  354 |   const old = day(new Date(historical.ended_at))
  355 |   await filter(page, old, old)
  356 |   await expect(page.getByRole('link', { name: /^fixture-7 .*기록 상세/ })).toBeVisible()
  357 |   await expect(page.getByRole('link', { name: /^fixture-1 .*기록 상세/ })).toHaveCount(0)
  358 |   await page.screenshot({ path: info.outputPath('records-period.png'), fullPage: true })
  359 |   const tomorrowFromOld = new Date(historical.ended_at)
  360 |   tomorrowFromOld.setDate(tomorrowFromOld.getDate() + 1)
  361 |   await filter(page, day(tomorrowFromOld), old)
> 362 |   await expect(page.getByRole('alert')).toContainText('올바른 날짜')
      |                                         ^ Error: expect(locator).toContainText(expected) failed
  363 |   await filter(page, old, old)
  364 |   await expect(page.getByRole('alert')).toHaveCount(0)
  365 |   await expect(page.getByRole('link', { name: /^fixture-7 .*기록 상세/ })).toBeVisible()
  366 | })
  367 | test('RW-04 actual bounded pagination uses one cutoff and keyboard', async ({
  368 |   page,
  369 |   context,
  370 | }, info) => {
  371 |   await join(context)
  372 |   for (let i = 1; i <= 21; i++) await seed(context, i)
  373 |   await page.goto('/records')
  374 |   await expect(page.getByRole('row')).toHaveCount(21)
  375 |   const first = await page
  376 |     .locator('tbody a')
  377 |     .evaluateAll((links) => links.map((link) => link.getAttribute('href')))
  378 |   const firstRequest = requests.find((url) => url.includes('/api/v1/records/stretch?'))
  379 |   await page.getByRole('button', { name: '다음 페이지' }).focus()
  380 |   await page.keyboard.press('Enter')
  381 |   await expect(page.getByRole('row')).toHaveCount(2)
  382 |   await expect(page.locator('.records-results h2')).toBeFocused()
  383 |   await expect(page.getByRole('button', { name: '다음 페이지' })).toBeDisabled()
  384 |   const next = await page.locator('tbody a').getAttribute('href')
  385 |   expect(first).not.toContain(next)
  386 |   const secondRequest = requests.find((url) => url.includes('offset=20'))
  387 |   expect(new URL(firstRequest as string).searchParams.get('end')).toBe(
  388 |     new URL(secondRequest as string).searchParams.get('end'),
  389 |   )
  390 |   await page.screenshot({ path: info.outputPath('records-page-two.png'), fullPage: true })
  391 |   await page.getByRole('button', { name: '이전 페이지' }).click()
  392 |   await expect(page.getByRole('row')).toHaveCount(21)
  393 | })
  394 | test('RW-05 read failure recovery and cancelled late response after real logout', async ({
  395 |   page,
  396 |   context,
  397 | }, info) => {
  398 |   await join(context)
  399 |   await seed(context)
  400 |   await page.route('**/api/v1/records/stretch?**', (route) => route.abort('failed'))
  401 |   await page.goto('/records')
  402 |   await expect(page.getByRole('heading', { name: '기록을 불러오지 못했습니다' })).toBeVisible()
  403 |   await expect(page.getByRole('table')).toHaveCount(0)
  404 |   await page.screenshot({ path: info.outputPath('records-read-error.png'), fullPage: true })
  405 |   await page.unroute('**/api/v1/records/stretch?**')
  406 |   await page.getByRole('button', { name: '다시 조회' }).click()
  407 |   await expect(page.getByRole('table')).toBeVisible()
  408 |   let release: () => void = () => {}
  409 |   let actualRead = false
  410 |   const held = new Promise<void>((resolve) => {
  411 |     release = resolve
  412 |   })
  413 |   await page.route('**/api/v1/records/stretch?**', async (route) => {
  414 |     const response = await route.fetch()
  415 |     actualRead = true
  416 |     await held
  417 |     try {
  418 |       await route.fulfill({ response })
  419 |     } catch {
  420 |       /* aborted by account recheck */
  421 |     }
  422 |   })
  423 |   try {
  424 |     await page.reload()
  425 |     await expect.poll(() => actualRead).toBe(true)
  426 |     await expect(page.getByText('기록을 불러오고 있습니다.')).toBeVisible()
  427 |     await page.screenshot({ path: info.outputPath('records-loading.png'), fullPage: true })
  428 |     expect((await post(context, '/auth/logout')).status()).toBe(204)
  429 |     await page.evaluate(() => window.dispatchEvent(new Event('focus')))
  430 |     await expect(page.getByRole('heading', { name: '다시 만나 반갑습니다' })).toBeVisible()
  431 |     release()
  432 |     await expect(page.getByRole('table')).toHaveCount(0)
  433 |   } finally {
  434 |     release()
  435 |   }
  436 | })
  437 | test('RW-06 own-only detail, second account and Back after logout', async ({
  438 |   page,
  439 |   context,
  440 | }, info) => {
  441 |   await join(context)
  442 |   const record = await seed(context)
  443 |   await page.goto(`/records/${record.id}`)
  444 |   await expect(page.getByText('fixture-not-release', { exact: true })).toBeVisible()
  445 |   expect((await post(context, '/auth/logout')).status()).toBe(204)
  446 |   await page.evaluate(() => window.dispatchEvent(new Event('focus')))
  447 |   await expect(page.getByRole('heading', { name: '다시 만나 반갑습니다' })).toBeVisible()
  448 |   await page.goBack()
  449 |   await expect(page.getByText('fixture-not-release', { exact: true })).toHaveCount(0)
  450 |   await join(context)
  451 |   await page.goto('/records')
  452 |   await expect(
  453 |     page.getByRole('heading', { name: '이 기간에는 수행 기록이 없습니다' }),
  454 |   ).toBeVisible()
  455 |   const foreign = await context.request.get(`/api/v1/records/stretch/${record.id}`)
  456 |   expect(foreign.status()).toBe(404)
  457 |   await page.goto(`/records/${record.id}`)
  458 |   await expect(page.getByRole('heading', { name: '기록을 찾을 수 없습니다' })).toBeVisible()
  459 |   await expect(page.getByText('fixture-not-release', { exact: true })).toHaveCount(0)
  460 |   await page.screenshot({ path: info.outputPath('record-unavailable.png'), fullPage: true })
  461 |   await page.goto('/records/not-an-id')
  462 |   await expect(page.getByRole('heading', { name: '기록을 찾을 수 없습니다' })).toBeVisible()
```