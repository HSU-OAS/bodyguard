# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: authcoaching.spec.ts >> H07 unannounced real cookie account replacement rejects the old proof instead of saving for another person
- Location: e2e/authcoaching.spec.ts:229:1

# Error details

```
Error: expect(received).toMatchObject(expected)

- Expected  - 1
+ Received  + 1

  Object {
-   "record": "closed",
+   "record": "failed",
  }
```

# Page snapshot

```yaml
- generic [ref=e3]:
  - button "본문으로 이동" [ref=e4]
  - banner [ref=e5]:
    - link "BODYGUARD 서비스 소개" [ref=e6] [cursor=pointer]:
      - /url: /
      - text: BODYGUARD.
    - navigation "계정 메뉴" [ref=e7]:
      - link "내 시작" [ref=e8] [cursor=pointer]:
        - /url: /start
      - link "자세 기록" [ref=e9] [cursor=pointer]:
        - /url: /posture-records
      - link "수행 기록" [ref=e10] [cursor=pointer]:
        - /url: /records
      - link "내 계정" [ref=e11] [cursor=pointer]:
        - /url: /account
  - main [ref=e12]:
    - generic [ref=e13]:
      - paragraph [ref=e14]: MY BODYGUARD
      - heading "내 몸을 위한 시작" [active] [level=1] [ref=e15]
      - paragraph [ref=e16]: auth-coach-9e18cf9c-f448-460d-ac05-a3943ea42eb4@example.com
      - link "스트레칭 시작 경로 선택" [ref=e17] [cursor=pointer]:
        - /url: /explore
      - paragraph [ref=e18]:
        - link "내 수행 기록 확인" [ref=e19] [cursor=pointer]:
          - /url: /records
      - paragraph [ref=e20]:
        - link "내 자세 기록 확인" [ref=e21] [cursor=pointer]:
          - /url: /posture-records
      - paragraph [ref=e22]:
        - link "계정 관리" [ref=e23] [cursor=pointer]:
          - /url: /account
      - generic [ref=e24]:
        - heading "첫 코칭 흐름을 준비하고 있습니다" [level=2] [ref=e25]
        - paragraph [ref=e26]: 동작 검증과 남녀 3D 아바타 제작이 끝나면 스트레칭 선택과 코칭을 이곳에 연결합니다. 지금은 계정 기능을 사용할 수 있습니다.
        - paragraph [ref=e27]: 카메라는 켜지지 않았습니다.
      - button "로그아웃" [ref=e28] [cursor=pointer]
  - contentinfo [ref=e29]:
    - generic [ref=e30]: BODYGUARD
    - paragraph [ref=e31]: 일상을 위한 스트레칭과 자세 코칭 · 출시 준비 중
    - navigation "서비스 안내" [ref=e32]:
      - link "도움말" [ref=e33] [cursor=pointer]:
        - /url: /help
      - link "카메라·데이터 안내" [ref=e34] [cursor=pointer]:
        - /url: /data
```

# Test source

```ts
  151 |       disposed: 3,
  152 |       lifecycleClosed: 1,
  153 |     })
  154 |   await page.evaluate(() => (window as unknown as PrivateWindow).authCoachingProbe.resume())
  155 |   await page.evaluate(() => (window as unknown as PrivateWindow).authCoachingProbe.save())
  156 |   expect(posts).toBe(0)
  157 |   expect((await (await context.request.get('/api/v1/records/stretch')).json()).items).toHaveLength(
  158 |     0,
  159 |   )
  160 |   await page.evaluate(() => (window as unknown as PrivateWindow).authCoachingProbe.unmount())
  161 | })
  162 | 
  163 | test('H06 server accepted response loss retries the identical reported result once, not a duplicate record', async ({
  164 |   page,
  165 |   context,
  166 |   browser,
  167 | }) => {
  168 |   await join(context)
  169 |   const data = await mount(page)
  170 |   await page.evaluate(() => (window as unknown as PrivateWindow).authCoachingProbe.prepare())
  171 |   await page.evaluate(() => (window as unknown as PrivateWindow).authCoachingProbe.start())
  172 |   await page.evaluate(() => (window as unknown as PrivateWindow).authCoachingProbe.perform())
  173 |   expect(await state(page)).toMatchObject({ session: 'ended', disposed: 3, lifecycleClosed: 1 })
  174 |   expect(posts).toBe(0)
  175 |   const bodies: string[] = [],
  176 |     statuses: number[] = []
  177 |   await page.route('**/api/v1/records/stretch', async (route) => {
  178 |     if (route.request().method() !== 'POST') return route.continue()
  179 |     bodies.push(route.request().postData() ?? '')
  180 |     const response = await route.fetch()
  181 |     statuses.push(response.status())
  182 |     if (statuses.length === 1) await route.abort('failed')
  183 |     else await route.fulfill({ response })
  184 |   })
  185 |   await page.evaluate(() => (window as unknown as PrivateWindow).authCoachingProbe.save())
  186 |   expect(await state(page)).toMatchObject({ record: 'failed' })
  187 |   expect(posts).toBe(1)
  188 |   expect(statuses).toEqual([201])
  189 |   const dto = JSON.parse(bodies[0])
  190 |   expect(Object.keys(dto).sort()).toEqual(
  191 |     [
  192 |       'id',
  193 |       'motion_id',
  194 |       'protocol_version',
  195 |       'started_at',
  196 |       'ended_at',
  197 |       'outcome',
  198 |       'observed_ms',
  199 |       'repetitions',
  200 |     ].sort(),
  201 |   )
  202 |   expect(dto.id).toBe(data.recordId)
  203 |   const before = await (await context.request.get('/api/v1/records/stretch')).json()
  204 |   expect(before.items).toHaveLength(1)
  205 |   await page.evaluate(() => (window as unknown as PrivateWindow).authCoachingProbe.retry())
  206 |   expect(await state(page)).toMatchObject({ record: 'saved', acquired: 3, disposed: 3 })
  207 |   expect(posts).toBe(2)
  208 |   expect(statuses).toEqual([201, 200])
  209 |   expect(bodies).toHaveLength(2)
  210 |   expect(bodies[1]).toBe(bodies[0])
  211 |   const after = await (await context.request.get('/api/v1/records/stretch')).json()
  212 |   expect(after.items).toEqual(before.items)
  213 |   // Separate real account/cookies: local API auth is real, test mailbox is synthetic.
  214 |   const other = await browser.newContext({ baseURL: origin, serviceWorkers: 'block' })
  215 |   try {
  216 |     await join(other)
  217 |     expect((await other.request.get(`/api/v1/records/stretch/${data.recordId}`)).status()).toBe(404)
  218 |     expect((await (await other.request.get('/api/v1/records/stretch')).json()).items).toHaveLength(
  219 |       0,
  220 |     )
  221 |   } finally {
  222 |     await other.close()
  223 |   }
  224 |   await page.evaluate(() => (window as unknown as PrivateWindow).authCoachingProbe.unmount())
  225 |   await page.goto(`/records/${data.recordId}`)
  226 |   await expect(page.getByRole('heading', { name: '수행 기록 상세', exact: true })).toBeVisible()
  227 | })
  228 | 
  229 | test('H07 unannounced real cookie account replacement rejects the old proof instead of saving for another person', async ({
  230 |   page,
  231 |   context,
  232 | }) => {
  233 |   await join(context)
  234 |   await mount(page)
  235 |   await page.evaluate(() => (window as unknown as PrivateWindow).authCoachingProbe.prepare())
  236 |   await page.evaluate(() => (window as unknown as PrivateWindow).authCoachingProbe.start())
  237 |   await page.evaluate(() => (window as unknown as PrivateWindow).authCoachingProbe.perform())
  238 |   // Intentionally no AuthProvider refresh: captured CSRF proof must be the server backstop.
  239 |   await context.clearCookies()
  240 |   await join(context)
  241 |   let rejected = 0
  242 |   page.on('response', (response) => {
  243 |     if (
  244 |       response.url().endsWith('/api/v1/records/stretch') &&
  245 |       response.request().method() === 'POST' &&
  246 |       response.status() === 403
  247 |     )
  248 |       rejected++
  249 |   })
  250 |   await page.evaluate(() => (window as unknown as PrivateWindow).authCoachingProbe.save())
> 251 |   expect(await state(page)).toMatchObject({ record: 'closed' })
      |                             ^ Error: expect(received).toMatchObject(expected)
  252 |   expect(posts).toBe(1)
  253 |   expect(rejected).toBe(1)
  254 |   expect((await (await context.request.get('/api/v1/records/stretch')).json()).items).toHaveLength(
  255 |     0,
  256 |   )
  257 |   await page.evaluate(() => (window as unknown as PrivateWindow).authCoachingProbe.retry())
  258 |   expect(posts).toBe(1)
  259 |   await page.evaluate(() => (window as unknown as PrivateWindow).authCoachingProbe.unmount())
  260 | })
  261 | test('H03 failed logout is not permission to keep coaching or save', async ({ page, context }) => {
  262 |   await join(context)
  263 |   await mount(page)
  264 |   await page.evaluate(() => (window as unknown as PrivateWindow).authCoachingProbe.prepare())
  265 |   await page.evaluate(() => (window as unknown as PrivateWindow).authCoachingProbe.start())
  266 |   await expect.poll(() => state(page)).toMatchObject({ session: 'running', acquired: 3 })
  267 |   await page.route('**/api/v1/auth/logout', (route) =>
  268 |     route.fulfill({ status: 503, contentType: 'application/json', body: '{}' }),
  269 |   )
  270 |   await page.evaluate(() => (window as unknown as PrivateWindow).authCoachingProbe.signOut())
  271 |   await expect
  272 |     .poll(() => state(page))
  273 |     .toMatchObject({
  274 |       auth: 'logout-error',
  275 |       hook: 'idle',
  276 |       owned: false,
  277 |       disposed: 3,
  278 |       lifecycleClosed: 1,
  279 |     })
  280 |   await page.evaluate(() => (window as unknown as PrivateWindow).authCoachingProbe.save())
  281 |   expect(posts).toBe(0)
  282 |   expect((await (await context.request.get('/api/v1/records/stretch')).json()).items).toHaveLength(
  283 |     0,
  284 |   )
  285 |   await page.evaluate(() => (window as unknown as PrivateWindow).authCoachingProbe.unmount())
  286 | })
  287 | test('H04 pagehide during synthetic pending permission reclaims late resource; pageshow never starts', async ({
  288 |   page,
  289 |   context,
  290 | }) => {
  291 |   await join(context)
  292 |   await mount(page, true)
  293 |   await page.evaluate(() => (window as unknown as PrivateWindow).authCoachingProbe.prepare())
  294 |   await page.evaluate(() => (window as unknown as PrivateWindow).authCoachingProbe.start())
  295 |   await expect.poll(() => state(page)).toMatchObject({ waiting: true, session: 'preparing' })
  296 |   await page.evaluate(() => window.dispatchEvent(new PageTransitionEvent('pagehide')))
  297 |   await expect
  298 |     .poll(() => state(page))
  299 |     .toMatchObject({ hook: 'idle', owned: false, lifecycleClosed: 1 })
  300 |   await page.evaluate(() => (window as unknown as PrivateWindow).authCoachingProbe.release())
  301 |   expect(await state(page)).toMatchObject({ acquired: 1, disposed: 1, session: 'ended' })
  302 |   await page.evaluate(() =>
  303 |     window.dispatchEvent(new PageTransitionEvent('pageshow', { persisted: true })),
  304 |   )
  305 |   await expect
  306 |     .poll(() => state(page))
  307 |     .toMatchObject({ auth: 'ready', hook: 'idle', acquired: 1, disposed: 1, owned: false })
  308 |   await page.evaluate(() => (window as unknown as PrivateWindow).authCoachingProbe.save())
  309 |   expect(posts).toBe(0)
  310 |   await page.evaluate(() => (window as unknown as PrivateWindow).authCoachingProbe.unmount())
  311 | })
  312 | 
  313 | test('H05 actual logout succeeds but never permits old session resume or save', async ({
  314 |   page,
  315 |   context,
  316 | }) => {
  317 |   await join(context)
  318 |   await mount(page)
  319 |   await page.evaluate(() => (window as unknown as PrivateWindow).authCoachingProbe.prepare())
  320 |   await page.evaluate(() => (window as unknown as PrivateWindow).authCoachingProbe.start())
  321 |   await expect.poll(() => state(page)).toMatchObject({ session: 'running', acquired: 3 })
  322 |   await page.evaluate(() => (window as unknown as PrivateWindow).authCoachingProbe.signOut())
  323 |   await expect
  324 |     .poll(() => state(page))
  325 |     .toMatchObject({
  326 |       auth: 'guest',
  327 |       owned: false,
  328 |       disposed: 3,
  329 |       lifecycleClosed: 1,
  330 |     })
  331 |   expect((await context.request.get('/api/v1/me')).status()).toBe(401)
  332 |   await page.evaluate(() => (window as unknown as PrivateWindow).authCoachingProbe.resume())
  333 |   await page.evaluate(() => (window as unknown as PrivateWindow).authCoachingProbe.save())
  334 |   expect(posts).toBe(0)
  335 |   expect(await state(page)).toMatchObject({ acquired: 3, lifecycleClosed: 1 })
  336 |   await page.evaluate(() => (window as unknown as PrivateWindow).authCoachingProbe.unmount())
  337 | })
  338 | 
  339 | test('H05 actual server revoked account returns 401 and refresh retires the owned lifecycle', async ({
  340 |   page,
  341 |   context,
  342 | }) => {
  343 |   await join(context)
  344 |   await mount(page)
  345 |   await page.evaluate(() => (window as unknown as PrivateWindow).authCoachingProbe.prepare())
  346 |   await page.evaluate(() => (window as unknown as PrivateWindow).authCoachingProbe.start())
  347 |   await expect.poll(() => state(page)).toMatchObject({ session: 'running', acquired: 3 })
  348 |   const csrf = (await (await context.request.get('/api/v1/auth/csrf')).json()).csrf_token
  349 |   expect(
  350 |     (
  351 |       await context.request.post('/api/v1/auth/logout', {
```