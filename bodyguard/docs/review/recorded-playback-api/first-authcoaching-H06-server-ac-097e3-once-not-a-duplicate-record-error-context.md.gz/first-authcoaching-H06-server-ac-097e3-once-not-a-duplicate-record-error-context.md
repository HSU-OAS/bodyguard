# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: authcoaching.spec.ts >> H06 server accepted response loss retries the identical reported result once, not a duplicate record
- Location: e2e/authcoaching.spec.ts:163:1

# Error details

```
Error: expect(received).toMatchObject(expected)

- Expected  - 1
+ Received  + 1

  Object {
    "disposed": 3,
-   "lifecycleClosed": 1,
+   "lifecycleClosed": 0,
    "session": "ended",
  }
```

# Page snapshot

```yaml
- generic [ref=e3]:
  - button "본문으로 이동" [ref=e4]
  - banner [ref=e5]:
    - link "BODYGUARD 서비스 소개" [ref=e6] [cursor=pointer]:
      - /url: /
      - text: BODYGUARD.
    - navigation "계정 메뉴" [ref=e7]:
      - link "내 시작" [ref=e8] [cursor=pointer]:
        - /url: /start
      - link "자세 기록" [ref=e9] [cursor=pointer]:
        - /url: /posture-records
      - link "수행 기록" [ref=e10] [cursor=pointer]:
        - /url: /records
      - link "내 계정" [ref=e11] [cursor=pointer]:
        - /url: /account
  - main [ref=e12]:
    - generic [ref=e13]:
      - paragraph [ref=e14]: MY BODYGUARD
      - heading "내 몸을 위한 시작" [active] [level=1] [ref=e15]
      - paragraph [ref=e16]: auth-coach-1031fdfe-139f-4111-958c-f69f6b916f49@example.com
      - link "스트레칭 시작 경로 선택" [ref=e17] [cursor=pointer]:
        - /url: /explore
      - paragraph [ref=e18]:
        - link "내 수행 기록 확인" [ref=e19] [cursor=pointer]:
          - /url: /records
      - paragraph [ref=e20]:
        - link "내 자세 기록 확인" [ref=e21] [cursor=pointer]:
          - /url: /posture-records
      - paragraph [ref=e22]:
        - link "계정 관리" [ref=e23] [cursor=pointer]:
          - /url: /account
      - generic [ref=e24]:
        - heading "첫 코칭 흐름을 준비하고 있습니다" [level=2] [ref=e25]
        - paragraph [ref=e26]: 동작 검증과 남녀 3D 아바타 제작이 끝나면 스트레칭 선택과 코칭을 이곳에 연결합니다. 지금은 계정 기능을 사용할 수 있습니다.
        - paragraph [ref=e27]: 카메라는 켜지지 않았습니다.
      - button "로그아웃" [ref=e28] [cursor=pointer]
  - contentinfo [ref=e29]:
    - generic [ref=e30]: BODYGUARD
    - paragraph [ref=e31]: 일상을 위한 스트레칭과 자세 코칭 · 출시 준비 중
    - navigation "서비스 안내" [ref=e32]:
      - link "도움말" [ref=e33] [cursor=pointer]:
        - /url: /help
      - link "카메라·데이터 안내" [ref=e34] [cursor=pointer]:
        - /url: /data
```

# Test source

```ts
  73  |         data: { challenge_id: (await response.json()).challenge_id, code },
  74  |       })
  75  |     ).status(),
  76  |   ).toBe(201)
  77  | }
  78  | async function mount(page: Page, delayed = false) {
  79  |   await page.goto('/start')
  80  |   await expect(page.getByRole('heading', { name: '내 몸을 위한 시작', exact: true })).toBeVisible()
  81  |   const options = {
  82  |     recordId: randomUUID(),
  83  |     utc: new Date(Date.now() - 2000).toISOString(),
  84  |     delayed,
  85  |   }
  86  |   await page.evaluate(async (options) => {
  87  |     const path = '/__private-auth-coaching-probe.js'
  88  |     const module = (await import(path)) as { mountAuthCoachingProbe: typeof mountAuthCoachingProbe }
  89  |     ;(window as unknown as PrivateWindow).authCoachingProbe = module.mountAuthCoachingProbe(options)
  90  |   }, options)
  91  |   await expect
  92  |     .poll(() =>
  93  |       page.evaluate(() => (window as unknown as PrivateWindow).authCoachingProbe.state().auth),
  94  |     )
  95  |     .toBe('ready')
  96  |   return options
  97  | }
  98  | const state = (page: Page) =>
  99  |   page.evaluate(() => (window as unknown as PrivateWindow).authCoachingProbe.state())
  100 | test('H02 actual provider prepares inert; explicit synthetic performance saves to own public record', async ({
  101 |   page,
  102 |   context,
  103 | }, info) => {
  104 |   await join(context)
  105 |   const data = await mount(page)
  106 |   expect(await state(page)).toMatchObject({ hook: 'idle', acquired: 0, owned: false })
  107 |   await page.evaluate(() => (window as unknown as PrivateWindow).authCoachingProbe.prepare())
  108 |   expect(await state(page)).toMatchObject({ hook: 'prepared', acquired: 0, owned: true })
  109 |   expect(posts).toBe(0)
  110 |   await page.evaluate(() => (window as unknown as PrivateWindow).authCoachingProbe.start())
  111 |   await page.evaluate(() => (window as unknown as PrivateWindow).authCoachingProbe.perform())
  112 |   expect(await state(page)).toMatchObject({ session: 'ended', acquired: 3, disposed: 3 })
  113 |   expect(posts).toBe(0)
  114 |   await page.evaluate(() => (window as unknown as PrivateWindow).authCoachingProbe.save())
  115 |   expect(await state(page)).toMatchObject({ record: 'saved' })
  116 |   expect(posts).toBe(1)
  117 |   const rows = await (await context.request.get('/api/v1/records/stretch')).json()
  118 |   expect(rows.items).toHaveLength(1)
  119 |   expect(rows.items[0]).toMatchObject({
  120 |     id: data.recordId,
  121 |     outcome: 'completed',
  122 |     observed_ms: 100,
  123 |     repetitions: 0,
  124 |     provenance: 'client-reported',
  125 |   })
  126 |   expect(Date.parse(rows.items[0].started_at)).toBe(Date.parse(data.utc))
  127 |   expect(Date.parse(rows.items[0].ended_at)).toBe(Date.parse(data.utc) + 103)
  128 |   await page.evaluate(() => (window as unknown as PrivateWindow).authCoachingProbe.unmount())
  129 |   await expect.poll(() => state(page)).toMatchObject({ lifecycleClosed: 1 })
  130 |   await page.goto(`/records/${data.recordId}`)
  131 |   await expect(page.getByRole('heading', { name: '수행 기록 상세', exact: true })).toBeVisible()
  132 |   await page.screenshot({ path: info.outputPath('auth-coaching-record.png'), fullPage: true })
  133 | })
  134 | test('H03 actual same-account refresh revokes old running session; no automatic recreation', async ({
  135 |   page,
  136 |   context,
  137 | }) => {
  138 |   await join(context)
  139 |   await mount(page)
  140 |   await page.evaluate(() => (window as unknown as PrivateWindow).authCoachingProbe.prepare())
  141 |   await page.evaluate(() => (window as unknown as PrivateWindow).authCoachingProbe.start())
  142 |   await expect.poll(() => state(page)).toMatchObject({ session: 'running', acquired: 3 })
  143 |   await page.evaluate(() => (window as unknown as PrivateWindow).authCoachingProbe.refresh())
  144 |   await expect
  145 |     .poll(() => state(page))
  146 |     .toMatchObject({
  147 |       auth: 'ready',
  148 |       hook: 'idle',
  149 |       owned: false,
  150 |       session: 'ended',
  151 |       disposed: 3,
  152 |       lifecycleClosed: 1,
  153 |     })
  154 |   await page.evaluate(() => (window as unknown as PrivateWindow).authCoachingProbe.resume())
  155 |   await page.evaluate(() => (window as unknown as PrivateWindow).authCoachingProbe.save())
  156 |   expect(posts).toBe(0)
  157 |   expect((await (await context.request.get('/api/v1/records/stretch')).json()).items).toHaveLength(
  158 |     0,
  159 |   )
  160 |   await page.evaluate(() => (window as unknown as PrivateWindow).authCoachingProbe.unmount())
  161 | })
  162 | 
  163 | test('H06 server accepted response loss retries the identical reported result once, not a duplicate record', async ({
  164 |   page,
  165 |   context,
  166 |   browser,
  167 | }) => {
  168 |   await join(context)
  169 |   const data = await mount(page)
  170 |   await page.evaluate(() => (window as unknown as PrivateWindow).authCoachingProbe.prepare())
  171 |   await page.evaluate(() => (window as unknown as PrivateWindow).authCoachingProbe.start())
  172 |   await page.evaluate(() => (window as unknown as PrivateWindow).authCoachingProbe.perform())
> 173 |   expect(await state(page)).toMatchObject({ session: 'ended', disposed: 3, lifecycleClosed: 1 })
      |                             ^ Error: expect(received).toMatchObject(expected)
  174 |   expect(posts).toBe(0)
  175 |   const bodies: string[] = [],
  176 |     statuses: number[] = []
  177 |   await page.route('**/api/v1/records/stretch', async (route) => {
  178 |     if (route.request().method() !== 'POST') return route.continue()
  179 |     bodies.push(route.request().postData() ?? '')
  180 |     const response = await route.fetch()
  181 |     statuses.push(response.status())
  182 |     if (statuses.length === 1) await route.abort('failed')
  183 |     else await route.fulfill({ response })
  184 |   })
  185 |   await page.evaluate(() => (window as unknown as PrivateWindow).authCoachingProbe.save())
  186 |   expect(await state(page)).toMatchObject({ record: 'failed' })
  187 |   expect(posts).toBe(1)
  188 |   expect(statuses).toEqual([201])
  189 |   const dto = JSON.parse(bodies[0])
  190 |   expect(Object.keys(dto).sort()).toEqual(
  191 |     [
  192 |       'id',
  193 |       'motion_id',
  194 |       'protocol_version',
  195 |       'started_at',
  196 |       'ended_at',
  197 |       'outcome',
  198 |       'observed_ms',
  199 |       'repetitions',
  200 |     ].sort(),
  201 |   )
  202 |   expect(dto.id).toBe(data.recordId)
  203 |   const before = await (await context.request.get('/api/v1/records/stretch')).json()
  204 |   expect(before.items).toHaveLength(1)
  205 |   await page.evaluate(() => (window as unknown as PrivateWindow).authCoachingProbe.retry())
  206 |   expect(await state(page)).toMatchObject({ record: 'saved', acquired: 3, disposed: 3 })
  207 |   expect(posts).toBe(2)
  208 |   expect(statuses).toEqual([201, 200])
  209 |   expect(bodies).toHaveLength(2)
  210 |   expect(bodies[1]).toBe(bodies[0])
  211 |   const after = await (await context.request.get('/api/v1/records/stretch')).json()
  212 |   expect(after.items).toEqual(before.items)
  213 |   // Separate real account/cookies: local API auth is real, test mailbox is synthetic.
  214 |   const other = await browser.newContext({ baseURL: origin, serviceWorkers: 'block' })
  215 |   try {
  216 |     await join(other)
  217 |     expect((await other.request.get(`/api/v1/records/stretch/${data.recordId}`)).status()).toBe(404)
  218 |     expect((await (await other.request.get('/api/v1/records/stretch')).json()).items).toHaveLength(
  219 |       0,
  220 |     )
  221 |   } finally {
  222 |     await other.close()
  223 |   }
  224 |   await page.evaluate(() => (window as unknown as PrivateWindow).authCoachingProbe.unmount())
  225 |   await page.goto(`/records/${data.recordId}`)
  226 |   await expect(page.getByRole('heading', { name: '수행 기록 상세', exact: true })).toBeVisible()
  227 | })
  228 | 
  229 | test('H07 unannounced real cookie account replacement rejects the old proof instead of saving for another person', async ({
  230 |   page,
  231 |   context,
  232 | }) => {
  233 |   await join(context)
  234 |   await mount(page)
  235 |   await page.evaluate(() => (window as unknown as PrivateWindow).authCoachingProbe.prepare())
  236 |   await page.evaluate(() => (window as unknown as PrivateWindow).authCoachingProbe.start())
  237 |   await page.evaluate(() => (window as unknown as PrivateWindow).authCoachingProbe.perform())
  238 |   // Intentionally no AuthProvider refresh: captured CSRF proof must be the server backstop.
  239 |   await context.clearCookies()
  240 |   await join(context)
  241 |   let rejected = 0
  242 |   page.on('response', (response) => {
  243 |     if (
  244 |       response.url().endsWith('/api/v1/records/stretch') &&
  245 |       response.request().method() === 'POST' &&
  246 |       response.status() === 403
  247 |     )
  248 |       rejected++
  249 |   })
  250 |   await page.evaluate(() => (window as unknown as PrivateWindow).authCoachingProbe.save())
  251 |   expect(await state(page)).toMatchObject({ record: 'closed' })
  252 |   expect(posts).toBe(1)
  253 |   expect(rejected).toBe(1)
  254 |   expect((await (await context.request.get('/api/v1/records/stretch')).json()).items).toHaveLength(
  255 |     0,
  256 |   )
  257 |   await page.evaluate(() => (window as unknown as PrivateWindow).authCoachingProbe.retry())
  258 |   expect(posts).toBe(1)
  259 |   await page.evaluate(() => (window as unknown as PrivateWindow).authCoachingProbe.unmount())
  260 | })
  261 | test('H03 failed logout is not permission to keep coaching or save', async ({ page, context }) => {
  262 |   await join(context)
  263 |   await mount(page)
  264 |   await page.evaluate(() => (window as unknown as PrivateWindow).authCoachingProbe.prepare())
  265 |   await page.evaluate(() => (window as unknown as PrivateWindow).authCoachingProbe.start())
  266 |   await expect.poll(() => state(page)).toMatchObject({ session: 'running', acquired: 3 })
  267 |   await page.route('**/api/v1/auth/logout', (route) =>
  268 |     route.fulfill({ status: 503, contentType: 'application/json', body: '{}' }),
  269 |   )
  270 |   await page.evaluate(() => (window as unknown as PrivateWindow).authCoachingProbe.signOut())
  271 |   await expect
  272 |     .poll(() => state(page))
  273 |     .toMatchObject({
```