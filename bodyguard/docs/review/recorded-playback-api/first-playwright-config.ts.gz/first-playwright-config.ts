// FR-U-04/FR-R-03/NFR-08: preserve existing gates, isolate owned build/env/assets.
import { defineConfig } from '@playwright/test'
import config from './playwright.account.config'

export default defineConfig({
  ...config,
  testMatch: 'authcoaching.spec.ts',
  use: {
    ...config.use,
    serviceWorkers: 'block',
    channel: undefined,
    launchOptions: {
      executablePath:
        '/Users/gongman/.browser-driver-manager/chrome/mac_arm-154.0.8037.57/chrome-mac-arm64/Google Chrome for Testing.app/Contents/MacOS/Google Chrome for Testing',
    },
  },
  webServer: {
    ...config.webServer,
    command: 'node scripts/serve-recorded-api-proof.mjs',
  },
})
