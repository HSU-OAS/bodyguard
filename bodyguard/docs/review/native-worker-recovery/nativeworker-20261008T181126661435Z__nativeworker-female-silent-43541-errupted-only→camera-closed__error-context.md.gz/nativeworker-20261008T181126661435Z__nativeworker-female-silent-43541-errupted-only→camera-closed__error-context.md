# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: nativeworker.spec.ts >> female silent worker death while running→interrupted only→camera closed
- Location: e2e/nativeworker.spec.ts:233:3

# Error details

```
Error: page.evaluate: ResourceCleanupError: Resource cleanup failed
    at http://localhost:4173/__private-native-head-probe.js:61199:11
```

# Page snapshot

```yaml
- generic [ref=e1]:
  - generic [ref=e3]:
    - button "본문으로 이동" [ref=e4]
    - banner [ref=e5]:
      - link "BODYGUARD 서비스 소개" [ref=e6] [cursor=pointer]:
        - /url: /
        - text: BODYGUARD.
      - navigation "계정 메뉴" [ref=e7]:
        - link "내 시작" [ref=e8] [cursor=pointer]:
          - /url: /start
        - link "자세 기록" [ref=e9] [cursor=pointer]:
          - /url: /posture-records
        - link "수행 기록" [ref=e10] [cursor=pointer]:
          - /url: /records
        - link "내 계정" [ref=e11] [cursor=pointer]:
          - /url: /account
    - main [ref=e12]:
      - generic [ref=e13]:
        - paragraph [ref=e14]: MY BODYGUARD
        - heading "내 몸을 위한 시작" [active] [level=1] [ref=e15]
        - paragraph [ref=e16]: worker-a4ed4f52-751d-478b-b51a-daa26de52628@example.com
        - link "스트레칭 시작 경로 선택" [ref=e17] [cursor=pointer]:
          - /url: /explore
        - paragraph [ref=e18]:
          - link "내 수행 기록 확인" [ref=e19] [cursor=pointer]:
            - /url: /records
        - paragraph [ref=e20]:
          - link "내 자세 기록 확인" [ref=e21] [cursor=pointer]:
            - /url: /posture-records
        - paragraph [ref=e22]:
          - link "계정 관리" [ref=e23] [cursor=pointer]:
            - /url: /account
        - generic [ref=e24]:
          - heading "첫 코칭 흐름을 준비하고 있습니다" [level=2] [ref=e25]
          - paragraph [ref=e26]: 동작 검증과 남녀 3D 아바타 제작이 끝나면 스트레칭 선택과 코칭을 이곳에 연결합니다. 지금은 계정 기능을 사용할 수 있습니다.
          - paragraph [ref=e27]: 카메라는 켜지지 않았습니다.
        - button "로그아웃" [ref=e28] [cursor=pointer]
    - contentinfo [ref=e29]:
      - generic [ref=e30]: BODYGUARD
      - paragraph [ref=e31]: 일상을 위한 스트레칭과 자세 코칭 · 출시 준비 중
      - navigation "서비스 안내" [ref=e32]:
        - link "도움말" [ref=e33] [cursor=pointer]:
          - /url: /help
        - link "카메라·데이터 안내" [ref=e34] [cursor=pointer]:
          - /url: /data
  - paragraph [ref=e36]: 미완성 아바타 · 가짜 카메라 · Worker 내부 검증
```