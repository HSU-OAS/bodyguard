export default {
  root: "/Applications/학교 내부/2026-2학기/오픈소스 AI SW 융합 프로젝트/BODYGUARD-native-worker-recovery/bodyguard/frontend",
  publicDir: false,
  worker: { format: 'iife' },
  build: { outDir: "/private/tmp/bodyguard-worker-recovery.VIP1ge/probe", emptyOutDir: false, minify: false,
    lib: { entry: 'e2e/fixtures/workerPoseProbe.ts', formats: ['es'], fileName: () => 'probe.js' } },
}
