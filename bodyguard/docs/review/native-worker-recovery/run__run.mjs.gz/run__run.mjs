// Mechanical receipts, captures fixed command output; no body/video evidence.
import { spawnSync } from 'node:child_process'
import { readFileSync,writeFileSync,readdirSync } from 'node:fs'
import { createHash } from 'node:crypto'
import assert from 'node:assert/strict'
const work="/Applications/학교 내부/2026-2학기/오픈소스 AI SW 융합 프로젝트/BODYGUARD-native-worker-recovery", proof="/private/tmp/bodyguard-worker-recovery.VIP1ge", fe=work+'/bodyguard/frontend'
const action=process.argv[2],label=process.argv[3];assert(/^[a-z-]+$/.test(label))
const commands={
 focused:['pnpm',['exec','vitest','run','src/pose/workerInference.test.ts','--reporter=json','--outputFile='+proof+'/focused-'+label+'.json']],
 units:['pnpm',['exec','vitest','run','--maxWorkers','1','--reporter=json','--outputFile='+proof+'/units-'+label+'.json']],
 build:['pnpm',['build']],
 privatebuild:['pnpm',['exec','vite','build','--config',proof+'/vite.config.mjs']],
 types:['pnpm',['exec','tsc','--noEmit']],
 lint:['pnpm',['check']],
 guard:['node',['scripts/check-selection-production.mjs']],
 browser:['node',[proof+'/reproduce.mjs',label]],
}
const [command,args]=commands[action],at=new Date().toISOString()
const r=spawnSync(command,args,{cwd:fe,encoding:'utf8',maxBuffer:24*1024*1024})
const sha=b=>createHash('sha256').update(b).digest('hex')
for(const [kind,bytes] of [['stdout',r.stdout],['stderr',r.stderr]])writeFileSync(proof+'/'+action+'-'+label+'.'+kind+'.txt',bytes??'',{flag:'wx'})
const receipt={command,args,cwd:fe,startedAt:at,finishedAt:new Date().toISOString(),exit:r.status,signal:r.signal,error:r.error?.name??null,sourceSha:sha(readFileSync(fe+'/src/pose/workerInference.ts'))}
if(action==='build'&&r.status===0)receipt.assets=Object.fromEntries(readdirSync(fe+'/dist/assets').map(n=>[n,{bytes:readFileSync(fe+'/dist/assets/'+n).length,sha:sha(readFileSync(fe+'/dist/assets/'+n))}]))
writeFileSync(proof+'/'+action+'-'+label+'.receipt.json',JSON.stringify(receipt,null,2),{flag:'wx'})
console.log(JSON.stringify({...receipt,stdout:(r.stdout??'').slice(-2000),stderr:(r.stderr??'').slice(-2000)}))
process.exitCode=r.status??1
