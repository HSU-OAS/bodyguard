// Actual browser failure injection; fixed states/counts only, no raw body/video output.
import assert from 'node:assert/strict'
import { createServer } from 'node:http'
import { readFileSync, writeFileSync } from 'node:fs'
import { createHash } from 'node:crypto'
import { chromium } from "/Applications/학교 내부/2026-2학기/오픈소스 AI SW 융합 프로젝트/BODYGUARD-native-worker-recovery/bodyguard/frontend/node_modules/@playwright/test/index.mjs"
const proof="/private/tmp/bodyguard-worker-recovery.VIP1ge", work="/Applications/학교 내부/2026-2학기/오픈소스 AI SW 융합 프로젝트/BODYGUARD-native-worker-recovery", assets="/Applications/학교 내부/2026-2학기/오픈소스 AI SW 융합 프로젝트/BODYGUARD-native-worker-inference/bodyguard/frontend/public"
const label=process.argv[2];assert(/^[a-z-]+$/.test(label))
const sha=bytes=>createHash('sha256').update(bytes).digest('hex')
const sourcePaths=['src/pose/workerInference.ts','e2e/fixtures/workerPoseProbe.ts']
const sources=()=>Object.fromEntries(sourcePaths.map(p=>[p,sha(readFileSync(work+'/bodyguard/frontend/'+p))]))
const before=sources(), bundle=readFileSync(proof+'/probe/probe.js','utf8'), workerNames=[...new Set(bundle.match(/nativeInference\.worker-[\w-]+\.js/g)??[])]
assert.equal(workerNames.length,1)
const worker=readFileSync(proof+'/probe/assets/'+workerNames[0]), results=[]
let mode='prepare', external=0
const server=createServer((req,res)=>{
 const path=new URL(req.url,'http://localhost').pathname
 res.setHeader('Content-Security-Policy',"connect-src 'self'")
 if(path==='/'){res.setHeader('Content-Type','text/html');res.end('<html><script type="module">import{mountWorkerPoseProbe}from"/probe.js";window.probe=mountWorkerPoseProbe();window.done=false;window.outcome="pending";</script></html>');return}
 let bytes
 if(path==='/probe.js')bytes=bundle
 else if(path==='/assets/'+workerNames[0])bytes=mode==='prepare'?'self.close()':worker
 else if(/^\/mediapipe\/wasm\/vision_wasm_(?:module_|nosimd_)?internal\.(?:js|wasm)$/.test(path)||/^\/models\/(?:pose_landmarker_lite|face_landmarker|gesture_recognizer)\.task$/.test(path))bytes=readFileSync(assets+path)
 else {res.writeHead(404);res.end();return}
 res.setHeader('Content-Type',path.endsWith('.js')?'application/javascript':path.endsWith('.wasm')?'application/wasm':'application/octet-stream');res.end(bytes)
})
await new Promise(r=>server.listen(0,'127.0.0.1',r))
const origin='http://127.0.0.1:'+server.address().port
const browser=await chromium.launch({channel:'chrome',args:['--use-fake-device-for-media-stream','--use-fake-ui-for-media-stream']})
try{
 for(mode of ['prepare','inference']){
  const context=await browser.newContext({permissions:['camera'],serviceWorkers:'block'}),page=await context.newPage()
  let starts=0,closes=0,errors=0,actualWorker
  page.on('worker',value=>{actualWorker=value;starts++;value.on('close',()=>closes++)})
  page.on('pageerror',()=>errors++)
  await context.route('**/*',route=>{if(!route.request().url().startsWith(origin+'/')){external++;return route.abort()}return route.continue()})
  try{
   await page.goto(origin)
   await page.waitForFunction(()=>typeof window.probe==='object')
   await page.evaluate(()=>{void window.probe.begin()})
   if(mode==='inference'){
    await page.waitForFunction(()=>window.probe.snapshot().state==='running',null,{timeout:5000})
    await actualWorker.evaluate(()=>self.close())
    await page.waitForTimeout(50)
    await page.evaluate(()=>{void window.probe.read().then(()=>{window.done=true;window.outcome='resolved'},()=>{window.done=true;window.outcome='rejected'})})
   }
   await page.waitForTimeout(11000)
   const state=await page.evaluate(()=>({snapshot:window.probe.snapshot(),done:window.done,outcome:window.outcome}))
   const item={mode,...state,starts,closes,errors,observationMs:11000}
   results.push(item)
  }finally{await context.close()}
 }
}finally{
 await browser.close();await new Promise(r=>server.close(r))
 const after=sources();assert.deepEqual(before,after)
 const report={label,at:new Date().toISOString(),sourcesBefore:before,sourcesAfter:after,workerSha:sha(worker),results,external,actualPeople:0,physicalCameras:0,injection:true}
 writeFileSync(proof+'/reproduction-'+label+'.json',JSON.stringify(report,null,2),{flag:'wx'})
 console.log(JSON.stringify(report))
}
