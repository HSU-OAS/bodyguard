import { spawnSync } from 'node:child_process'
import { createHash } from 'node:crypto'
import { readFileSync, writeFileSync } from 'node:fs'
import { join } from 'node:path'
const [wd, bg, fe, out] = process.argv.slice(2)
const files = [
  'backend/app/main.py', 'backend/app/records.py', 'backend/tests/test_records_web_binding.py',
  'frontend/src/api/recordBinding.ts', 'frontend/src/api/recordBinding.test.ts',
  'frontend/src/api/records.ts', 'frontend/src/api/recordDeletion.ts',
  'frontend/src/api/generated/types.gen.ts', 'frontend/e2e/records.spec.ts',
  'frontend/src/pages/RecordsPage.tsx', 'frontend/src/pages/RecordsPage.test.tsx',
  'frontend/src/pages/RecordDeletion.tsx', 'frontend/src/pages/RecordDeletion.test.tsx',
]
const hash = data => createHash('sha256').update(data).digest('hex')
const snapshot = () => files.map(file => ({ file, sha256: hash(readFileSync(join(bg, file))) }))
const before = snapshot()
writeFileSync(join(out, 'source-before.json'), JSON.stringify(before, null, 2)+'\n')
const commands = [
  ['types', fe, 'pnpm', ['typecheck']],
  ['biome-final', fe, 'pnpm', ['check']],
  ['ruff', join(bg, 'backend'), '.venv/bin/ruff', ['check', '.']],
  ['ruff-format', join(bg, 'backend'), '.venv/bin/ruff', ['format', '--check', '.']],
  ['mypy', join(bg, 'backend'), '.venv/bin/mypy', ['app']],
  ['build', fe, 'pnpm', ['build']],
  ['production-guard-final', fe, 'node', ['scripts/check-selection-production.mjs']],
  ['diff-check', wd, 'git', ['diff', '--check']],
]
const results = []
for(const [name, cwd, command, args] of commands){
  const result = spawnSync(command, args, {cwd, encoding:'utf8', maxBuffer:20*1024*1024})
  writeFileSync(join(out,name+'.log'), (result.stdout??'')+(result.stderr??''))
  results.push({name, command:[command,...args],exitCode:result.status,error:result.error?.message??null})
  console.log(name,result.status)
}
const after = snapshot()
const sourcesUnchanged = JSON.stringify(before)===JSON.stringify(after)
writeFileSync(join(out,'quality.json'),JSON.stringify({results,sourcesUnchanged,sourceFiles:after},null,2)+'\n')
if(!sourcesUnchanged || results.some(r=>r.exitCode!==0))process.exitCode=1
