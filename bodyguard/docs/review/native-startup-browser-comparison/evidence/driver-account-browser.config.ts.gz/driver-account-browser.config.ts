import assert from 'node:assert/strict'
import { existsSync } from 'node:fs'
import config from '/Applications/학교 내부/2026-2학기/오픈소스 AI SW 융합 프로젝트/BODYGUARD-native-main-thread-contention/bodyguard/frontend/playwright.account.config'

const frontend = '/Applications/학교 내부/2026-2학기/오픈소스 AI SW 융합 프로젝트/BODYGUARD-native-main-thread-contention/bodyguard/frontend'
const executablePath = process.env.BODYGUARD_TEST_BROWSER_EXECUTABLE
assert(executablePath && existsSync(executablePath))
assert(config.webServer && !Array.isArray(config.webServer))
export default {
  ...config,
  testDir: frontend + '/e2e',
  use: {
    ...config.use,
    channel: undefined,
    launchOptions: { ...config.use?.launchOptions, executablePath },
  },
  webServer: { ...config.webServer, cwd: frontend },
}
