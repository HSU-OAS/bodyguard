import assert from 'node:assert/strict'
import { spawnSync } from 'node:child_process'
import { writeFileSync, existsSync } from 'node:fs'
const root='/Applications/학교 내부/2026-2학기/오픈소스 AI SW 융합 프로젝트/BODYGUARD-native-main-thread-contention'
const proof='/private/tmp/bodyguard-startup-browser-proof.iidajw',fe=root+'/bodyguard/frontend'
assert(!existsSync('/private/tmp/bodyguard-auth-test.oicSqH/data/postmaster.pid'),'Wait for current browser/SQL run to finish; do not contend with its startup measurement')
const steps=[
 ['original-contract','node',['bodyguard/docs/review/native-neck-full-regression/compare-original.mjs'],root],
 ['unit','node',['node_modules/vitest/vitest.mjs','run','--reporter=json','--outputFile='+proof+'/unit-final-results.json'],fe],
 ['types','node',['node_modules/typescript/bin/tsc','--noEmit'],fe],
 ['biome','node',['node_modules/@biomejs/biome/bin/biome','check','.'],fe],
 ['assets','node',['scripts/prepare-assets.mjs'],fe],
 ['build','node',['node_modules/vite/bin/vite.js','build'],fe],
 ['public-guard','node',['scripts/check-selection-production.mjs'],fe],
 ['diff','git',['diff','--check'],root],
]
let failed=false
for(const [label,cmd,args,cwd]of steps){const start=new Date().toISOString(),r=spawnSync(cmd,args,{cwd,encoding:'utf8',maxBuffer:64*1024*1024});for(const k of ['stdout','stderr'])writeFileSync(proof+'/check-final-'+label+'.'+k+'.txt',r[k]??'',{flag:'wx',mode:0o600});writeFileSync(proof+'/check-final-'+label+'.receipt.json',JSON.stringify({cmd,args,cwd,start,end:new Date().toISOString(),status:r.status,signal:r.signal},null,2)+'\n',{flag:'wx',mode:0o600});console.log(JSON.stringify({label,status:r.status}));failed ||= r.status!==0}
process.exitCode=failed?1:0
