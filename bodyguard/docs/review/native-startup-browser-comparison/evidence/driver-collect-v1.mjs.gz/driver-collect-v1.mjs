import assert from 'node:assert/strict'
import { readFileSync, writeFileSync, readdirSync, mkdirSync, existsSync } from 'node:fs'
import { execFileSync } from 'node:child_process'
import { createHash } from 'node:crypto'
import { gzipSync } from 'node:zlib'
const root='/Applications/학교 내부/2026-2학기/오픈소스 AI SW 융합 프로젝트/BODYGUARD-native-main-thread-contention'
const proof='/private/tmp/bodyguard-startup-browser-proof.iidajw',assets='/private/tmp/bodyguard-native-feedback-proof.3BFa9J'
const out=root+'/bodyguard/docs/review/native-startup-browser-comparison',sha=b=>createHash('sha256').update(b).digest('hex')
assert(!existsSync('/private/tmp/bodyguard-auth-test.oicSqH/data/postmaster.pid'))
assert(!existsSync(out+'/manifest.json'),'Never overwrite evidence')
mkdirSync(out+'/evidence',{recursive:true})
const files=[]
function save(name,path){assert(/^[a-zA-Z0-9_.-]+$/.test(name));const raw=readFileSync(path),compressed=gzipSync(raw);writeFileSync(out+'/evidence/'+name+'.gz',compressed,{flag:'wx'});files.push({file:'evidence/'+name+'.gz',original:path,bytes:raw.length,sha256:sha(raw),compressedBytes:compressed.length,compressedSha256:sha(compressed)});return raw}
const labels=['chrome154-male','chrome154-male-corrected','chrome154-female','chrome155-male','chrome155-female','chrome154-timed-male','chrome154-timed-female']
const reports=readdirSync(proof+'/test-results').map(d=>{const path=proof+'/test-results/'+d+'/report.json';return{d,path,report:JSON.parse(readFileSync(path))}})
const runs=[]
function cases(r){return [...(r.specs??[]).flatMap(s=>(s.tests??[]).map(t=>({title:s.title,status:t.status,results:t.results}))),...(r.suites??[]).flatMap(cases)]}
const stageNames=['camera','body-sdk','face-sdk','hands-sdk','avatar','render','body','face','hands','result']
for(const [index,label]of labels.entries()){
 const prefix=proof+'/'+label,receipt=JSON.parse(readFileSync(prefix+'-browser.receipt.json'))
 const found=reports.filter(r=>Date.parse(r.report.stats.startTime)>=Date.parse(receipt.start)&&Date.parse(r.report.stats.startTime)<=Date.parse(receipt.end))
 assert.equal(found.length,1,label);const{d,path,report}=found[0],rows=report.suites.flatMap(cases)
 const before=JSON.parse(readFileSync(prefix+'-source-before.json')),after=JSON.parse(readFileSync(prefix+'-source-after.json'));assert.deepEqual(before.sources,after.sources)
 const timed=label.includes('-timed-'),environmentFailure=label==='chrome154-male'
 if(!environmentFailure){assert.equal(rows.length,13);assert(rows.every(r=>r.results.length===1));assert.equal(report.stats.skipped,0);assert.equal(report.stats.flaky,0);assert.deepEqual(report.errors,[])}
 save('browser-'+index+'-report.json',path)
 for(const step of ['browser-version','db-start','identity','browser','db-stop'])for(const suffix of ['stdout.txt','stderr.txt','receipt.json'])save('run-'+index+'-'+step+'.'+suffix,prefix+'-'+step+'.'+suffix)
 for(const step of ['source-before','source-after'])save('run-'+index+'-'+step+'.json',prefix+'-'+step+'.json')
 const snapshots=[],browserVersions=new Set()
 if(!environmentFailure){
  const dir=root+'/bodyguard/frontend/test-results/'+d
  for(const caseDir of readdirSync(dir,{withFileTypes:true}).filter(e=>e.isDirectory()).map(e=>e.name).sort()){
   for(const kind of ['before-close.json','native-hands-summary.json','native-startup-timing.json']){
    const p=dir+'/'+caseDir+'/'+kind;if(!existsSync(p))continue
    const file='browser-'+index+'-snapshot-'+snapshots.length+'-'+kind
    const bytes=save(file,p),data=JSON.parse(bytes)
    snapshots.push({file:'evidence/'+file+'.gz',case:caseDir,kind})
    if(kind==='native-hands-summary.json'){
     browserVersions.add(data.browser);assert.equal(data.external,0);assert.deepEqual(data.errors,[]);assert.equal(data.actualHuman,false);assert.equal(data.actualCamera,false);assert.equal(data.productPolicyApproved,false)
     assert(data.final.tracksEnded&&data.final.detached&&data.final.allFramesClosed);assert.equal(data.final.models,0);assert.deepEqual(data.final.failures,[]);assert.equal(data.final.nativeCloses,data.final.nativeCalls)
     if(timed){
      const t=data.final.startupTiming;assert(t&&t.closed&&!t.invalid);assert(t.events.length>0&&t.events.length<=30)
      const counts=new Map();for(const e of t.events){assert.deepEqual(Object.keys(e).sort(),['endMs','stage','startMs']);assert(stageNames.includes(e.stage));assert(Number.isFinite(e.startMs)&&e.startMs>=0);assert(e.endMs===null||(Number.isFinite(e.endMs)&&e.endMs>=e.startMs));counts.set(e.stage,(counts.get(e.stage)??0)+1)}assert([...counts.values()].every(n=>n<=3))
     }
    }
   }
  }
  assert.equal(snapshots.filter(s=>s.kind==='native-hands-summary.json').length,13)
 }
 const failures=rows.filter(r=>r.status!=='expected').map(r=>({title:r.title,errors:r.results.flatMap(v=>v.errors??[]).map(e=>({message:e.message,location:e.location}))}))
 runs.push({label,report:'evidence/browser-'+index+'-report.json.gz',stats:report.stats,receiptStatus:receipt.status,environmentFailure,timed,browserVersions:[...browserVersions],titles:rows.map(r=>r.title).sort(),failures,snapshots})
}
assert.equal(runs[0].stats.expected,0);assert.equal(runs[0].receiptStatus,1)
assert.equal(runs[1].stats.unexpected,1);assert.equal(runs[1].failures[0].title,'male native neck captured aspect→presence→retirement→new generation');assert(runs[1].failures[0].errors[0].message.includes('Timeout 5000ms'))
for(const r of runs.slice(2)){assert.equal(r.stats.expected,13);assert.equal(r.stats.unexpected,0);assert.equal(r.receiptStatus,0)}
const contract=JSON.parse(readFileSync(proof+'/check-original-contract.stdout.txt'))
for(const group of [[runs[1],runs[2]],[runs[3],runs[4]],[runs[5],runs[6]]])assert.deepEqual(group.flatMap(r=>r.titles).sort(),contract.expandedCases)
for(const step of ['original-contract','unit','types','biome','assets','build','public-guard','diff'])for(const suffix of ['stdout.txt','stderr.txt','receipt.json'])save('check-'+step+'.'+suffix,proof+'/check-'+step+'.'+suffix)
save('unit-results.json',proof+'/unit-results.json')
for(const name of ['contract.md','account-browser.config.ts','bin/pnpm','compare-browser-v1.mjs','compare-browser-v2.mjs','compare-browser.mjs','setup.mjs','checks.mjs','collect.mjs'])save('driver-'+name.replaceAll('/','-'),proof+'/'+name)
for(const step of ['initdb','start','createdb','identity','stop'])for(const suffix of ['stdout.txt','stderr.txt','receipt.json'])save('setup-'+step+'.'+suffix,proof+'/setup-'+step+'.'+suffix)
const publicAssets=readdirSync(root+'/bodyguard/frontend/dist/assets').filter(p=>/\.(js|css)$/.test(p)).map(p=>{const b=readFileSync(root+'/bodyguard/frontend/dist/assets/'+p);return{name:p,bytes:b.length,sha256:sha(b)}})
const glb=['male.glb','female.glb','authored-fixture.json'].map(p=>{const b=readFileSync(assets+'/'+p);return{name:p,bytes:b.length,sha256:sha(b)}})
const source='bodyguard/frontend/e2e/nativehead.spec.ts',sourceBytes=readFileSync(root+'/'+source)
const manifest={base:'85885c4d1ed3bc019dea3112fe8beaa62d4fd88b',historical:'884700e3cebfce2b1c0c51fdca2cce4788e6dc4b',testedHead:execFileSync('git',['rev-parse','HEAD'],{cwd:root,encoding:'utf8'}).trim(),sources:[{path:source,sha256:sha(sourceBytes),bytes:sourceBytes.length}],files,runs,publicAssets,glb,originalContractBodiesGuardsBindingsUnchanged:contract.unchangedBodiesGuardsBindings,originalCases:contract.expandedCases,actualSDK:true,actualAPI:true,isolatedSQL:true,actualHuman:false,actualCamera:false,generatedInput:true,productPolicyApproved:false,allStagesComplete:false,startupFailureReproduced:true,startupRootCauseProven:false,startupP2Resolved:false,mergeEligible:false,dbStopped:true,untimed154:{passed:25,failed:1},untimed155:{passed:26,failed:0},timed154:{passed:26,failed:0}}
writeFileSync(out+'/manifest.json',JSON.stringify(manifest,null,2)+'\n',{flag:'wx'})
console.log(JSON.stringify({files:files.length,runs:runs.map(r=>({label:r.label,stats:r.stats})),startupP2Resolved:false,mergeEligible:false}))
