import assert from 'node:assert/strict'
import { spawnSync } from 'node:child_process'
import { existsSync, realpathSync, statSync, writeFileSync, chmodSync } from 'node:fs'
const proof='/private/tmp/bodyguard-startup-browser-proof.iidajw',db='/private/tmp/bodyguard-auth-test.oicSqH',bin='/opt/homebrew/opt/postgresql@18/bin/'
assert.equal(realpathSync(db),db);assert.equal(statSync(db).uid,process.getuid());assert(!existsSync(db+'/data'))
chmodSync(proof,0o700);chmodSync(db,0o700);chmodSync(proof+'/bin/pnpm',0o700)
function run(label,cmd,args){const start=new Date().toISOString(),r=spawnSync(cmd,args,{encoding:'utf8',maxBuffer:8*1024*1024});for(const k of ['stdout','stderr'])writeFileSync(proof+'/setup-'+label+'.'+k+'.txt',r[k]??'',{flag:'wx',mode:0o600});writeFileSync(proof+'/setup-'+label+'.receipt.json',JSON.stringify({cmd,args,start,end:new Date().toISOString(),status:r.status,signal:r.signal},null,2)+'\n',{flag:'wx',mode:0o600});console.log(JSON.stringify({step:label,status:r.status}));assert.equal(r.status,0)}
let started=false
try{
 run('initdb',bin+'initdb',['-D',db+'/data','-U','bodyguard_test','--auth=trust','--encoding=UTF8','--no-locale'])
 run('start',bin+'pg_ctl',['-D',db+'/data','-l',db+'/postgres.log','-o',"-k "+db+" -c listen_addresses='' -p 54329",'-w','start']);started=true
 run('createdb',bin+'createdb',['-h',db,'-p','54329','-U','bodyguard_test','-O','bodyguard_test','bodyguard_test'])
 run('identity',bin+'psql',['-h',db,'-p','54329','-U','bodyguard_test','-d','bodyguard_test','-At','-c',"SELECT current_database(),current_user,current_setting('server_version'),current_setting('listen_addresses');"])
}finally{if(started)run('stop',bin+'pg_ctl',['-D',db+'/data','-m','fast','-w','stop']);assert(!existsSync(db+'/data/postmaster.pid'));if(existsSync(db+'/postgres.log'))chmodSync(db+'/postgres.log',0o600)}
