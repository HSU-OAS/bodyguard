# Native startup browser comparison — read-only investigation

Base: origin/main 85885c4d1ed3bc019dea3112fe8beaa62d4fd88b, same tree as PR100.
Question: does the current restored 26-case contract still fail on the locally retained Chrome for Testing 154.0.8037.57 while passing on Chrome 155.0.8059.40?

The retained 154 executable is Chrome for Testing; the 155 executable is installed desktop Chrome. Only those two executables are present in the checked manager directory. Version and packaging are therefore confounded; a difference cannot be attributed solely to version. Neither fresh controlled run reproduces unknown historical host load/cache/timing conditions.

Run the current nativefeedback suite, BODYGUARD_TEST_NATIVE_NECK=1 for all cases, male and female in isolated sequential API/SQL partitions. Keep the original 5-second nativeCloses>=3 poll, 60-second cases, retry0, model, GLB, default main thread, unprepared renderer and authentication limits unchanged. Browser executable is the sole intended browser configuration difference. Fake camera/mail, generated positive input and synthetic phase/errors remain technical fixtures, not real participants or a clinical classifier.

Preserve fresh command receipts, report/probe artifacts and source-before/after hashes. Never overwrite old proof, record video/coordinates/body values, capture real camera pixels or export credentials. Test output may contain only the existing avatar-only/synthetic account screenshots.

If 154 fails: inspect exact failed assertion and timing before proposing a product fix. If both versions pass: this rejects a browser-version-only explanation in this current code/environment; it does not establish the original failure's cause or close startup P2. If startup/environment fails: record it separately, no test-pass claim. Do not enlarge timeouts, add retries, warm up successful observations before start or remove original cases to get green results.

No product/UI/SDK policy/sculpt/GLB/operating change, provider connection or deployment. Each database operation targets only the new owned /private/tmp/bodyguard-auth-test.oicSqH socket, local bodyguard_test database and role, no TCP listener. Do not touch .env, workflows, existing migrations or other harness state.
