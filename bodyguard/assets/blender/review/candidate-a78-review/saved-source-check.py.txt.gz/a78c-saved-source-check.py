"""FR-A-03/04: independent read-only saved-source preservation check."""

import json
import sys
from hashlib import file_digest
from pathlib import Path

import bpy


def digest(path):
    with path.open("rb") as file:
        return file_digest(file, "sha256").hexdigest()


def capture():
    result = {}
    for label in ("Male", "Female"):
        obj = bpy.data.objects[f"BODYGUARD {label} sculpt WIP"]
        rig = bpy.data.objects[f"BODYGUARD {label} rig WIP"]
        groups = [g.name for g in obj.vertex_groups]
        result[label] = {
            "points": [tuple(v.co) for v in obj.data.vertices],
            "skin": [tuple((groups[g.group], g.weight) for g in v.groups) for v in obj.data.vertices],
            "edges": [tuple(e.vertices) for e in obj.data.edges],
            "faces": [tuple(p.vertices) for p in obj.data.polygons],
            "hands": list(obj["bodyguard_distal_hand_vertices"]),
            "rings": {role: list(obj[f"bodyguard_authored_cervical_{role}_ring"]) for role in ("body", "head")},
            "bones": [(b.name, tuple(tuple(row) for row in b.matrix_local)) for b in rig.data.bones],
            "matrices": [tuple(tuple(row) for row in x.matrix_world) for x in (obj, rig)],
        }
    return result


source, target, report = map(Path, sys.argv[sys.argv.index("--") + 1:])
assert len({p.resolve() for p in (source, target, report)}) == 3
assert not report.exists()
assert digest(source) == "5f158d9ad9cbba42e6eaf143eed761d3eabdc3fc46c4f30b860799963999dcf3"
assert digest(target) == "a5666e1dc2efd7a698a9c737c00d7e961ae151fefa357ed7b5e1b27406b0583b"
bpy.ops.wm.open_mainfile(filepath=str(source))
old = capture()
bpy.ops.wm.open_mainfile(filepath=str(target))
new = capture()
checks = []
for label in ("Male", "Female"):
    a, b = old[label], new[label]
    assert len(a["points"]) == len(b["points"])
    for key in ("skin", "edges", "faces", "hands", "rings", "bones", "matrices"):
        assert a[key] == b[key], f"{label}/{key} changed"
    assert len(b["bones"]) == 163
    planes = [
        sum(a["points"][i][2] - 0.6 * a["points"][i][1] for i in a["rings"][role]) / len(a["rings"][role])
        for role in ("body", "head")
    ]
    outside = {i for i, p in enumerate(a["points"]) if not planes[0] - 0.03 < p[2] - 0.6 * p[1] < planes[1] + 0.03}
    assert set(a["hands"]) <= outside
    assert all(a["points"][i] == b["points"][i] for i in outside)
    changed = sum(p != q for p, q in zip(a["points"], b["points"], strict=True))
    assert changed > 0
    checks.append({
        "body": label, "vertices": len(b["points"]),
        "outside_tangent_band_exact": len(outside), "changed_band_vertices": changed,
        "named_skin_topology_hands_ring_ids_163_bones_rest_matrices_exact": True,
        "appearance_anatomy_coaching_not_verified_by_this_check": True,
    })
report.write_text(json.dumps({"passed": True, "source_saved": False, "checks": checks}, indent=2) + "\n")
print("ACTUAL SAVED SOURCE COMPARISON", json.dumps(checks))

